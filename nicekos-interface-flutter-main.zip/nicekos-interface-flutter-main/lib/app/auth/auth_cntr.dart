import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:get/get.dart';
import '../../repo/api/secure_storge.dart';
import '../../repo/data/login_data.dart';
import '../../repo/response/res_data.dart';

class AuthBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AuthCntr>(
      () => AuthCntr(),
    );
  }
}

class AuthCntr extends GetxController with SecureStorage {
  static AuthCntr get to => Get.find();

  Rx<LoginRes> resLoginData = LoginRes().obs;
  RxBool isLogged = false.obs;
  //로그인 방식
  RxString authMethod = "".obs;
  //로그인 방식
  RxString membNo = "".obs;

  @override
  void onInit() async {
    super.onInit();
    loginCheck();
  }

  @override
  void dispose() {
    super.dispose();
  }


  //스토리지에서 membNo 존재 여부 판단
  //  -> 온보딩 화면으로 이동 - 회원가입 화면
  //  -> 로그인 화면 이동
  void loginCheck() async {

    isLogged.value = true;
    Get.toNamed("/login");

    //await Future.delayed(const Duration(milliseconds: 10), () => Get.toNamed("/login"));
    return;
  }
}
