import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../repo/data/cntr_detail_data.dart';
import '../../repo/data/search_payment_list_data.dart';
import '../../repo/data/trns_hist_data.dart';
import '../../theme/colors.dart';
import '../../theme/spacing.dart';
import '../../theme/text_style.dart';
import '../../utils/if_format.dart';
import '../../utils/if_utils.dart';
import '../../widget/If_button.dart';
import '../../widget/if_divider.dart';
import 'cntr_info_chng_page.dart';

class PayListPage extends StatefulWidget {
  final dynamic controller;

  final TextEditingController searchTextCtrl;

  const PayListPage({
    super.key,
    required this.controller,
    required this.searchTextCtrl,
  });

  @override
  State<PayListPage> createState() => _PayListPageState();
}

class _PayListPageState extends State<PayListPage>
    with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: SizedBox(
        width: Get.width * 0.1,
        height: Get.height * 0.8,
        child: SingleChildScrollView(
            child: Column(
          children: [
            IfUtils.commonStreamBody(widget.controller.cntrDtlResStream,
                buildLoanBody, widget.controller.fetchData),
            Spacing.height(80),
            IfUtils.commonStreamList2(widget.controller.paymentResStream,
                buildPaymentListBody, widget.controller.fetchData),
            Spacing.height(80),
            IfUtils.commonStreamList2(widget.controller.trnsHistResListStream,
                buildPayBody, widget.controller.fetchData),
          ],
        )),
      ),
    );
  }

  Column buildPaymentListBody(List<PaymentListResData> list) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Spacing.height(10),
        IfUtils.buildCategory('지급 정보 리스트'),
        Spacing.height(20),
        IfDivider(width: 0.45),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal, // 가로 스크롤 활성화
          child: DataTable(
              columnSpacing: Get.width * 0.015,
              columns: [
                DataColumn(
                  label: SelectableText(
                    '번호',
                    style: TextSyle.dataTable().copyWith(
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
                DataColumn(
                  label: MouseRegion(
                    cursor: SystemMouseCursors.text, // 마우스 커서 변경
                    child: SelectableText(
                      '지급구분(코드)',
                      style: TextSyle.dataTable().copyWith(
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ),
                ),
                DataColumn(
                  label: MouseRegion(
                    cursor: SystemMouseCursors.text, // 마우스 커서 변경
                    child: SelectableText(
                      '지급금액',
                      style: TextSyle.dataTable().copyWith(
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ),
                ),
                DataColumn(
                  label: MouseRegion(
                    cursor: SystemMouseCursors.text, // 마우스 커서 변경
                    child: SelectableText(
                      '은행명(코드)',
                      style: TextSyle.dataTable().copyWith(
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ),
                ),
                DataColumn(
                  label: MouseRegion(
                    cursor: SystemMouseCursors.text, // 마우스 커서 변경
                    child: SelectableText(
                      '상태(코드)',
                      style: TextSyle.dataTable().copyWith(
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ),
                ),
              ],
              rows: list.map((data) {
                return DataRow(
                  cells: [
                    DataCell(
                      MouseRegion(
                        cursor: SystemMouseCursors.text, // 마우스 커서 변경
                        child: SelectableText(
                          data.no?.toString() ?? '', // 번호
                          style: TextSyle.text(),
                        ),
                      ),
                    ),
                    DataCell(
                      MouseRegion(
                        cursor: SystemMouseCursors.text, // 마우스 커서 변경
                        child: SelectableText(
                          '${data.payNm ?? ''}(${data.payCd ?? ''})', // 지급구분
                          style: TextSyle.text(),
                        ),
                      ),
                    ),
                    DataCell(
                      MouseRegion(
                        cursor: SystemMouseCursors.text, // 마우스 커서 변경
                        child: SelectableText(
                              IfFormat.getStrNumerFormat(data.payAmt),
                          style: TextSyle.text(),
                        ),
                      ),
                    ),
                    DataCell(
                      MouseRegion(
                        cursor: SystemMouseCursors.text, // 마우스 커서 변경
                        child: SelectableText(
                          '${data.bankNm ?? ''}(${data.bankCd ?? ''})',
                          // 은행명(코드)
                          style: TextSyle.text(),
                        ),
                      ),
                    ),
                    DataCell(
                      MouseRegion(
                        cursor: SystemMouseCursors.text, // 마우스 커서 변경
                        child: SelectableText(
                          '${data.statNm ?? ''}(${data.statCd ?? ''})', //상태(코드)

                          style: TextSyle.text(),
                        ),
                      ),
                    ),
                  ],
                );
              }).toList()),
        ),
        list.isEmpty
            ? Column(
                children: [
                  const Gap(20),
                  Container(
                      alignment: Alignment.center,
                      child: Text(
                        '지급 정보 리스트가 존재하지 않습니다.',
                        style: TextSyle.text(),
                      )),
                  const Gap(125),
                ],
              )
            : const SizedBox.shrink()
      ],
    );
  }

  Column buildPayBody(List<TrnsHistResData> list) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Spacing.height(10),
        IfUtils.buildCategory('전문 발송 내역 리스트'),
        Spacing.height(20),
        IfDivider(width: 0.45),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal, // 가로 스크롤 활성화
          child: DataTable(
              columnSpacing: Get.width * 0.015,
              columns: [
                DataColumn(
                  label: SelectableText(
                    '번호',
                    style: TextSyle.dataTable().copyWith(
                      decoration: TextDecoration.none,
                    ),
                  ),
                ),
                DataColumn(
                  label: MouseRegion(
                    cursor: SystemMouseCursors.text, // 마우스 커서 변경
                    child: SelectableText(
                      '전문 명',
                      style: TextSyle.dataTable().copyWith(
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ),
                ),
                DataColumn(
                  label: MouseRegion(
                    cursor: SystemMouseCursors.text, // 마우스 커서 변경
                    child: SelectableText(
                      '응답 코드',
                      style: TextSyle.dataTable().copyWith(
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ),
                ),
                DataColumn(
                  label: MouseRegion(
                    cursor: SystemMouseCursors.text, // 마우스 커서 변경
                    child: SelectableText(
                      '응답 여부',
                      style: TextSyle.dataTable().copyWith(
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ),
                ),
                DataColumn(
                  label: MouseRegion(
                    cursor: SystemMouseCursors.text, // 마우스 커서 변경
                    child: SelectableText(
                      '요청 일시',
                      style: TextSyle.dataTable().copyWith(
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ),
                ),
              ],
              rows: list.map((data) {
                return DataRow(
                  cells: [
                    DataCell(
                      MouseRegion(
                        cursor: SystemMouseCursors.text, // 마우스 커서 변경
                        child: SelectableText(
                          data.seq?.toString() ?? '', // 번호
                          style: TextSyle.text(),
                        ),
                      ),
                    ),
                    DataCell(
                      MouseRegion(
                        cursor: SystemMouseCursors.text, // 마우스 커서 변경
                        child: SelectableText(
                          '[${data.trnKnd ?? ''}] ${data.trnName ?? ''}',
                          // 지급구분
                          style: TextSyle.text(),
                        ),
                      ),
                    ),
                    DataCell(
                      MouseRegion(
                        cursor: SystemMouseCursors.text, // 마우스 커서 변경
                        child: SelectableText(
                          data.resCd ?? '', // 지급금액
                          style: TextSyle.text(),
                        ),
                      ),
                    ),
                    DataCell(
                      MouseRegion(
                        cursor: SystemMouseCursors.text, // 마우스 커서 변경
                        child: SelectableText(
                          data.resYn ?? '', // 은행명(코드)
                          style: TextSyle.text(),
                        ),
                      ),
                    ),
                    DataCell(
                      MouseRegion(
                        cursor: SystemMouseCursors.text, // 마우스 커서 변경
                        child: SelectableText(
                          (data.reqDttm ?? '').replaceAll('T', ' '),
                          // "T" → " " 변환
                          style: TextSyle.text(),
                        ),
                      ),
                    ),
                  ],
                );
              }).toList()),
        ),
        list.isEmpty
            ? Column(
                children: [
                  const Gap(20),
                  Container(
                      alignment: Alignment.center,
                      child: Text(
                        '지급 정보 리스트가 존재하지 않습니다.',
                        style: TextSyle.text(),
                      )),
                  const Gap(125),
                ],
              )
            : const SizedBox.shrink()
      ],
    );
  }

  Widget buildCategory(String text) {
    return Container(
      alignment: Alignment.centerLeft,
      child: Text(
        text,
        style: const TextStyle(
          color: white,
          fontSize: 14,
          fontFamily: 'Noto Sans KR',
          fontWeight: FontWeight.w500,
          height: 0.10,
        ),
      ),
    );
  }

  Widget buildLoanBody(CntrDetailResData cntrDtl) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Spacing.height(10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            IfUtils.buildCategory('상품 정보'),
            Row(
              children: [
                IfButton(
                  elevation: 0,
                  padding: Spacing.xy(40, 20),
                  backgroundColor: canvasColor,
                  borderRadiusAll: 5,
                  onPressed: () async {
                    String? res = await showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return CntrInfoChngPage(cntrDtl);
                        });
                    await widget.controller
                        .getCntrDtl(widget.searchTextCtrl.text);
                  },
                  child: Text('수정', style: TextSyle.searchFormText()),
                ),
                Spacing.width(5),
              ],
            ),
          ],
        ),
        Spacing.height(10),
        IfDivider(width: 0.45),
        Spacing.height(20),
        Row(
          children: [
            buildShortRow('여신 번호', cntrDtl.loanNo ?? ''),
            buildShortRow('사업자 번호',
              IfFormat.getStrBizNoFormat(cntrDtl.bizNo ?? '')),
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow('보험 구분 코드', cntrDtl.isrnGbCd ?? ''),
            buildShortRow('은행 지점명', cntrDtl.bnkBrnchNm ?? ''),
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow('은행 담당자명', cntrDtl.dbtrNm ?? ''),
            buildShortRow('은행지점 전화번호',
                IfFormat.getStrPhnNumFormat(cntrDtl.bnkBrnchPhno ?? ''))
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow('대출 종류 코드', cntrDtl.lndKndCd ?? ''),
            buildShortRow('상태 코드', cntrDtl.statCd ?? '')
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow('대출 구분(KND_CD)', cntrDtl.kndCd ?? ''),
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildLongRow('대출 상품명', cntrDtl.lndPrdtNm ?? ''),
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow('지점명', cntrDtl.bnkBrnchNm ?? ''),
            buildShortRow('지점 전화번호',
                IfFormat.getStrPhnNumFormat(cntrDtl.bnkBrnchPhno ?? ''))
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildLongRow('대출 물건지 주소', cntrDtl.lndThngAddr ?? ''),
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildLongRow('대출 이동 구분 코드', cntrDtl.lwyrDiffBankCd8 ?? ''),
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildLongRow('선기표 말소 구분 코드', cntrDtl.lwyrDiffBankCd10 ?? ''),
          ],
        ),
        Spacing.height(40),
        IfUtils.buildCategory('차주 정보'),
        Spacing.height(20),
        IfDivider(width: 0.45),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow('차주명', cntrDtl.dbtrNm ?? ''),
            buildShortRow(
                '차주 전화번호', IfFormat.getStrPhnNumFormat(cntrDtl.dbtrHpno ?? '')),
          ],
        ),
        Spacing.height(10),
        Row(
          children: [buildLongRow('차주 주소', cntrDtl.dbtrAddr ?? '')],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow('담보 제공자명', cntrDtl.pwpsNm ?? ''),
            buildShortRow('담보 제공자 전화번호',
                IfFormat.getStrPhnNumFormat(cntrDtl.pwpsHpno ?? '')),
          ],
        ),
        Spacing.height(40),
        IfUtils.buildCategory('대출 정보'),
        Spacing.height(20),
        IfDivider(width: 0.45),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow('실행 예정 금액',
                IfFormat.getStrNumerFormat(cntrDtl.execPlnAmt ?? '')),
            buildShortRow(
                '실행 예정 일자', IfFormat.getDateFormat(cntrDtl.execPlnDt ?? '-')),
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow(
                '실행 금액', IfFormat.getStrNumerFormat(cntrDtl.execAmt ?? '')),
            buildShortRow(
                '실행 일자', IfFormat.getDateFormat(cntrDtl.execDt ?? '-')),
          ],
        ),
        Spacing.height(40),
        IfUtils.buildCategory('기타 정보'),
        Spacing.height(20),
        IfDivider(width: 0.45),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow('전자 등기+자담 여부', cntrDtl.eltnSecuredYn ?? '-'),
            buildShortRow('실행 금액 변경 여부', cntrDtl.execAmtChangYn ?? '-')
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow('견적서 등록 여부', cntrDtl.estmRegYn ?? '-'),
            buildShortRow('견적서 확정 여부', cntrDtl.estmCnfmYn ?? '-')
          ],
        ),
        Spacing.height(10),
        Row(
          children: [
            buildShortRow('지급 정보 등록 여부', cntrDtl.payRegYn ?? '-'),
            buildShortRow('등기 정보 등록 여부', cntrDtl.rgstrRegYn ?? '-')
          ],
        ),
      ],
    );
  }

  Widget buildShortRow(String name, String data) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: Get.width * 0.09,
          child: Text(
            name,
            style: TextSyle.text(),
          ),
        ),
        SizedBox(
          width: Get.width * 0.1,
          child: Text(
            data,
            style: TextSyle.text(),
          ),
        ),
      ],
    );
  }

  Widget buildLongRow(String name, String data) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: Get.width * 0.09,
          child: Text(
            name,
            style: TextSyle.text(),
          ),
        ),
        SizedBox(
          width: Get.width * 0.3,
          child: Text(
            data,
            style: TextSyle.text(),
          ),
        ),
      ],
    );
  }
}
