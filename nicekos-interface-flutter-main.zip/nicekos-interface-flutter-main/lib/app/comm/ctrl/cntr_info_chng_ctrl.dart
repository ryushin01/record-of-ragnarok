import 'dart:async';

import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/bindings_interface.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:nicekos_interface_flutter/repo/data/cntr_info_chng_data.dart';

import '../../../repo/cntr_detail_repo.dart';
import '../../../repo/response/res_data.dart';
import '../../../repo/response/res_stream.dart';
import '../../../utils/log_utils.dart';

class CntrInfoChngBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<CntrInfoChngCtrl>(
          () => CntrInfoChngCtrl(),
    );
  }
}

class CntrInfoChngCtrl extends GetxController {

  static CntrInfoChngCtrl get to => Get.find();

  StreamController<ResStream<CntrChngResData>> cntrChngResStream =
  StreamController<ResStream<CntrChngResData>>();

  Future<ResData> setCntrInfoChng(CntrChngReqData reqData) async {
    try {
      cntrChngResStream.sink.add(ResStream.loading());
      CntrDetailRepo cntrDetailRepo = CntrDetailRepo();
      ResData resData = await cntrDetailRepo.modifyCntrInfo(reqData);
      Lo.g("resData ctrl : ${resData}");
      if (resData.code != '00') {
        cntrChngResStream.sink.add(ResStream.error(resData.msg.toString()));
        return resData;
      }
      CntrChngResData cntrChngResData = CntrChngResData.fromMap(resData.data);
      cntrChngResStream.sink.add(ResStream.completed(cntrChngResData));
      return resData;
    } catch (e) {
      Lo.g(e);
      cntrChngResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }
}