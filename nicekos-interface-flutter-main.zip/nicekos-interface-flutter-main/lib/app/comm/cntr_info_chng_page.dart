import 'dart:html';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/app/comm/ctrl/cntr_info_chng_ctrl.dart';
import 'package:nicekos_interface_flutter/repo/data/cntr_info_chng_data.dart';
import 'package:nicekos_interface_flutter/theme/text_style.dart';

import '../../repo/data/cntr_detail_data.dart';
import '../../repo/response/res_data.dart';
import '../../theme/colors.dart';
import '../../theme/spacing.dart';
import '../../utils/if_utils.dart';
import '../../widget/If_button.dart';
import '../../widget/if_text_form_field.dart';

class CntrInfoChngPage extends StatefulWidget {
  final CntrDetailResData data;

  const CntrInfoChngPage(this.data, {super.key});

  @override
  State<CntrInfoChngPage> createState() => _CntrInfoChngPageState();
}

class _CntrInfoChngPageState extends State<CntrInfoChngPage> with
    TickerProviderStateMixin {

  late CntrInfoChngCtrl chngCtrl;
  TextEditingController _kndCdTextCtrl = TextEditingController();
  TextEditingController _lndKndCdTextCtrl = TextEditingController();
  TextEditingController _rgstrGbCdTextCtrl = TextEditingController();
  TextEditingController _statCdTextCtrl = TextEditingController();
  TextEditingController _lndStatCdTextCtrl = TextEditingController();
  TextEditingController _execPlnAmtTextCtrl = TextEditingController();
  TextEditingController _execPlnDtTextCtrl = TextEditingController();
  TextEditingController _execAmtTextCtrl = TextEditingController();
  TextEditingController _execDtTextCtrl = TextEditingController();
  TextEditingController _slPrcTextCtrl = TextEditingController();
  TextEditingController _bnkBrnchCdTextCtrl = TextEditingController();
  TextEditingController _bizNoTextCtrl = TextEditingController();
  TextEditingController _trnInCntTextCtrl = TextEditingController();
  TextEditingController _refndAcctRegYnTextCtrl = TextEditingController();
  TextEditingController _refndAcctRegDateTextCtrl = TextEditingController();
  TextEditingController _eltnSecuredYnTextCtrl = TextEditingController();
  TextEditingController _execAmtChangYnTextCtrl = TextEditingController();
  TextEditingController _estmRegYnTextCtrl = TextEditingController();
  TextEditingController _estmCnfmYnTextCtrl = TextEditingController();
  TextEditingController _rgstrRegYnTextCtrl = TextEditingController();
  TextEditingController _payRegYnTextCtrl = TextEditingController();
  TextEditingController _lndAmtPayYnTextCtrl = TextEditingController();
  TextEditingController _revisionCheckYnTextCtrl = TextEditingController();
  TextEditingController _estbsCntrFnYnTextCtrl = TextEditingController();
  TextEditingController _slCntrctEaneTextCtrl = TextEditingController();
  TextEditingController _slCntrctFlnmTextCtrl = TextEditingController();
  TextEditingController _mvhhdSbmtYnTextCtrl = TextEditingController();
  TextEditingController _rrcpCnfmReqYnTextCtrl = TextEditingController();
  TextEditingController _rtalSbmtYnTextCtrl = TextEditingController();
  TextEditingController _cndtCntrYnTextCtrl = TextEditingController();
  TextEditingController _lwyrDiffBankCd8TextCtrl = TextEditingController();
  TextEditingController _lwyrDiffBankCd10TextCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (Get.isRegistered<CntrInfoChngCtrl>()) {
      Get.delete<CntrInfoChngCtrl>();
    }
    chngCtrl = Get.put(CntrInfoChngCtrl());
    _kndCdTextCtrl.text = widget.data.kndCd ?? '';
    _lndKndCdTextCtrl.text = widget.data.lndKndCd ?? '';
    _rgstrGbCdTextCtrl.text = widget.data.rgstrGbCd ?? '';
    _statCdTextCtrl.text = widget.data.statCd ?? '';
    _lndStatCdTextCtrl.text = widget.data.lndStatCd ?? '';
    _execPlnAmtTextCtrl.text = widget.data.execPlnAmt.toString();
    _execPlnDtTextCtrl.text = widget.data.execPlnDt ?? '';
    _execAmtTextCtrl.text = widget.data.execAmt.toString();
    _execDtTextCtrl.text = widget.data.execDt ?? '';
    _slPrcTextCtrl.text = widget.data.slPrc.toString();
    _bnkBrnchCdTextCtrl.text = widget.data.bnkBrnchCd ?? '';
    _bizNoTextCtrl.text = widget.data.bizNo ?? '';
    _trnInCntTextCtrl.text = widget.data.trnInCnt.toString();
    _refndAcctRegYnTextCtrl.text = widget.data.refndAcctRegYn ?? '';
    _refndAcctRegDateTextCtrl.text = widget.data.refndAcctRegDate ?? '';
    _eltnSecuredYnTextCtrl.text = widget.data.eltnSecuredYn ?? '';
    _execAmtChangYnTextCtrl.text = widget.data.execAmtChangYn ?? '';
    _estmRegYnTextCtrl.text = widget.data.estmRegYn ?? '';
    _estmCnfmYnTextCtrl.text = widget.data.estmCnfmYn ?? '';
    _rgstrRegYnTextCtrl.text = widget.data.rgstrRegYn ?? '';
    _payRegYnTextCtrl.text = widget.data.payRegYn ?? '';
    _lndAmtPayYnTextCtrl.text = widget.data.lndAmtPayYn ?? '';
    _revisionCheckYnTextCtrl.text = widget.data.revisionCheckYn ?? '';
    _estbsCntrFnYnTextCtrl.text = widget.data.estbsCntrFnYn ?? '';
    _slCntrctEaneTextCtrl.text = widget.data.slCntrctEane ?? '';
    _slCntrctFlnmTextCtrl.text = widget.data.slCntrctFlnm ?? '';
    _mvhhdSbmtYnTextCtrl.text = widget.data.mvhhdSbmtYn ?? '';
    _rrcpCnfmReqYnTextCtrl.text = widget.data.rrcpCnfmReqYn ?? '';
    _rtalSbmtYnTextCtrl.text= widget.data.rtalSbmtYn ?? '';
    _cndtCntrYnTextCtrl.text = widget.data.cndtCntrYn ?? '';
    _lwyrDiffBankCd8TextCtrl.text = widget.data.lwyrDiffBankCd8 ?? '';
    _lwyrDiffBankCd10TextCtrl.text = widget.data.lwyrDiffBankCd10 ?? '';
  }

  @override
  void dispose() {
    super.dispose();
    _kndCdTextCtrl = TextEditingController();
    _lndKndCdTextCtrl = TextEditingController();
    _rgstrGbCdTextCtrl = TextEditingController();
    _statCdTextCtrl = TextEditingController();
    _lndStatCdTextCtrl = TextEditingController();
    _execPlnAmtTextCtrl = TextEditingController();
    _execPlnDtTextCtrl = TextEditingController();
    _execAmtTextCtrl = TextEditingController();
    _execDtTextCtrl = TextEditingController();
    _slPrcTextCtrl = TextEditingController();
    _bnkBrnchCdTextCtrl = TextEditingController();
    _bizNoTextCtrl = TextEditingController();
    _trnInCntTextCtrl = TextEditingController();
    _refndAcctRegYnTextCtrl = TextEditingController();
    _refndAcctRegDateTextCtrl = TextEditingController();
    _eltnSecuredYnTextCtrl = TextEditingController();
    _execAmtChangYnTextCtrl = TextEditingController();
    _estmRegYnTextCtrl = TextEditingController();
    _estmCnfmYnTextCtrl = TextEditingController();
    _slCntrctEaneTextCtrl = TextEditingController();
    _slCntrctFlnmTextCtrl = TextEditingController();
    _rgstrRegYnTextCtrl = TextEditingController();
    _payRegYnTextCtrl = TextEditingController();
    _lndAmtPayYnTextCtrl = TextEditingController();
    _revisionCheckYnTextCtrl = TextEditingController();
    _estbsCntrFnYnTextCtrl = TextEditingController();
    _mvhhdSbmtYnTextCtrl = TextEditingController();
    _rrcpCnfmReqYnTextCtrl = TextEditingController();
    _rtalSbmtYnTextCtrl = TextEditingController();
    _cndtCntrYnTextCtrl = TextEditingController();
    _lwyrDiffBankCd8TextCtrl = TextEditingController();
    _lwyrDiffBankCd10TextCtrl = TextEditingController();
  }

  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10)
      ),
      backgroundColor: scaffoldBackgroundColor,
      child: Container(
        alignment: Alignment.center,
        width: Get.width * 0.28,
        height: Get.height * 1.0,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text('대출원장 수정',
              style: TextSyle.title(),),
            ),
            Container(
              margin: const EdgeInsets.only(left: 10, right: 10),
              color: canvasColor,
              child: Container(
                margin: const EdgeInsets.all(10),
                width: Get.width * 0.25,
                height: Get.height * 0.75,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      buildTextField('대출구분코드(KND_CD)', _kndCdTextCtrl),
                      Spacing.height(10),
                      buildTextField('대출 이동 구분 코드', _lwyrDiffBankCd8TextCtrl),
                      Spacing.height(10),
                      buildTextField('선기표 말소 구분 코드', _lwyrDiffBankCd10TextCtrl),
                      Spacing.height(10),
                      buildTextField('대출종류코드', _lndKndCdTextCtrl),
                      Spacing.height(10),
                      buildTextField('등기구분', _rgstrGbCdTextCtrl),
                      Spacing.height(10),
                      buildTextField('상태코드', _statCdTextCtrl),
                      Spacing.height(10),
                      buildTextField('대출상태', _lndStatCdTextCtrl),
                      Spacing.height(10),
                      buildTextField('실행예정금액', _execPlnAmtTextCtrl),
                      Spacing.height(10),
                      buildTextField('실행금액', _execAmtTextCtrl),
                      Spacing.height(10),
                      buildTextField('실행예정일자', _execPlnDtTextCtrl),
                      Spacing.height(10),
                      buildTextField('실행일자', _execDtTextCtrl),
                      Spacing.height(10),
                      buildTextField('매매금액', _slPrcTextCtrl),
                      Spacing.height(10),
                      buildTextField('은행지점코드', _bnkBrnchCdTextCtrl),
                      Spacing.height(10),
                      buildTextField('사업자번호', _bizNoTextCtrl),
                      Spacing.height(10),
                      buildTextField('전문인입횟수', _trnInCntTextCtrl),
                      Spacing.height(10),
                      buildTextField('상환금 수령계좌 등록여부', _refndAcctRegYnTextCtrl),
                      Spacing.height(10),
                      buildTextField('상환금 수령계좌 등록일자', _refndAcctRegDateTextCtrl),
                      Spacing.height(10),
                      buildTextField('전자등기+자담건인지 여부', _eltnSecuredYnTextCtrl),
                      Spacing.height(10),
                      buildTextField('실행금액 변경 여부', _execAmtChangYnTextCtrl),
                      Spacing.height(10),
                      buildTextField('견적서 등록 여부', _estmRegYnTextCtrl),
                      Spacing.height(10),
                      buildTextField('등기정보 등록 여부', _rgstrRegYnTextCtrl),
                      Spacing.height(10),
                      buildTextField('지급정보 등록 여부', _payRegYnTextCtrl),
                      Spacing.height(10),
                      buildTextField('대출금/상환금 지급 여부', _lndAmtPayYnTextCtrl),
                      Spacing.height(10),
                      buildTextField('이전등기 보정 여부', _revisionCheckYnTextCtrl),
                      Spacing.height(10),
                      buildTextField('6200 설정등기 확인결과서 발송여부', _estbsCntrFnYnTextCtrl),
                      Spacing.height(10),
                      buildTextField('전입세대열람원 제출여부', _mvhhdSbmtYnTextCtrl),
                      Spacing.height(10),
                      buildTextField('주민등록등본 제출여부', _rrcpCnfmReqYnTextCtrl),
                      Spacing.height(10),
                      buildTextField('수정임대차 계약서 제출여부', _rtalSbmtYnTextCtrl),
                      Spacing.height(10),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.all(30),
              alignment: Alignment.centerRight,
              width: Get.width * 0.25,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IfButton(
                    elevation: 0,
                    padding: Spacing.xy(40, 20),
                    backgroundColor: canvasColor,
                    borderRadiusAll: 5,
                    onPressed: () async {
                      CntrChngReqData reqData = CntrChngReqData();
                      reqData.loanNo = widget.data.loanNo;
                      reqData.kndCd = _kndCdTextCtrl.text;
                      reqData.lndKndCd = _lndKndCdTextCtrl.text;
                      reqData.rgstrGbCd = _rgstrGbCdTextCtrl.text;
                      reqData.statCd = _statCdTextCtrl.text;
                      reqData.lndStatCd = _lndStatCdTextCtrl.text;
                      reqData.execPlnAmt = int.parse(_execPlnAmtTextCtrl.text);
                      reqData.execAmt = int.parse(_execAmtTextCtrl.text);
                      reqData.execPlnDt = _execPlnDtTextCtrl.text;
                      reqData.execDt = _execDtTextCtrl.text;
                      reqData.slPrc = int.parse(_slPrcTextCtrl.text);
                      reqData.bnkBrnchCd = _bnkBrnchCdTextCtrl.text;
                      reqData.bizNo = _bizNoTextCtrl.text;
                      reqData.trnInCnt = int.parse(_trnInCntTextCtrl.text);
                      reqData.refndAcctRegYn = _refndAcctRegYnTextCtrl.text;
                      reqData.refndAcctRegDate = _refndAcctRegDateTextCtrl.text;
                      reqData.eltnSecuredYn = _eltnSecuredYnTextCtrl.text;
                      reqData.execAmtChangYn = _execAmtChangYnTextCtrl.text;
                      reqData.estmRegYn = _estmRegYnTextCtrl.text;
                      reqData.rgstrRegYn = _rgstrRegYnTextCtrl.text;
                      reqData.payRegYn = _payRegYnTextCtrl.text;
                      reqData.estmCnfmYn = _estmCnfmYnTextCtrl.text;
                      reqData.lndAmtPayYn = _lndAmtPayYnTextCtrl.text;
                      reqData.revisionCheckYn = _revisionCheckYnTextCtrl.text;
                      reqData.estbsCntrFnYn = _estbsCntrFnYnTextCtrl.text;
                      reqData.slCntrctEane = _slCntrctEaneTextCtrl.text;
                      reqData.slCntrctFlnm = _slCntrctFlnmTextCtrl.text;
                      reqData.mvhhdSbmtYn = _mvhhdSbmtYnTextCtrl.text;
                      reqData.rrcpSbmtYn = _rrcpCnfmReqYnTextCtrl.text;
                      reqData.rtalSbmtYn = _rtalSbmtYnTextCtrl.text;
                      reqData.cndtCntrYn = _cndtCntrYnTextCtrl.text;
                      reqData.lwyrDiffBankCd8 = _lwyrDiffBankCd8TextCtrl.text;
                      reqData.lwyrDiffBankCd10 = _lwyrDiffBankCd10TextCtrl.text;

                      ResData resData =
                      await chngCtrl.setCntrInfoChng(reqData);
                      if (resData.code == '00') {
                        IfUtils.alertIcon(resData.msg.toString(),
                            icontype: '');
                      } else {
                        IfUtils.alertIcon(resData.msg.toString(),
                            icontype: 'W');
                      }
                      Navigator.pop(context);
                    },
                    child: Text('저장', style: TextSyle.searchFormText()),
                  ),
                  Spacing.width(5),
                  IfButton(
                    elevation: 0,
                    padding: Spacing.xy(40, 20),
                    backgroundColor: canvasColor,
                    borderRadiusAll: 5,
                    onPressed: () async {
                      Navigator.pop(context);
                    },
                    child: Text('취소', style: TextSyle.searchFormText()),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget buildTextField(String text, TextEditingController textCtrl) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      SizedBox(
        width: Get.width * 0.15,
        child: Text(
          text,
          style: TextSyle.text(),
        ),
      ),
      IfTextFormField.contract(
        controller: textCtrl,
        textStyle: TextSyle.dialogText(),
      ),
    ],
  );
}