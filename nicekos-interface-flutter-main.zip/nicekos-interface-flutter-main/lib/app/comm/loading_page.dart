import 'package:flutter/material.dart';

import '../../repo/response/res_stream.dart';
import '../../utils/if_utils.dart';

class LoadingPage<T> extends StatelessWidget {
  final Stream<ResStream<T>> stream;

  const LoadingPage({super.key, required this.stream});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<ResStream<T>>(
      stream: stream,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          switch (snapshot.data?.status) {
            case Status.LOADING:
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: IfUtils.progressbar(),
                ),
              );
            case Status.COMPLETED:
              return Container(); // 필요한 위젯 반환
            case Status.ERROR:
              return Text('Error: ${snapshot.data?.message}');
            case null:
              return const SizedBox(
                width: 200,
                height: 300,
                child: Text("조회 중 오류가 발생했습니다."),
              );
          }
        }

        return Container();
      },
    );
  }
}
