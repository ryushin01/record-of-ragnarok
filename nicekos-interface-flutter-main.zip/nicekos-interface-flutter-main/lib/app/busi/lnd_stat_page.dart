import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/app/busi/ctrl/pre_ask_fa_ctrl.dart';
import 'package:nicekos_interface_flutter/repo/data/cntr_detail_data.dart';
import 'package:nicekos_interface_flutter/repo/data/preask_fa_tran_data.dart';
import 'package:nicekos_interface_flutter/repo/data/trns_hist_data.dart';
import 'package:nicekos_interface_flutter/repo/data/preask_fa_send_data.dart';
import 'package:nicekos_interface_flutter/repo/response/res_data.dart';
import 'package:nicekos_interface_flutter/utils/if_format.dart';
import 'package:nicekos_interface_flutter/utils/if_utils.dart';
import 'package:nicekos_interface_flutter/widget/if_divider.dart';
import 'package:nicekos_interface_flutter/widget/if_text_form_field.dart';
import 'package:nicekos_interface_flutter/theme/text_style.dart';
import '../../repo/data/search_payment_list_data.dart';
import '../../repo/data/trans_6300_detail_data.dart';
import '../../repo/data/trns_6300_send_data.dart';
import '../../repo/response/res_stream.dart';
import '../../utils/log_utils.dart';
import '../../widget/If_button.dart';
import '../../theme/colors.dart';
import '../../theme/spacing.dart';
import '../comm/loading_page.dart';
import '../comm/pay_list_page.dart';
import 'ctrl/lnd_stat_ctrl.dart';

class LndStatPage extends StatefulWidget {
  const LndStatPage({super.key});

  @override
  State<StatefulWidget> createState() => _LndStatPageState();
}

class _LndStatPageState extends State<LndStatPage>
    with TickerProviderStateMixin {
  late LndStatCtrl controller;

  CntrDetailResData cntrDtl = CntrDetailResData();
  Trns6300DetailResData trnsDtl = Trns6300DetailResData();
  TrnsHistResList trnsHist = TrnsHistResList();

  late TextEditingController _newLoanTextCtrl; // 신규 여신번호
  late TextEditingController _searchTextCtrl; // 조회
  late TextEditingController _tgLenTextCtrl; // 전문 길이
  late TextEditingController _tgDscTextCtrl; // 전문 구분 코드
  late TextEditingController _bnkTgNoTextCtrl; // 은행 전문 번호
  late TextEditingController _faTgNoTextCtrl; // FA 전문 번호
  late TextEditingController _kosTgSndNoTextCtrl; // KOS 전문 송신 번호
  late TextEditingController _tgSndDtmTextCtrl; // 전문 발송 일시
  late TextEditingController _tgRcvDtmTextCtrl; // 전문 수신 일시
  late TextEditingController _resCdTextCtrl; // 응답 코드
  late TextEditingController _rsrvItmHTextCtrl; // 예비 항목 H
  late TextEditingController _bnkTtlReqNoTextCtrl; // 은행 권원 신청 번호
  late TextEditingController _lndPrgsStcTextCtrl; // 대출 진행 상태코드
  late TextEditingController _prgsDtTextCtrl; // 진행 일자
  late TextEditingController _sbmtDocLstTextCtrl; // 제출 서류 목록
  late TextEditingController _mvhrHshldrRnoTextCtrl; // 전입세대열람 세대주 개수
  late TextEditingController _mvhrTrgtThngAddrTextCtrl; // 전입세대열람 대상 물건 주소
  late TextEditingController _mvhrHshldrNmMvinDtTextCtrl; // 전입세대열람 세대주 명 전입 일자
  late TextEditingController _mvhrdtmTextCtrl; // 전입세대열람일시
  late TextEditingController _rsrvItmBTextCtrl; // 예비 항목 B
  late TextEditingController _regDtmTextCtrl; // 등록 일시
  late TextEditingController _lnAprvNo2TextCtrl; // 여신 승인 번호2

  @override
  void initState() {
    super.initState();
    if (Get.isRegistered<LndStatCtrl>()) {
      Get.delete<LndStatCtrl>();
    }
    controller = Get.put(LndStatCtrl());
    _newLoanTextCtrl = TextEditingController();
    _searchTextCtrl = TextEditingController(); // 조회
    _tgLenTextCtrl = TextEditingController(); // 전문 길이
    _tgDscTextCtrl = TextEditingController(); // 전문 구분 코드
    _bnkTgNoTextCtrl = TextEditingController(); // 은행 전문 번호
    _faTgNoTextCtrl = TextEditingController(); // FA 전문 번호
    _kosTgSndNoTextCtrl = TextEditingController(); // KOS 전문 송신 번호
    _tgSndDtmTextCtrl = TextEditingController(); // 전문 발송 일시
    _tgRcvDtmTextCtrl = TextEditingController(); // 전문 수신 일시
    _resCdTextCtrl = TextEditingController(); // 응답 코드
    _rsrvItmHTextCtrl = TextEditingController(); // 예비 항목 H
    _bnkTtlReqNoTextCtrl = TextEditingController(); // 은행 권원 신청 번호
    _lndPrgsStcTextCtrl = TextEditingController(); // 대출 진행 상태코드
    _prgsDtTextCtrl = TextEditingController(); // 진행 일자
    _sbmtDocLstTextCtrl = TextEditingController(); // 제출 서류 목록
    _mvhrHshldrRnoTextCtrl = TextEditingController(); // 전입세대열람 세대주 개수
    _mvhrTrgtThngAddrTextCtrl = TextEditingController(); // 전입세대열람 대상 물건 주소
    _mvhrHshldrNmMvinDtTextCtrl = TextEditingController(); // 전입세대열람 세대주 명 전입 일자
    _mvhrdtmTextCtrl = TextEditingController(); // 전입세대열람일시
    _rsrvItmBTextCtrl = TextEditingController(); // 예비 항목 B
    _regDtmTextCtrl = TextEditingController(); // 등록 일시
    _lnAprvNo2TextCtrl = TextEditingController(); // 여신 승인 번호2
  }

  @override
  void dispose() {
    super.dispose();
    if (Get.isRegistered<LndStatCtrl>()) {
      Get.delete<LndStatCtrl>();
    }
    _newLoanTextCtrl = TextEditingController();
    _searchTextCtrl = TextEditingController(); // 조회
    _tgLenTextCtrl = TextEditingController(); // 전문 길이
    _tgDscTextCtrl = TextEditingController(); // 전문 구분 코드
    _bnkTgNoTextCtrl = TextEditingController(); // 은행 전문 번호
    _faTgNoTextCtrl = TextEditingController(); // FA 전문 번호
    _kosTgSndNoTextCtrl = TextEditingController(); // KOS 전문 송신 번호
    _tgSndDtmTextCtrl = TextEditingController(); // 전문 발송 일시
    _tgRcvDtmTextCtrl = TextEditingController(); // 전문 수신 일시
    _resCdTextCtrl = TextEditingController(); // 응답 코드
    _rsrvItmHTextCtrl = TextEditingController(); // 예비 항목 H
    _bnkTtlReqNoTextCtrl = TextEditingController(); // 은행 권원 신청 번호
    _lndPrgsStcTextCtrl = TextEditingController(); // 대출 진행 상태코드
    _prgsDtTextCtrl = TextEditingController(); // 진행 일자
    _sbmtDocLstTextCtrl = TextEditingController(); // 제출 서류 목록
    _mvhrHshldrRnoTextCtrl = TextEditingController(); // 전입세대열람 세대주 개수
    _mvhrTrgtThngAddrTextCtrl = TextEditingController(); // 전입세대열람 대상 물건 주소
    _mvhrHshldrNmMvinDtTextCtrl = TextEditingController(); // 전입세대열람 세대주 명 전입 일자
    _mvhrdtmTextCtrl = TextEditingController(); // 전입세대열람일시
    _rsrvItmBTextCtrl = TextEditingController(); // 예비 항목 B
    _regDtmTextCtrl = TextEditingController(); // 등록 일시
    _lnAprvNo2TextCtrl = TextEditingController(); // 여신 승인 번호2
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
        init: controller,
        builder: (controller) {
          return Container(
            margin:
                const EdgeInsets.only(left: 50, top: 20, bottom: 20, right: 50),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 20),
                      child: IfTextFormField.search(
                        controller: _searchTextCtrl,
                        textStyle: TextSyle.searchFormText(),
                      ),
                    ),
                    Spacing.width(20),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          IfUtils.alertIcon("여신 번호 입력!", icontype: 'W');
                          return;
                        }
                        ResData resCntrData =
                            await controller.getCntrDtl(_searchTextCtrl.text);
                        if (resCntrData.code == '00') {
                          cntrDtl = controller.cntrDetailResData;
                          IfUtils.alertIcon(resCntrData.msg.toString(),
                              icontype: '');
                        } else {
                          IfUtils.alertIcon('검색 실패', icontype: 'W');
                        }
                      },
                      child: Text('검색', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          IfUtils.alertIcon("검색 후 전문 복사", icontype: 'W');
                          return;
                        }
                        ResData resData =
                            await controller.getTrnsDtl(_searchTextCtrl.text);
                        if (resData.code == '00') {
                          trnsDtl = controller.trns6300DetailResData;
                          Lo.g("trnsDtl.regDtm :${trnsDtl.regDtm}");
                          _newLoanTextCtrl.text = trnsDtl.loanNo ?? '';
                          _tgLenTextCtrl.text = trnsDtl.tgLen.toString();
                          _tgDscTextCtrl.text = trnsDtl.tgDsc ?? '';
                          _bnkTgNoTextCtrl.text = trnsDtl.bnkTgNo.toString();
                          _faTgNoTextCtrl.text = trnsDtl.faTgNo.toString();
                          _kosTgSndNoTextCtrl.text = trnsDtl.kosTgSndNo.toString();
                          _rsrvItmHTextCtrl.text = trnsDtl.rsrvItmH ?? '';
                          _bnkTtlReqNoTextCtrl.text =
                              trnsDtl.bnkTtlReqNo.toString();
                          _lndPrgsStcTextCtrl.text = trnsDtl.lndPrgsStc ?? '';
                          _prgsDtTextCtrl.text = trnsDtl.prgsDt ?? '';
                          _sbmtDocLstTextCtrl.text = trnsDtl.sbmtDocLst ?? '';
                          _mvhrHshldrRnoTextCtrl.text =
                              trnsDtl.mvhrHshldrRno.toString();
                          _mvhrTrgtThngAddrTextCtrl.text =
                              trnsDtl.mvhrTrgtThngAddr ?? '';
                          _mvhrHshldrNmMvinDtTextCtrl.text =
                              trnsDtl.mvhrHshldrNmMvinDt ?? '';
                          _mvhrdtmTextCtrl.text = trnsDtl.mvhrdtm ?? '';
                          _regDtmTextCtrl.text = trnsDtl.regDtm ?? '';
                          _rsrvItmBTextCtrl.text = trnsDtl.rsrvItmB ?? '';
                          _lnAprvNo2TextCtrl.text = trnsDtl.lnAprvNo2 ?? '';
                          IfUtils.alertIcon(resData.msg.toString(),
                              icontype: '');
                        } else {
                          IfUtils.alertIcon(resData.msg.toString(),
                              icontype: 'W');
                        }
                      },
                      child: Text('전문 복사', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    Row(
                      children: [
                        IfButton(
                          elevation: 0,
                          padding: Spacing.xy(40, 20),
                          backgroundColor: canvasColor,
                          borderRadiusAll: 5,
                          onPressed: () async {
                            if (_searchTextCtrl.text.isEmpty) {
                              IfUtils.alertIcon("전문 복사 후 전문 송신", icontype: 'W');
                              return;
                            }
                            Trns6300SendReqData reqData = Trns6300SendReqData();
                            reqData.newLoanNo = _newLoanTextCtrl.text;
                            reqData.loanNo = _searchTextCtrl.text;
                            reqData.newLoanNo = _newLoanTextCtrl.text;
                            reqData.tgLen = int.parse(_tgLenTextCtrl.text);
                            reqData.tgDsc = _tgDscTextCtrl.text;
                            reqData.bnkTgNo = int.parse(_bnkTgNoTextCtrl.text);
                            reqData.faTgNo = int.parse(_faTgNoTextCtrl.text);
                            //reqData.kosTgSndNo = int.parse
                            //(_kosTgSndNoTextCtrl.text);
                            reqData.rsrvItmH = _rsrvItmHTextCtrl.text;
                            reqData.bnkTtlReqNo = _bnkTtlReqNoTextCtrl.text;
                            reqData.lndPrgsStc = _lndPrgsStcTextCtrl.text;
                            reqData.prgsDt = _prgsDtTextCtrl.text;
                            reqData.sbmtDocLst = _sbmtDocLstTextCtrl.text;
                            reqData.mvhrHshldrRno =
                                int.parse(_mvhrHshldrRnoTextCtrl.text);
                            reqData.mvhrTrgtThngAddr =
                                _mvhrTrgtThngAddrTextCtrl.text;
                            reqData.mvhrHshldrNmMvinDt =
                                _mvhrHshldrNmMvinDtTextCtrl.text;
                            reqData.mvhrdtm = _mvhrdtmTextCtrl.text;
                            reqData.rsrvItmB = _rsrvItmBTextCtrl.text;
                            reqData.regDtm = _regDtmTextCtrl.text;
                            reqData.lnAprvNo2 = _lnAprvNo2TextCtrl.text;

                            ResData resData =
                                await controller.setLndStat(reqData);
                            if (resData.code == '00') {
                              IfUtils.alertIcon(resData.msg.toString(),
                                  icontype: '');
                            } else {
                              IfUtils.alertIcon('실패', icontype: '');
                            }
                          },
                          child:
                              Text('전문 송신', style: TextSyle.searchFormText()),
                        ),
                        LoadingPage<Trns6300SendResData>(
                          stream: LndStatCtrl.to.trns6300SendResStream.stream,
                        ),
                      ],
                    ),
                    Spacing.width(10),
                  ],
                ),
                Spacing.height(40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    PayListPage(controller: controller,
                        searchTextCtrl: _searchTextCtrl),
                    Spacing.width(40),
                    Spacing.width(10),
                    Expanded(
                      child: SizedBox(
                        height: Get.height * 0.8,
                        //width: Get.width * 0.2,
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Spacing.height(40),
                              IfUtils.buildCategory('전문 전송 정보'),
                              Spacing.height(20),
                              IfDivider(width: 0.37),
                              Spacing.height(20),
                              buildTextField('신규 여신 번호 (NEW_LOAN_NO)', _newLoanTextCtrl),
                              Spacing.height(5),
                              buildTextField('전문 길이 (TG_LEN)', _tgLenTextCtrl),
                              Spacing.height(5),
                              buildTextField('전문 구분 코드 (TG_DSC)', _tgDscTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 전문 번호 (BNK_TG_NO)', _bnkTgNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('FA 전문 번호 (FA_TG_NO)', _faTgNoTextCtrl),
                              Spacing.height(5),
                              // buildTextField('코스 전문 송신 번호 (KOS_TG_SND_NO)', _kosTgSndNoTextCtrl),
                              // Spacing.height(5),
                              buildTextField('예비 항목 H (RSRV_ITM_H)', _rsrvItmHTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 권원 신청 번호 (BNK_TTL_REQ_NO)', _bnkTtlReqNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('대출 진행 상태 코드 (LND_PRGS_STC)', _lndPrgsStcTextCtrl),
                              Spacing.height(5),
                              buildTextField('진행 일자 (PRGS_DT)', _prgsDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('제출 서류 목록 (SBMT_DOC_LST)', _sbmtDocLstTextCtrl),
                              Spacing.height(5),
                              buildTextField('전입세대열람 세대주 개수 (MVHR_HSHLDR_RNO)', _mvhrHshldrRnoTextCtrl),
                              Spacing.height(5),
                              buildTextField('전입세대열람 대상 물건 주소 (MVHR_TRGT_THNG_ADDR)', _mvhrTrgtThngAddrTextCtrl),
                              Spacing.height(5),
                              buildTextField('전입세대열람세대주명전입일자(MVHR_HSHLDR_NM_MVIN_DT)', _mvhrHshldrNmMvinDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('전입세대열람일시 (MVHRDTM)', _mvhrdtmTextCtrl),
                              Spacing.height(5),
                              buildTextField('예비 항목 B (RSRV_ITM_B)', _rsrvItmBTextCtrl),
                              Spacing.height(5),
                              buildTextField('등록 일시 (REG_DTM)', _regDtmTextCtrl),
                              Spacing.height(5),
                              buildTextField('여신 승인 번호2 (LN_APRV_NO2)', _lnAprvNo2TextCtrl),
                              Spacing.height(5),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        });
  }

  Widget buildTextField(String text, TextEditingController textCtrl) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: Get.width * 0.25,
          child: MouseRegion(
            cursor: SystemMouseCursors.text, // 마우스 커서 변경
            child: SelectableText(
              text,
              style: TextSyle.text(),
            ),
          ),
        ),
        IfTextFormField.trans(
          controller: textCtrl,
          textStyle: TextSyle.inputFormText(),
        ),
      ],
    );
  }
}

Widget loading(BuildContext context) {
  return StreamBuilder<ResStream<Trns6300SendResData>>(
    stream: LndStatCtrl.to.trns6300SendResStream.stream,
    builder: (context, snapshot) {
      if (snapshot.hasData) {
        switch (snapshot.data?.status) {
          case Status.LOADING:
            return Center(
                child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: IfUtils.progressbar(),
            ));
          case Status.COMPLETED:
            var list = snapshot.data!.data;
            return Container();
          case Status.ERROR:
            return Text('Error: ${snapshot.data?.message}');
          case null:
            return const SizedBox(
              width: 200,
              height: 300,
              child: Text("조회 중 오류가 발생했습니다."),
            );
        }
      }

      return Container();
    },
  );
}
