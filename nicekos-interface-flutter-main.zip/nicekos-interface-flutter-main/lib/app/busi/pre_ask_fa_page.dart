import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/app/busi/ctrl/pre_ask_fa_ctrl.dart';
import 'package:nicekos_interface_flutter/repo/data/cntr_detail_data.dart';
import 'package:nicekos_interface_flutter/repo/data/preask_fa_tran_data.dart';
import 'package:nicekos_interface_flutter/repo/data/trns_hist_data.dart';
import 'package:nicekos_interface_flutter/repo/data/preask_fa_send_data.dart';
import 'package:nicekos_interface_flutter/repo/response/res_data.dart';
import 'package:nicekos_interface_flutter/utils/if_format.dart';
import 'package:nicekos_interface_flutter/utils/if_utils.dart';
import 'package:nicekos_interface_flutter/widget/if_divider.dart';
import 'package:nicekos_interface_flutter/widget/if_text_form_field.dart';
import 'package:nicekos_interface_flutter/theme/text_style.dart';
import '../../repo/data/search_payment_list_data.dart';
import '../../repo/response/res_stream.dart';
import '../../widget/If_button.dart';
import '../../theme/colors.dart';
import '../../theme/spacing.dart';
import '../comm/cntr_info_chng_page.dart';
import '../comm/loading_page.dart';
import '../comm/pay_list_page.dart';

class PreAskFaPage extends StatefulWidget {
  const PreAskFaPage({super.key});

  @override
  State<StatefulWidget> createState() => _PreAskFaPageState();
}

class _PreAskFaPageState extends State<PreAskFaPage> with
    TickerProviderStateMixin {
  late PreAskCtrl controller;

  CntrDetailResData cntrDtl = CntrDetailResData();
  TrnsDetailResData trnsDtl = TrnsDetailResData();
  TrnsHistResList trnsHist = TrnsHistResList();

  late TextEditingController _newLoanTextCtrl; // 신규 여신번호
  late TextEditingController _searchTextCtrl; // 조회
  late TextEditingController _tgLenTextCtrl; // 전문 길이
  late TextEditingController _tgDscTextCtrl; // 전문 구분 코드
  late TextEditingController _bnkTgNoTextCtrl; // 은행 전문 번호
  late TextEditingController _faTgNoTextCtrl; // FA 전문 번호
  late TextEditingController _kosTgSndNoTextCtrl; // KOS 전문 송신 번호
  late TextEditingController _tgSndDtmTextCtrl; // 전문 발송 일시
  late TextEditingController _tgRcvDtmTextCtrl; // 전문 수신 일시
  late TextEditingController _resCdTextCtrl; // 응답 코드
  late TextEditingController _rsrvItmHTextCtrl; // 예비 항목 H
  late TextEditingController _lndDscTextCtrl; // 대출 구분 코드
  late TextEditingController _lndKndCdTextCtrl; // 대출 종류 코드
  late TextEditingController _fndUseCdTextCtrl; // 자금 용도 코드
  late TextEditingController _bnkLndPrdtCdTextCtrl; // 은행 대출 상품 코드
  late TextEditingController _bnkLndPrdtNmTextCtrl; // 은행 대출 상품명
  late TextEditingController _stndAplYnTextCtrl; // 표준화 적용 여부
  late TextEditingController _mvLwyrCnfmYnTextCtrl; // 이전 법무사 확인 여부
  late TextEditingController _rgstrUnqNo1TextCtrl; // 등기 고유 번호 1
  late TextEditingController _rgstrUnqNo2TextCtrl; // 등기 고유 번호 2
  late TextEditingController _rgstrUnqNo3TextCtrl; // 등기 고유 번호 3
  late TextEditingController _rgstrUnqNo4TextCtrl; // 등기 고유 번호 4
  late TextEditingController _rgstrUnqNo5TextCtrl; // 등기 고유 번호 5
  late TextEditingController _rlesDscTextCtrl; // 부동산 구분 코드
  late TextEditingController _trgtRlesDscTextCtrl; // 대상 부동산 구분 코드
  late TextEditingController _trgtRlesAddrTextCtrl; // 대상 부동산 주소
  late TextEditingController _bfAskDtTextCtrl; // 사전 의뢰 일자
  late TextEditingController _lndPlnDtTextCtrl; // 대출 예정 일자
  late TextEditingController _slPrcTextCtrl; // 매매 가액
  late TextEditingController _scrtEvlAmtTextCtrl; // 담보 평가 금액
  late TextEditingController _isrnEntrAmtTextCtrl; // 보험 가입 금액
  late TextEditingController _lndAmtTextCtrl; // 대출 금액
  late TextEditingController _bnkFxcltRgstrRnkTextCtrl; // 은행 근저당권 등기 순위
  late TextEditingController _dbtrNmTextCtrl; // 차주명
  late TextEditingController _dbtrBirthDtTextCtrl; // 차주 생년 월일
  late TextEditingController _dbtrAddrTextCtrl; // 차주 주소
  late TextEditingController _dbtrPhnoTextCtrl; // 차주 전화 번호
  late TextEditingController _dbtrHpnoTextCtrl; // 차주 핸드폰 번호
  late TextEditingController _pwpsNmTextCtrl; // 담보 제공자 명
  late TextEditingController _pwpsBirthDtTextCtrl; // 담보 제공자 생년 월일
  late TextEditingController _pwpsAddrTextCtrl; // 담보 제공자 주소
  late TextEditingController _pwpsPhnoTextCtrl; // 담보 제공자 전화 번호
  late TextEditingController _pwpsHpnoTextCtrl; // 담보 제공자 핸드폰 번호
  late TextEditingController _rmkFctTextCtrl; // 비고 사항
  late TextEditingController _lndHndgSlfDscTextCtrl; // 대출 취급 주체 구분 코드
  late TextEditingController _bnkBrnchNmTextCtrl; // 은행 지점명
  late TextEditingController _bnkDrctrNmTextCtrl; // 은행 담당자 명
  late TextEditingController _bnkBrnchPhnoTextCtrl; // 은행 지점 전화 번호
  late TextEditingController _bnkDrctrHpTextCtrl;
  late TextEditingController _bnkBrnchFaxTextCtrl;
  late TextEditingController _bnkBrnchAddrTextCtrl;
  late TextEditingController _slmnCmpyNmTextCtrl;
  late TextEditingController _slmnNmTextCtrl;
  late TextEditingController _slmnPhnoTextCtrl;
  late TextEditingController _rfrLnAprvNoTextCtrl;
  late TextEditingController _rgstrMtdDscTextCtrl;
  late TextEditingController _odprtRpyEaneTextCtrl;
  late TextEditingController _eltnEstbsLwyrNmTextCtrl;
  late TextEditingController _eltnEstbsLwyrBiznoTextCtrl;
  late TextEditingController _slCntrctEaneTextCtrl;
  late TextEditingController _slCntrctFlnmTextCtrl;
  late TextEditingController _afrgstrScrtYnTextCtrl;
  late TextEditingController _bnkBrnchCdTextCtrl;
  late TextEditingController _rsrvItmBTextCtrl;

  @override
  void initState() {
    super.initState();
    if (Get.isRegistered<PreAskCtrl>()) {
      Get.delete<PreAskCtrl>();
    }
    controller = Get.put(PreAskCtrl());
    _newLoanTextCtrl = TextEditingController();
    _searchTextCtrl = TextEditingController(); // 조회
    _tgLenTextCtrl = TextEditingController(); // 전문 길이
    _tgDscTextCtrl = TextEditingController(); // 전문 구분 코드
    _bnkTgNoTextCtrl = TextEditingController(); // 은행 전문 번호
    _faTgNoTextCtrl = TextEditingController(); // FA 전문 번호
    _kosTgSndNoTextCtrl = TextEditingController(); // KOS 전문 송신 번호
    _tgSndDtmTextCtrl = TextEditingController(); // 전문 발송 일시
    _tgRcvDtmTextCtrl = TextEditingController(); // 전문 수신 일시
    _resCdTextCtrl = TextEditingController(); // 응답 코드
    _rsrvItmHTextCtrl = TextEditingController(); // 예비 항목 H
    _lndDscTextCtrl = TextEditingController(); // 대출 구분 코드
    _lndKndCdTextCtrl = TextEditingController(); // 대출 종류 코드
    _fndUseCdTextCtrl = TextEditingController(); // 자금 용도 코드
    _bnkLndPrdtCdTextCtrl = TextEditingController(); // 은행 대출 상품 코드
    _bnkLndPrdtNmTextCtrl = TextEditingController(); // 은행 대출 상품명
    _stndAplYnTextCtrl = TextEditingController(); // 표준화 적용 여부
    _mvLwyrCnfmYnTextCtrl = TextEditingController(); // 이전 법무사 확인 여부
    _rgstrUnqNo1TextCtrl = TextEditingController(); // 등기 고유 번호 1
    _rgstrUnqNo2TextCtrl = TextEditingController(); // 등기 고유 번호 2
    _rgstrUnqNo3TextCtrl = TextEditingController(); // 등기 고유 번호 3
    _rgstrUnqNo4TextCtrl = TextEditingController(); // 등기 고유 번호 4
    _rgstrUnqNo5TextCtrl = TextEditingController(); // 등기 고유 번호 5
    _rlesDscTextCtrl = TextEditingController(); // 부동산 구분 코드
    _trgtRlesDscTextCtrl = TextEditingController(); // 대상 부동산 구분 코드
    _trgtRlesAddrTextCtrl = TextEditingController(); // 대상 부동산 주소
    _bfAskDtTextCtrl = TextEditingController(); // 사전 의뢰 일자
    _lndPlnDtTextCtrl = TextEditingController(); // 대출 예정 일자
    _slPrcTextCtrl = TextEditingController(); // 매매 가액
    _scrtEvlAmtTextCtrl = TextEditingController(); // 담보 평가 금액
    _isrnEntrAmtTextCtrl = TextEditingController(); // 보험 가입 금액
    _lndAmtTextCtrl = TextEditingController(); // 대출 금액
    _bnkFxcltRgstrRnkTextCtrl = TextEditingController(); // 은행 근저당권 등기 순위
    _dbtrNmTextCtrl = TextEditingController(); // 차주명
    _dbtrBirthDtTextCtrl = TextEditingController(); // 차주 생년 월일
    _dbtrAddrTextCtrl = TextEditingController(); // 차주 주소
    _dbtrPhnoTextCtrl = TextEditingController(); // 차주 전화 번호
    _dbtrHpnoTextCtrl = TextEditingController(); // 차주 핸드폰 번호
    _pwpsNmTextCtrl = TextEditingController(); // 담보 제공자 명
    _pwpsBirthDtTextCtrl = TextEditingController(); // 담보 제공자 생년 월일
    _pwpsAddrTextCtrl = TextEditingController(); // 담보 제공자 주소
    _pwpsPhnoTextCtrl = TextEditingController(); // 담보 제공자 전화 번호
    _pwpsHpnoTextCtrl = TextEditingController(); // 담보 제공자 핸드폰 번호
    _rmkFctTextCtrl = TextEditingController(); // 비고 사항
    _lndHndgSlfDscTextCtrl = TextEditingController(); // 대출 취급 주체 구분 코드
    _bnkBrnchNmTextCtrl = TextEditingController(); // 은행 지점명
    _bnkDrctrNmTextCtrl = TextEditingController(); // 은행 담당자 명
    _bnkBrnchPhnoTextCtrl = TextEditingController(); // 은행 지점 전화 번호
   _bnkDrctrHpTextCtrl = TextEditingController();
   _bnkBrnchFaxTextCtrl = TextEditingController();
   _bnkBrnchAddrTextCtrl = TextEditingController();
   _slmnCmpyNmTextCtrl = TextEditingController();
   _slmnNmTextCtrl = TextEditingController();
   _slmnPhnoTextCtrl = TextEditingController();
   _rfrLnAprvNoTextCtrl = TextEditingController();
   _rgstrMtdDscTextCtrl = TextEditingController();
   _odprtRpyEaneTextCtrl = TextEditingController();
   _eltnEstbsLwyrNmTextCtrl = TextEditingController();
   _eltnEstbsLwyrBiznoTextCtrl = TextEditingController();
   _slCntrctEaneTextCtrl = TextEditingController();
   _slCntrctFlnmTextCtrl = TextEditingController();
   _afrgstrScrtYnTextCtrl = TextEditingController();
   _bnkBrnchCdTextCtrl = TextEditingController();
    _rsrvItmBTextCtrl = TextEditingController();
  }

  @override
  void dispose() {
    super.dispose();
    if (Get.isRegistered<PreAskCtrl>()) {
      Get.delete<PreAskCtrl>();
    }
    _newLoanTextCtrl = TextEditingController();
    _searchTextCtrl = TextEditingController(); // 조회
    _tgLenTextCtrl = TextEditingController(); // 전문 길이
    _tgDscTextCtrl = TextEditingController(); // 전문 구분 코드
    _bnkTgNoTextCtrl = TextEditingController(); // 은행 전문 번호
    _faTgNoTextCtrl = TextEditingController(); // FA 전문 번호
    _kosTgSndNoTextCtrl = TextEditingController(); // KOS 전문 송신 번호
    _tgSndDtmTextCtrl = TextEditingController(); // 전문 발송 일시
    _tgRcvDtmTextCtrl = TextEditingController(); // 전문 수신 일시
    _resCdTextCtrl = TextEditingController(); // 응답 코드
    _rsrvItmHTextCtrl = TextEditingController(); // 예비 항목 H
    _lndDscTextCtrl = TextEditingController(); // 대출 구분 코드
    _lndKndCdTextCtrl = TextEditingController(); // 대출 종류 코드
    _fndUseCdTextCtrl = TextEditingController(); // 자금 용도 코드
    _bnkLndPrdtCdTextCtrl = TextEditingController(); // 은행 대출 상품 코드
    _bnkLndPrdtNmTextCtrl = TextEditingController(); // 은행 대출 상품명
    _stndAplYnTextCtrl = TextEditingController(); // 표준화 적용 여부
    _mvLwyrCnfmYnTextCtrl = TextEditingController(); // 이전 법무사 확인 여부
    _rgstrUnqNo1TextCtrl = TextEditingController(); // 등기 고유 번호 1
    _rgstrUnqNo2TextCtrl = TextEditingController(); // 등기 고유 번호 2
    _rgstrUnqNo3TextCtrl = TextEditingController(); // 등기 고유 번호 3
    _rgstrUnqNo4TextCtrl = TextEditingController(); // 등기 고유 번호 4
    _rgstrUnqNo5TextCtrl = TextEditingController(); // 등기 고유 번호 5
    _rlesDscTextCtrl = TextEditingController(); // 부동산 구분 코드
    _trgtRlesDscTextCtrl = TextEditingController(); // 대상 부동산 구분 코드
    _trgtRlesAddrTextCtrl = TextEditingController(); // 대상 부동산 주소
    _bfAskDtTextCtrl = TextEditingController(); // 사전 의뢰 일자
    _lndPlnDtTextCtrl = TextEditingController(); // 대출 예정 일자
    _slPrcTextCtrl = TextEditingController(); // 매매 가액
    _scrtEvlAmtTextCtrl = TextEditingController(); // 담보 평가 금액
    _isrnEntrAmtTextCtrl = TextEditingController(); // 보험 가입 금액
    _lndAmtTextCtrl = TextEditingController(); // 대출 금액
    _bnkFxcltRgstrRnkTextCtrl = TextEditingController(); // 은행 근저당권 등기 순위
    _dbtrNmTextCtrl = TextEditingController(); // 차주명
    _dbtrBirthDtTextCtrl = TextEditingController(); // 차주 생년 월일
    _dbtrAddrTextCtrl = TextEditingController(); // 차주 주소
    _dbtrPhnoTextCtrl = TextEditingController(); // 차주 전화 번호
    _dbtrHpnoTextCtrl = TextEditingController(); // 차주 핸드폰 번호
    _pwpsNmTextCtrl = TextEditingController(); // 담보 제공자 명
    _pwpsBirthDtTextCtrl = TextEditingController(); // 담보 제공자 생년 월일
    _pwpsAddrTextCtrl = TextEditingController(); // 담보 제공자 주소
    _pwpsPhnoTextCtrl = TextEditingController(); // 담보 제공자 전화 번호
    _pwpsHpnoTextCtrl = TextEditingController(); // 담보 제공자 핸드폰 번호
    _rmkFctTextCtrl = TextEditingController(); // 비고 사항
    _lndHndgSlfDscTextCtrl = TextEditingController(); // 대출 취급 주체 구분 코드
    _bnkBrnchNmTextCtrl = TextEditingController(); // 은행 지점명
    _bnkDrctrNmTextCtrl = TextEditingController(); // 은행 담당자 명
    _bnkBrnchPhnoTextCtrl = TextEditingController(); // 은행 지점 전화 번호
    _bnkDrctrHpTextCtrl = TextEditingController();
    _bnkBrnchFaxTextCtrl = TextEditingController();
    _bnkBrnchAddrTextCtrl = TextEditingController();
    _slmnCmpyNmTextCtrl = TextEditingController();
    _slmnNmTextCtrl = TextEditingController();
    _slmnPhnoTextCtrl = TextEditingController();
    _rfrLnAprvNoTextCtrl = TextEditingController();
    _rgstrMtdDscTextCtrl = TextEditingController();
    _odprtRpyEaneTextCtrl = TextEditingController();
    _eltnEstbsLwyrNmTextCtrl = TextEditingController();
    _eltnEstbsLwyrBiznoTextCtrl = TextEditingController();
    _slCntrctEaneTextCtrl = TextEditingController();
    _slCntrctFlnmTextCtrl = TextEditingController();
    _afrgstrScrtYnTextCtrl = TextEditingController();
    _bnkBrnchCdTextCtrl = TextEditingController();
    _rsrvItmBTextCtrl = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
        init: controller,
        builder: (controller) {
          return Container(
            margin:
                const EdgeInsets.only(left: 50, top: 20, bottom: 20, right: 50),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 20),
                      child: IfTextFormField.search(
                        controller: _searchTextCtrl,
                        textStyle: TextSyle.searchFormText(),
                      ),
                    ),
                    Spacing.width(20),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          IfUtils.alertIcon("여신 번호 입력!", icontype: 'W');
                          return;
                        }
                        ResData resCntrData =
                            await controller.getCntrDtl(_searchTextCtrl.text);
                        if (resCntrData.code == '00') {
                          cntrDtl = controller.cntrDetailResData;
                          IfUtils.alertIcon(resCntrData.msg.toString(), icontype: '');
                        } else {
                          IfUtils.alertIcon('검색 실패', icontype: 'W');
                        }
                      },
                      child: Text('검색', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          IfUtils.alertIcon("검색 후 전문 복사", icontype: 'W');
                          return;
                        }
                        ResData resData =
                            await controller.getTrnsDtl(_searchTextCtrl.text);
                        if (resData.code == '00') {
                          trnsDtl = controller.trnsDetailResData;
                          _newLoanTextCtrl.text = trnsDtl.loanNo ?? '';
                          _tgLenTextCtrl.text = trnsDtl.tgLen.toString();
                          _tgDscTextCtrl.text = trnsDtl.tgDsc ?? '';
                          _bnkTgNoTextCtrl.text = trnsDtl.bnkTgNo ?? '';
                          _faTgNoTextCtrl.text = trnsDtl.faTgNo ?? '';
                          _kosTgSndNoTextCtrl.text = trnsDtl.kosTgSndNo ?? '';
                          _rsrvItmHTextCtrl.text = trnsDtl.rsrvItmH ?? '';
                          _lndDscTextCtrl.text = trnsDtl.lndDsc ?? '';
                          _lndKndCdTextCtrl.text = trnsDtl.lndKndCd ?? '';
                          _fndUseCdTextCtrl.text = trnsDtl.fndUseCd ?? '';
                          _bnkLndPrdtCdTextCtrl.text =
                              trnsDtl.bnkLndProdtCd ?? '';
                          _bnkLndPrdtNmTextCtrl.text =
                          trnsDtl.bnkLndProdtNm ?? '';
                          _stndAplYnTextCtrl.text = trnsDtl.stndAplYn ?? '';
                          _mvLwyrCnfmYnTextCtrl.text =
                          trnsDtl.mvLwyrCnfmYn ?? '';
                          _rgstrUnqNo1TextCtrl.text = trnsDtl.rgstrUnqNo1 ?? '';
                          _rgstrUnqNo2TextCtrl.text = trnsDtl.rgstrUnqNo2 ?? '';
                          _rgstrUnqNo3TextCtrl.text = trnsDtl.rgstrUnqNo3 ?? '';
                          _rgstrUnqNo4TextCtrl.text = trnsDtl.rgstrUnqNo4 ?? '';
                          _rgstrUnqNo5TextCtrl.text = trnsDtl.rgstrUnqNo5 ?? '';
                          _rlesDscTextCtrl.text = trnsDtl.rlesDsc ?? '';
                          _trgtRlesDscTextCtrl.text = trnsDtl.trgtRlesDsc ?? '';
                          _trgtRlesAddrTextCtrl.text =
                              trnsDtl.trgtRlesAddr ?? '';
                          _bfAskDtTextCtrl.text = trnsDtl.bfAskDt ?? '';
                          _lndPlnDtTextCtrl.text = trnsDtl.lndPlnDt ?? '';
                          _slPrcTextCtrl.text = trnsDtl.slPrc!.toString();
                          _scrtEvlAmtTextCtrl.text = trnsDtl.scrtevlAmt ?? '';
                          _isrnEntrAmtTextCtrl.text = trnsDtl.isrnEntrAmt ?? '';
                          _lndAmtTextCtrl.text = trnsDtl.lndAmt!.toString();
                          _bnkFxcltRgstrRnkTextCtrl.text = trnsDtl
                              .bnkfxcltRgstrRnk.toString() ?? '';
                          _dbtrNmTextCtrl.text = trnsDtl.dbrtNm ?? '';
                          // _dbtrNmTextCtrl.text = '이상협';
                          _dbtrBirthDtTextCtrl.text = trnsDtl.dbtrBirthDt ?? '';
                          _dbtrAddrTextCtrl.text =trnsDtl.dbtrAddr ?? '';
                          _dbtrPhnoTextCtrl.text = trnsDtl.dbtrHpno ?? '';
                          // _dbtrPhnoTextCtrl.text = '01099274288';
                          _dbtrHpnoTextCtrl.text = trnsDtl.dbtrHpno ?? '';
                          // _dbtrHpnoTextCtrl.text = '01099274288';
                          _pwpsNmTextCtrl.text = trnsDtl.pwpsNm ?? '';
                          // _pwpsNmTextCtrl.text = '이상협';
                          _pwpsBirthDtTextCtrl.text = trnsDtl.pwpsBirthDt ?? '';
                          _pwpsAddrTextCtrl.text = trnsDtl.pwpsAddr ?? '';
                          _pwpsPhnoTextCtrl.text = trnsDtl.pwpsPhno ?? '';
                          // _pwpsPhnoTextCtrl.text = '01099274288';
                          _pwpsHpnoTextCtrl.text = trnsDtl.pwpsHpno ?? '';
                          // _pwpsHpnoTextCtrl.text = '01099274288';
                          _rmkFctTextCtrl.text = trnsDtl.rmkFct ?? '';
                          _lndHndgSlfDscTextCtrl.text =
                          trnsDtl.lndHndgSlfDsc ?? '';
                          _bnkBrnchNmTextCtrl.text = trnsDtl.bnkBrnchNm ?? '';
                          _bnkDrctrNmTextCtrl.text = trnsDtl.bnkDrctrNm ?? '';
                          _bnkBrnchPhnoTextCtrl.text =
                              trnsDtl.bnkBrnchPhno ?? '';
                          _bnkDrctrHpTextCtrl.text = trnsDtl.bnkDrctrHp ?? '';
                          _bnkBrnchFaxTextCtrl.text = trnsDtl.bnkBrnchFax ?? '';
                          _bnkBrnchAddrTextCtrl.text = trnsDtl.bnkBrnchAddr ?? '';
                          _slmnCmpyNmTextCtrl.text = trnsDtl.slmnCmpyNm ?? '';
                          _slmnNmTextCtrl.text = trnsDtl.slmnNm ?? '';
                          // _slmnNmTextCtrl.text = '이상협';
                          _slmnPhnoTextCtrl.text = trnsDtl.slmnPhno ?? '';
                          // _slmnPhnoTextCtrl.text = '01099274288';
                          _rfrLnAprvNoTextCtrl.text = trnsDtl.rfrLnAprvNo ?? '';
                          _rgstrMtdDscTextCtrl.text = trnsDtl.rgstrMtdDsc ?? '';
                          _odprtRpyEaneTextCtrl.text = trnsDtl.odprtRpyEane ?? '';
                          _eltnEstbsLwyrNmTextCtrl.text = trnsDtl.eltnEstbsLwyrNm ?? '';
                          _eltnEstbsLwyrBiznoTextCtrl.text = trnsDtl
                            .eltnEstbsLwyrBizNo ?? '';
                          _slCntrctEaneTextCtrl.text = trnsDtl.slCntrctEane ?? '';
                          _slCntrctFlnmTextCtrl.text = trnsDtl.slCntrctFlnm ?? '';
                          _afrgstrScrtYnTextCtrl.text = trnsDtl.afrgstrScrtYn ?? '';
                          _bnkBrnchCdTextCtrl.text = trnsDtl.bnkBrnchCd ?? '';
                          _rsrvItmBTextCtrl.text = trnsDtl.rsrvItmB ?? '';
                          IfUtils.alertIcon(resData.msg.toString(), icontype: '');
                        } else {
                          IfUtils.alertIcon(resData.msg.toString(), icontype: 'W');
                        }
                      },
                      child: Text('전문 복사', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    Row(
                    children: [
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          IfUtils.alertIcon("전문 복사 후 전문 송신", icontype: 'W');
                          return;
                        }
                        TrnsSendReqData reqData = TrnsSendReqData();
                        reqData.loanNo = _searchTextCtrl.text;
                        reqData.newLoanNo = _newLoanTextCtrl.text;
                        reqData.tgLen = int.parse(_tgLenTextCtrl.text);
                        reqData.tgDsc = _tgDscTextCtrl.text;
                        reqData.bnkTgNo = _bnkTgNoTextCtrl.text;
                        reqData.faTgNo = _faTgNoTextCtrl.text;
                        reqData.kosTgSndNo = _kosTgSndNoTextCtrl.text;
                        reqData.rsrvItmH = _rsrvItmHTextCtrl.text;
                        reqData.lndDsc = _lndDscTextCtrl.text;
                        reqData.lndKndCd = _lndKndCdTextCtrl.text;
                        reqData.fndUseCd = _fndUseCdTextCtrl.text;
                        reqData.bnkLndProdtCd = _bnkLndPrdtCdTextCtrl.text;
                        reqData.bnkLndProdtNm = _bnkLndPrdtNmTextCtrl.text;
                        reqData.stndAplYn = _stndAplYnTextCtrl.text;
                        reqData.mvLwyrCnfmYn = _mvLwyrCnfmYnTextCtrl.text;
                        reqData.rgstrUnqNo1 = _rgstrUnqNo1TextCtrl.text;
                        reqData.rgstrUnqNo2 =_rgstrUnqNo2TextCtrl.text;
                        reqData.rgstrUnqNo3 = _rgstrUnqNo3TextCtrl.text;
                        reqData.rgstrUnqNo4 = _rgstrUnqNo4TextCtrl.text;
                        reqData.rgstrUnqNo5 = _rgstrUnqNo5TextCtrl.text;
                        reqData.rlesDsc = _rlesDscTextCtrl.text;
                        reqData.trgtRlesDsc = _trgtRlesDscTextCtrl.text;
                        reqData.trgtRlesAddr = _trgtRlesAddrTextCtrl.text;
                        reqData.bfAskDt = _bfAskDtTextCtrl.text;
                        reqData.lndPlnDt = _lndPlnDtTextCtrl.text;
                        reqData.slPrc = _slPrcTextCtrl.text;
                        reqData.scrtevlAmt = _scrtEvlAmtTextCtrl.text;
                        reqData.isrnEntrAmt = _isrnEntrAmtTextCtrl.text;
                        reqData.lndAmt = _lndAmtTextCtrl.text;
                        reqData.bnkfxcltRgstrRnk =
                            int.parse(_bnkFxcltRgstrRnkTextCtrl.text);
                        reqData.dbrtNm = _dbtrNmTextCtrl.text;
                        reqData.dbtrBirthDt = _dbtrBirthDtTextCtrl.text;
                        reqData.dbtrAddr = _dbtrAddrTextCtrl.text;
                        reqData.dbtrHpno = _dbtrPhnoTextCtrl.text;
                        reqData.dbtrHpno = _dbtrHpnoTextCtrl.text;
                        reqData.pwpsNm = _pwpsNmTextCtrl.text;
                        reqData.pwpsBirthDt = _pwpsBirthDtTextCtrl.text;
                        reqData.pwpsAddr = _pwpsAddrTextCtrl.text;
                        reqData.pwpsPhno = _pwpsPhnoTextCtrl.text;
                        reqData.pwpsHpno = _pwpsHpnoTextCtrl.text;
                        reqData.rmkFct = _rmkFctTextCtrl.text;
                        reqData.lndHndgSlfDsc = _lndHndgSlfDscTextCtrl.text;
                        reqData.bnkBrnchNm = _bnkBrnchNmTextCtrl.text;
                        reqData.bnkDrctrNm = _bnkDrctrNmTextCtrl.text;
                        reqData.bnkBrnchPhno = _bnkBrnchPhnoTextCtrl.text;
                        reqData.bnkDrctrHp =  _bnkDrctrHpTextCtrl.text;
                        reqData.bnkBrnchFax = _bnkBrnchFaxTextCtrl.text;
                        reqData.bnkBrnchAddr = _bnkBrnchAddrTextCtrl.text;
                        reqData.slmnCmpyNm = _slmnCmpyNmTextCtrl.text;
                        reqData.slmnNm = _slmnNmTextCtrl.text;
                        reqData.slmnPhno = _slmnPhnoTextCtrl.text;
                        reqData.rfrLnAprvNo = _rfrLnAprvNoTextCtrl.text;
                        reqData.rgstrMtdDsc = _rgstrMtdDscTextCtrl.text;
                        reqData.odprtRpyEane = _odprtRpyEaneTextCtrl.text;
                        reqData.eltnEstbsLwyrNm = _eltnEstbsLwyrNmTextCtrl.text;
                        reqData.eltnEstbsLwyrBizNo =
                        _eltnEstbsLwyrBiznoTextCtrl.text;
                        reqData.slCntrctEane = _slCntrctEaneTextCtrl.text;
                        reqData.slCntrctFlnm = _slCntrctFlnmTextCtrl.text;
                        reqData.afrgstrScrtYn = _afrgstrScrtYnTextCtrl.text;
                        reqData.bnkBrnchCd = _bnkBrnchCdTextCtrl.text;
                        reqData.rsrvItmB = _rsrvItmBTextCtrl.text;

                        ResData resData = await controller.setSendPreAsk(reqData);
                        if (resData.code == '00') {
                          IfUtils.alertIcon(
                              resData.msg.toString(), icontype: '');
                        } else {
                          IfUtils.alertIcon('실패', icontype: '');
                        }
                      },
                      child: Text('전문 송신', style: TextSyle.searchFormText()),
                    ),
                      LoadingPage<TrnsSendResData>(
                        stream: PreAskCtrl.to.trnsSendResStream.stream,
                      ),
                    ],
                    ),
                    Spacing.width(10),
                  ],
                ),
                Spacing.height(40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    PayListPage(controller: controller,
                        searchTextCtrl: _searchTextCtrl),
                    Spacing.width(40),
                    Expanded(
                      child: SizedBox(
                        //width: Get.height * 0.5,
                        height: Get.height * 0.8,
                        //width: Get.width * 0.2,
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Spacing.height(40),
                              IfUtils.buildCategory('전문 전송 정보'),
                              Spacing.height(20),
                              IfDivider(width: 0.37),
                              Spacing.height(20),
                              buildTextField('신규 여신 번호 (NEW_LOAN_NO)', _newLoanTextCtrl),
                              Spacing.height(5),
                              buildTextField('전문 길이 (TG_LEN)', _tgLenTextCtrl),
                              Spacing.height(5),
                              buildTextField('전문 구분 코드 (TG_DSC)', _tgDscTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 전문 번호 (BNK_TG_NO)', _bnkTgNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('FA 전문 번호 (FA_TG_NO)', _faTgNoTextCtrl),
                              Spacing.height(5),
                              //buildTextField('코스 전문 송신 번호 (KOS_TG_SND_NO)',
                              //_kosTgSndNoTextCtrl),
                              //Spacing.height(5),
                              // buildTextField('전문 발송 일시', _tgSndDtmTextCtrl),
                              // Spacing.height(5),
                              // buildTextField('전문 수신 일시', _tgRcvDtmTextCtrl),
                              // Spacing.height(5),
                              // buildTextField('응답 코드', _resCdTextCtrl),
                              // Spacing.height(5),
                              buildTextField('예비 항목 H (RSRV_ITM_H)', _rsrvItmHTextCtrl),
                              Spacing.height(5),
                              buildTextField('대출 구분 코드 (LND_DSC)', _lndDscTextCtrl),
                              Spacing.height(5),
                              buildTextField('대출 종류 코드 (LND_KND_CD)', _lndKndCdTextCtrl),
                              Spacing.height(5),
                              buildTextField('자금 용도 코드 (FND_USE_CD)', _fndUseCdTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '은행 대출 상품 코드 (BNK_LND_PRDT_CD)', _bnkLndPrdtCdTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 대출 상품명 (BNK_LND_PRDT_NM)', _bnkLndPrdtNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('표준화 적용 여부 (STND_APL_YN)', _stndAplYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '이전 법무사 확인 여부 (MV_LWYR_CNFM_YN)', _mvLwyrCnfmYnTextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호 1 (RGSTR_UNQ_NO_1)', _rgstrUnqNo1TextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호 2 (RGSTR_UNQ_NO_2)', _rgstrUnqNo2TextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호 3 (RGSTR_UNQ_NO_3)', _rgstrUnqNo3TextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호 4 (RGSTR_UNQ_NO_4)', _rgstrUnqNo4TextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호 5 (RGSTR_UNQ_NO_5)', _rgstrUnqNo5TextCtrl),
                              Spacing.height(5),
                              buildTextField('부동산 구분 코드 (RLES_DSC)', _rlesDscTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대상 부동산 구분 코드 (TRGT_RLES_DSC)', _trgtRlesDscTextCtrl),
                              Spacing.height(5),
                              buildTextField('대상 부동산 주소 (TRGT_RLES_ADDR)', _trgtRlesAddrTextCtrl),
                              Spacing.height(5),
                              buildTextField('사전 의뢰 일자 (BF_ASK_DT)', _bfAskDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('대출 예정 일자 (LND_PLN_DT)', _lndPlnDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('매매 가액 (SL_PRC)', _slPrcTextCtrl),
                              Spacing.height(5),
                              buildTextField('담보 평가 금액 (SCRT_EVL_AMT)', _scrtEvlAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField('보험 가입 금액 (ISRN_ENTR_AMT)', _isrnEntrAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField('대출 금액 (LND_AMT)', _lndAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '은행 근저당권 등기 순위 (BNK_FXCLT_RGSTR_RNK)', _bnkFxcltRgstrRnkTextCtrl),
                              Spacing.height(5),
                              buildTextField('차주명 (DBTR_NM)', _dbtrNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('차주 생년 월일 (DBTR_BIRTH_DT)', _dbtrBirthDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('차주 주소 (DBTR_ADDR)', _dbtrAddrTextCtrl),
                              Spacing.height(5),
                              buildTextField('차주 전화 번호 (DBTR_PHNO)', _dbtrPhnoTextCtrl),
                              Spacing.height(5),
                              buildTextField('차주 핸드폰 번호 (DBTR_HPNO)', _dbtrHpnoTextCtrl),
                              Spacing.height(5),
                              buildTextField('담보 제공자 명 (PWPS_NM)', _pwpsNmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '담보 제공자 생년 월일 (PWPS_BIRTH_DT)', _pwpsBirthDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('담보 제공자 주소 (PWPS_ADDR)', _pwpsAddrTextCtrl),
                              Spacing.height(5),
                              buildTextField('담보 제공자 전화 번호 (PWPS_PHNO)', _pwpsPhnoTextCtrl),
                              Spacing.height(5),
                              buildTextField('담보 제공자 핸드폰 번호 (PWPS_HPNO)', _pwpsHpnoTextCtrl),
                              Spacing.height(5),
                              buildTextField('비고 사항 (RMK_FCT)', _rmkFctTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 취급 주체 구분 코드 (LND_HNDG_SLF_DSC)', _lndHndgSlfDscTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 지점명 (BNK_BRNCH_NM)', _bnkBrnchNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 담당자 명 (BNK_DRCTR_NM)', _bnkDrctrNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 지점 전화 번호 (BNK_BRNCH_PHNO)', _bnkBrnchPhnoTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 담당자 핸드폰 (BNK_DRCTR_HP)', _bnkDrctrHpTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 지점 주소 (BNK_BRNCH_ADDR)', _bnkDrctrHpTextCtrl),
                              Spacing.height(5),
                              buildTextField('모집인 회사명 (SLMN_CMPY_NM)', _slmnCmpyNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('모집인 명 (SLMN_NM)', _slmnCmpyNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('모집인 전화번호 (SLMN_PHNO)', _slmnPhnoTextCtrl),
                              Spacing.height(5),
                              buildTextField('참조 여신 승인번호 (RFR_LN_APRV_NO)', _rfrLnAprvNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 방식 구분 코드 (RGSTR_MTD_DSC)', _rgstrMtdDscTextCtrl),
                              Spacing.height(5),
                              buildTextField('선순위 상환 여부 (ODPRT_RPY_EANE)',_odprtRpyEaneTextCtrl),
                              Spacing.height(5),
                              buildTextField('전자 설정 법무사 명 (ELTN_ESTBS_LWYR_NM)',_eltnEstbsLwyrNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('전자 설정 법무사 사업자 번호 (ELTN_ESTBS_LWYR_BIZNO)',
                                  _eltnEstbsLwyrBiznoTextCtrl),
                              Spacing.height(5),
                              buildTextField('매매 계약서 유무 (SL_CNTRCT_EANE)',_slCntrctEaneTextCtrl),
                              Spacing.height(5),
                              buildTextField('매매 계약서 파일명 (SL_CNTRCT_FLNM)',_slCntrctFlnmTextCtrl),
                              Spacing.height(5),
                              buildTextField('후취 담보 여부 (AFRGSTR_SCRT_YN)', _afrgstrScrtYnTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 지점 코드 (BNK_BRNCH_CD)', _bnkBrnchCdTextCtrl),
                              Spacing.height(5),
                              buildTextField('예비 항목 B (RSRV_ITM_B)', _rsrvItmBTextCtrl),
                           ],
                         ),
                       ),
                     ),
                   ),
                  ],
                ),
              ],
            ),
          );
        });
  }

  Widget buildTextField(String text, TextEditingController textCtrl) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: Get.width * 0.25,
          child: MouseRegion(
            cursor: SystemMouseCursors.text, // 마우스 커서 변경
            child: SelectableText(
              text,
              style: TextSyle.text(),
            ),
          ),
        ),
        IfTextFormField.trans(
          controller: textCtrl,
          textStyle: TextSyle.inputFormText(),
        ),
      ],
    );
  }
}
