import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/repo/data/ask_db_tran_data.dart';
import 'package:nicekos_interface_flutter/repo/data/cntr_detail_data.dart';
import 'package:nicekos_interface_flutter/repo/response/res_data.dart';
import 'package:nicekos_interface_flutter/utils/if_utils.dart';
import 'package:nicekos_interface_flutter/widget/if_divider.dart';
import 'package:nicekos_interface_flutter/widget/if_text_form_field.dart';
import 'package:nicekos_interface_flutter/theme/text_style.dart';
import '../../repo/data/ask_db_send_data.dart';
import '../../repo/data/trns_6100_send_data.dart';
import '../../repo/response/res_stream.dart';
import '../../utils/if_format.dart';
import '../../widget/If_button.dart';
import '../../theme/colors.dart';
import '../../theme/spacing.dart';
import '../comm/loading_page.dart';
import '../comm/pay_list_page.dart';
import 'ctrl/ask_db_ctrl.dart';

class AskDbPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _AskDbPageState();
}

class _AskDbPageState extends State<AskDbPage> with TickerProviderStateMixin {
  late AskDbCtrl controller;

  CntrDetailResData cntrDtl = CntrDetailResData();
  AskDbTranResData trnsDtl = AskDbTranResData();

  // StreamController<ResStream<Trns6100SendResData>> trnsSendResStream =
  // StreamController<ResStream<Trns6100SendResData>>.broadcast();
  late TextEditingController _searchTextCtrl;
  late TextEditingController _newLoanNoTextCtrl;
  late TextEditingController _tgLenTextCtrl;
  late TextEditingController _tgDscTextCtrl;
  late TextEditingController _resCdTextCtrl;
  late TextEditingController _lndAgncCdTextCtrl;
  late TextEditingController _bnkTgTrnsDtmTextCtrl;
  late TextEditingController _dbTgTrnsDtmTextCtrl;
  late TextEditingController _bnkTgNoTextCtrl;
  late TextEditingController _dbTgNoTextCtrl;
  late TextEditingController _rsrvItmHTextCtrl;
  late TextEditingController _bnkAskNoTextCtrl;
  late TextEditingController _dbMngNoTextCtrl;
  late TextEditingController _kosTgTrnsDtmTextCtrl;
  late TextEditingController _kosTgNoTextCtrl;
  late TextEditingController _procDvsnCdTextCtrl;
  late TextEditingController _rthIsrnEntrYnTextCtrl;
  late TextEditingController _rthIsrnEntrCmpyTextCtrl;
  late TextEditingController _rthIsrnScrtNoTextCtrl;
  late TextEditingController _pstNoTextCtrl;
  late TextEditingController _crtdnCdTextCtrl;
  late TextEditingController _trgtAddrTextCtrl;
  late TextEditingController _trgtDtlAddrTextCtrl;
  late TextEditingController _rgstrUnqNo1TextCtrl;
  late TextEditingController _rgstrUnqNo2TextCtrl;
  late TextEditingController _rgstrUnqNo3TextCtrl;
  late TextEditingController _lndKndCdTextCtrl;
  late TextEditingController _fndYnTextCtrl;
  late TextEditingController _prdtNmTextCtrl;
  late TextEditingController _prdtCdTextCtrl;
  late TextEditingController _grntAgncCdTextCtrl;
  late TextEditingController _srvTrgtYnTextCtrl;
  late TextEditingController _stndTrgtYnTextCtrl;
  late TextEditingController _rrcpChrgTrgtYnTextCtrl;
  late TextEditingController _rvsnCntrctChrgTrgtYnTextCtrl;
  late TextEditingController _sscptAskDtTextCtrl;
  late TextEditingController _lndPlnDtTextCtrl;
  late TextEditingController _rntlPrdEndDtTextCtrl;
  late TextEditingController _lndExprdDtTextCtrl;
  late TextEditingController _lndPrdTextCtrl;
  late TextEditingController _lndAmtTextCtrl;
  late TextEditingController _isrnEntrAmtTextCtrl;
  late TextEditingController _objtEbnkRgstrRnkTextCtrl;
  late TextEditingController _objtEbnkBndMaxAmtTextCtrl;
  late TextEditingController _mggFnlOdprtAmtTextCtrl;
  late TextEditingController _trolFnlOdprtAmtTextCtrl;
  late TextEditingController _srvcEndDtTextCtrl;
  late TextEditingController _dbtrNmTextCtrl;
  late TextEditingController _dbtrRrnoTextCtrl;
  late TextEditingController _dbtrPstNoTextCtrl;
  late TextEditingController _dbtrAddrTextCtrl;
  late TextEditingController _dbtrPhnoTextCtrl;
  late TextEditingController _dbtrHpnoTextCtrl;
  late TextEditingController _wdngPlnYnTextCtrl;
  late TextEditingController _wdngPlnDtTextCtrl;
  late TextEditingController _hshldrCnddtYnTextCtrl;
  late TextEditingController _unmrdHshldr25agLstnYnTextCtrl;
  late TextEditingController _acptDscTextCtrl;
  late TextEditingController _lwfmNmTextCtrl;
  late TextEditingController _lwfmBiznoTextCtrl;
  late TextEditingController _askBrnchCdTextCtrl;
  late TextEditingController _askBrnchNmTextCtrl;
  late TextEditingController _askBrnchDrctrNmTextCtrl;
  late TextEditingController _askBrnchPhnoTextCtrl;
  late TextEditingController _bnkLesDscTextCtrl;
  late TextEditingController _fndLesDscTextCtrl;
  late TextEditingController _cndtlCntsTextCtrl;
  late TextEditingController _isrnPrmmTextCtrl;
  late TextEditingController _rsrvItmBTextCtrl;
  late TextEditingController _regDtmTextCtrl;
  late TextEditingController _loanAprvNo2TextCtrl;

  @override
  void initState() {
    super.initState();
    if (Get.isRegistered<AskDbCtrl>()) {
      Get.delete<AskDbCtrl>();
    }
    controller = Get.put(AskDbCtrl());
    _searchTextCtrl = TextEditingController();
    _newLoanNoTextCtrl = TextEditingController();
    _tgLenTextCtrl = TextEditingController();
    _tgDscTextCtrl = TextEditingController();
    _resCdTextCtrl = TextEditingController();
    _lndAgncCdTextCtrl = TextEditingController();
    _bnkTgTrnsDtmTextCtrl = TextEditingController();
    _dbTgTrnsDtmTextCtrl = TextEditingController();
    _bnkTgNoTextCtrl = TextEditingController();
    _dbTgNoTextCtrl = TextEditingController();
    _rsrvItmHTextCtrl = TextEditingController();
    _bnkAskNoTextCtrl = TextEditingController();
    _dbMngNoTextCtrl = TextEditingController();
    _kosTgTrnsDtmTextCtrl = TextEditingController();
    _kosTgNoTextCtrl = TextEditingController();
    _procDvsnCdTextCtrl = TextEditingController();
    _rthIsrnEntrYnTextCtrl = TextEditingController();
    _rthIsrnEntrCmpyTextCtrl = TextEditingController();
    _rthIsrnScrtNoTextCtrl = TextEditingController();
    _pstNoTextCtrl = TextEditingController();
    _crtdnCdTextCtrl = TextEditingController();
    _trgtAddrTextCtrl = TextEditingController();
    _trgtDtlAddrTextCtrl = TextEditingController();
    _rgstrUnqNo1TextCtrl = TextEditingController();
    _rgstrUnqNo2TextCtrl = TextEditingController();
    _rgstrUnqNo3TextCtrl = TextEditingController();
    _lndKndCdTextCtrl = TextEditingController();
    _fndYnTextCtrl = TextEditingController();
    _prdtNmTextCtrl = TextEditingController();
    _prdtCdTextCtrl = TextEditingController();
    _grntAgncCdTextCtrl = TextEditingController();
    _srvTrgtYnTextCtrl = TextEditingController();
    _stndTrgtYnTextCtrl = TextEditingController();
    _rrcpChrgTrgtYnTextCtrl = TextEditingController();
    _rvsnCntrctChrgTrgtYnTextCtrl = TextEditingController();
    _sscptAskDtTextCtrl = TextEditingController();
    _lndPlnDtTextCtrl = TextEditingController();
    _rntlPrdEndDtTextCtrl = TextEditingController();
    _lndExprdDtTextCtrl = TextEditingController();
    _lndPrdTextCtrl = TextEditingController();
    _lndAmtTextCtrl = TextEditingController();
    _isrnEntrAmtTextCtrl = TextEditingController();
    _objtEbnkRgstrRnkTextCtrl = TextEditingController();
    _objtEbnkBndMaxAmtTextCtrl = TextEditingController();
    _mggFnlOdprtAmtTextCtrl = TextEditingController();
    _trolFnlOdprtAmtTextCtrl = TextEditingController();
    _srvcEndDtTextCtrl = TextEditingController();
    _dbtrNmTextCtrl = TextEditingController();
    _dbtrRrnoTextCtrl = TextEditingController();
    _dbtrPstNoTextCtrl = TextEditingController();
    _dbtrAddrTextCtrl = TextEditingController();
    _dbtrPhnoTextCtrl = TextEditingController();
    _dbtrHpnoTextCtrl = TextEditingController();
    _wdngPlnYnTextCtrl = TextEditingController();
    _wdngPlnDtTextCtrl = TextEditingController();
    _hshldrCnddtYnTextCtrl = TextEditingController();
    _unmrdHshldr25agLstnYnTextCtrl = TextEditingController();
    _acptDscTextCtrl = TextEditingController();
    _lwfmNmTextCtrl = TextEditingController();
    _lwfmBiznoTextCtrl = TextEditingController();
    _askBrnchCdTextCtrl = TextEditingController();
    _askBrnchNmTextCtrl = TextEditingController();
    _askBrnchDrctrNmTextCtrl = TextEditingController();
    _askBrnchPhnoTextCtrl = TextEditingController();
    _bnkLesDscTextCtrl = TextEditingController();
    _fndLesDscTextCtrl = TextEditingController();
    _cndtlCntsTextCtrl = TextEditingController();
    _isrnPrmmTextCtrl = TextEditingController();
    _rsrvItmBTextCtrl = TextEditingController();
    _regDtmTextCtrl = TextEditingController();
    _loanAprvNo2TextCtrl = TextEditingController();
  }

  @override
  void dispose() {
    super.dispose();
    if (Get.isRegistered<AskDbCtrl>()) {
      Get.delete<AskDbCtrl>();
    }
    controller.dispose();
    _searchTextCtrl = TextEditingController();
    _newLoanNoTextCtrl = TextEditingController();
    _tgLenTextCtrl = TextEditingController();
    _tgDscTextCtrl = TextEditingController();
    _resCdTextCtrl = TextEditingController();
    _lndAgncCdTextCtrl = TextEditingController();
    _bnkTgTrnsDtmTextCtrl = TextEditingController();
    _dbTgTrnsDtmTextCtrl = TextEditingController();
    _bnkTgNoTextCtrl = TextEditingController();
    _dbTgNoTextCtrl = TextEditingController();
    _rsrvItmHTextCtrl = TextEditingController();
    _bnkAskNoTextCtrl = TextEditingController();
    _dbMngNoTextCtrl = TextEditingController();
    _kosTgTrnsDtmTextCtrl = TextEditingController();
    _kosTgNoTextCtrl = TextEditingController();
    _procDvsnCdTextCtrl = TextEditingController();
    _rthIsrnEntrYnTextCtrl = TextEditingController();
    _rthIsrnEntrCmpyTextCtrl = TextEditingController();
    _rthIsrnScrtNoTextCtrl = TextEditingController();
    _pstNoTextCtrl = TextEditingController();
    _crtdnCdTextCtrl = TextEditingController();
    _trgtAddrTextCtrl = TextEditingController();
    _trgtDtlAddrTextCtrl = TextEditingController();
    _rgstrUnqNo1TextCtrl = TextEditingController();
    _rgstrUnqNo2TextCtrl = TextEditingController();
    _rgstrUnqNo3TextCtrl = TextEditingController();
    _lndKndCdTextCtrl = TextEditingController();
    _fndYnTextCtrl = TextEditingController();
    _prdtNmTextCtrl = TextEditingController();
    _prdtCdTextCtrl = TextEditingController();
    _grntAgncCdTextCtrl = TextEditingController();
    _srvTrgtYnTextCtrl = TextEditingController();
    _stndTrgtYnTextCtrl = TextEditingController();
    _rrcpChrgTrgtYnTextCtrl = TextEditingController();
    _rvsnCntrctChrgTrgtYnTextCtrl = TextEditingController();
    _sscptAskDtTextCtrl = TextEditingController();
    _lndPlnDtTextCtrl = TextEditingController();
    _rntlPrdEndDtTextCtrl = TextEditingController();
    _lndExprdDtTextCtrl = TextEditingController();
    _lndPrdTextCtrl = TextEditingController();
    _lndAmtTextCtrl = TextEditingController();
    _isrnEntrAmtTextCtrl = TextEditingController();
    _objtEbnkRgstrRnkTextCtrl = TextEditingController();
    _objtEbnkBndMaxAmtTextCtrl = TextEditingController();
    _mggFnlOdprtAmtTextCtrl = TextEditingController();
    _trolFnlOdprtAmtTextCtrl = TextEditingController();
    _srvcEndDtTextCtrl = TextEditingController();
    _dbtrNmTextCtrl = TextEditingController();
    _dbtrRrnoTextCtrl = TextEditingController();
    _dbtrPstNoTextCtrl = TextEditingController();
    _dbtrAddrTextCtrl = TextEditingController();
    _dbtrPhnoTextCtrl = TextEditingController();
    _dbtrHpnoTextCtrl = TextEditingController();
    _wdngPlnYnTextCtrl = TextEditingController();
    _wdngPlnDtTextCtrl = TextEditingController();
    _hshldrCnddtYnTextCtrl = TextEditingController();
    _unmrdHshldr25agLstnYnTextCtrl = TextEditingController();
    _acptDscTextCtrl = TextEditingController();
    _lwfmNmTextCtrl = TextEditingController();
    _lwfmBiznoTextCtrl = TextEditingController();
    _askBrnchCdTextCtrl = TextEditingController();
    _askBrnchNmTextCtrl = TextEditingController();
    _askBrnchDrctrNmTextCtrl = TextEditingController();
    _askBrnchPhnoTextCtrl = TextEditingController();
    _bnkLesDscTextCtrl = TextEditingController();
    _fndLesDscTextCtrl = TextEditingController();
    _cndtlCntsTextCtrl = TextEditingController();
    _isrnPrmmTextCtrl = TextEditingController();
    _rsrvItmBTextCtrl = TextEditingController();
    _regDtmTextCtrl = TextEditingController();
    _loanAprvNo2TextCtrl = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
        init: controller,
        builder: (controller) {
          return Container(
            margin:
                const EdgeInsets.only(left: 50, top: 20, bottom: 20, right: 50),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 20),
                      child: IfTextFormField.search(
                        controller: _searchTextCtrl,
                        textStyle: TextSyle.searchFormText(),
                      ),
                    ),
                    Spacing.width(20),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          return;
                        }
                        ResData resData =
                            await controller.getCntrDtl(_searchTextCtrl.text);
                        if (resData.code == '00') {
                          cntrDtl = controller.cntrDetailResData;
                          IfUtils.alertIcon(resData.msg.toString(),
                              icontype: '');
                        }
                      },
                      child: Text('검색', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          IfUtils.alertIcon("검색 후 전문 복사", icontype: 'W');
                          return;
                        }
                        ResData resData =
                            await controller.getTrnsDtl(_searchTextCtrl.text);
                        // Lo.g('resData: $resData');
                        if (resData.code == '00') {
                          trnsDtl = controller.askDbTranResData;
                          _newLoanNoTextCtrl.text = trnsDtl.newLoanNo ?? '';
                          _tgLenTextCtrl.text = trnsDtl.tgLen.toString();
                          _tgDscTextCtrl.text = trnsDtl.tgDsc ?? '';
                          _resCdTextCtrl.text = trnsDtl.resCd ?? '';
                          _lndAgncCdTextCtrl.text = trnsDtl.lndAgncCd ?? '';
                          _bnkTgTrnsDtmTextCtrl.text =
                              trnsDtl.bnkTgTrnsDtm ?? '';
                          _dbTgTrnsDtmTextCtrl.text = trnsDtl.dbTgTrnsDtm ?? '';
                          _bnkTgNoTextCtrl.text = trnsDtl.bnkTgNo ?? '';
                          _dbTgNoTextCtrl.text = trnsDtl.dbTgNo.toString();
                          _rsrvItmHTextCtrl.text = trnsDtl.rsrvItmH ?? '';
                          _bnkAskNoTextCtrl.text = trnsDtl.bnkAskNo ?? '';
                          _dbMngNoTextCtrl.text = trnsDtl.dbMngNo ?? '';
                          _kosTgTrnsDtmTextCtrl.text =
                              trnsDtl.kosTgTrnsDtm ?? '';
                          _kosTgNoTextCtrl.text = trnsDtl.kosTgNo ?? '';
                          _procDvsnCdTextCtrl.text = trnsDtl.procDvsnCd ?? '';
                          _rthIsrnEntrYnTextCtrl.text =
                              trnsDtl.rthIsrnEntrYn ?? '';
                          _rthIsrnEntrCmpyTextCtrl.text =
                              trnsDtl.rthIsrnEntrCmpy ?? '';
                          _rthIsrnScrtNoTextCtrl.text =
                              trnsDtl.rthIsrnScrtNo ?? '';
                          _pstNoTextCtrl.text = trnsDtl.pstNo ?? '';
                          _crtdnCdTextCtrl.text = trnsDtl.crtdnCd ?? '';
                          _trgtAddrTextCtrl.text = trnsDtl.trgtAddr ?? '';
                          _trgtDtlAddrTextCtrl.text = trnsDtl.trgtDtlAddr ?? '';
                          _rgstrUnqNo1TextCtrl.text = trnsDtl.rgstrUnqNo1 ?? '';
                          _rgstrUnqNo2TextCtrl.text = trnsDtl.rgstrUnqNo2 ?? '';
                          _rgstrUnqNo3TextCtrl.text = trnsDtl.rgstrUnqNo3 ?? '';
                          _lndKndCdTextCtrl.text = trnsDtl.lndKndCd ?? '';
                          _fndYnTextCtrl.text = trnsDtl.fndYn ?? '';
                          _prdtNmTextCtrl.text = trnsDtl.prdtNm ?? '';
                          _prdtCdTextCtrl.text = trnsDtl.prdtCd ?? '';
                          _grntAgncCdTextCtrl.text = trnsDtl.grntAgncCd ?? '';
                          _srvTrgtYnTextCtrl.text = trnsDtl.srvTrgtYn ?? '';
                          _stndTrgtYnTextCtrl.text = trnsDtl.stndTrgtYn ?? '';
                          _rrcpChrgTrgtYnTextCtrl.text =
                              trnsDtl.rrcpChrgTrgtYn ?? '';
                          _rvsnCntrctChrgTrgtYnTextCtrl.text =
                              trnsDtl.rvsnCntrctChrgTrgtYn ?? '';
                          _sscptAskDtTextCtrl.text = trnsDtl.sscptAskDt ?? '';
                          _lndPlnDtTextCtrl.text = trnsDtl.lndPlnDt ?? '';
                          _rntlPrdEndDtTextCtrl.text =
                              trnsDtl.rntlPrdEndDt ?? '';
                          _lndExprdDtTextCtrl.text = trnsDtl.lndExprdDt ?? '';
                          _lndPrdTextCtrl.text = trnsDtl.lndPrd.toString();
                          _lndAmtTextCtrl.text = trnsDtl.lndAmt.toString();
                          _isrnEntrAmtTextCtrl.text =
                              trnsDtl.isrnEntrAmt.toString();
                          _objtEbnkRgstrRnkTextCtrl.text =
                              trnsDtl.objtEbnkRgstrRnk.toString();
                          _objtEbnkBndMaxAmtTextCtrl.text =
                              trnsDtl.objtEbnkBndMaxAmt.toString();
                          _mggFnlOdprtAmtTextCtrl.text =
                              trnsDtl.mggFnlOdprtAmt.toString();
                          _trolFnlOdprtAmtTextCtrl.text =
                              trnsDtl.trolFnlOdprtAmt.toString();
                          _srvcEndDtTextCtrl.text = trnsDtl.srvcEndDt ?? '';
                          _dbtrNmTextCtrl.text = trnsDtl.dbtrNm ?? '';
                          // _dbtrNmTextCtrl.text = trnsDtl.dbtrNm ?? '이상협';
                          _dbtrRrnoTextCtrl.text = trnsDtl.dbtrRrno ?? '';
                          _dbtrPstNoTextCtrl.text = trnsDtl.dbtrPstNo ?? '';
                          _dbtrAddrTextCtrl.text = trnsDtl.dbtrAddr ?? '';
                          _dbtrPhnoTextCtrl.text = trnsDtl.dbtrPhno ?? '';
                          // _dbtrPhnoTextCtrl.text = '01099274288';
                          _dbtrHpnoTextCtrl.text = trnsDtl.dbtrHpno ?? '';
                          // _dbtrHpnoTextCtrl.text = '01099274288';
                          _wdngPlnYnTextCtrl.text = trnsDtl.wdngPlnYn ?? '';
                          _wdngPlnDtTextCtrl.text = trnsDtl.wdngPlnDt ?? '';
                          _hshldrCnddtYnTextCtrl.text =
                              trnsDtl.hshldrCnddtYn ?? '';
                          _unmrdHshldr25agLstnYnTextCtrl.text =
                              trnsDtl.unmrdHshldr25agLstnYn ?? '';
                          _acptDscTextCtrl.text = trnsDtl.acptDsc ?? '';
                          _lwfmNmTextCtrl.text = trnsDtl.lwfmNm ?? '';
                          _lwfmBiznoTextCtrl.text = trnsDtl.lwfmBizno ?? '';
                          _askBrnchCdTextCtrl.text = trnsDtl.askBrnchCd ?? '';
                          _askBrnchNmTextCtrl.text = trnsDtl.askBrnchNm ?? '';
                          _askBrnchDrctrNmTextCtrl.text =
                              trnsDtl.askBrnchDrctrNm ?? '';
                          _askBrnchPhnoTextCtrl.text =
                              trnsDtl.askBrnchPhno ?? '';
                          _bnkLesDscTextCtrl.text = trnsDtl.bnkLesDsc ?? '';
                          _fndLesDscTextCtrl.text = trnsDtl.fndLesDsc ?? '';
                          _cndtlCntsTextCtrl.text = trnsDtl.cndtlCnts ?? '';
                          _isrnPrmmTextCtrl.text = trnsDtl.isrnPrmm ?? '';
                          _rsrvItmBTextCtrl.text = trnsDtl.rsrvItmB ?? '';
                          _regDtmTextCtrl.text = trnsDtl.regDtm ?? '';
                          _loanAprvNo2TextCtrl.text = trnsDtl.loanAprvNo2 ?? '';

                          IfUtils.alertIcon(resData.msg.toString(),
                              icontype: '');
                        } else {
                          IfUtils.alertIcon(resData.msg.toString(),
                              icontype: 'W');
                        }
                      },
                      child: Text('전문 복사', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    Row(
                      children: [
                        IfButton(
                          elevation: 0,
                          padding: Spacing.xy(40, 20),
                          backgroundColor: canvasColor,
                          borderRadiusAll: 5,
                          onPressed: () async {
                            if (_searchTextCtrl.text.isEmpty) {
                              IfUtils.alertIcon("전문 복사 후 전문 송신", icontype: 'W');
                              return;
                            }
                            AskDbSendReqData reqData = AskDbSendReqData();
                            reqData.loanNo = _searchTextCtrl.text;
                            reqData.newLoanNo = _newLoanNoTextCtrl.text;
                            reqData.tgLen = int.parse(_tgLenTextCtrl.text);
                            reqData.tgDsc = _tgDscTextCtrl.text;
                            reqData.lndAgncCd = _lndAgncCdTextCtrl.text;
                            reqData.bnkTgTrnsDtm = _bnkTgTrnsDtmTextCtrl.text;
                            reqData.dbTgTrnsDtm = _dbTgTrnsDtmTextCtrl.text;
                            reqData.bnkTgNo = _bnkTgNoTextCtrl.text;
                            reqData.dbTgNo = int.parse(_dbTgNoTextCtrl.text);
                            reqData.rsrvItmH = _rsrvItmHTextCtrl.text;
                            reqData.bnkAskNo = _bnkAskNoTextCtrl.text;
                            reqData.dbMngNo = _dbMngNoTextCtrl.text;
                            reqData.kosTgTrnsDtm = _kosTgTrnsDtmTextCtrl.text;
                            reqData.kosTgNo = _kosTgNoTextCtrl.text;
                            reqData.procDvsnCd = _procDvsnCdTextCtrl.text;
                            reqData.rthIsrnEntrYn = _rthIsrnEntrYnTextCtrl.text;
                            reqData.rthIsrnEntrCmpy =
                                _rthIsrnEntrCmpyTextCtrl.text;
                            reqData.rthIsrnScrtNo = _rthIsrnScrtNoTextCtrl.text;
                            reqData.pstNo = _pstNoTextCtrl.text;
                            reqData.crtdnCd = _crtdnCdTextCtrl.text;
                            reqData.trgtAddr = _trgtAddrTextCtrl.text;
                            reqData.trgtDtlAddr = _trgtDtlAddrTextCtrl.text;
                            reqData.rgstrUnqNo1 = _rgstrUnqNo1TextCtrl.text;
                            reqData.rgstrUnqNo2 = _rgstrUnqNo2TextCtrl.text;
                            reqData.rgstrUnqNo3 = _rgstrUnqNo3TextCtrl.text;
                            reqData.lndKndCd = _lndKndCdTextCtrl.text;
                            reqData.fndYn = _fndYnTextCtrl.text;
                            reqData.prdtNm = _prdtNmTextCtrl.text;
                            reqData.prdtCd = _prdtCdTextCtrl.text;
                            reqData.grntAgncCd = _grntAgncCdTextCtrl.text;
                            reqData.srvTrgtYn = _srvTrgtYnTextCtrl.text;
                            reqData.stndTrgtYn = _stndTrgtYnTextCtrl.text;
                            reqData.rrcpChrgTrgtYn =
                                _rrcpChrgTrgtYnTextCtrl.text;
                            reqData.rvsnCntrctChrgTrgtYn =
                                _rvsnCntrctChrgTrgtYnTextCtrl.text;
                            reqData.sscptAskDt = _sscptAskDtTextCtrl.text;
                            reqData.lndPlnDt = _lndPlnDtTextCtrl.text;
                            reqData.rntlPrdEndDt = _rntlPrdEndDtTextCtrl.text;
                            reqData.lndExprdDt = _lndExprdDtTextCtrl.text;
                            reqData.lndPrd = int.parse(_lndPrdTextCtrl.text);
                            reqData.lndAmt = int.parse(_lndAmtTextCtrl.text);
                            reqData.isrnEntrAmt =
                                int.parse(_isrnEntrAmtTextCtrl.text);
                            reqData.objtEbnkRgstrRnk =
                                int.parse(_objtEbnkRgstrRnkTextCtrl.text);
                            reqData.objtEbnkBndMaxAmt =
                                int.parse(_objtEbnkBndMaxAmtTextCtrl.text);
                            reqData.mggFnlOdprtAmt =
                                int.parse(_mggFnlOdprtAmtTextCtrl.text);
                            reqData.trolFnlOdprtAmt =
                                int.parse(_trolFnlOdprtAmtTextCtrl.text);
                            reqData.srvcEndDt = _srvcEndDtTextCtrl.text;
                            reqData.dbtrNm = _dbtrNmTextCtrl.text;
                            reqData.dbtrRrno = _dbtrRrnoTextCtrl.text;
                            reqData.dbtrPstNo = _dbtrPstNoTextCtrl.text;
                            reqData.dbtrAddr = _dbtrAddrTextCtrl.text;
                            reqData.dbtrPhno = _dbtrPhnoTextCtrl.text;
                            reqData.dbtrHpno = _dbtrHpnoTextCtrl.text;
                            reqData.wdngPlnYn = _wdngPlnYnTextCtrl.text;
                            reqData.wdngPlnDt = _wdngPlnDtTextCtrl.text;
                            reqData.hshldrCnddtYn = _hshldrCnddtYnTextCtrl.text;
                            reqData.unmrdHshldr25agLstnYn =
                                _unmrdHshldr25agLstnYnTextCtrl.text;
                            reqData.acptDsc = _acptDscTextCtrl.text;
                            reqData.lwfmNm = _lwfmNmTextCtrl.text;
                            reqData.lwfmBizno = _lwfmBiznoTextCtrl.text;
                            reqData.askBrnchCd = _askBrnchCdTextCtrl.text;
                            reqData.askBrnchNm = _askBrnchNmTextCtrl.text;
                            reqData.askBrnchDrctrNm =
                                _askBrnchDrctrNmTextCtrl.text;
                            reqData.askBrnchPhno = _askBrnchPhnoTextCtrl.text;
                            reqData.bnkLesDsc = _bnkLesDscTextCtrl.text;
                            reqData.fndLesDsc = _fndLesDscTextCtrl.text;
                            reqData.cndtlCnts = _cndtlCntsTextCtrl.text;
                            reqData.isrnPrmm = _isrnPrmmTextCtrl.text;
                            reqData.rsrvItmB = _rsrvItmBTextCtrl.text;
                            reqData.loanAprvNo2 = _loanAprvNo2TextCtrl.text;

                            ResData resData =
                                await controller.setSendAsk(reqData);
                            if (resData.code == '00') {
                              IfUtils.alertIcon(resData.msg.toString(),
                                  icontype: '');
                            } else {
                              IfUtils.alertIcon('실패', icontype: '');
                            }
                          },
                          child:
                              Text('전문 송신', style: TextSyle.searchFormText()),
                        ),
                        LoadingPage<AskDbSendResData>(
                          stream: AskDbCtrl.to.trnSendResStream.stream,
                        ),
                      ],
                    ),
                    Spacing.width(10),
                  ],
                ),
                Spacing.height(40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    PayListPage(
                        controller: controller,
                        searchTextCtrl: _searchTextCtrl),
                    Spacing.width(40),
                    Spacing.width(10),
                    Expanded(
                      child: SizedBox(
                        height: Get.height * 0.8,
                        //width: Get.width * 0.2,
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Spacing.height(40),
                              IfUtils.buildCategory('전문 전송 정보'),
                              Spacing.height(20),
                              IfDivider(width: 0.37),
                              Spacing.height(20),
                              buildTextField(
                                  '신규 여신 번호 (NEW_LOAN_NO)', _newLoanNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('전문 길이 (TG_LEN)', _tgLenTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전문 구분 코드 (TG_DSC)', _tgDscTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 기관 코드 (LND_AGNC_CD)', _lndAgncCdTextCtrl),
                              Spacing.height(5),
                              // buildTextField('은행 전문 전송 일시', _bnkTgTrnsDtmTextCtrl),
                              // Spacing.height(5),
                              // buildTextField('DB 전문 전송 일시', _dbTgTrnsDtmTextCtrl),
                              // Spacing.height(5),
                              buildTextField(
                                  '은행 전문 번호 (BNK_TG_NO)', _bnkTgNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  'DB 전문 번호 (DB_TG_NO)', _dbTgNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '예비 항목 H (RSRV_ITM_H)', _rsrvItmHTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '은행 의뢰 번호 (BNK_ASK_NO)', _bnkAskNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  'DB 관리 번호 (DB_MNG_NO)', _dbMngNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('KOS 전문 전송 일시 (KOS_TG_TRNS_DTM)',
                                  _kosTgTrnsDtmTextCtrl),
                              Spacing.height(5),
                              buildTextField('처리 구분 코드 (PROC_DVSN_CD)',
                                  _procDvsnCdTextCtrl),
                              Spacing.height(5),
                              buildTextField('권리 보험 가입 여부 (RTH_ISRN_ENTR_YN)',
                                  _rthIsrnEntrYnTextCtrl),
                              Spacing.height(5),
                              buildTextField('권리 보험 가입 회사 (RTH_ISRN_ENTR_CMPY)',
                                  _rthIsrnEntrCmpyTextCtrl),
                              Spacing.height(5),
                              buildTextField('권리 보험 증권 번호 (RTH_ISRN_SCRT_NO)',
                                  _rthIsrnScrtNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('우편 번호 (PST_NO)', _pstNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '법정동 코드 (CRTDN_CD)', _crtdnCdTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대상 주소 (TRGT_ADDR)', _trgtAddrTextCtrl),
                              Spacing.height(5),
                              buildTextField('대상 상세 주소 (TRGT_DTL_ADDR)',
                                  _trgtDtlAddrTextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호1 (RGSTR_UNQ_NO_1)',
                                  _rgstrUnqNo1TextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호2 (RGSTR_UNQ_NO_2)',
                                  _rgstrUnqNo2TextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호3 (RGSTR_UNQ_NO_3)',
                                  _rgstrUnqNo3TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 종류 코드 (LND_KND_CD)', _lndKndCdTextCtrl),
                              Spacing.height(5),
                              buildTextField('기금 여부 (FND_YN)', _fndYnTextCtrl),
                              Spacing.height(5),
                              buildTextField('상품명 (PRDT_NM)', _prdtNmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상품 코드 (PRDT_CD)', _prdtCdTextCtrl),
                              Spacing.height(5),
                              buildTextField('보증 기관 코드 (GRNT_AGNC_CD)',
                                  _grntAgncCdTextCtrl),
                              Spacing.height(5),
                              buildTextField('표준화 대상 여부 (STND_TRGT_YN)',
                                  _stndTrgtYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '주민등록등본 징구 대상 여부 (RRCP_CHRG_TRGT_YN)',
                                  _rrcpChrgTrgtYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '수정계약서 징구 대상 여부 (RVSN_CNTRCT_CHRG_TRGT_YN)',
                                  _rvsnCntrctChrgTrgtYnTextCtrl),
                              Spacing.height(5),
                              buildTextField('청약 의뢰 일자 (SSCPT_ASK_DT)',
                                  _sscptAskDtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 예정 일자 (LND_PLN_DT)', _lndPlnDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('임대차 기간 종료 일자 (RNTL_PRD_END_DT)',
                                  _rntlPrdEndDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('대출 만기 일자 (LND_EXPRD_DT)',
                                  _lndExprdDtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 기간 (LND_PRD)', _lndPrdTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 금액 (LND_AMT)', _lndAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField('보험 가입 금액 (ISRN_ENTR_AMT)',
                                  _isrnEntrAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '목적물 당행 등기 순위 (OBJT_EBNK_RGSTR_RNK)',
                                  _objtEbnkRgstrRnkTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '목적물 당행 채권 최고 금액 (OBJT_EBNK_BND_MAX_AMT)',
                                  _objtEbnkBndMaxAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '저당권 최종 선순위 금액 (MGG_FNL_ODPRT_AMT)',
                                  _mggFnlOdprtAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '임차권 최종 선순위 금액 (TROL_FNL_ODPRT_AMT)',
                                  _trolFnlOdprtAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField('서비스 종료 일자 (SRVC_END_DT)',
                                  _srvcEndDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('차주 명 (DBTR_NM)', _dbtrNmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '차주 주민등록번호 (DBTR_RRNO)', _dbtrRrnoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '차주 우편 번호 (DBTR_PST_NO)', _dbtrPstNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '차주 주소 (DBTR_ADDR)', _dbtrAddrTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '차주 연락처 (DBTR_PHNO)', _dbtrPhnoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '차주 핸드폰 번호 (DBTR_HPNO)', _dbtrHpnoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '결혼 예정 여부 (WDNG_PLN_YN)', _wdngPlnYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '결혼 예정 일자 (WDNG_PLN_DT)', _wdngPlnDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('세대주 예정자 여부 (HSHLDR_CNDDT_YN)',
                                  _hshldrCnddtYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '미혼세대주25세미만여부 (UNMRD_HSHLDR_25AG_LSTN_YN)',
                                  _unmrdHshldr25agLstnYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '접수 구분 코드 (ACPT_DSC)', _acptDscTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '법무 법인 명 (LWFM_NM)', _lwfmNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('법무법인 사업자 등록번호 (LWFM_BIZNO)',
                                  _lwfmBiznoTextCtrl),
                              Spacing.height(5),
                              buildTextField('의뢰 지점 코드 (ASK_BRNCH_CD)',
                                  _askBrnchCdTextCtrl),
                              Spacing.height(5),
                              buildTextField('의뢰 지점 명 (ASK_BRNCH_NM)',
                                  _askBrnchNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('의뢰 지점 담당자 명 (ASK_BRNCH_DRCTR_NM)',
                                  _askBrnchDrctrNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('의뢰 지점 전화 번호 (ASK_BRNCH_PHNO)',
                                  _askBrnchPhnoTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 전세 구분 코드 (BNK_LES_DSC)',
                                  _bnkLesDscTextCtrl),
                              Spacing.height(5),
                              buildTextField('기금 전세 구분 코드 (FND_LES_DSC)',
                                  _fndLesDscTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '조건부 내용 (CNDTL_CNTS)', _cndtlCntsTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '보험료 (ISRN_PRMM)', _isrnPrmmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '예비 항목 B (RSRV_ITM_B)', _rsrvItmBTextCtrl),
                              Spacing.height(5),
                              // buildTextField('등록 일시', _regDtmTextCtrl),
                              // Spacing.height(5),
                              buildTextField('여신 승인 번호 2 (LOAN_APRV_NO_2)',
                                  _loanAprvNo2TextCtrl),
                              Spacing.height(5),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        });
  }

  Widget buildTextField(String text, TextEditingController textCtrl) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: Get.width * 0.25,
          child: MouseRegion(
            cursor: SystemMouseCursors.text, // 마우스 커서 변경
            child: SelectableText(
              text,
              style: TextSyle.text(),
            ),
          ),
        ),
        IfTextFormField.trans(
          controller: textCtrl,
          textStyle: TextSyle.inputFormText(),
        ),
      ],
    );
  }
}
