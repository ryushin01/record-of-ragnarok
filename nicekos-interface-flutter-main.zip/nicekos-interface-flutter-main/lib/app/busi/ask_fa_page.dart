import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/repo/data/cntr_detail_data.dart';
import 'package:nicekos_interface_flutter/repo/response/res_data.dart';
import 'package:nicekos_interface_flutter/utils/if_utils.dart';
import 'package:nicekos_interface_flutter/widget/if_divider.dart';
import 'package:nicekos_interface_flutter/widget/if_text_form_field.dart';
import 'package:nicekos_interface_flutter/theme/text_style.dart';
import '../../repo/data/trans_6100_detail_data.dart';
import '../../repo/data/trns_6100_send_data.dart';
import '../../repo/response/res_stream.dart';
import '../../utils/if_format.dart';
import '../../utils/log_utils.dart';
import '../../widget/If_button.dart';
import '../../theme/colors.dart';
import '../../theme/spacing.dart';
import '../comm/cntr_info_chng_page.dart';
import '../comm/loading_page.dart';
import '../comm/pay_list_page.dart';
import 'ctrl/ask_fa_ctrl.dart';

class AskFaPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _AskPageState();
}

class _AskPageState extends State<AskFaPage> with TickerProviderStateMixin {
  late AskCtrl controller;

  CntrDetailResData cntrDtl = CntrDetailResData();
  Trns6100DetailResData trnsDtl = Trns6100DetailResData();

  StreamController<ResStream<Trns6100SendResData>> trnsSendResStream =
  StreamController<ResStream<Trns6100SendResData>>.broadcast();

  late TextEditingController _newLoanTextCtrl; // 신규 여신번호
  late TextEditingController _searchTextCtrl; // 조회
  late TextEditingController _chgDtmTextCtrl; //
  late TextEditingController _tgLenTextCtrl; // 전문 길이
  late TextEditingController _tgDscTextCtrl; // 전문 구분 코드
  late TextEditingController _bnkTgNoTextCtrl; // 은행 전문 번호
  late TextEditingController _faTgNoTextCtrl; // FA 전문 번호
  late TextEditingController _kosTgSndNoTextCtrl; // KOS 전문 송신 번호
  late TextEditingController _tgSndDtmTextCtrl; // 전문 발송 일시
  late TextEditingController _tgRcvDtmTextCtrl; // 전문 수신 일시
  late TextEditingController _resCdTextCtrl; // 응답 코드
  late TextEditingController _rsrvItmHTextCtrl; // 예비 항목 H
  late TextEditingController _lndDscTextCtrl; // 대출 구분 코드
  late TextEditingController _bnkTtlReqNoTextCtrl; // 은행 권원 신청 번호
  late TextEditingController _ttlArdEntrEaneTextCtrl; // 권원 기 가입 유무
  late TextEditingController _ttlEntrcmpyTextCtrl; // 권원 가입회사
  late TextEditingController _ttlScrtNoTextCtrl; // 권원 증권 번호
  late TextEditingController _lndKndCdTextCtrl; // 대출 종류 코드
  late TextEditingController _fndUseCdTextCtrl; // 자금 용도 코드
  late TextEditingController _bnkLndPrdtCdTextCtrl; // 은행 대출 상품 코드
  late TextEditingController _bnkLndPrdtNmTextCtrl; // 은행 대출 상품명
  late TextEditingController _grntDscTextCtrl; // 보증 구분코드
  late TextEditingController _stndAplYnTextCtrl; // 표준화 적용 여부
  late TextEditingController _rrcpCnfmReqYnTextCtrl; // 주민등록등본 확인 요청 여부
  late TextEditingController _mvhrCnfmReqYnTextCtrl; // 전입세대열람 확인 요청 여부
  late TextEditingController _bfSrvtrgtReqYnTextCtrl; // 사전 설문대상 요청 여부
  late TextEditingController _afSrvtrgtReqYnTextCtrl; // 사후 설문대상 요청 여부
  late TextEditingController _mvLwyrCnfmYnTextCtrl; // 이전 법무사 확인 여부
  late TextEditingController _rgstrUnqNo1TextCtrl; // 등기 고유 번호 1
  late TextEditingController _rgstrUnqNo2TextCtrl; // 등기 고유 번호 2
  late TextEditingController _rgstrUnqNo3TextCtrl; // 등기 고유 번호 3
  late TextEditingController _rgstrUnqNo4TextCtrl; // 등기 고유 번호 4
  late TextEditingController _rgstrUnqNo5TextCtrl; // 등기 고유 번호 5
  late TextEditingController _rlesDscTextCtrl; // 부동산 구분 코드
  late TextEditingController _trgtRlesDscTextCtrl; // 대상 부동산 구분 코드
  late TextEditingController _trgtRlesAddrTextCtrl; // 대상 부동산 주소
  late TextEditingController _sscptAskDtTextCtrl; // 청약 의뢰 일자
  late TextEditingController _lndPlnDtTextCtrl; // 대출 예정 일자
  late TextEditingController _lndExprdDtTextCtrl; // 대출 만기 일자
  late TextEditingController _slPrcTextCtrl; // 매매 가액
  late TextEditingController _scrtEvlAmtTextCtrl; // 담보 평가 금액
  late TextEditingController _isrnEntrAmtTextCtrl; // 보험 가입 금액
  late TextEditingController _lndPrdTextCtrl; // 대출 기간
  late TextEditingController _lndAmtTextCtrl; // 대출 금액
  late TextEditingController _bnkFxcltRgstrRnkTextCtrl; // 은행 근저당권 등기 순위
  late TextEditingController _bnkFxcltBndMaxAmtTextCtrl; // 은행 근저당권 채권 최고 금액
  late TextEditingController _dbtrNmTextCtrl; // 차주명
  late TextEditingController _dbtrBirthDtTextCtrl; // 차주 생년 월일
  late TextEditingController _dbtrAddrTextCtrl; // 차주 주소
  late TextEditingController _dbtrPhnoTextCtrl; // 차주 전화 번호
  late TextEditingController _dbtrHpnoTextCtrl; // 차주 핸드폰 번호
  late TextEditingController _pwpsNmTextCtrl; // 담보 제공자 명
  late TextEditingController _pwpsBirthDtTextCtrl; // 담보 제공자 생년 월일
  late TextEditingController _pwpsAddrTextCtrl; // 담보 제공자 주소
  late TextEditingController _pwpsPhnoTextCtrl; // 담보 제공자 전화 번호
  late TextEditingController _pwpsHpnoTextCtrl; // 담보 제공자 핸드폰 번호
  late TextEditingController _rmkFctTextCtrl; // 비고 사항
  late TextEditingController _lndHndgSlfDscTextCtrl; // 대출 취급 주체 구분 코드
  late TextEditingController _bnkBrnchNmTextCtrl; // 은행 지점명
  late TextEditingController _bnkDrctrNmTextCtrl; // 은행 담당자 명
  late TextEditingController _bnkBrnchPhnoTextCtrl; // 은행 지점 전화 번호
  late TextEditingController _bnkDrctrHpTextCtrl; // 은행 담당자 핸드폰
  late TextEditingController _bnkBrnchFaxTextCtrl; // 은행 지점 팩스
  late TextEditingController _bnkBrnchAddrTextCtrl; // 은행 지점 주소
  late TextEditingController _slmnCmpyNmTextCtrl; // 모집인 회사 명
  late TextEditingController _slmnNmTextCtrl; // 모집인 명
  late TextEditingController _slmnPhnoTextCtrl; // 모집인 전화번호
  late TextEditingController _lwfmNmTextCtrl; // 법무법인 명
  late TextEditingController _lwfmBiznoTextCtrl; // 법무법인 사업자등록번호
  late TextEditingController _dbtrWdngPlnYnTextCtrl; // 차주 결혼 예정 여부
  late TextEditingController _rrcpCnfmYnTextCtrl; // 주민등록등본 확인 여부
  late TextEditingController _spusNmTextCtrl; // 배우자 명
  late TextEditingController _wdngPlnDtTextCtrl; // 결혼 예정 일자
  late TextEditingController _rschWkDdlnReqDtTextCtrl; // 조사 업무 마감 요청 일자
  late TextEditingController _isrnPrmmTextCtrl; // 보험료
  late TextEditingController _rfrLnAprvNoTextCtrl; // 참조 여신 승인 번호
  late TextEditingController _rgstrMtdDscTextCtrl; // 등기 방식 구분코드
  late TextEditingController _rgstrReqNoTextCtrl; // 등기 신청 번호
  late TextEditingController _odprtRpyEaneTextCtrl; // 선순위 상환 유무
  late TextEditingController _eltnEstbsLwyrNmTextCtrl; // 전자 설정 법무사 명
  late TextEditingController _eltnEstbsLwyrBiznoTextCtrl; // 전자 설정 법무사 사업자등록번호
  late TextEditingController _eltnRpyLoaAplYnTextCtrl; // 전자 상환 위임장 적용 여부
  late TextEditingController _eltnRpyLoaSqnTextCtrl; // 전자 상환 위임장 일련번호
  late TextEditingController _eltnRpyLoaCtfcNoTextCtrl; // 전자 상환 위임장 인증 번호
  late TextEditingController _whlRpyCntTextCtrl; // 전체 상환 건수
  late TextEditingController _whlRpyAmtTextCtrl; // 전체 상환 금액
  late TextEditingController _ebnkRpyTotAmtTextCtrl; // 당행 상환 합산 금액
  late TextEditingController _dfbnkRpyTotAmtTextCtrl; // 타행 상환 합산 금액
  late TextEditingController _rpyTrgtRnkNo1TextCtrl; // 상환 대상 순위 번호 1
  late TextEditingController _rpyTrgtAcptDt1TextCtrl; // 상환 대상 접수 일자 1
  late TextEditingController _rpyTrgtAcptNo1TextCtrl; // 상환 대상 접수 번호 1
  late TextEditingController _rpyTrgtBndAmt1TextCtrl; // 상환 대상 채권 금액 1
  late TextEditingController _rpyTrgtRnkNo2TextCtrl; // 상환 대상 순위 번호 2
  late TextEditingController _rpyTrgtAcptDt2TextCtrl; // 상환 대상 접수 일자 2
  late TextEditingController _rpyTrgtAcptNo2TextCtrl; // 상환 대상 접수 번호 2
  late TextEditingController _rpyTrgtBndAmt2TextCtrl; // 상환 대상 채권 금액 2
  late TextEditingController _rpyTrgtRnkNo3TextCtrl; // 상환 대상 순위 번호 3
  late TextEditingController _rpyTrgtAcptDt3TextCtrl; // 상환 대상 접수 일자 3
  late TextEditingController _rpyTrgtAcptNo3TextCtrl; // 상환 대상 접수 번호 3
  late TextEditingController _rpyTrgtBndAmt3TextCtrl; // 상환 대상 채권 금액 3
  late TextEditingController _rpyTrgtRnkNo4TextCtrl; // 상환 대상 순위 번호 4
  late TextEditingController _rpyTrgtAcptDt4TextCtrl; // 상환 대상 접수 일자 4
  late TextEditingController _rpyTrgtAcptNo4TextCtrl; // 상환 대상 접수 번호 4
  late TextEditingController _rpyTrgtBndAmt4TextCtrl; // 상환 대상 채권 금액 4
  late TextEditingController _rpyTrgtRnkNo5TextCtrl; // 상환 대상 순위 번호 5
  late TextEditingController _rpyTrgtAcptDt5TextCtrl; // 상환 대상 접수 일자 5
  late TextEditingController _rpyTrgtAcptNo5TextCtrl; // 상환 대상 접수 번호 5
  late TextEditingController _rpyTrgtBndAmt5TextCtrl; // 상환 대상 채권 금액 5
  late TextEditingController _afrgstrScrtYnTextCtrl; // 후취 담보 여부
  late TextEditingController _slmnLndProc; // 모집인(SR) 대출프로세스
  late TextEditingController _srMembNo; // 모집인(SR) 회원번호
  late TextEditingController _trAmt; // 매매금액
  late TextEditingController _sllNm1; // 소유권이전 매도인명 1
  late TextEditingController _sllBrDay1; // 소유권이전 매도인명 1
  late TextEditingController _sllNm2; // 소유권이전 매도인명 2
  late TextEditingController _sllBrDay2; // 소유권이전 매도인명 2
  late TextEditingController _ownLoanMaxAmt; // (대출신청시점) 선순위채권최고합계액
  late TextEditingController _ownLoanPlnAmt; // (대출당일시점) 말소/감액 최종 예정 금액
  late TextEditingController _ownLoanBnkNm1; // 소유자 대출 보유 은행명 1
  late TextEditingController _ownLoanBnkNm2; // 소유자 대출 보유 은행명 2
  late TextEditingController _ownLoanBnkNm3; // 소유자 대출 보유 은행명 3
  late TextEditingController _ownLoanBnkNm4; // 소유자 대출 보유 은행명 4
  late TextEditingController _ownLoanBnkNm5; // 소유자 대출 보유 은행명 5
  late TextEditingController _cnsgnNm; // (신탁등기)부동산소유자_위탁자명
  late TextEditingController _trstNm; // (신탁등기)신탁사_수탁자명
  late TextEditingController _bnfrNm; // (신탁등기)금융기관_우선수익자명
  late TextEditingController _nowLessNm; // 현 임차인명
  late TextEditingController _rsrvItmBTextCtrl; // 예비 항목 B
  late TextEditingController _regDtmCtrl; //등록일시
  late TextEditingController _oblMLnAprvNoTextCtrl; // 입주잔금대출-모승인번호
  late TextEditingController _oblTotCntTextCtrl; // 입주잔금대출-전체건수
  late TextEditingController _oblGrpRnkNoTextCtrl; // 입주잔금대출-우선순위
  late TextEditingController _lnAprvNo2TextCtrl; // 여신 승인 번호2

  @override
  void initState() {
    super.initState();
    if (Get.isRegistered<AskCtrl>()) {
      Get.delete<AskCtrl>();
    }
    controller = Get.put(AskCtrl());
    _newLoanTextCtrl = TextEditingController();
    _searchTextCtrl = TextEditingController(); // 조회
    _chgDtmTextCtrl = TextEditingController(); // 조회
    _tgLenTextCtrl = TextEditingController(); // 전문 길이
    _tgDscTextCtrl = TextEditingController(); // 전문 구분 코드
    _bnkTgNoTextCtrl = TextEditingController(); // 은행 전문 번호
    _faTgNoTextCtrl = TextEditingController(); // FA 전문 번호
    _kosTgSndNoTextCtrl = TextEditingController(); // KOS 전문 송신 번호
    _tgSndDtmTextCtrl = TextEditingController(); // 전문 발송 일시
    _tgRcvDtmTextCtrl = TextEditingController(); // 전문 수신 일시
    _resCdTextCtrl = TextEditingController(); // 응답 코드
    _rsrvItmHTextCtrl = TextEditingController(); // 예비 항목 H
    _lndDscTextCtrl = TextEditingController(); // 대출 구분 코드
    _bnkTtlReqNoTextCtrl = TextEditingController(); // 은행 권원 신청 번호
    _ttlArdEntrEaneTextCtrl = TextEditingController(); // 권원 기 가입 유무
    _ttlEntrcmpyTextCtrl = TextEditingController(); // 권원 가입회사
    _ttlScrtNoTextCtrl = TextEditingController(); // 권원 증권 번호
    _lndKndCdTextCtrl = TextEditingController(); // 대출 종류 코드
    _fndUseCdTextCtrl = TextEditingController(); // 자금 용도 코드
    _bnkLndPrdtCdTextCtrl = TextEditingController(); // 은행 대출 상품 코드
    _bnkLndPrdtNmTextCtrl = TextEditingController(); // 은행 대출 상품명
    _grntDscTextCtrl = TextEditingController(); // 보증 구분코드
    _stndAplYnTextCtrl = TextEditingController(); // 표준화 적용 여부
    _rrcpCnfmReqYnTextCtrl = TextEditingController(); // 주민등록등본 확인 요청 여부
    _mvhrCnfmReqYnTextCtrl = TextEditingController(); // 전입세대열람 확인 요청 여부
    _bfSrvtrgtReqYnTextCtrl = TextEditingController(); // 사전 설문대상 요청 여부
    _afSrvtrgtReqYnTextCtrl = TextEditingController(); // 사후 설문대상 요청 여부
    _mvLwyrCnfmYnTextCtrl = TextEditingController(); // 이전 법무사 확인 여부
    _rgstrUnqNo1TextCtrl = TextEditingController(); // 등기 고유 번호 1
    _rgstrUnqNo2TextCtrl = TextEditingController(); // 등기 고유 번호 2
    _rgstrUnqNo3TextCtrl = TextEditingController(); // 등기 고유 번호 3
    _rgstrUnqNo4TextCtrl = TextEditingController(); // 등기 고유 번호 4
    _rgstrUnqNo5TextCtrl = TextEditingController(); // 등기 고유 번호 5
    _rlesDscTextCtrl = TextEditingController(); // 부동산 구분 코드
    _trgtRlesDscTextCtrl = TextEditingController(); // 대상 부동산 구분 코드
    _trgtRlesAddrTextCtrl = TextEditingController(); // 대상 부동산 주소
    _sscptAskDtTextCtrl = TextEditingController(); // 청약 의뢰 일자
    _lndPlnDtTextCtrl = TextEditingController(); // 대출 예정 일자
    _lndExprdDtTextCtrl = TextEditingController(); // 대출 만기 일자
    _slPrcTextCtrl = TextEditingController(); // 매매 가액
    _scrtEvlAmtTextCtrl = TextEditingController(); // 담보 평가 금액
    _isrnEntrAmtTextCtrl = TextEditingController(); // 보험 가입 금액
    _lndPrdTextCtrl = TextEditingController(); // 대출 기간
    _lndAmtTextCtrl = TextEditingController(); // 대출 금액
    _bnkFxcltRgstrRnkTextCtrl = TextEditingController(); // 은행 근저당권 등기 순위
    _bnkFxcltBndMaxAmtTextCtrl = TextEditingController(); // 은행 근저당권 채권 최고 금액
    _dbtrNmTextCtrl = TextEditingController(); // 차주명
    _dbtrBirthDtTextCtrl = TextEditingController(); // 차주 생년 월일
    _dbtrAddrTextCtrl = TextEditingController(); // 차주 주소
    _dbtrPhnoTextCtrl = TextEditingController(); // 차주 전화 번호
    _dbtrHpnoTextCtrl = TextEditingController(); // 차주 핸드폰 번호
    _pwpsNmTextCtrl = TextEditingController(); // 담보 제공자 명
    _pwpsBirthDtTextCtrl = TextEditingController(); // 담보 제공자 생년 월일
    _pwpsAddrTextCtrl = TextEditingController(); // 담보 제공자 주소
    _pwpsPhnoTextCtrl = TextEditingController(); // 담보 제공자 전화 번호
    _pwpsHpnoTextCtrl = TextEditingController(); // 담보 제공자 핸드폰 번호
    _rmkFctTextCtrl = TextEditingController(); // 비고 사항
    _lndHndgSlfDscTextCtrl = TextEditingController(); // 대출 취급 주체 구분 코드
    _bnkBrnchNmTextCtrl = TextEditingController(); // 은행 지점명
    _bnkDrctrNmTextCtrl = TextEditingController(); // 은행 담당자 명
    _bnkBrnchPhnoTextCtrl = TextEditingController(); // 은행 지점 전화 번호
    _bnkDrctrHpTextCtrl = TextEditingController(); // 은행 담당자 핸드폰
    _bnkBrnchFaxTextCtrl = TextEditingController(); // 은행 지점 팩스
    _bnkBrnchAddrTextCtrl = TextEditingController(); // 은행 지점 주소
    _slmnCmpyNmTextCtrl = TextEditingController(); // 모집인 회사 명
    _slmnNmTextCtrl = TextEditingController(); // 모집인 명
    _slmnPhnoTextCtrl = TextEditingController(); // 모집인 전화번호
    _lwfmNmTextCtrl = TextEditingController(); // 법무법인 명
    _lwfmBiznoTextCtrl = TextEditingController(); // 법무법인 사업자등록번호
    _dbtrWdngPlnYnTextCtrl = TextEditingController(); // 차주 결혼 예정 여부
    _rrcpCnfmYnTextCtrl = TextEditingController(); // 주민등록등본 확인 여부
    _spusNmTextCtrl = TextEditingController(); // 배우자 명
    _wdngPlnDtTextCtrl = TextEditingController(); // 결혼 예정 일자
    _rschWkDdlnReqDtTextCtrl = TextEditingController(); // 조사 업무 마감 요청 일자
    _isrnPrmmTextCtrl = TextEditingController(); // 보험료
    _rfrLnAprvNoTextCtrl = TextEditingController(); // 참조 여신 승인 번호
    _rgstrMtdDscTextCtrl = TextEditingController(); // 등기 방식 구분코드
    _rgstrReqNoTextCtrl = TextEditingController(); // 등기 신청 번호
    _odprtRpyEaneTextCtrl = TextEditingController(); // 선순위 상환 유무
    _eltnEstbsLwyrNmTextCtrl = TextEditingController(); // 전자 설정 법무사 명
    _eltnEstbsLwyrBiznoTextCtrl = TextEditingController(); // 전자 설정 법무사 사업자등록번호
    _eltnRpyLoaAplYnTextCtrl = TextEditingController(); // 전자 상환 위임장 적용 여부
    _eltnRpyLoaSqnTextCtrl = TextEditingController(); // 전자 상환 위임장 일련번호
    _eltnRpyLoaCtfcNoTextCtrl = TextEditingController(); // 전자 상환 위임장 인증 번호
    _whlRpyCntTextCtrl = TextEditingController(); // 전체 상환 건수
    _whlRpyAmtTextCtrl = TextEditingController(); // 전체 상환 금액
    _ebnkRpyTotAmtTextCtrl = TextEditingController(); // 당행 상환 합산 금액
    _dfbnkRpyTotAmtTextCtrl = TextEditingController(); // 타행 상환 합산 금액
    _rpyTrgtRnkNo1TextCtrl = TextEditingController(); // 상환 대상 순위 번호 1
    _rpyTrgtAcptDt1TextCtrl = TextEditingController(); // 상환 대상 접수 일자 1
    _rpyTrgtAcptNo1TextCtrl = TextEditingController(); // 상환 대상 접수 번호 1
    _rpyTrgtBndAmt1TextCtrl = TextEditingController(); // 상환 대상 채권 금액 1
    _rpyTrgtRnkNo2TextCtrl = TextEditingController(); // 상환 대상 순위 번호 2
    _rpyTrgtAcptDt2TextCtrl = TextEditingController(); // 상환 대상 접수 일자 2
    _rpyTrgtAcptNo2TextCtrl = TextEditingController(); // 상환 대상 접수 번호 2
    _rpyTrgtBndAmt2TextCtrl = TextEditingController(); // 상환 대상 채권 금액 2
    _rpyTrgtRnkNo3TextCtrl = TextEditingController(); // 상환 대상 순위 번호 3
    _rpyTrgtAcptDt3TextCtrl = TextEditingController(); // 상환 대상 접수 일자 3
    _rpyTrgtAcptNo3TextCtrl = TextEditingController(); // 상환 대상 접수 번호 3
    _rpyTrgtBndAmt3TextCtrl = TextEditingController(); // 상환 대상 채권 금액 3
    _rpyTrgtRnkNo4TextCtrl = TextEditingController(); // 상환 대상 순위 번호 4
    _rpyTrgtAcptDt4TextCtrl = TextEditingController(); // 상환 대상 접수 일자 4
    _rpyTrgtAcptNo4TextCtrl = TextEditingController(); // 상환 대상 접수 번호 4
    _rpyTrgtBndAmt4TextCtrl = TextEditingController(); // 상환 대상 채권 금액 4
    _rpyTrgtRnkNo5TextCtrl = TextEditingController(); // 상환 대상 순위 번호 5
    _rpyTrgtAcptDt5TextCtrl = TextEditingController(); // 상환 대상 접수 일자 5
    _rpyTrgtAcptNo5TextCtrl = TextEditingController(); // 상환 대상 접수 번호 5
    _rpyTrgtBndAmt5TextCtrl = TextEditingController(); // 상환 대상 채권 금액 5
    _afrgstrScrtYnTextCtrl = TextEditingController(); // 후취 담보 여부
    _slmnLndProc = TextEditingController(); // 모집인(SR) 대출프로세스
    _srMembNo = TextEditingController(); // 모집인(SR) 회원번호
    _trAmt = TextEditingController(); // 매매금액
    _sllNm1 = TextEditingController(); // 소유권이전 매도인명 1
    _sllBrDay1 = TextEditingController(); // 소유권이전 매도인명 1
    _sllNm2 = TextEditingController(); // 소유권이전 매도인명 2
    _sllBrDay2 = TextEditingController(); // 소유권이전 매도인명 2
    _ownLoanMaxAmt = TextEditingController(); // (대출신청시점) 선순위채권최고합계액
    _ownLoanPlnAmt = TextEditingController(); // (대출당일시점) 말소/감액 최종 예정 금액
    _ownLoanBnkNm1 = TextEditingController(); // 소유자 대출 보유 은행명 1
    _ownLoanBnkNm2 = TextEditingController(); // 소유자 대출 보유 은행명 2
    _ownLoanBnkNm3 = TextEditingController(); // 소유자 대출 보유 은행명 3
    _ownLoanBnkNm4 = TextEditingController(); // 소유자 대출 보유 은행명 4
    _ownLoanBnkNm5 = TextEditingController(); // 소유자 대출 보유 은행명 5
    _cnsgnNm = TextEditingController(); // (신탁등기)부동산소유자_위탁자명
    _trstNm = TextEditingController(); // (신탁등기)신탁사_수탁자명
    _bnfrNm = TextEditingController(); // (신탁등기)금융기관_우선수익자명
    _nowLessNm = TextEditingController(); // 현 임차인명
    _rsrvItmBTextCtrl = TextEditingController(); // 예비 항목 B
    _regDtmCtrl = TextEditingController(); //등록일시
    _oblMLnAprvNoTextCtrl = TextEditingController(); // 입주잔금대출-모승인번호
    _oblTotCntTextCtrl = TextEditingController(); // 입주잔금대출-전체건수
    _oblGrpRnkNoTextCtrl = TextEditingController(); // 입주잔금대출-우선순위
    _lnAprvNo2TextCtrl = TextEditingController(); // 여신 승인 번호2
  }

  @override
  void dispose() {
    super.dispose();
    if (Get.isRegistered<AskCtrl>()) {
      Get.delete<AskCtrl>();
    }
    _newLoanTextCtrl = TextEditingController();
    _searchTextCtrl = TextEditingController(); // 조회
    _chgDtmTextCtrl = TextEditingController(); // 조회
    _tgLenTextCtrl = TextEditingController(); // 전문 길이
    _tgDscTextCtrl = TextEditingController(); // 전문 구분 코드
    _bnkTgNoTextCtrl = TextEditingController(); // 은행 전문 번호
    _faTgNoTextCtrl = TextEditingController(); // FA 전문 번호
    _kosTgSndNoTextCtrl = TextEditingController(); // KOS 전문 송신 번호
    _resCdTextCtrl = TextEditingController(); // 응답 코드
    _rsrvItmHTextCtrl = TextEditingController(); // 예비 항목 H
    _lndDscTextCtrl = TextEditingController(); // 대출 구분 코드
    _bnkTtlReqNoTextCtrl = TextEditingController(); // 은행 권원 신청 번호
    _ttlArdEntrEaneTextCtrl = TextEditingController(); // 권원 기 가입 유무
    _ttlEntrcmpyTextCtrl = TextEditingController(); // 권원 가입회사
    _ttlScrtNoTextCtrl = TextEditingController(); // 권원 증권 번호
    _lndKndCdTextCtrl = TextEditingController(); // 대출 종류 코드
    _fndUseCdTextCtrl = TextEditingController(); // 자금 용도 코드
    _bnkLndPrdtCdTextCtrl = TextEditingController(); // 은행 대출 상품 코드
    _bnkLndPrdtNmTextCtrl = TextEditingController(); // 은행 대출 상품명
    _grntDscTextCtrl = TextEditingController(); // 보증 구분코드
    _stndAplYnTextCtrl = TextEditingController(); // 표준화 적용 여부
    _rrcpCnfmReqYnTextCtrl = TextEditingController(); // 주민등록등본 확인 요청 여부
    _mvhrCnfmReqYnTextCtrl = TextEditingController(); // 전입세대열람 확인 요청 여부
    _bfSrvtrgtReqYnTextCtrl = TextEditingController(); // 사전 설문대상 요청 여부
    _afSrvtrgtReqYnTextCtrl = TextEditingController(); // 사후 설문대상 요청 여부
    _mvLwyrCnfmYnTextCtrl = TextEditingController(); // 이전 법무사 확인 여부
    _rgstrUnqNo1TextCtrl = TextEditingController(); // 등기 고유 번호 1
    _rgstrUnqNo2TextCtrl = TextEditingController(); // 등기 고유 번호 2
    _rgstrUnqNo3TextCtrl = TextEditingController(); // 등기 고유 번호 3
    _rgstrUnqNo4TextCtrl = TextEditingController(); // 등기 고유 번호 4
    _rgstrUnqNo5TextCtrl = TextEditingController(); // 등기 고유 번호 5
    _rlesDscTextCtrl = TextEditingController(); // 부동산 구분 코드
    _trgtRlesDscTextCtrl = TextEditingController(); // 대상 부동산 구분 코드
    _trgtRlesAddrTextCtrl = TextEditingController(); // 대상 부동산 주소
    _sscptAskDtTextCtrl = TextEditingController(); // 청약 의뢰 일자
    _lndPlnDtTextCtrl = TextEditingController(); // 대출 예정 일자
    _lndExprdDtTextCtrl = TextEditingController(); // 대출 만기 일자
    _slPrcTextCtrl = TextEditingController(); // 매매 가액
    _scrtEvlAmtTextCtrl = TextEditingController(); // 담보 평가 금액
    _isrnEntrAmtTextCtrl = TextEditingController(); // 보험 가입 금액
    _lndPrdTextCtrl = TextEditingController(); // 대출 기간
    _lndAmtTextCtrl = TextEditingController(); // 대출 금액
    _bnkFxcltRgstrRnkTextCtrl = TextEditingController(); // 은행 근저당권 등기 순위
    _bnkFxcltBndMaxAmtTextCtrl = TextEditingController(); // 은행 근저당권 채권 최고 금액
    _dbtrNmTextCtrl = TextEditingController(); // 차주명
    _dbtrBirthDtTextCtrl = TextEditingController(); // 차주 생년 월일
    _dbtrAddrTextCtrl = TextEditingController(); // 차주 주소
    _dbtrPhnoTextCtrl = TextEditingController(); // 차주 전화 번호
    _dbtrHpnoTextCtrl = TextEditingController(); // 차주 핸드폰 번호
    _pwpsNmTextCtrl = TextEditingController(); // 담보 제공자 명
    _pwpsBirthDtTextCtrl = TextEditingController(); // 담보 제공자 생년 월일
    _pwpsAddrTextCtrl = TextEditingController(); // 담보 제공자 주소
    _pwpsPhnoTextCtrl = TextEditingController(); // 담보 제공자 전화 번호
    _pwpsHpnoTextCtrl = TextEditingController(); // 담보 제공자 핸드폰 번호
    _rmkFctTextCtrl = TextEditingController(); // 비고 사항
    _lndHndgSlfDscTextCtrl = TextEditingController(); // 대출 취급 주체 구분 코드
    _bnkBrnchNmTextCtrl = TextEditingController(); // 은행 지점명
    _bnkDrctrNmTextCtrl = TextEditingController(); // 은행 담당자 명
    _bnkBrnchPhnoTextCtrl = TextEditingController(); // 은행 지점 전화 번호
    _bnkDrctrHpTextCtrl = TextEditingController(); // 은행 담당자 핸드폰
    _bnkBrnchFaxTextCtrl = TextEditingController(); // 은행 지점 팩스
    _bnkBrnchAddrTextCtrl = TextEditingController(); // 은행 지점 주소
    _slmnCmpyNmTextCtrl = TextEditingController(); // 모집인 회사 명
    _slmnNmTextCtrl = TextEditingController(); // 모집인 명
    _slmnPhnoTextCtrl = TextEditingController(); // 모집인 전화번호
    _lwfmNmTextCtrl = TextEditingController(); // 법무법인 명
    _lwfmBiznoTextCtrl = TextEditingController(); // 법무법인 사업자등록번호
    _dbtrWdngPlnYnTextCtrl = TextEditingController(); // 차주 결혼 예정 여부
    _rrcpCnfmYnTextCtrl = TextEditingController(); // 주민등록등본 확인 여부
    _spusNmTextCtrl = TextEditingController(); // 배우자 명
    _wdngPlnDtTextCtrl = TextEditingController(); // 결혼 예정 일자
    _rschWkDdlnReqDtTextCtrl = TextEditingController(); // 조사 업무 마감 요청 일자
    _isrnPrmmTextCtrl = TextEditingController(); // 보험료
    _rfrLnAprvNoTextCtrl = TextEditingController(); // 참조 여신 승인 번호
    _rgstrMtdDscTextCtrl = TextEditingController(); // 등기 방식 구분코드
    _rgstrReqNoTextCtrl = TextEditingController(); // 등기 신청 번호
    _odprtRpyEaneTextCtrl = TextEditingController(); // 선순위 상환 유무
    _eltnEstbsLwyrNmTextCtrl = TextEditingController(); // 전자 설정 법무사 명
    _eltnEstbsLwyrBiznoTextCtrl = TextEditingController(); // 전자 설정 법무사 사업자등록번호
    _eltnRpyLoaAplYnTextCtrl = TextEditingController(); // 전자 상환 위임장 적용 여부
    _eltnRpyLoaSqnTextCtrl = TextEditingController(); // 전자 상환 위임장 일련번호
    _eltnRpyLoaCtfcNoTextCtrl = TextEditingController(); // 전자 상환 위임장 인증 번호
    _whlRpyCntTextCtrl = TextEditingController(); // 전체 상환 건수
    _whlRpyAmtTextCtrl = TextEditingController(); // 전체 상환 금액
    _ebnkRpyTotAmtTextCtrl = TextEditingController(); // 당행 상환 합산 금액
    _dfbnkRpyTotAmtTextCtrl = TextEditingController(); // 타행 상환 합산 금액
    _rpyTrgtRnkNo1TextCtrl = TextEditingController(); // 상환 대상 순위 번호 1
    _rpyTrgtAcptDt1TextCtrl = TextEditingController(); // 상환 대상 접수 일자 1
    _rpyTrgtAcptNo1TextCtrl = TextEditingController(); // 상환 대상 접수 번호 1
    _rpyTrgtBndAmt1TextCtrl = TextEditingController(); // 상환 대상 채권 금액 1
    _rpyTrgtRnkNo2TextCtrl = TextEditingController(); // 상환 대상 순위 번호 2
    _rpyTrgtAcptDt2TextCtrl = TextEditingController(); // 상환 대상 접수 일자 2
    _rpyTrgtAcptNo2TextCtrl = TextEditingController(); // 상환 대상 접수 번호 2
    _rpyTrgtBndAmt2TextCtrl = TextEditingController(); // 상환 대상 채권 금액 2
    _rpyTrgtRnkNo3TextCtrl = TextEditingController(); // 상환 대상 순위 번호 3
    _rpyTrgtAcptDt3TextCtrl = TextEditingController(); // 상환 대상 접수 일자 3
    _rpyTrgtAcptNo3TextCtrl = TextEditingController(); // 상환 대상 접수 번호 3
    _rpyTrgtBndAmt3TextCtrl = TextEditingController(); // 상환 대상 채권 금액 3
    _rpyTrgtRnkNo4TextCtrl = TextEditingController(); // 상환 대상 순위 번호 4
    _rpyTrgtAcptDt4TextCtrl = TextEditingController(); // 상환 대상 접수 일자 4
    _rpyTrgtAcptNo4TextCtrl = TextEditingController(); // 상환 대상 접수 번호 4
    _rpyTrgtBndAmt4TextCtrl = TextEditingController(); // 상환 대상 채권 금액 4
    _rpyTrgtRnkNo5TextCtrl = TextEditingController(); // 상환 대상 순위 번호 5
    _rpyTrgtAcptDt5TextCtrl = TextEditingController(); // 상환 대상 접수 일자 5
    _rpyTrgtAcptNo5TextCtrl = TextEditingController(); // 상환 대상 접수 번호 5
    _rpyTrgtBndAmt5TextCtrl = TextEditingController(); // 상환 대상 채권 금액 5
    _afrgstrScrtYnTextCtrl = TextEditingController(); // 후취 담보 여부
    _afrgstrScrtYnTextCtrl = TextEditingController(); // 후취 담보 여부
    _slmnLndProc = TextEditingController(); // 모집인(SR) 대출프로세스
    _srMembNo = TextEditingController(); // 모집인(SR) 회원번호
    _trAmt = TextEditingController(); // 매매금액
    _sllNm1 = TextEditingController(); // 소유권이전 매도인명 1
    _sllBrDay1 = TextEditingController(); // 소유권이전 매도인명 1
    _sllNm2 = TextEditingController(); // 소유권이전 매도인명 2
    _sllBrDay2 = TextEditingController(); // 소유권이전 매도인명 2
    _ownLoanMaxAmt = TextEditingController(); // (대출신청시점) 선순위채권최고합계액
    _ownLoanPlnAmt = TextEditingController(); // (대출당일시점) 말소/감액 최종 예정 금액
    _ownLoanBnkNm1 = TextEditingController(); // 소유자 대출 보유 은행명 1
    _ownLoanBnkNm2 = TextEditingController(); // 소유자 대출 보유 은행명 2
    _ownLoanBnkNm3 = TextEditingController(); // 소유자 대출 보유 은행명 3
    _ownLoanBnkNm4 = TextEditingController(); // 소유자 대출 보유 은행명 4
    _ownLoanBnkNm5 = TextEditingController(); // 소유자 대출 보유 은행명 5
    _cnsgnNm = TextEditingController(); // (신탁등기)부동산소유자_위탁자명
    _trstNm = TextEditingController(); // (신탁등기)신탁사_수탁자명
    _bnfrNm = TextEditingController(); // (신탁등기)금융기관_우선수익자명
    _nowLessNm = TextEditingController(); // 현 임차인명
    _rsrvItmBTextCtrl = TextEditingController(); // 예비 항목 B
    _regDtmCtrl = TextEditingController(); //등록일시
    _oblMLnAprvNoTextCtrl = TextEditingController(); // 입주잔금대출-모승인번호
    _oblTotCntTextCtrl = TextEditingController(); // 입주잔금대출-전체건수
    _oblGrpRnkNoTextCtrl = TextEditingController(); // 입주잔금대출-우선순위
    _lnAprvNo2TextCtrl = TextEditingController(); // 여신 승인 번호2
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
        init: controller,
        builder: (controller) {
          return Container(
            margin:
            const EdgeInsets.only(left: 50, top: 20, bottom: 20, right: 50),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 20),
                      child: IfTextFormField.search(
                        controller: _searchTextCtrl,
                        textStyle: TextSyle.searchFormText(),
                      ),
                    ),
                    Spacing.width(20),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          return;
                        }
                        ResData resData =
                        await controller.getCntrDtl(_searchTextCtrl.text);
                        if (resData.code == '00') {
                          cntrDtl = controller.cntrDetailResData;
                          IfUtils.alertIcon(resData.msg.toString(),
                              icontype: '');
                        }
                      },
                      child: Text('검색', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          IfUtils.alertIcon("검색 후 전문 복사", icontype: 'W');
                          return;
                        }
                        ResData resData =
                        await controller.getTrnsDtl(_searchTextCtrl.text);
                        // Lo.g('resData: $resData');
                        if (resData.code == '00') {
                          // Lo.g("resData.code page : ${resData.code}");
                          trnsDtl = controller.trns6100DetailResData;
                          _newLoanTextCtrl.text = trnsDtl.loanNo ?? '';
                          _tgLenTextCtrl.text = trnsDtl.tgLen?.toString() ?? '';
                          _tgDscTextCtrl.text = trnsDtl.tgDsc ?? ''; //전문 구분 코드
                          _bnkTgNoTextCtrl.text =
                              trnsDtl.bnkTgNo ?? ''; //은행 전문 번호
                          _faTgNoTextCtrl.text =
                              trnsDtl.faTgNo ?? ''; //FA 전문 번호
                          _kosTgSndNoTextCtrl.text =
                              trnsDtl.kosTgSndNo ?? ''; //KOS 전문 송신 번호
                          _resCdTextCtrl.text = trnsDtl.resCd ?? ''; //응답 코드
                          _rsrvItmHTextCtrl.text =
                              trnsDtl.rsrvItmH ?? ''; //예비 항목 H
                          _bnkTtlReqNoTextCtrl.text = trnsDtl.bnkTtlReqNo ?? '';
                          _ttlArdEntrEaneTextCtrl.text =
                              trnsDtl.ttlArdEntrEane ?? '';
                          _ttlEntrcmpyTextCtrl.text = trnsDtl.ttlEntrcmpy ?? '';
                          _ttlScrtNoTextCtrl.text = trnsDtl.ttlScrtNo ?? '';
                          _lndDscTextCtrl.text =
                              trnsDtl.lndDsc ?? ''; //대출 구분 코드
                          _lndKndCdTextCtrl.text = trnsDtl.lndKndCd ?? '';
                          _fndUseCdTextCtrl.text = trnsDtl.fndUseCd ?? '';
                          _bnkLndPrdtCdTextCtrl.text =
                              trnsDtl.bnkLndPrdtCd ?? '';
                          _bnkLndPrdtNmTextCtrl.text =
                              trnsDtl.bnkLndPrdtNm ?? '';
                          _grntDscTextCtrl.text = trnsDtl.grntDsc ?? '';
                          _stndAplYnTextCtrl.text = trnsDtl.stndAplYn ?? '';
                          _rrcpCnfmReqYnTextCtrl.text =
                              trnsDtl.rrcpCnfmReqYn ?? '';
                          _mvhrCnfmReqYnTextCtrl.text =
                              trnsDtl.mvhrCnfmReqYn ?? '';
                          _bfSrvtrgtReqYnTextCtrl.text =
                              trnsDtl.bfSrvtrgtReqYn ?? '';
                          _afSrvtrgtReqYnTextCtrl.text =
                              trnsDtl.afSrvtrgtReqYn ?? '';
                          _rgstrUnqNo1TextCtrl.text = trnsDtl.rgstrUnqNo1 ?? '';
                          _rgstrUnqNo2TextCtrl.text = trnsDtl.rgstrUnqNo2 ?? '';
                          _rgstrUnqNo3TextCtrl.text = trnsDtl.rgstrUnqNo3 ?? '';
                          _rgstrUnqNo4TextCtrl.text = trnsDtl.rgstrUnqNo4 ?? '';
                          _rgstrUnqNo5TextCtrl.text = trnsDtl.rgstrUnqNo5 ?? '';
                          _rlesDscTextCtrl.text = trnsDtl.rlesDsc ?? '';
                          _trgtRlesDscTextCtrl.text = trnsDtl.trgtRlesDsc ?? '';
                          _trgtRlesAddrTextCtrl.text =
                              trnsDtl.trgtRlesAddr ?? '';
                          _sscptAskDtTextCtrl.text = trnsDtl.sscptAskDt ?? '';
                          _lndPlnDtTextCtrl.text = trnsDtl.lndPlnDt ?? '';
                          _lndExprdDtTextCtrl.text = trnsDtl.lndExprdDt ?? '';
                          _slPrcTextCtrl.text = trnsDtl.slPrc?.toString() ?? '';
                          _isrnEntrAmtTextCtrl.text =
                              trnsDtl.isrnEntrAmt?.toString() ?? '';
                          _lndPrdTextCtrl.text =
                              trnsDtl.lndPrd?.toString() ?? '';
                          _lndAmtTextCtrl.text =
                              trnsDtl.lndAmt?.toString() ?? '';
                          _bnkFxcltRgstrRnkTextCtrl.text =
                              trnsDtl.bnkFxcltRgstrRnk?.toString() ?? '';
                          _bnkFxcltBndMaxAmtTextCtrl.text =
                              trnsDtl.bnkFxcltBndMaxAmt?.toString() ?? '';
                          _dbtrNmTextCtrl.text = trnsDtl.dbtrNm ?? '';
                          // _dbtrNmTextCtrl.text = '이상협';
                          _dbtrBirthDtTextCtrl.text = trnsDtl.dbtrBirthDt ?? '';
                          _dbtrAddrTextCtrl.text = trnsDtl.dbtrAddr ?? '';
                          _dbtrPhnoTextCtrl.text = trnsDtl.dbtrPhno ?? '';
                          // _dbtrPhnoTextCtrl.text = '01099274288';
                          _dbtrHpnoTextCtrl.text = trnsDtl.dbtrHpno ?? '';
                          // _dbtrHpnoTextCtrl.text = '01099274288';
                          _pwpsNmTextCtrl.text = trnsDtl.pwpsNm ?? '';
                          // _pwpsNmTextCtrl.text = '이상협';
                          _pwpsBirthDtTextCtrl.text = trnsDtl.pwpsBirthDt ?? '';
                          _pwpsAddrTextCtrl.text = trnsDtl.pwpsAddr ?? '';
                          _pwpsPhnoTextCtrl.text = trnsDtl.pwpsPhno ?? '';
                          // _pwpsPhnoTextCtrl.text = '01099274288';
                          _pwpsHpnoTextCtrl.text = trnsDtl.pwpsHpno ?? '';
                          // _pwpsHpnoTextCtrl.text = '01099274288';
                          _rmkFctTextCtrl.text = trnsDtl.rmkFct ?? '';
                          _lndHndgSlfDscTextCtrl.text =
                              trnsDtl.lndHndgSlfDsc ?? '';
                          _bnkBrnchNmTextCtrl.text = trnsDtl.bnkBrnchNm ?? '';
                          _bnkDrctrNmTextCtrl.text = trnsDtl.bnkDrctrNm ?? '';
                          _bnkBrnchPhnoTextCtrl.text =
                              trnsDtl.bnkBrnchPhno ?? '';
                          _bnkDrctrHpTextCtrl.text = trnsDtl.bnkDrctrHp ?? '';
                          _bnkBrnchFaxTextCtrl.text = trnsDtl.bnkBrnchFax ?? '';
                          _bnkBrnchAddrTextCtrl.text =
                              trnsDtl.bnkBrnchAddr ?? '';
                          _slmnCmpyNmTextCtrl.text = trnsDtl.slmnCmpyNm ?? '';
                          _slmnNmTextCtrl.text = trnsDtl.slmnNm ?? '';
                          // _slmnNmTextCtrl.text = '이상협';
                          _slmnPhnoTextCtrl.text = trnsDtl.slmnPhno ?? '';
                          // _slmnPhnoTextCtrl.text = '01099274288';
                          _lwfmNmTextCtrl.text = trnsDtl.lwfmNm ?? '';
                          _lwfmBiznoTextCtrl.text = trnsDtl.lwfmBizNo ?? '';
                          _dbtrWdngPlnYnTextCtrl.text =
                              trnsDtl.dbtrWdngPlnYn ?? '';
                          _rrcpCnfmYnTextCtrl.text = trnsDtl.rrcpCnfmYn ?? '';
                          _spusNmTextCtrl.text = trnsDtl.spusNm ?? '';
                          _wdngPlnDtTextCtrl.text = trnsDtl.wdngPlnDt ?? '';
                          _rschWkDdlnReqDtTextCtrl.text =
                              trnsDtl.rschWkDdlnReqDt ?? '';
                          _isrnPrmmTextCtrl.text =
                              trnsDtl.isrnPrmm?.toString() ?? '';
                          _rfrLnAprvNoTextCtrl.text = trnsDtl.rfrLnAprvNo ?? '';
                          _rgstrMtdDscTextCtrl.text = trnsDtl.rgstrMtdDsc ?? '';
                          _rgstrReqNoTextCtrl.text = trnsDtl.rgstrReqNo ?? '';
                          _odprtRpyEaneTextCtrl.text =
                              trnsDtl.odprtRpyEane ?? '';
                          _eltnEstbsLwyrNmTextCtrl.text =
                              trnsDtl.eltnEstbsLwyrNm ?? '';
                          _eltnEstbsLwyrBiznoTextCtrl.text =
                              trnsDtl.eltnEstbsLywrBizNo ?? '';
                          _eltnRpyLoaAplYnTextCtrl.text =
                              trnsDtl.eltnRpyLoaAplYn ?? '';
                          _eltnRpyLoaSqnTextCtrl.text =
                              trnsDtl.eltnRpyLoaSqn ?? '';
                          _eltnRpyLoaCtfcNoTextCtrl.text =
                              trnsDtl.eltnRpyLoaCtfcNo ?? '';
                          _whlRpyCntTextCtrl.text =
                              trnsDtl.whlRpyCnt?.toString() ?? '';
                          _whlRpyAmtTextCtrl.text =
                              trnsDtl.whlRpyAmt?.toString() ?? '';
                          _ebnkRpyTotAmtTextCtrl.text =
                              trnsDtl.ebnkRpyTotAmt?.toString() ?? '';
                          _dfbnkRpyTotAmtTextCtrl.text =
                              trnsDtl.dfbnkRpyTotAmt?.toString() ?? '';
                          _rpyTrgtRnkNo1TextCtrl.text =
                              trnsDtl.rpyTrgtRnkNo1 ?? '';
                          _rpyTrgtAcptDt1TextCtrl.text =
                              trnsDtl.rpyTrgtAcptDt1 ?? '';
                          _rpyTrgtAcptNo1TextCtrl.text =
                              trnsDtl.rpyTrgtAcptNo1 ?? '';
                          _rpyTrgtBndAmt1TextCtrl.text =
                              trnsDtl.rpyTrgtBndAmt1?.toString() ?? '';
                          _rpyTrgtRnkNo2TextCtrl.text =
                              trnsDtl.rpyTrgtRnkNo2 ?? '';
                          _rpyTrgtAcptDt2TextCtrl.text =
                              trnsDtl.rpyTrgtAcptDt2 ?? '';
                          _rpyTrgtAcptNo2TextCtrl.text =
                              trnsDtl.rpyTrgtAcptNo2 ?? '';
                          _rpyTrgtBndAmt2TextCtrl.text =
                              trnsDtl.rpyTrgtBndAmt2?.toString() ?? '';
                          _rpyTrgtRnkNo3TextCtrl.text =
                              trnsDtl.rpyTrgtRnkNo3 ?? '';
                          _rpyTrgtAcptDt3TextCtrl.text =
                              trnsDtl.rpyTrgtAcptDt3 ?? '';
                          _rpyTrgtAcptNo3TextCtrl.text =
                              trnsDtl.rpyTrgtAcptNo3 ?? '';
                          _rpyTrgtBndAmt3TextCtrl.text =
                              trnsDtl.rpyTrgtBndAmt3?.toString() ?? '';
                          _rpyTrgtRnkNo4TextCtrl.text =
                              trnsDtl.rpyTrgtRnkNo4 ?? '';
                          _rpyTrgtAcptDt4TextCtrl.text =
                              trnsDtl.rpyTrgtAcptDt4 ?? '';
                          _rpyTrgtAcptNo4TextCtrl.text =
                              trnsDtl.rpyTrgtAcptNo4 ?? '';
                          _rpyTrgtBndAmt4TextCtrl.text =
                              trnsDtl.rpyTrgtBndAmt4?.toString() ?? '';
                          _rpyTrgtRnkNo5TextCtrl.text =
                              trnsDtl.rpyTrgtRnkNo5 ?? '';
                          _rpyTrgtAcptDt5TextCtrl.text =
                              trnsDtl.rpyTrgtAcptDt5 ?? '';
                          _rpyTrgtAcptNo5TextCtrl.text =
                              trnsDtl.rpyTrgtAcptNo5 ?? '';
                          _rpyTrgtBndAmt5TextCtrl.text =
                              trnsDtl.rpyTrgtBndAmt5?.toString() ?? '';
                          _afrgstrScrtYnTextCtrl.text =
                              trnsDtl.afrgstrScrtYn ?? '';
                          _slmnLndProc.text = trnsDtl.slmnLndProc ?? '';
                          _srMembNo.text = trnsDtl.srMembNo ?? '';
                          _trAmt.text = trnsDtl.trAmt?.toString() ?? '';
                          _sllNm1.text = trnsDtl.sllNm1 ?? '';
                          _sllBrDay1.text = trnsDtl.sllBrDay1 ?? '';
                          _sllNm2.text = trnsDtl.sllNm2 ?? '';
                          _sllBrDay2.text = trnsDtl.sllBrDay2 ?? '';
                          _ownLoanMaxAmt.text =
                              trnsDtl.ownLoanMaxAmt?.toString() ?? '';
                          _ownLoanPlnAmt.text =
                              trnsDtl.ownLoanPlnAmt?.toString() ?? '';
                          _ownLoanBnkNm1.text = trnsDtl.ownLoanBnkNm1 ?? '';
                          _ownLoanBnkNm2.text = trnsDtl.ownLoanBnkNm2 ?? '';
                          _ownLoanBnkNm3.text = trnsDtl.ownLoanBnkNm3 ?? '';
                          _ownLoanBnkNm4.text = trnsDtl.ownLoanBnkNm4 ?? '';
                          _ownLoanBnkNm5.text = trnsDtl.ownLoanBnkNm5 ?? '';
                          _cnsgnNm.text = trnsDtl.cnsgnNm ?? '';
                          _trstNm.text = trnsDtl.trstNm ?? '';
                          _bnfrNm.text = trnsDtl.bnfrNm ?? '';
                          _nowLessNm.text = trnsDtl.nowLessNm ?? '';
                          _rsrvItmBTextCtrl.text = trnsDtl.rsrvItmB ?? '';
                          _oblMLnAprvNoTextCtrl.text =
                              trnsDtl.oblMLnAprvNo ?? '';
                          _oblTotCntTextCtrl.text =
                              trnsDtl.oblTotCnt?.toString() ?? '';
                          _oblGrpRnkNoTextCtrl.text =
                              trnsDtl.oblGrpRnkNo?.toString() ?? '';
                          _lnAprvNo2TextCtrl.text = trnsDtl.lnAprvNo2 ?? '';
                          IfUtils.alertIcon(resData.msg.toString(),
                              icontype: '');
                        } else {
                          IfUtils.alertIcon(resData.msg.toString(),
                              icontype: 'W');
                        }
                      },
                      child: Text('전문 복사', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    Row(
                      children: [
                        IfButton(
                          elevation: 0,
                          padding: Spacing.xy(40, 20),
                          backgroundColor: canvasColor,
                          borderRadiusAll: 5,
                          onPressed: () async {
                            if (_searchTextCtrl.text.isEmpty) {
                              IfUtils.alertIcon("전문 복사 후 전문 송신", icontype: 'W');
                              return;
                            }
                            Trns6100SendReqData reqData = Trns6100SendReqData();
                            reqData.loanNo = _searchTextCtrl.text;
                            reqData.newLoanNo = _newLoanTextCtrl.text;
                            reqData.chgDtm = _chgDtmTextCtrl.text;
                            Lo.g("reqData.chgDtm : ${reqData.chgDtm}");
                            reqData.tgLen = int.tryParse(_tgLenTextCtrl.text);
                            reqData.tgDsc = _tgDscTextCtrl.text; //전문 구분 코드
                            Lo.g("reqData.tgDsc : ${reqData.tgDsc}");
                            reqData.bnkTgNo = _bnkTgNoTextCtrl.text; //은행 전문 번호
                            reqData.faTgNo = _faTgNoTextCtrl.text; //FA 전문 번호
                            //reqData.kosTgSndNo =
                            //    _kosTgSndNoTextCtrl.text; //KOS 전문 송신 번호
                            reqData.tgSndDtm = _tgSndDtmTextCtrl.text;
                            reqData.tgRcvDtm = _tgRcvDtmTextCtrl.text;
                            reqData.resCd = _resCdTextCtrl.text; //응답 코드
                            reqData.rsrvItmH = _rsrvItmHTextCtrl.text; //예비 항목 H
                            reqData.bnkTtlReqNo = _bnkTtlReqNoTextCtrl.text;
                            reqData.ttlArdEntrEane =
                                _ttlArdEntrEaneTextCtrl.text;
                            reqData.ttlEntrcmpy = _ttlEntrcmpyTextCtrl.text;
                            reqData.ttlScrtNo = _ttlScrtNoTextCtrl.text;
                            reqData.lndDsc = _lndDscTextCtrl.text; //대출 구분 코드
                            reqData.lndKndCd = _lndKndCdTextCtrl.text;
                            reqData.fndUseCd = _fndUseCdTextCtrl.text;
                            reqData.bnkLndPrdtCd = _bnkLndPrdtCdTextCtrl.text;
                            reqData.bnkLndPrdtNm = _bnkLndPrdtNmTextCtrl.text;
                            reqData.grntDsc = _grntDscTextCtrl.text;
                            reqData.stndAplYn = _stndAplYnTextCtrl.text;
                            reqData.rrcpCnfmReqYn = _rrcpCnfmReqYnTextCtrl.text;
                            reqData.mvhrCnfmReqYn = _mvhrCnfmReqYnTextCtrl.text;
                            reqData.bfSrvtrgtReqYn =
                                _bfSrvtrgtReqYnTextCtrl.text;
                            reqData.afSrvtrgtReqYn =
                                _afSrvtrgtReqYnTextCtrl.text;
                            reqData.rgstrUnqNo1 = _rgstrUnqNo1TextCtrl.text;
                            reqData.rgstrUnqNo2 = _rgstrUnqNo2TextCtrl.text;
                            reqData.rgstrUnqNo3 = _rgstrUnqNo3TextCtrl.text;
                            reqData.rgstrUnqNo4 = _rgstrUnqNo4TextCtrl.text;
                            reqData.rgstrUnqNo5 = _rgstrUnqNo5TextCtrl.text;
                            reqData.rlesDsc = _rlesDscTextCtrl.text;
                            reqData.trgtRlesDsc = _trgtRlesDscTextCtrl.text;
                            reqData.trgtRlesAddr = _trgtRlesAddrTextCtrl.text;
                            reqData.sscptAskDt = _sscptAskDtTextCtrl.text;
                            reqData.lndPlnDt = _lndPlnDtTextCtrl.text;
                            reqData.lndExprdDt = _lndExprdDtTextCtrl.text;
                            reqData.slPrc = int.tryParse(_slPrcTextCtrl.text);
                            reqData.isrnEntrAmt =
                                int.tryParse(_isrnEntrAmtTextCtrl.text);
                            reqData.lndPrd = int.tryParse(_lndPrdTextCtrl.text);
                            reqData.lndAmt = int.tryParse(_lndAmtTextCtrl.text);
                            reqData.bnkFxcltRgstrRnk =
                                int.tryParse(_bnkFxcltRgstrRnkTextCtrl.text);
                            reqData.bnkFxcltBndMaxAmt =
                                int.tryParse(_bnkFxcltBndMaxAmtTextCtrl.text);
                            reqData.dbtrNm = _dbtrNmTextCtrl.text;
                            reqData.dbtrBirthDt = _dbtrBirthDtTextCtrl.text;
                            reqData.dbtrAddr = _dbtrAddrTextCtrl.text;
                            reqData.dbtrPhno = _dbtrPhnoTextCtrl.text;
                            reqData.dbtrHpno = _dbtrHpnoTextCtrl.text;
                            reqData.pwpsNm = _pwpsNmTextCtrl.text;
                            reqData.pwpsBirthDt = _pwpsBirthDtTextCtrl.text;
                            reqData.pwpsAddr = _pwpsAddrTextCtrl.text;
                            reqData.pwpsPhno = _pwpsPhnoTextCtrl.text;
                            reqData.pwpsHpno = _pwpsHpnoTextCtrl.text;
                            reqData.rmkFct = _rmkFctTextCtrl.text;
                            reqData.lndHndgSlfDsc = _lndHndgSlfDscTextCtrl.text;
                            reqData.bnkBrnchNm = _bnkBrnchNmTextCtrl.text;
                            reqData.bnkLndPrdtNm = _bnkLndPrdtNmTextCtrl.text;
                            reqData.bnkDrctrNm = _bnkDrctrNmTextCtrl.text;
                            reqData.bnkBrnchPhno = _bnkBrnchPhnoTextCtrl.text;
                            reqData.bnkDrctrHp = _bnkDrctrHpTextCtrl.text;
                            reqData.bnkBrnchFax = _bnkBrnchFaxTextCtrl.text;
                            reqData.bnkBrnchAddr = _bnkBrnchAddrTextCtrl.text;
                            reqData.slmnCmpyNm = _slmnCmpyNmTextCtrl.text;
                            reqData.slmnNm = _slmnNmTextCtrl.text;
                            reqData.slmnPhno = _slmnPhnoTextCtrl.text;
                            reqData.lwfmNm = _lwfmNmTextCtrl.text;
                            reqData.lwfmBizNo = _lwfmBiznoTextCtrl.text;
                            reqData.dbtrWdngPlnYn = _dbtrWdngPlnYnTextCtrl.text;
                            reqData.rrcpCnfmYn = _rrcpCnfmYnTextCtrl.text;
                            reqData.spusNm = _spusNmTextCtrl.text;
                            reqData.wdngPlnDt = _wdngPlnDtTextCtrl.text;
                            reqData.rschWkDdlnReqDt =
                                _rschWkDdlnReqDtTextCtrl.text;
                            reqData.isrnPrmm =
                                int.tryParse(_isrnPrmmTextCtrl.text);
                            reqData.rfrLnAprvNo = _rfrLnAprvNoTextCtrl.text;
                            reqData.rgstrMtdDsc = _rgstrMtdDscTextCtrl.text;
                            reqData.rgstrReqNo = _rgstrReqNoTextCtrl.text;
                            reqData.odprtRpyEane = _odprtRpyEaneTextCtrl.text;
                            reqData.eltnEstbsLwyrNm =
                                _eltnEstbsLwyrNmTextCtrl.text;
                            reqData.eltnEstbsLwyrBizNo =
                                _eltnEstbsLwyrBiznoTextCtrl.text;
                            reqData.eltnRpyLoaAplYn =
                                _eltnRpyLoaAplYnTextCtrl.text;
                            reqData.eltnRpyLoaSqn = _eltnRpyLoaSqnTextCtrl.text;
                            reqData.eltnRpyLoaCtfcNo =
                                _eltnRpyLoaCtfcNoTextCtrl.text;
                            reqData.whlRpyCnt =
                                int.tryParse(_whlRpyCntTextCtrl.text);
                            reqData.whlRpyAmt =
                                int.tryParse(_whlRpyAmtTextCtrl.text);
                            reqData.ebnkRpyTotAmt =
                                int.tryParse(_ebnkRpyTotAmtTextCtrl.text);
                            reqData.dfbnkRpyTotAmt =
                                int.tryParse(_dfbnkRpyTotAmtTextCtrl.text);
                            reqData.rpyTrgtRntNo1 = _rpyTrgtRnkNo1TextCtrl.text;
                            reqData.rpyTrgtAcptDt1 =
                                _rpyTrgtAcptDt1TextCtrl.text;
                            reqData.rpyTrgtAcptNo1 =
                                _rpyTrgtAcptNo1TextCtrl.text;
                            reqData.rpyTrgtBndAmt1 =
                                int.tryParse(_rpyTrgtBndAmt1TextCtrl.text);
                            reqData.rpyTrgtRntNo2 = _rpyTrgtRnkNo2TextCtrl.text;
                            reqData.rpyTrgtAcptDt2 =
                                _rpyTrgtAcptDt2TextCtrl.text;
                            reqData.rpyTrgtAcptNo2 =
                                _rpyTrgtAcptNo2TextCtrl.text;
                            reqData.rpyTrgtBndAmt2 =
                                int.tryParse(_rpyTrgtBndAmt2TextCtrl.text);
                            reqData.rpyTrgtRntNo3 = _rpyTrgtRnkNo3TextCtrl.text;
                            reqData.rpyTrgtAcptDt3 =
                                _rpyTrgtAcptDt3TextCtrl.text;
                            reqData.rpyTrgtAcptNo3 =
                                _rpyTrgtAcptNo3TextCtrl.text;
                            reqData.rpyTrgtBndAmt3 =
                                int.tryParse(_rpyTrgtBndAmt3TextCtrl.text);
                            reqData.rpyTrgtRntNo4 = _rpyTrgtRnkNo4TextCtrl.text;
                            reqData.rpyTrgtAcptDt4 =
                                _rpyTrgtAcptDt4TextCtrl.text;
                            reqData.rpyTrgtAcptNo4 =
                                _rpyTrgtAcptNo4TextCtrl.text;
                            reqData.rpyTrgtBndAmt4 =
                                int.tryParse(_rpyTrgtBndAmt4TextCtrl.text);
                            reqData.rpyTrgtRntNo5 = _rpyTrgtRnkNo5TextCtrl.text;
                            reqData.rpyTrgtAcptDt5 =
                                _rpyTrgtAcptDt5TextCtrl.text;
                            reqData.rpyTrgtAcptNo5 =
                                _rpyTrgtAcptNo5TextCtrl.text;
                            reqData.rpyTrgtBndAmt5 =
                                int.tryParse(_rpyTrgtBndAmt5TextCtrl.text);
                            reqData.afrgstrScrtYn = _afrgstrScrtYnTextCtrl.text;
                            reqData.slmnLndProc = _slmnLndProc.text;
                            reqData.srMembNo = _srMembNo.text;
                            reqData.trAmt = int.tryParse(_trAmt.text);
                            reqData.sllNm1 = _sllNm1.text;
                            reqData.sllBrDay1 = _sllBrDay1.text;
                            reqData.sllNm2 = _sllNm2.text;
                            reqData.sllBrDay2 = _sllBrDay2.text;
                            reqData.ownLoanMaxAmt =
                                int.tryParse(_ownLoanMaxAmt.text);
                            reqData.ownLoanPlnAmt =
                                int.tryParse(_ownLoanPlnAmt.text);
                            reqData.ownLoanBnkNm1 = _ownLoanBnkNm1.text;
                            reqData.ownLoanBnkNm2 = _ownLoanBnkNm2.text;
                            reqData.ownLoanBnkNm3 = _ownLoanBnkNm3.text;
                            reqData.ownLoanBnkNm4 = _ownLoanBnkNm4.text;
                            reqData.ownLoanBnkNm5 = _ownLoanBnkNm5.text;
                            reqData.cnsgnNm = _cnsgnNm.text;
                            reqData.trstNm = _trstNm.text;
                            reqData.bnfrNm = _bnfrNm.text;
                            reqData.nowLessNm = _nowLessNm.text;
                            reqData.rsrvItmB = _rsrvItmBTextCtrl.text;
                            reqData.regDtm = _regDtmCtrl.text;
                            reqData.oblMLnAprvNo = _oblMLnAprvNoTextCtrl.text;
                            reqData.oblTotCnt =
                                int.tryParse(_oblTotCntTextCtrl.text);
                            reqData.oblGrpRnkNo =
                                int.tryParse(_oblGrpRnkNoTextCtrl.text);
                            reqData.lnAprvNo2 = _lnAprvNo2TextCtrl.text;
                            Lo.g("전문 송신 버튼 클릭");
                            ResData resData =
                            await controller.setSendAsk(reqData);
                            if (resData.code == '00') {
                              IfUtils.alertIcon(resData.msg.toString(),
                                  icontype: '');
                            } else {
                              IfUtils.alertIcon('실패', icontype: 'W');
                            }
                          },
                          child:
                          Text('전문 송신', style: TextSyle.searchFormText()),
                        ),
                        LoadingPage<Trns6100SendResData>(
                          stream: AskCtrl.to.trnsSendResStream.stream,
                        ),
                      ],
                    ),
                    Spacing.width(10),
                  ],
                ),
                Spacing.height(40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    PayListPage(controller: controller,
                        searchTextCtrl: _searchTextCtrl),
                    Spacing.width(40),
                    Spacing.width(10),
                    Expanded(
                      child: SizedBox(
                        height: Get.height * 0.8,
                        //width: Get.width * 0.2,
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Spacing.height(40),
                              IfUtils.buildCategory('전문 전송 정보'),
                              Spacing.height(20),
                              IfDivider(width: 0.37),
                              Spacing.height(20),
                              buildTextField(
                                  '신규 여신 번호 (NEW_LOAN_NO)', _newLoanTextCtrl),
                              Spacing.height(5),
                              buildTextField('전문 길이 (TG_LEN)', _tgLenTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전문 구분 코드 (TG_DSC)', _tgDscTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '은행 전문 번호 (BNK_TG_NO)', _bnkTgNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  'FA 전문 번호 (FA_TG_NO)', _faTgNoTextCtrl),
                              Spacing.height(5),
                              // buildTextField('코스 전문 송신 번호 (KOS_TG_SND_NO)', _kosTgSndNoTextCtrl),
                              // Spacing.height(5),
                              buildTextField('응답 코드 (RES_CD)', _resCdTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '예비 항목 H (RSRV_ITM_H)', _rsrvItmHTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 권원 신청 번호 (BNK_TTL_REQ_NO)',
                                  _bnkTtlReqNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '권원 기 가입 유무 (TTL_ARD_ENTR_EANE)',
                                  _ttlArdEntrEaneTextCtrl),
                              Spacing.height(5),
                              buildTextField('권원 가입회사 (TTL_ENTRCMPY)',
                                  _ttlEntrcmpyTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '권원 증권 번호 (TTL_SCRT_NO)', _ttlScrtNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 구분 코드 (LND_DSC)', _lndDscTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 종류 코드 (LND_KND_CD)', _lndKndCdTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '자금 용도 코드 (FND_USE_CD)', _fndUseCdTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '은행 대출 상품 코드 (BNK_LND_PRDT_CD)',
                                  _bnkLndPrdtCdTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 대출 상품명 (BNK_LND_PRDT_NM)',
                                  _bnkLndPrdtNmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '보증 구분코드 (GRNT_DSC)', _grntDscTextCtrl),
                              Spacing.height(5),
                              buildTextField('표준화 적용 여부 (STND_APL_YN)',
                                  _stndAplYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '주민등록등본 확인 요청 여부 (RRCP_CNFM_REQ_YN)',
                                  _rrcpCnfmReqYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전입세대열람 확인 요청 여부 (MVHR_CNFM_REQ_YN)',
                                  _mvhrCnfmReqYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '사전 설문대상 요청 여부 (BF_SRVTRGT_REQ_YN)',
                                  _bfSrvtrgtReqYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '사후 설문대상 요청 여부 (AF_SRVTRGT_REQ_YN)',
                                  _bfSrvtrgtReqYnTextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호 1 (RGSTR_UNQ_NO_1)',
                                  _rgstrUnqNo1TextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호 2 (RGSTR_UNQ_NO_2)',
                                  _rgstrUnqNo2TextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호 3 (RGSTR_UNQ_NO_3)',
                                  _rgstrUnqNo3TextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호 4 (RGSTR_UNQ_NO_4)',
                                  _rgstrUnqNo4TextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 고유 번호 5 (RGSTR_UNQ_NO_5)',
                                  _rgstrUnqNo5TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '부동산 구분 코드 (RLES_DSC)', _rlesDscTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대상 부동산 구분 코드 (TRGT_RLES_DSC)',
                                  _trgtRlesDscTextCtrl),
                              Spacing.height(5),
                              buildTextField('대상 부동산 주소 (TRGT_RLES_ADDR)',
                                  _trgtRlesAddrTextCtrl),
                              Spacing.height(5),
                              buildTextField('청약 의뢰 일자 (SSCPT_ASK_DT)',
                                  _sscptAskDtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 예정 일자 (LND_PLN_DT)', _lndPlnDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('대출 만기 일자 (LND_EXPRD_DT)',
                                  _lndExprdDtTextCtrl),
                              Spacing.height(5),
                              buildTextField('매매 가액 (SL_PRC)', _slPrcTextCtrl),
                              Spacing.height(5),
                              buildTextField('보험 가입 금액 (ISRN_ENTR_AMT)',
                                  _isrnEntrAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 기간 (LND_PRD)', _lndPrdTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 금액 (LND_AMT)', _lndAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '은행 근저당권 등기 순위 (BNK_FXCLT_RGSTR_RNK)',
                                  _bnkFxcltRgstrRnkTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '은행 근저당권 채권 최고 금액 (BNK_FXCLT_BND_MAX_AMT)',
                                  _bnkFxcltBndMaxAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField('차주명 (DBTR_NM)', _dbtrNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('차주 생년 월일 (DBTR_BIRTH_DT)',
                                  _dbtrBirthDtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '차주 주소 (DBTR_ADDR)', _dbtrAddrTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '차주 전화 번호 (DBTR_PHNO)', _dbtrPhnoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '차주 핸드폰 번호 (DBTR_HPNO)', _dbtrHpnoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '담보 제공자 명 (PWPS_NM)', _pwpsNmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '담보 제공자 생년 월일 (PWPS_BIRTH_DT)',
                                  _pwpsBirthDtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '담보 제공자 주소 (PWPS_ADDR)', _pwpsAddrTextCtrl),
                              Spacing.height(5),
                              buildTextField('담보 제공자 전화 번호 (PWPS_PHNO)',
                                  _pwpsPhnoTextCtrl),
                              Spacing.height(5),
                              buildTextField('담보 제공자 핸드폰 번호 (PWPS_HPNO)',
                                  _pwpsHpnoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '비고 사항 (RMK_FCT)', _rmkFctTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 취급 주체 구분 코드 (LND_HNDG_SLF_DSC)',
                                  _lndHndgSlfDscTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '은행 지점명 (BNK_BRNCH_NM)', _bnkBrnchNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 담당자 명 (BNK_DRCTR_NM)',
                                  _bnkDrctrNmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '은행 지점 전화 번호 (BNK_BRNCH_PHNO)',
                                  _bnkBrnchPhnoTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 담당자 핸드폰 (BNK_DRCTR_HP)',
                                  _bnkDrctrHpTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 지점 팩스 (BNK_BRNCH_FAX)',
                                  _bnkBrnchFaxTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 지점 주소 (BNK_BRNCH_ADDR)',
                                  _bnkBrnchAddrTextCtrl),
                              Spacing.height(5),
                              buildTextField('모집인 회사 명 (SLMN_CMPY_NM)',
                                  _slmnCmpyNmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '모집인 명 (SLMN_NM)', _slmnNmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '모집인 전화번호 (SLMN_PHNO)', _slmnPhnoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '법무법인 명 (LWFM_NM)', _lwfmNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('법무법인 사업자등록번호 (LWFM_BIZNO)',
                                  _lwfmBiznoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '차주 결혼 예정 여부 (DBTR_WDNG_PLN_YN)',
                                  _dbtrWdngPlnYnTextCtrl),
                              Spacing.height(5),
                              buildTextField('주민등록등본 확인 여부 (RRCP_CNFM_YN)',
                                  _rrcpCnfmYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '배우자 명 (SPUS_NM)', _spusNmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '결혼 예정 일자 (WDNG_PLN_DT)', _wdngPlnDtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '조사 업무 마감 요청 일자 (RSCH_WK_DDLN_REQ_DT)',
                                  _rschWkDdlnReqDtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '보험료 (ISRN_PRMM)', _isrnPrmmTextCtrl),
                              Spacing.height(5),
                              buildTextField('참조 여신 승인 번호 (RFR_LN_APRV_NO)',
                                  _rfrLnAprvNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 방식 구분코드 (RGSTR_MTD_DSC)',
                                  _rgstrMtdDscTextCtrl),
                              Spacing.height(5),
                              buildTextField('등기 신청 번호 (RGSTR_REQ_NO)',
                                  _rgstrReqNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('선순위 상환 유무 (ODPRT_RPY_EANE)',
                                  _odprtRpyEaneTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전자 설정 법무사 명 (ELTN_ESTBS_LWYR_NM)',
                                  _eltnEstbsLwyrNmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전자 설정 법무사 사업자등록번호 (ELTN_ESTBS_LWYR_BIZNO)',
                                  _eltnEstbsLwyrBiznoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전자 상환 위임장 적용 여부 (ELTN_RPY_LOA_APL_YN)',
                                  _eltnRpyLoaAplYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전자 상환 위임장 일련번호 (ELTN_RPY_LOA_SQN)',
                                  _eltnRpyLoaSqnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전자 상환 위임장 인증 번호 (ELTN_RPY_LOA_CTFC_NO)',
                                  _eltnRpyLoaCtfcNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전체 상환 건수 (WHL_RPY_CNT)', _whlRpyCntTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전체 상환 금액 (WHL_RPY_AMT)', _whlRpyAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '당행 상환 합산 금액 (EBNK_RPY_TOT_AMT)',
                                  _ebnkRpyTotAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '타행 상환 합산 금액 (DFBNK_RPY_TOT_AMT)',
                                  _dfbnkRpyTotAmtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 순위 번호 1 (RPY_TRGT_RNK_NO_1)',
                                  _rpyTrgtRnkNo1TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 접수 일자 1 (RPY_TRGT_ACPT_DT_1)',
                                  _rpyTrgtAcptDt1TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 접수 번호 1 (RPY_TRGT_ACPT_NO_1)',
                                  _rpyTrgtAcptNo1TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 채권 금액 1 (RPY_TRGT_BND_AMT_1)',
                                  _rpyTrgtBndAmt1TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 순위 번호 2 (RPY_TRGT_RNK_NO_2)',
                                  _rpyTrgtRnkNo2TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 접수 일자 2 (RPY_TRGT_ACPT_DT_2)',
                                  _rpyTrgtAcptDt2TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 접수 번호 2 (RPY_TRGT_ACPT_NO_2)',
                                  _rpyTrgtAcptNo2TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 채권 금액 2 (RPY_TRGT_BND_AMT_2)',
                                  _rpyTrgtBndAmt2TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 순위 번호 3 (RPY_TRGT_RNK_NO_3)',
                                  _rpyTrgtRnkNo3TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 접수 일자 3 (RPY_TRGT_ACPT_DT_3)',
                                  _rpyTrgtAcptDt3TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 접수 번호 3 (RPY_TRGT_ACPT_NO_3)',
                                  _rpyTrgtAcptNo3TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 채권 금액 3 (RPY_TRGT_BND_AMT_3)',
                                  _rpyTrgtBndAmt3TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 순위 번호 4 (RPY_TRGT_RNK_NO_4)',
                                  _rpyTrgtRnkNo4TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 접수 일자 4 (RPY_TRGT_ACPT_DT_4)',
                                  _rpyTrgtAcptDt4TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 접수 번호 4 (RPY_TRGT_ACPT_NO_4)',
                                  _rpyTrgtAcptNo4TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 채권 금액 4 (RPY_TRGT_BND_AMT_4)',
                                  _rpyTrgtBndAmt4TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 순위 번호 5 (RPY_TRGT_RNK_NO_5)',
                                  _rpyTrgtRnkNo5TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 접수 일자 5 (RPY_TRGT_ACPT_DT_5)',
                                  _rpyTrgtAcptDt5TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 접수 번호 5 (RPY_TRGT_ACPT_NO_5)',
                                  _rpyTrgtAcptNo5TextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '상환 대상 채권 금액 5 (RPY_TRGT_BND_AMT_5)',
                                  _rpyTrgtBndAmt5TextCtrl),
                              Spacing.height(5),
                              buildTextField('후취 담보 여부 (AFRGSTR_SCRT_YN)',
                                  _afrgstrScrtYnTextCtrl),
                              Spacing.height(5),
                              buildTextField('모집인(SR) 대출프로세스 (SLMN_LND_PROC)',
                                  _slmnLndProc),
                              //here
                              Spacing.height(5),
                              buildTextField(
                                  '모집인(SR) 회원번호 (SR_MEMB_NO)', _srMembNo),
                              Spacing.height(5),
                              buildTextField('매매금액 (TR_AMT)', _trAmt),
                              Spacing.height(5),
                              buildTextField(
                                  '소유권이전 매도인명 1 (SLL_NM_1)', _sllNm1),
                              Spacing.height(5),
                              buildTextField('소유권이전 매도인 생년월일 1 (SLL_BR_DAY_1)',
                                  _sllBrDay1),
                              Spacing.height(5),
                              buildTextField(
                                  '소유권이전 매도인명 2 (SLL_NM_2)', _sllNm2),
                              Spacing.height(5),
                              buildTextField('소유권이전 매도인 생년월일 2 (SLL_BR_DAY_2)',
                                  _sllBrDay2),
                              Spacing.height(5),
                              buildTextField(
                                  '(대출신청시점) 선순위채권최고합계액 (OWN_LOAN_MAX_AMT)',
                                  _ownLoanMaxAmt),
                              Spacing.height(5),
                              buildTextField(
                                  '(대출당일시점) 말소/감액 최종 예정 금액 (OWN_LOAN_PLN_AMT)',
                                  _ownLoanPlnAmt),
                              Spacing.height(5),
                              buildTextField(
                                  '소유자 대출 보유 은행명 1 (OWN_LOAN_BNK_NM_1)',
                                  _ownLoanBnkNm1),
                              Spacing.height(5),
                              buildTextField(
                                  '소유자 대출 보유 은행명 2 (OWN_LOAN_BNK_NM_2)',
                                  _ownLoanBnkNm2),
                              Spacing.height(5),
                              buildTextField(
                                  '소유자 대출 보유 은행명 3 (OWN_LOAN_BNK_NM_3)',
                                  _ownLoanBnkNm3),
                              Spacing.height(5),
                              buildTextField(
                                  '소유자 대출 보유 은행명 4 (OWN_LOAN_BNK_NM_4)',
                                  _ownLoanBnkNm4),
                              Spacing.height(5),
                              buildTextField(
                                  '소유자 대출 보유 은행명 5 (OWN_LOAN_BNK_NM_5)',
                                  _ownLoanBnkNm5),
                              Spacing.height(5),
                              buildTextField(
                                  '(신탁등기)부동산소유자_위탁자명 (CNSGN_NM)', _cnsgnNm),
                              Spacing.height(5),
                              buildTextField(
                                  '(신탁등기)신탁사_수탁자명 (TRST_NM)', _trstNm),
                              Spacing.height(5),
                              buildTextField(
                                  '(신탁등기)금융기관_우선수익자명 (BNFR_NM)', _bnfrNm),
                              Spacing.height(5),
                              buildTextField(
                                  '현 임차인명 (NOW_LESS_NM)', _nowLessNm),
                              Spacing.height(5),
                              buildTextField(
                                  '예비 항목 B (RSRV_ITM_B)', _rsrvItmBTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '입주잔금대출-모승인번호 (OBL_M_LN_APRV_NO)',
                                  _oblMLnAprvNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('입주잔금대출-전체건수 (OBL_TOT_CNT)',
                                  _oblTotCntTextCtrl),
                              Spacing.height(5),
                              buildTextField('입주잔금대출-우선순위 (OBL_GRP_RNK_NO)',
                                  _oblGrpRnkNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('여신 승인 번호2 (LN_APRV_NO2)',
                                  _lnAprvNo2TextCtrl),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        });
  }

  Widget buildTextField(String text, TextEditingController textCtrl) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: Get.width * 0.25,
          child: MouseRegion(
            cursor: SystemMouseCursors.text, // 마우스 커서 변경
            child: SelectableText(
              text,
              style: TextSyle.text(),
            ),
          ),
        ),
        IfTextFormField.trans(
          controller: textCtrl,
          textStyle: TextSyle.inputFormText(),
        ),
      ],
    );
  }
}
