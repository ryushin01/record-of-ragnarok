
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/repo/data/cntr_detail_data.dart';
import 'package:nicekos_interface_flutter/repo/response/res_data.dart';
import 'package:nicekos_interface_flutter/utils/if_utils.dart';
import 'package:nicekos_interface_flutter/widget/if_divider.dart';
import 'package:nicekos_interface_flutter/widget/if_text_form_field.dart';
import 'package:nicekos_interface_flutter/theme/text_style.dart';
import '../../repo/data/lnd_stat_db_send_data.dart';
import '../../repo/data/lnd_stat_db_tran_data.dart';
import '../../utils/log_utils.dart';
import '../../widget/If_button.dart';
import '../../theme/colors.dart';
import '../../theme/spacing.dart';
import '../comm/loading_page.dart';
import '../comm/pay_list_page.dart';
import 'ctrl/lnd_stat_db_ctrl.dart';

class LndStatDbPage extends StatefulWidget {
  const LndStatDbPage({super.key});

  @override
  State<StatefulWidget> createState() => _LndStatDbPageState();
}

class _LndStatDbPageState extends State<LndStatDbPage>
    with TickerProviderStateMixin {
  late LndStatDbCtrl controller;

  CntrDetailResData cntrDtl = CntrDetailResData();
  LndStatDbTranResData trnsDtl = LndStatDbTranResData();

  // StreamController<ResStream<Trns6100SendResData>> trnsSendResStream =
  // StreamController<ResStream<Trns6100SendResData>>.broadcast();
  late TextEditingController _searchTextCtrl;
  late TextEditingController _newLoanNoTextCtrl;
  late TextEditingController _tgLenTextCtrl;
  late TextEditingController _tgDscTextCtrl;
  late TextEditingController _resCdTextCtrl;
  late TextEditingController _lndAgncCdTextCtrl;
  late TextEditingController _bnkTgTrnsDtmTextCtrl;
  late TextEditingController _dbTgTrnsDtmTextCtrl;
  late TextEditingController _bnkTgNoTextCtrl;
  late TextEditingController _dbTgNoTextCtrl;
  late TextEditingController _rsrvItmHTextCtrl;
  late TextEditingController _bnkAskNoTextCtrl;
  late TextEditingController _dbMngNoTextCtrl;
  late TextEditingController _kosTgTrnsDtmTextCtrl;
  late TextEditingController _kosTgNoTextCtrl;
  late TextEditingController _nttnYnTextCtrl;
  late TextEditingController _endNotiDtTextCtrl;
  late TextEditingController _endNotiTmTextCtrl;
  late TextEditingController _bnkDrctrNmTextCtrl;
  late TextEditingController _bnkDrctrPhnoTextCtrl;
  late TextEditingController _rsrvItmBTextCtrl;
  late TextEditingController _regDtmTextCtrl;

  @override
  void initState() {
    super.initState();
    if (Get.isRegistered<LndStatDbCtrl>()) {
      Get.delete<LndStatDbCtrl>();
    }
    controller = Get.put(LndStatDbCtrl());
    _searchTextCtrl = TextEditingController();
    _newLoanNoTextCtrl = TextEditingController();
    _tgLenTextCtrl = TextEditingController();
    _tgDscTextCtrl = TextEditingController();
    _resCdTextCtrl = TextEditingController();
    _lndAgncCdTextCtrl = TextEditingController();
    _bnkTgTrnsDtmTextCtrl = TextEditingController();
    _dbTgTrnsDtmTextCtrl = TextEditingController();
    _bnkTgNoTextCtrl = TextEditingController();
    _dbTgNoTextCtrl = TextEditingController();
    _rsrvItmHTextCtrl = TextEditingController();
    _bnkAskNoTextCtrl = TextEditingController();
    _dbMngNoTextCtrl = TextEditingController();
    _kosTgTrnsDtmTextCtrl = TextEditingController();
    _kosTgNoTextCtrl = TextEditingController();
    _nttnYnTextCtrl = TextEditingController();
    _endNotiDtTextCtrl = TextEditingController();
    _endNotiTmTextCtrl = TextEditingController();
    _bnkDrctrNmTextCtrl = TextEditingController();
    _bnkDrctrPhnoTextCtrl = TextEditingController();
    _rsrvItmBTextCtrl = TextEditingController();
    _regDtmTextCtrl = TextEditingController();
  }

  @override
  void dispose() {
    super.dispose();
    if (Get.isRegistered<LndStatDbCtrl>()) {
      Get.delete<LndStatDbCtrl>();
    }
    controller.dispose();
    _searchTextCtrl = TextEditingController();
    _newLoanNoTextCtrl = TextEditingController();
    _tgLenTextCtrl = TextEditingController();
    _tgDscTextCtrl = TextEditingController();
    _resCdTextCtrl = TextEditingController();
    _lndAgncCdTextCtrl = TextEditingController();
    _bnkTgTrnsDtmTextCtrl = TextEditingController();
    _dbTgTrnsDtmTextCtrl = TextEditingController();
    _bnkTgNoTextCtrl = TextEditingController();
    _dbTgNoTextCtrl = TextEditingController();
    _rsrvItmHTextCtrl = TextEditingController();
    _bnkAskNoTextCtrl = TextEditingController();
    _dbMngNoTextCtrl = TextEditingController();
    _kosTgTrnsDtmTextCtrl = TextEditingController();
    _kosTgNoTextCtrl = TextEditingController();
    _nttnYnTextCtrl = TextEditingController();
    _endNotiDtTextCtrl = TextEditingController();
    _endNotiTmTextCtrl = TextEditingController();
    _bnkDrctrNmTextCtrl = TextEditingController();
    _bnkDrctrPhnoTextCtrl = TextEditingController();
    _rsrvItmBTextCtrl = TextEditingController();
    _regDtmTextCtrl = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
        init: controller,
        builder: (controller) {
          return Container(
            margin:
                const EdgeInsets.only(left: 50, top: 20, bottom: 20, right: 50),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 20),
                      child: IfTextFormField.search(
                        controller: _searchTextCtrl,
                        textStyle: TextSyle.searchFormText(),
                      ),
                    ),
                    Spacing.width(20),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          return;
                        }
                        ResData resData =
                            await controller.getCntrDtl(_searchTextCtrl.text);
                        if (resData.code == '00') {
                          cntrDtl = controller.cntrDetailResData;
                          IfUtils.alertIcon(resData.msg.toString(),
                              icontype: '');
                        }
                      },
                      child: Text('검색', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          IfUtils.alertIcon("검색 후 전문 복사", icontype: 'W');
                          return;
                        }
                        Lo.g('_searchTextCtrl.text: ${_searchTextCtrl.text}');
                        ResData resData =
                            await controller.getTrnsDtl(_searchTextCtrl.text);
                        if (resData.code == '00') {
                          Lo.g('trnsDtl.lndAgncCd : ${trnsDtl.lndAgncCd}');
                          trnsDtl = controller.lndStatDbTranResData;
                          _newLoanNoTextCtrl.text = trnsDtl.loanNo ?? '';
                          _tgLenTextCtrl.text = trnsDtl.tgLen.toString();
                          _tgDscTextCtrl.text = trnsDtl.tgDsc ?? '';
                          _resCdTextCtrl.text = trnsDtl.resCd ?? '';
                          _lndAgncCdTextCtrl.text = trnsDtl.lndAgncCd ?? '';
                          _bnkTgTrnsDtmTextCtrl.text =
                              trnsDtl.bnkTgTrnsDtm ?? '';
                          _dbTgTrnsDtmTextCtrl.text = trnsDtl.dbTgTrnsDtm ?? '';
                          _bnkTgNoTextCtrl.text = trnsDtl.bnkTgNo ?? '';
                          _dbTgNoTextCtrl.text = trnsDtl.dbTgNo.toString();
                          _rsrvItmHTextCtrl.text = trnsDtl.rsrvItmH ?? '';
                          _bnkAskNoTextCtrl.text = trnsDtl.bnkAskNo ?? '';
                          _dbMngNoTextCtrl.text = trnsDtl.dbMngNo ?? '';
                          _kosTgTrnsDtmTextCtrl.text =
                              trnsDtl.kosTgTrnsDtm ?? '';
                          _kosTgNoTextCtrl.text = trnsDtl.kosTgNo ?? '';
                          _nttnYnTextCtrl.text = trnsDtl.nttnYn ?? '';
                          _endNotiDtTextCtrl.text = trnsDtl.endNotiDt ?? '';
                          _endNotiTmTextCtrl.text = trnsDtl.endNotiTm ?? '';
                          _bnkDrctrNmTextCtrl.text = trnsDtl.bnkDrctrNm ?? '';
                          _bnkDrctrPhnoTextCtrl.text =
                              trnsDtl.bnkDrctrPhno ?? '';
                          _rsrvItmBTextCtrl.text = trnsDtl.rsrvItmB ?? '';
                          _regDtmTextCtrl.text = trnsDtl.regDtm ?? '';

                          IfUtils.alertIcon(resData.msg.toString(),
                              icontype: '');
                        } else {
                          IfUtils.alertIcon(resData.msg.toString(),
                              icontype: 'W');
                        }
                      },
                      child: Text('전문 복사', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    Row(
                      children: [
                        IfButton(
                          elevation: 0,
                          padding: Spacing.xy(40, 20),
                          backgroundColor: canvasColor,
                          borderRadiusAll: 5,
                          onPressed: () async {
                            if (_searchTextCtrl.text.isEmpty) {
                              IfUtils.alertIcon("전문 복사 후 전문 송신", icontype: 'W');
                              return;
                            }
                            LndStatDbSendReqData reqData =
                                LndStatDbSendReqData();
                            reqData.loanNo = _searchTextCtrl.text;
                            reqData.newLoanNo = _newLoanNoTextCtrl.text;
                            reqData.tgLen = int.parse(_tgLenTextCtrl.text);
                            reqData.tgDsc = _tgDscTextCtrl.text;
                            reqData.lndAgncCd = _lndAgncCdTextCtrl.text;
                            reqData.bnkTgTrnsDtm = _bnkTgTrnsDtmTextCtrl.text;
                            reqData.dbTgTrnsDtm = _dbTgTrnsDtmTextCtrl.text;
                            reqData.bnkTgNo = _bnkTgNoTextCtrl.text;
                            reqData.dbTgNo = int.parse(_dbTgNoTextCtrl.text);
                            reqData.rsrvItmH = _rsrvItmHTextCtrl.text;
                            reqData.bnkAskNo = _bnkAskNoTextCtrl.text;
                            reqData.dbMngNo = _dbMngNoTextCtrl.text;
                            reqData.kosTgTrnsDtm = _kosTgTrnsDtmTextCtrl.text;
                            reqData.kosTgNo = _kosTgNoTextCtrl.text;
                            reqData.nttnYn = _nttnYnTextCtrl.text;
                            reqData.endNotiDt = _endNotiDtTextCtrl.text;
                            reqData.endNotiTm = _endNotiTmTextCtrl.text;
                            reqData.bnkDrctrNm = _bnkDrctrNmTextCtrl.text;
                            reqData.bnkDrctrPhno = _bnkDrctrPhnoTextCtrl.text;
                            reqData.rsrvItmB = _rsrvItmBTextCtrl.text;
                            reqData.regDtm = _regDtmTextCtrl.text;

                            ResData resData =
                                await controller.setSendLndStat(reqData);
                            if (resData.code == '00') {
                              IfUtils.alertIcon(resData.msg.toString(),
                                  icontype: '');
                            } else {
                              IfUtils.alertIcon('실패', icontype: 'W');
                            }
                          },
                          child:
                              Text('전문 송신', style: TextSyle.searchFormText()),
                        ),
                        LoadingPage<LndStatDbSendResData>(
                          stream: LndStatDbCtrl.to.trnSendResStream.stream,
                        ),
                      ],
                    ),
                    Spacing.width(10),
                  ],
                ),
                Spacing.height(40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    PayListPage(
                        controller: controller,
                        searchTextCtrl: _searchTextCtrl),
                    Spacing.width(40),
                    Spacing.width(10),
                    Expanded(
                      child: SizedBox(
                        height: Get.height * 0.8,
                        //width: Get.width * 0.2,
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Spacing.height(40),
                              IfUtils.buildCategory('전문 전송 정보'),
                              Spacing.height(20),
                              IfDivider(width: 0.37),
                              Spacing.height(20),
                              buildTextField(
                                  '신규 여신 번호 (NEW_LOAN_NO)', _newLoanNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('전문 길이 (TG_LEN)', _tgLenTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전문 구분 코드 (TG_DSC)', _tgDscTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '대출 기관 코드 (LND_AGNC_CD)', _lndAgncCdTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 전문 전송 일시 (BNK_TG_TRNS_DTM)',
                                  _bnkTgTrnsDtmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '은행 전문 번호 (KOS_TG_NO)', _bnkTgNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  'DB 전문 번호 (DB_TG_NO)', _dbTgNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '예비 항목 H (RSRV_ITM_H)', _rsrvItmHTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '은행 의뢰 번호 (BNK_ASK_NO)', _bnkAskNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  'DB 관리 번호 (DB_MNG_NO)', _dbMngNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('KOS 전문 전송 일시 (KOS_TG_TRNS_DTM)',
                                  _kosTgTrnsDtmTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  'KOS 전문 번호 (KOS_TG_NO)', _kosTgNoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '기표 여부 (NTTN_YN)', _nttnYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '종료 통보 일자 (END_NOTI_DT)', _endNotiDtTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '종료 통보 시간 (END_NOTI_TM)', _endNotiTmTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 담당자 명 (BNK_DRCTR_NM)',
                                  _bnkDrctrNmTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 담당자 연락처 (BNK_DRCTR_PHNO)',
                                  _bnkDrctrPhnoTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '예비 항목 B (RSRV_ITM_B)', _rsrvItmBTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '등록 일시 (REG_DTM)', _regDtmTextCtrl),
                              Spacing.height(5),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        });
  }

  Widget buildTextField(String text, TextEditingController textCtrl) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: Get.width * 0.25,
          child: MouseRegion(
            cursor: SystemMouseCursors.text, // 마우스 커서 변경
            child: SelectableText(
              text,
              style: TextSyle.text(),
            ),
          ),
        ),
        IfTextFormField.trans(
          controller: textCtrl,
          textStyle: TextSyle.inputFormText(),
        ),
      ],
    );
  }
}