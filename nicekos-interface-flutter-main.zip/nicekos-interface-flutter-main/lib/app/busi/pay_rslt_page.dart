import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import '../../repo/data/cntr_detail_data.dart';
import '../../repo/data/search_payment_list_data.dart';
import '../../repo/data/trans_A400_detail_data.dart';
import '../../repo/data/trns_A400_send_data.dart';
import '../../repo/response/res_data.dart';
import '../../repo/response/res_stream.dart';
import '../../theme/colors.dart';
import '../../theme/spacing.dart';
import '../../theme/text_style.dart';
import '../../utils/if_format.dart';
import '../../utils/if_utils.dart';
import '../../widget/If_button.dart';
import '../../widget/if_divider.dart';
import '../../widget/if_text_form_field.dart';
import '../comm/loading_page.dart';
import '../comm/pay_list_page.dart';
import 'ctrl/pay_rslt_ctrl.dart';

class A400Page extends StatefulWidget {
  const A400Page({super.key});

  @override
  State<StatefulWidget> createState() => _A400PageState();
}

class _A400PageState extends State<A400Page> with TickerProviderStateMixin {
  late PayRsltCtrl controller;
  CntrDetailResData cntrDtl = CntrDetailResData();
  TrnA400ResData a400Dtl = TrnA400ResData();

  late TextEditingController _searchTextCtrl; // 조회

  //late TextEditingController _newLoanTextCtrl; //신규 여신번호
  late TextEditingController _trLnTextCtrl; // 전문길이
  late TextEditingController _trCdTextCtrl; // 전문종별코드
  late TextEditingController _trTpCdTextCtrl; // 거래구분코드
  late TextEditingController _loNoTextCtrl; // 관리번호
  // late TextEditingController _trSqTextCtrl;             // 식별번호
  // late TextEditingController _reqDttmTextCtrl;          // 송신일자
  // late TextEditingController _resDttmTextCtrl;          // 수신일자
  // late TextEditingController _resCdTextCtrl;             // 응답코드
  // late TextEditingController _approvalNumTextCtrl;      // 여신승인신청번호
  late TextEditingController _payTypeTextCtrl; // 지급구분
  late TextEditingController _payBankCdTextCtrl; // 지급요청 은행코드
  late TextEditingController _payAmtTextCtrl; // 지급요청 금액
  late TextEditingController _transResultCdTextCtrl; // 이체 결과 코드

  @override
  void initState() {
    super.initState();
    if (Get.isRegistered<PayRsltCtrl>()) {
      Get.delete<PayRsltCtrl>();
    }
    controller = Get.put(PayRsltCtrl());

    // TextEditingController 초기화
    _searchTextCtrl = TextEditingController();
    //_newLoanTextCtrl = TextEditingController();
    _trLnTextCtrl = TextEditingController();
    _trCdTextCtrl = TextEditingController();
    _trTpCdTextCtrl = TextEditingController();
    _loNoTextCtrl = TextEditingController();
    _payTypeTextCtrl = TextEditingController();
    _payBankCdTextCtrl = TextEditingController();
    _payAmtTextCtrl = TextEditingController();
    _transResultCdTextCtrl = TextEditingController();
  }

  @override
  void dispose() {
    // TextEditingController 해제
    _searchTextCtrl.dispose();
    //_newLoanTextCtrl.dispose();
    _trLnTextCtrl.dispose();
    _trCdTextCtrl.dispose();
    _trTpCdTextCtrl.dispose();
    _loNoTextCtrl.dispose();
    _payTypeTextCtrl.dispose();
    _payBankCdTextCtrl.dispose();
    _payAmtTextCtrl.dispose();
    _transResultCdTextCtrl.dispose();

    // A400Ctrl 해제
    if (Get.isRegistered<PayRsltCtrl>()) {
      Get.delete<PayRsltCtrl>();
    }

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
        init: controller,
        builder: (controller) {
          return Container(
            margin:
                const EdgeInsets.only(left: 50, top: 20, bottom: 20, right: 50),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 20),
                        child: IfTextFormField.search(
                          controller: _searchTextCtrl,
                          textStyle: TextSyle.searchFormText(),
                        ),
                      ),
                      Spacing.width(20),
                      IfButton(
                        elevation: 0,
                        padding: Spacing.xy(40, 20),
                        backgroundColor: canvasColor,
                        borderRadiusAll: 5,
                        onPressed: () async {
                          if (_searchTextCtrl.text.isEmpty) {
                            IfUtils.alertIcon("여신 번호 입력!", icontype: 'W');
                            return;
                          }
                          ResData resCntrData =
                              await controller.getCntrDtl(_searchTextCtrl.text);
                          if (resCntrData.code == '00') {
                            cntrDtl = controller.cntrDetailResData;
                            IfUtils.alertIcon(resCntrData.msg.toString(),
                                icontype: '');
                          } else {
                            IfUtils.alertIcon('검색 실패', icontype: 'W');
                          }
                        },
                        child: Text('검색', style: TextSyle.searchFormText()),
                      ),
                      Spacing.width(10),
                      IfButton(
                        elevation: 0,
                        padding: Spacing.xy(40, 20),
                        backgroundColor: canvasColor,
                        borderRadiusAll: 5,
                        onPressed: () async {
                          if (_searchTextCtrl.text.isEmpty) {
                            IfUtils.alertIcon("검색 후 전문 복사", icontype: 'W');
                            return;
                          }

                          ResData resData =
                              await controller.getTrnsDtl(_searchTextCtrl.text);
                          if (resData.code == '00') {
                            a400Dtl = controller.trnA400ResData;
                            //_searchTextCtrl.text = a400Dtl.loanNo ?? '';
                            _trLnTextCtrl.text = a400Dtl.trLn ?? '';
                            _trCdTextCtrl.text = a400Dtl.trCd ?? '';
                            _trTpCdTextCtrl.text = a400Dtl.trTpCd ?? '';
                            _loNoTextCtrl.text = a400Dtl.loNo ?? '';
                            _payTypeTextCtrl.text = a400Dtl.payType ?? '';
                            _payBankCdTextCtrl.text = a400Dtl.payBankCd ?? '';
                            _payAmtTextCtrl.text = a400Dtl.payAmt ?? '';
                            _transResultCdTextCtrl.text =
                                a400Dtl.transResultCd ?? '';
                          }
                        },
                        child: Text('전문 복사', style: TextSyle.searchFormText()),
                      ),
                      Spacing.width(10),
                      Row(
                        children: [
                          IfButton(
                            elevation: 0,
                            padding: Spacing.xy(40, 20),
                            backgroundColor: canvasColor,
                            borderRadiusAll: 5,
                            onPressed: () async {
                              if (_searchTextCtrl.text.isEmpty) {
                                IfUtils.alertIcon("전문 복사 후 전문 송신",
                                    icontype: 'W');
                                return;
                              }
                              TrnsA400SendReqData reqData =
                                  TrnsA400SendReqData();
                              // reqData.loanNo = _searchTextCtrl.text;
                              reqData.loanNo = _searchTextCtrl.text;
                              reqData.trLn = _trLnTextCtrl.text;
                              reqData.trCd = _trCdTextCtrl.text;
                              reqData.trTpCd = _trTpCdTextCtrl.text;
                              reqData.loNo = _loNoTextCtrl.text;
                              reqData.payType = _payTypeTextCtrl.text;
                              reqData.payBankCd = _payBankCdTextCtrl.text;
                              reqData.payAmt = _payAmtTextCtrl.text;
                              reqData.transResultCd =
                                  _transResultCdTextCtrl.text;

                              ResData resData =
                                  await controller.setSendPayRslt(reqData);
                              if (resData.code == '00') {
                                IfUtils.alertIcon(resData.msg.toString(),
                                    icontype: '');
                              } else {
                                IfUtils.alertIcon('실패', icontype: '');
                              }
                            },
                            child:
                                Text('전문 송신', style: TextSyle.searchFormText()),
                          ),
                          LoadingPage<TrnsA400SendResData>(
                            stream: PayRsltCtrl.to.trnSendResStream.stream,
                          ),
                        ],
                      ),
                      Spacing.width(10),
                    ],
                  ),
                  Spacing.height(40),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      PayListPage(
                          controller: controller,
                          searchTextCtrl: _searchTextCtrl),
                      Spacing.width(40),
                      Expanded(
                        child: SizedBox(
                          height: Get.height * 0.8,
                          //width: Get.width * 0.2,
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Spacing.height(40),
                                IfUtils.buildCategory('전문 전송 정보'),
                                Spacing.height(20),
                                IfDivider(width: 0.37),
                                Spacing.height(20),
                                buildTextField(
                                    '여신 번호 (LOAN_NO)', _searchTextCtrl),
                                Spacing.height(5),
                                buildTextField('전문 길이 (TR_LN)', _trLnTextCtrl),
                                Spacing.height(5),
                                buildTextField(
                                    '전문 구분 코드 (TR_CD)', _trCdTextCtrl),
                                Spacing.height(5),
                                buildTextField(
                                    '전문 거래 구분 코드 (TR_TP_CD)', _trTpCdTextCtrl),
                                Spacing.height(5),
                                buildTextField(
                                    '지급 구분 코드 (PAY_TYPE)', _payTypeTextCtrl),
                                Spacing.height(5),
                                buildTextField('지급 요청 은행 코드 (PAY_BANK_CD)',
                                    _payBankCdTextCtrl),
                                Spacing.height(5),
                                buildTextField(
                                    '지급 요청 금액 (PAY_AMT)', _payAmtTextCtrl),
                                Spacing.height(5),
                                buildTextField('이체 결과 코드 (TRANS_RESULT_CD)',
                                    _transResultCdTextCtrl),
                                Spacing.height(10),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        });
  }
}

Widget buildTextField(String text, TextEditingController textCtrl) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      SizedBox(
        width: Get.width * 0.25,
        child: MouseRegion(
          cursor: SystemMouseCursors.text, // 마우스 커서 변경
          child: SelectableText(
            text,
            style: TextSyle.text(),
          ),
        ),
      ),
      IfTextFormField.trans(
          controller: textCtrl,
          textStyle: TextSyle.inputFormText(),
          onSuffixIconTap: () {
            textCtrl.clear();
          }),
    ],
  );
}
