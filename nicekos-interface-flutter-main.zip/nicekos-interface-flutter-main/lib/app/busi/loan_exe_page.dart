import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/app/busi/ctrl/loan_exe_ctrl.dart';
import 'package:nicekos_interface_flutter/repo/data/trans_A700_detail_data.dart';

import '../../repo/data/cntr_detail_data.dart';
import '../../repo/data/search_payment_list_data.dart';
import '../../repo/data/trns_A700_send_data.dart';
import '../../repo/data/preask_fa_send_data.dart';
import '../../repo/response/res_data.dart';
import '../../repo/response/res_stream.dart';
import '../../theme/colors.dart';
import '../../theme/spacing.dart';
import '../../theme/text_style.dart';
import '../../utils/if_format.dart';
import '../../utils/if_utils.dart';
import '../../widget/If_button.dart';
import '../../widget/if_divider.dart';
import '../../widget/if_text_form_field.dart';
import '../comm/loading_page.dart';
import '../comm/pay_list_page.dart';

class LoanExePage extends StatefulWidget {
  const LoanExePage({super.key});

  @override
  State<StatefulWidget> createState() => _LoanExePageState();
}

class _LoanExePageState extends State<LoanExePage>
    with TickerProviderStateMixin {

  late LoanExeCtrl controller;
  CntrDetailResData cntrDtl = CntrDetailResData();
  TrnA700ResData trnsDtl = TrnA700ResData();

  late TextEditingController _searchTextCtrl; // 조회
  late TextEditingController _newLoanTextCtrl; // 신규 여신번호
  late TextEditingController _trLnTextCtrl; // 전문 길이
  late TextEditingController _trCdTextCtrl; // 전문 종별 코드
  late TextEditingController _trTpCdTextCtrl; // 전문 종별 코드
  late TextEditingController _loNoTextCtrl; // 관리 번호
  late TextEditingController _trSQTextCtrl; // 식별 번호
  late TextEditingController _approvalNumTextCtrl; // 여신 승인 신청 번호
  late TextEditingController _exeDtmTextCtrl; // 실행 일시
  late TextEditingController _procDvsnTextCtrl; // 실행/취소 구분
  late TextEditingController _exeAmtTextCtrl; // 실행 금액
  late TextEditingController _categoryCdTextCtrl; // 대출 구분 (역전세, 대출이동)
  late TextEditingController _docTaxTextCtrl; // 인지세
  late TextEditingController _debtDcAmtTextCtrl; // 채권 할인 금액
  late TextEditingController _etcAmtTextCtrl; // 기타 비용


  @override
  void initState() {
    super.initState();
    if (Get.isRegistered<LoanExeCtrl>()) {
      Get.delete<LoanExeCtrl>();
    }
    controller = Get.put(LoanExeCtrl());
    _searchTextCtrl = TextEditingController();
    _newLoanTextCtrl = TextEditingController();
    _trLnTextCtrl = TextEditingController();// 전문 길이
    _trCdTextCtrl = TextEditingController(); // 전문 종별 코드
    _trTpCdTextCtrl = TextEditingController(); // 전문 종별 코드
    _loNoTextCtrl = TextEditingController(); // 관리 번호
    _trSQTextCtrl = TextEditingController(); // 식별 번호
    _approvalNumTextCtrl = TextEditingController(); // 여신 승인 신청 번호
    _exeDtmTextCtrl = TextEditingController(); // 실행 일시
    _procDvsnTextCtrl = TextEditingController(); // 실행/취소 구분
    _exeAmtTextCtrl = TextEditingController();  // 실행 금액
    _categoryCdTextCtrl = TextEditingController(); // 대출 구분 (역전세, 대출이동)
    _docTaxTextCtrl = TextEditingController();// 인지세
   _debtDcAmtTextCtrl = TextEditingController();// 채권 할인 금액
    _etcAmtTextCtrl = TextEditingController(); // 기타 비용
  }

  @override
  void dispose() {
    super.dispose();
    if (Get.isRegistered<LoanExeCtrl>()) {
      Get.delete<LoanExeCtrl>();
    }
    _searchTextCtrl = TextEditingController();
    _newLoanTextCtrl = TextEditingController();
    _trLnTextCtrl = TextEditingController();// 전문 길이
    _trCdTextCtrl = TextEditingController(); // 전문 종별 코드
    _trTpCdTextCtrl = TextEditingController(); // 전문 종별 코드
    _loNoTextCtrl = TextEditingController(); // 관리 번호
    _trSQTextCtrl = TextEditingController(); // 식별 번호
    _approvalNumTextCtrl = TextEditingController(); // 여신 승인 신청 번호
    _exeDtmTextCtrl = TextEditingController(); // 실행 일시
    _procDvsnTextCtrl = TextEditingController(); // 실행/취소 구분
    _exeAmtTextCtrl = TextEditingController();  // 실행 금액
    _categoryCdTextCtrl = TextEditingController(); // 대출 구분 (역전세, 대출이동)
    _docTaxTextCtrl = TextEditingController();// 인지세
    _debtDcAmtTextCtrl = TextEditingController();// 채권 할인 금액
    _etcAmtTextCtrl = TextEditingController(); // 기타 비용
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
        init: controller,
        builder: (controller) {
      return Container(
        margin:
        const EdgeInsets.only(left: 50, top: 20, bottom: 20, right: 50),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 20),
                  child: IfTextFormField.search(
                    controller: _searchTextCtrl,
                    textStyle: TextSyle.searchFormText(),
                  ),
                ),
                Spacing.width(20),
                IfButton(
                  elevation: 0,
                  padding: Spacing.xy(40, 20),
                  backgroundColor: canvasColor,
                  borderRadiusAll: 5,
                  onPressed: () async {
                    if (_searchTextCtrl.text.isEmpty) {
                      IfUtils.alertIcon("여신 번호 입력!", icontype: 'W');
                      return;
                    }
                    ResData resCntrData =
                    await controller.getCntrDtl(_searchTextCtrl.text);
                    if (resCntrData.code == '00') {
                      cntrDtl = controller.cntrDetailResData;
                      IfUtils.alertIcon(resCntrData.msg.toString(), icontype: '');
                    } else {
                      IfUtils.alertIcon('검색 실패', icontype: 'W');
                    }
                  },
                  child: Text('검색', style: TextSyle.searchFormText()),
                ),
                Spacing.width(10),
                IfButton(
                  elevation: 0,
                  padding: Spacing.xy(40, 20),
                  backgroundColor: canvasColor,
                  borderRadiusAll: 5,
                  onPressed: () async {
                    if (_searchTextCtrl.text.isEmpty) {
                      IfUtils.alertIcon("검색 후 전문 복사", icontype: 'W');
                      return;
                    }
                    ResData resData =
                    await controller.getTrnsDtl(_searchTextCtrl.text);
                    if (resData.code == '00') {
                      trnsDtl = controller.trnA700ResData;
                      _newLoanTextCtrl.text = trnsDtl.loanNo ?? '';
                      _trLnTextCtrl.text = trnsDtl.trLn ?? '';
                      _trCdTextCtrl.text = trnsDtl.trCd ?? '';
                      _trTpCdTextCtrl.text = trnsDtl.trTpCd ?? '';
                      _loNoTextCtrl.text = trnsDtl.loNo ?? '';
                      _trSQTextCtrl.text = trnsDtl.trSq ?? '';
                      _approvalNumTextCtrl.text = trnsDtl.approvalNum ?? '';
                      _exeDtmTextCtrl.text = trnsDtl.exeDtm ?? '';
                      _procDvsnTextCtrl.text = trnsDtl.procDvsn ?? '';
                      _exeAmtTextCtrl.text = trnsDtl.exeAmt ?? '';
                      _categoryCdTextCtrl.text = trnsDtl.categoryCd ?? '';
                      _docTaxTextCtrl.text = trnsDtl.docTax ?? '';
                      _debtDcAmtTextCtrl.text = trnsDtl.debtDcAmt ?? '';
                      _etcAmtTextCtrl.text = trnsDtl.etcAmt ?? '';
                    }
                  },
                  child: Text('전문 복사', style: TextSyle.searchFormText()),
                ),
                Spacing.width(10),
                Row(
                  children: [
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_newLoanTextCtrl.text.isEmpty) {
                          IfUtils.alertIcon("전문 복사 후 전문 송신", icontype: 'W');
                          return;
                        }
                        TrnsA700SendReqData reqData = TrnsA700SendReqData();
                        reqData.loanNo = _searchTextCtrl.text;
                        reqData.newLoanNo = _newLoanTextCtrl.text;
                        reqData.trLn = _trLnTextCtrl.text;
                        reqData.trCd = _trCdTextCtrl.text;
                        reqData.trTpCd = _trTpCdTextCtrl.text;
                        reqData.loNo = _loNoTextCtrl.text;
                        reqData.trSq = _trSQTextCtrl.text;
                        reqData.approvalNum = _approvalNumTextCtrl.text;
                        reqData.exeDtm = _exeDtmTextCtrl.text;
                        reqData.procDvsn = _procDvsnTextCtrl.text;
                        reqData.etcAmt = _exeAmtTextCtrl.text;
                        reqData.categoryCd = _categoryCdTextCtrl.text;
                        reqData.docTax = _docTaxTextCtrl.text;
                        reqData.debtDcAmt = _debtDcAmtTextCtrl.text;
                        reqData.etcAmt = _etcAmtTextCtrl.text;
                        ResData resData = await controller.setSendLoanExe(reqData);
                        if (resData.code == '00') {
                          IfUtils.alertIcon(
                              resData.msg.toString(), icontype: '');
                        } else {
                          IfUtils.alertIcon('실패', icontype: '');
                        }

                      },
                      child: Text('전문 송신', style: TextSyle.searchFormText()),
                    ),
                    LoadingPage<TrnsA700SendResData>(
                      stream: LoanExeCtrl.to.trnSendResStream.stream,
                    ),
                  ],
                ),
                Spacing.width(10),
              ],
            ),
            Spacing.height(40),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                PayListPage(controller: controller,
                    searchTextCtrl: _searchTextCtrl),
                Spacing.width(40),

                Spacing.width(10),
                Expanded(
                  child: SizedBox(
                    height: Get.height * 0.8,
                    width: Get.width * 0.2,
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Spacing.height(40),
                          IfUtils.buildCategory('전문 전송 정보'),
                          Spacing.height(20),
                          IfDivider(width: 0.37),
                          Spacing.height(20),
                          buildTextField('여신 번호 (LOAN_NO)', _searchTextCtrl),
                          Spacing.height(5),
                          buildTextField('전문 길이 (TR_LN)', _trLnTextCtrl),
                          Spacing.height(5),
                          buildTextField('전문 구분 코드 (TR_CD)', _trCdTextCtrl),
                          Spacing.height(5),
                          buildTextField('전문 거래 구분 코드 (TR_TP_CD)', _trTpCdTextCtrl),
                          Spacing.height(5),
                          buildTextField('관리 번호 (LO_NO)', _loNoTextCtrl),
                          Spacing.height(5),
                          buildTextField('식별 번호 (TR_SQ)', _trSQTextCtrl),
                          Spacing.height(5),
                          buildTextField('여신 번호 (APPROVAL_NUM)', _approvalNumTextCtrl),
                          Spacing.height(5),
                          buildTextField('실행 일시 (EXE_DTM)', _exeDtmTextCtrl),
                          Spacing.height(5),
                          buildTextField('실행/취소 구분 (PROC_DVSN)', _procDvsnTextCtrl),
                          Spacing.height(5),
                          buildTextField('실행 금액 (EXE_AMT)', _exeAmtTextCtrl),
                          Spacing.height(5),
                          buildTextField('대출 구분 코드 (CATEGORY_CD)', _categoryCdTextCtrl),
                          Spacing.height(5),
                          buildTextField('인지세 (DOC_TAX)', _docTaxTextCtrl),
                          Spacing.height(5),
                          buildTextField('채권 할인 금액 (DEBT_DC_AMT)', _debtDcAmtTextCtrl),
                          Spacing.height(5),
                          buildTextField('기타 비용 (ETC_AMT)', _etcAmtTextCtrl),
                          Spacing.height(5),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
        });
    }
}


Widget buildTextField(String text, TextEditingController textCtrl) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      SizedBox(
        width: Get.width * 0.25,
        child: MouseRegion(
          cursor: SystemMouseCursors.text, // 마우스 커서 변경
          child: SelectableText(
            text,
            style: TextSyle.text(),
          ),
        ),
      ),
      IfTextFormField.trans(
        controller: textCtrl,
        textStyle: TextSyle.inputFormText(),
      ),
    ],
  );
}


