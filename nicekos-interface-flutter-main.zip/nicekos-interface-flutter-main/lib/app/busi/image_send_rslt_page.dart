import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/app/busi/ctrl/loan_exe_ctrl.dart';
import 'package:nicekos_interface_flutter/repo/data/trans_B700_detail_data.dart';

import '../../repo/data/cntr_detail_data.dart';
import '../../repo/data/search_comm_code_data.dart';
import '../../repo/data/search_payment_list_data.dart';
import '../../repo/data/trns_B700_send_data.dart';
import '../../repo/data/preask_fa_send_data.dart';
import '../../repo/response/res_data.dart';
import '../../repo/response/res_stream.dart';
import '../../theme/colors.dart';
import '../../theme/spacing.dart';
import '../../theme/text_style.dart';
import '../../utils/if_format.dart';
import '../../utils/if_utils.dart';
import '../../widget/If_button.dart';
import '../../widget/if_divider.dart';
import '../../widget/if_text_form_field.dart';
import '../comm/loading_page.dart';
import '../comm/pay_list_page.dart';
import 'ctrl/image_send_rslt_ctrl.dart';

class ImageSendRsltPage extends StatefulWidget {
  const ImageSendRsltPage({super.key});

  @override
  State<StatefulWidget> createState() => _ImageSendRsltPageState();
}

class _ImageSendRsltPageState extends State<ImageSendRsltPage>
    with TickerProviderStateMixin {
  late ImageSendRsltCtrl controller;
  CntrDetailResData cntrDtl = CntrDetailResData();
  TrnB700ResData trnsDtl = TrnB700ResData();

  late TextEditingController _searchTextCtrl; // 조회
  //late TextEditingController _newLoanTextCtrl; // 신규 여신번호
  late TextEditingController _trLnTextCtrl; // 전문 길이
  late TextEditingController _trCdTextCtrl; // 전문 종별 코드
  late TextEditingController _trTpCdTextCtrl; // 거래구분코드
  late TextEditingController _loNoTextCtrl; // 관리 번호
  late TextEditingController _imgTpTextCtrl; // 이미지구분
  late TextEditingController _imgCheckYnTextCtrl; // 이미지확인여부
  late TextEditingController _imgKeyTextCtrl; // 이미지 키
  late TextEditingController _imgPageCntTextCtrl; // 이미지 페이지 수
  late TextEditingController _seqNoTextCtrl; // 시퀀스번호
  late TextEditingController _imgFileNameTextCtrl; // 이미지 파일명
  late TextEditingController _resultCdTextCtrl; // 처리결과

  SearchCommCodeRes? selectedImageCd;

  @override
  void initState() {
    super.initState();
    if (Get.isRegistered<ImageSendRsltCtrl>()) {
      Get.delete<ImageSendRsltCtrl>();
    }
    controller = Get.put(ImageSendRsltCtrl());

    _searchTextCtrl = TextEditingController();
    //_newLoanTextCtrl = TextEditingController(); //여신번호
    _trLnTextCtrl = TextEditingController(); // 전문 길이
    _trCdTextCtrl = TextEditingController(); // 전문 종별 코드
    _trTpCdTextCtrl = TextEditingController(); // 전문 종별 코드
    _loNoTextCtrl = TextEditingController(); // 관리 번호
    _imgTpTextCtrl = TextEditingController(); // 이미지구분
    _imgCheckYnTextCtrl = TextEditingController(); // 이미지확인여부
    _imgKeyTextCtrl = TextEditingController(); // 이미지 키
    _imgPageCntTextCtrl = TextEditingController(); // 이미지 페이지 수
    _seqNoTextCtrl = TextEditingController(); // 시퀀스번호
    _imgFileNameTextCtrl = TextEditingController(); // 이미지 파일명
    _resultCdTextCtrl = TextEditingController(); // 처리결과
  }

  @override
  void dispose() {
    super.dispose();
    _searchTextCtrl = TextEditingController();
    //_newLoanTextCtrl = TextEditingController();
    _trLnTextCtrl = TextEditingController(); // 전문 길이
    _trCdTextCtrl = TextEditingController(); // 전문 종별 코드
    _trTpCdTextCtrl = TextEditingController(); // 전문 종별 코드
    _loNoTextCtrl = TextEditingController(); // 관리 번호
    _imgTpTextCtrl.dispose();
    _imgCheckYnTextCtrl.dispose();
    _imgKeyTextCtrl.dispose();
    _imgPageCntTextCtrl.dispose();
    _seqNoTextCtrl.dispose();
    _imgFileNameTextCtrl.dispose();
    _resultCdTextCtrl.dispose();

    if (Get.isRegistered<ImageSendRsltCtrl>()) {
      Get.delete<ImageSendRsltCtrl>();
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
        init: controller,
        builder: (controller) {
          return Container(
            margin:
                const EdgeInsets.only(left: 50, top: 20, bottom: 20, right: 50),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 20),
                      child: IfTextFormField.search(
                        controller: _searchTextCtrl,
                        textStyle: TextSyle.searchFormText(),
                      ),
                    ),
                    Spacing.width(20),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          IfUtils.alertIcon("여신 번호 입력!", icontype: 'W');
                          return;
                        }
                        ResData resCntrData =
                            await controller.getCntrDtl(_searchTextCtrl.text);
                        if (resCntrData.code == '00') {
                          cntrDtl = controller.cntrDetailResData;
                          IfUtils.alertIcon(resCntrData.msg.toString(),
                              icontype: '');
                        } else {
                          IfUtils.alertIcon('검색 실패', icontype: 'W');
                        }
                      },
                      child: Text('검색', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    IfButton(
                      elevation: 0,
                      padding: Spacing.xy(40, 20),
                      backgroundColor: canvasColor,
                      borderRadiusAll: 5,
                      onPressed: () async {
                        if (_searchTextCtrl.text.isEmpty) {
                          IfUtils.alertIcon("검색 후 전문 복사", icontype: 'W');
                          return;
                        }
                        ResData resData =
                            await controller.getTrnsDtl(_searchTextCtrl.text);
                        if (resData.code == '00') {
                          trnsDtl = controller.trnB700ResData;
                          //_searchTextCtrl.text = trnsDtl.loanNo ?? '';
                          _trLnTextCtrl.text = trnsDtl.trLn ?? '';
                          _trCdTextCtrl.text = trnsDtl.trCd ?? '';
                          _trTpCdTextCtrl.text = trnsDtl.trTpCd ?? '';
                          _loNoTextCtrl.text = trnsDtl.loNo ?? '';
                          _imgTpTextCtrl.text = trnsDtl.imgTp ?? '';
                          _imgCheckYnTextCtrl.text = trnsDtl.imgCheckYn ?? '';
                          _imgKeyTextCtrl.text = trnsDtl.imgKey ?? '';
                          _imgPageCntTextCtrl.text = trnsDtl.imgPageCnt ?? '';
                          _seqNoTextCtrl.text = trnsDtl.seqNo ?? '';
                          _imgFileNameTextCtrl.text = trnsDtl.imgFileName ?? '';
                          _resultCdTextCtrl.text = trnsDtl.resultCd ?? '';
                        }
                      },
                      child: Text('전문 복사', style: TextSyle.searchFormText()),
                    ),
                    Spacing.width(10),
                    Row(
                      children: [
                        IfButton(
                          elevation: 0,
                          padding: Spacing.xy(40, 20),
                          backgroundColor: canvasColor,
                          borderRadiusAll: 5,
                          onPressed: () async {
                            if (_searchTextCtrl.text.isEmpty) {
                              IfUtils.alertIcon("전문 복사 후 전문 송신", icontype: 'W');
                              return;
                            }
                            TrnsB700SendReqData reqData = TrnsB700SendReqData();
                            reqData.loanNo = _searchTextCtrl.text;
                            reqData.trLn = _trLnTextCtrl.text;
                            reqData.trCd = _trCdTextCtrl.text;
                            reqData.trTpCd = _trTpCdTextCtrl.text;
                            reqData.loNo = _loNoTextCtrl.text;
                            reqData.imgTp = selectedImageCd?.code ?? '';
                            reqData.imgCheckYn = _imgCheckYnTextCtrl.text;
                            reqData.imgKey = _imgKeyTextCtrl.text;
                            reqData.imgPageCnt = _imgPageCntTextCtrl.text;
                            reqData.seqNo = _seqNoTextCtrl.text;
                            reqData.imgFileName = _imgFileNameTextCtrl.text;
                            reqData.resultCd = _resultCdTextCtrl.text;
                            ResData resData =
                                await controller.setSendLoanExe(reqData);
                            if (resData.code == '00') {
                              IfUtils.alertIcon(resData.msg.toString(),
                                  icontype: '');
                            } else {
                              IfUtils.alertIcon('실패', icontype: '');
                            }
                          },
                          child:
                              Text('전문 송신', style: TextSyle.searchFormText()),
                        ),
                        LoadingPage<TrnsB700SendResData>(
                          stream: ImageSendRsltCtrl.to.trnSendResStream.stream,
                        ),
                      ],
                    ),
                    Spacing.width(10),
                  ],
                ),
                Spacing.height(40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    PayListPage(
                        controller: controller,
                        searchTextCtrl: _searchTextCtrl),
                    Spacing.width(40),
                    Expanded(
                      child: SizedBox(
                        height: Get.height * 0.8,
                        //width: Get.width * 0.2,
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Spacing.height(40),
                              IfUtils.buildCategory('전문 전송 정보'),
                              Spacing.height(20),
                              IfDivider(width: 0.37),
                              Spacing.height(10),
                              const Text(
                                '필수x 항목들은 실제 운영 환경에서 포함되는 항목들이지만, \n테스트 환경에서는 필수가 아닌 항목입니다.',
                                style: TextStyle(
                                  color: gray100,
                                  fontSize: 12,
                                  fontFamily: 'Noto Sans KR',
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              Spacing.height(20),
                              buildTextField(
                                  '여신 번호 (LOAN_NO)', _searchTextCtrl),
                              Spacing.height(5),
                              buildTextField('전문 길이 (TR_LN)', _trLnTextCtrl),
                              Spacing.height(5),
                              buildTextField('전문 구분 코드 (TR_CD)', _trCdTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '전문 거래 구분 코드 (TR_TP_CD)', _trTpCdTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '관리 번호 (필수x) (LO_NO)', _loNoTextCtrl),
                              Spacing.height(5),
                              selectImageCd(),
                              Spacing.height(5),
                              buildTextField('이미지 확인 여부 (필수x) (IMG_CHECK_YN)',
                                  _imgCheckYnTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '이미지 키 (필수x) (IMG_KEY)', _imgKeyTextCtrl),
                              Spacing.height(5),
                              buildTextField('이미지 페이지 수 (필수x) (IMG_PAGE_CNT)',
                                  _imgPageCntTextCtrl),
                              Spacing.height(5),
                              buildTextField(
                                  '시퀀스 번호 (필수x) (SEQ_NO)', _seqNoTextCtrl),
                              Spacing.height(5),
                              buildTextField('이미지 파일명 (필수x) (IMG_FILE_NAME)',
                                  _imgFileNameTextCtrl),
                              Spacing.height(5),
                              buildTextField('은행 코드(타행 상환) (RESULT_CD)',
                                  _resultCdTextCtrl),
                              Spacing.height(5),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        });
  }

  Widget selectImageCd() {
    return Row(
      children: [
        SizedBox(
          width: Get.width * 0.25, // 고정 너비 설정
          child: Text(
            '이미지 구분',
            style: TextSyle.text(),
          ),
        ),
        Container(
          height: 27,
          width: 230,
          color: Colors.white,
          padding: EdgeInsets.all(0),
          child: Obx(() => DropdownButtonFormField<SearchCommCodeRes>(
                value: selectedImageCd,
                items: controller.imageCdList.map((SearchCommCodeRes data) {
                  return DropdownMenuItem<SearchCommCodeRes>(
                    value: data,
                    child: Text(
                      '${data.codeNm} (${data.code})' ?? '',
                      style: TextStyle(color: Colors.black, fontSize: 12),
                    ),
                  );
                }).toList(),
                onChanged: (SearchCommCodeRes? newValue) {
                  selectedImageCd = newValue;
                },
                dropdownColor: Colors.white,
                // 드롭다운 배경 색상 설정
                decoration: InputDecoration(
                  // border 및 배경 설정
                  contentPadding: EdgeInsets.symmetric(horizontal: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5), // 둥근 테두리
                  ),
                ),
                iconEnabledColor: Colors.black,
                // 드롭다운 아이콘 색상
                style: TextStyle(
                  color: Colors.black, // 선택된 텍스트 색상
                ),
                elevation: 0, // 그림자 제거
              )),
        ),
      ],
    );
  }
}

Widget buildTextField(String text, TextEditingController textCtrl) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      SizedBox(
        width: Get.width * 0.25,
        child: MouseRegion(
          cursor: SystemMouseCursors.text, // 마우스 커서 변경
          child: SelectableText(
            text,
            style: TextSyle.text(),
          ),
        ),
      ),
      IfTextFormField.trans(
        controller: textCtrl,
        textStyle: TextSyle.inputFormText(),
      ),
    ],
  );
}
