import 'dart:async';

import 'package:get/get.dart';

import '../../../repo/data/trns_hist_data.dart';
import '../../../repo/response/res_data.dart';
import '../../../repo/response/res_stream.dart';
import '../../../repo/trns_hist_repo.dart';
import '../../../utils/log_utils.dart';

class HomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<HomeCtrl>(
      () => HomeCtrl(),
    );
  }
}

class HomeCtrl extends GetxController {
  @override
  void onInit() async {
    super.onInit();
  }

  @override
  void dispose() {
    super.dispose();
  }

  // 전문 발송내역 조회
  Future<ResData> getTrnsHist(StreamController<ResStream<List<TrnsHistResData>>> trnsHistResListStream , String loanNo) async {
    try {

      trnsHistResListStream.sink.add(ResStream.loading());
      TrnsHistRepo trnsHistRepo = TrnsHistRepo();
      ResData resData = await trnsHistRepo.searchTrnHist(loanNo);

      if (resData.code != '00') {
        trnsHistResListStream.sink.add(ResStream.completed([]));
        return resData;
      }

      List<TrnsHistResData> list = ((resData.data) as List)
          .map((data) => TrnsHistResData.fromMap(data))
          .toList();
      trnsHistResListStream.sink.add(ResStream.completed(list));
      return resData;

    } catch (e) {
      Lo.g('전문 발송내역 조회 중 오류 발생 >>>>');
      trnsHistResListStream.sink.add(ResStream.completed([]));
      return ResData();
    }
  }

}
