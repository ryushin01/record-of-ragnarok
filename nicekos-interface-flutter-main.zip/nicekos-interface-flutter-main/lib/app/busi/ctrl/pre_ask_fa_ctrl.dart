import 'dart:async';

import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/repo/cntr_detail_repo.dart';
import 'package:nicekos_interface_flutter/repo/data/cntr_detail_data.dart';
import 'package:nicekos_interface_flutter/repo/data/trns_hist_data.dart';
import 'package:nicekos_interface_flutter/repo/data/preask_fa_send_data.dart';
import 'package:nicekos_interface_flutter/repo/trns_hist_repo.dart';
import 'package:nicekos_interface_flutter/repo/trns_send_repo.dart';

import '../../../repo/data/preask_fa_tran_data.dart';
import '../../../repo/data/search_payment_list_data.dart';
import '../../../repo/payment_repo.dart';
import '../../../repo/response/res_data.dart';
import '../../../repo/response/res_stream.dart';
import '../../../repo/trns_detail_repo.dart';
import '../../../utils/log_utils.dart';
import 'home_ctrl.dart';

class PreAskBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<PreAskCtrl>(
      () => PreAskCtrl(),
    );
  }
}

class PreAskCtrl extends GetxController {

  static PreAskCtrl get to => Get.find();

  CntrDetailResData cntrDetailResData = CntrDetailResData();

  TrnsDetailResData trnsDetailResData = TrnsDetailResData();

  TrnsSendResData trnsSendResData = TrnsSendResData();

  TrnsHistResList trnsHistResList = TrnsHistResList();

  StreamController<ResStream<CntrDetailResData>> cntrDtlResStream =
      StreamController<ResStream<CntrDetailResData>>();

  StreamController<ResStream<TrnsDetailResData>> trnsDtlResStream =
  StreamController<ResStream<TrnsDetailResData>>();

  StreamController<ResStream<TrnsSendResData>> trnsSendResStream =
  StreamController<ResStream<TrnsSendResData>>.broadcast();

  StreamController<ResStream<List<TrnsHistResData>>> trnsHistResListStream =
  StreamController<ResStream<List<TrnsHistResData>>>();


  StreamController<ResStream<List<PaymentListResData>>> paymentResStream =
  StreamController<ResStream<List<PaymentListResData>>>();

  Future<void> fetchData() async {
    try {
      cntrDtlResStream.sink.add(ResStream.loading());
      CntrDetailRepo cntrDetailRepo = CntrDetailRepo();
      ResData resData = await cntrDetailRepo.searchCntrDtl('');
      if (resData.code != '00') {
        cntrDtlResStream.sink.add(ResStream.error(resData.msg.toString()));
        return;
      }
      cntrDetailResData = CntrDetailResData.fromMap(resData.data[0]);
      cntrDtlResStream.sink.add(ResStream.completed(cntrDetailResData));
    } catch (e) {
      Lo.g(e);
      cntrDtlResStream.sink.add(ResStream.error(e.toString()));
    }
  }

//"검색"버튼 클릭 시 호출
  Future<ResData> getCntrDtl(String loanNo) async {
    try {
      cntrDtlResStream.sink.add(ResStream.loading());
      CntrDetailRepo cntrDetailRepo = CntrDetailRepo();
      ResData cntrResData = await cntrDetailRepo.searchCntrDtl(loanNo);
      if (cntrResData.code != '00') {
        cntrDtlResStream.sink.add(ResStream.error(cntrResData.msg.toString()));
        return cntrResData;
      }
      cntrDetailResData = CntrDetailResData.fromMap(cntrResData.data[0]);
      cntrDtlResStream.sink.add(ResStream.completed(cntrDetailResData));

      //지급정보 조회
      paymentResStream.sink.add(ResStream.loading());
      PaymentRepo paymentRepo = PaymentRepo();
      ResData payResData = await paymentRepo.searchPaymentList(loanNo);
      if (payResData.code != '00') {
        Lo.g('지급정보 조회 실패 >>>>>>>>>>> ${cntrResData.msg.toString()}');
        paymentResStream.sink.add(ResStream.completed([]));
        return cntrResData;
      }

      List<PaymentListResData> paymentListResData = ((payResData.data) as List)
          .map((data) => PaymentListResData.fromMap(data))
          .toList();

      paymentResStream.sink.add(ResStream.completed(paymentListResData));

      // 전문 기록 조회
      await Get.find<HomeCtrl>().getTrnsHist(trnsHistResListStream , loanNo);


      return cntrResData;
    } catch (e) {
      Lo.g(e);
      cntrDtlResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }

  Future<ResData> getTrnsDtl(String loanNo) async {
    try {
      trnsDtlResStream.sink.add(ResStream.loading());
      TrnsDetailRepo trnsDetailRepo  = TrnsDetailRepo();
      ResData resData = await trnsDetailRepo.searchTransDtl(loanNo);
      if (resData.code != '00') {
        trnsDtlResStream.sink.add(ResStream.error(resData.msg.toString()));
        return resData;
      }
      trnsDetailResData = TrnsDetailResData.fromMap(resData.data[0]);
      trnsDtlResStream.sink.add(ResStream.completed(trnsDetailResData));
      return resData;
    } catch (e) {
      Lo.g(e);
      trnsDtlResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }

  Future<ResData> setSendPreAsk(TrnsSendReqData reqData) async {
    try {
      trnsSendResStream.sink.add(ResStream.loading());
      TrnsSendRepo trnsSendRepo = TrnsSendRepo();
      ResData resData = await trnsSendRepo.sendFaPreAsk(reqData);
      if (resData.code != '00') {
        trnsSendResStream.sink.add(ResStream.error(resData.msg.toString()));
        return resData;
      }
      trnsSendResData = TrnsSendResData.fromMap(resData.data);
      trnsSendResStream.sink.add(ResStream.completed(trnsSendResData));

      // 전문 기록 조회
      await Get.find<HomeCtrl>().getTrnsHist(trnsHistResListStream , reqData.loanNo ?? '');

      return resData;
    } catch (e) {
      Lo.g(e);
      trnsSendResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }

}
