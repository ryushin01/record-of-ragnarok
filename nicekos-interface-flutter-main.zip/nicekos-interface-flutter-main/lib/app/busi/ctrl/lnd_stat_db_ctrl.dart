import 'dart:async';

import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/repo/cntr_detail_repo.dart';
import 'package:nicekos_interface_flutter/repo/data/cntr_detail_data.dart';

import '../../../repo/data/ask_db_send_data.dart';
import '../../../repo/data/ask_db_tran_data.dart';
import '../../../repo/data/lnd_stat_db_send_data.dart';
import '../../../repo/data/lnd_stat_db_tran_data.dart';
import '../../../repo/data/search_payment_list_data.dart';
import '../../../repo/data/trans_6100_detail_data.dart';
import '../../../repo/data/trns_6100_send_data.dart';
import '../../../repo/data/trns_hist_data.dart';
import '../../../repo/payment_repo.dart';
import '../../../repo/response/res_data.dart';
import '../../../repo/response/res_stream.dart';
import '../../../repo/trns_detail_repo.dart';
import '../../../repo/trns_send_repo.dart';
import '../../../utils/log_utils.dart';
import 'home_ctrl.dart';

class LndStatDbCtrl extends GetxController {
  static LndStatDbCtrl get to => Get.find();

  CntrDetailResData cntrDetailResData = CntrDetailResData();
  LndStatDbTranResData lndStatDbTranResData = LndStatDbTranResData();
  LndStatDbSendResData lndStatDbSendResData = LndStatDbSendResData();

  StreamController<ResStream<CntrDetailResData>> cntrDtlResStream =
  StreamController<ResStream<CntrDetailResData>>();
  StreamController<ResStream<LndStatDbTranResData>> trnsDtlResStream =
  StreamController<ResStream<LndStatDbTranResData>>();
  StreamController<ResStream<LndStatDbSendResData>> trnSendResStream =
  StreamController<ResStream<LndStatDbSendResData>>();
  StreamController<ResStream<List<PaymentListResData>>> paymentResStream =
  StreamController<ResStream<List<PaymentListResData>>>();
  StreamController<ResStream<List<TrnsHistResData>>> trnsHistResListStream =
  StreamController<ResStream<List<TrnsHistResData>>>();



  Future<void> fetchData() async {
    try {
      cntrDtlResStream.sink.add(ResStream.loading());
      CntrDetailRepo cntrDetailRepo = CntrDetailRepo();
      ResData resData = await cntrDetailRepo.searchCntrDtl('');
      if (resData.code != '00') {
        cntrDtlResStream.sink.add(ResStream.error(resData.msg.toString()));
        return;
      }
      cntrDetailResData = CntrDetailResData.fromMap(resData.data[0]);
      cntrDtlResStream.sink.add(ResStream.completed(cntrDetailResData));
    } catch (e) {
      Lo.g(e);
      cntrDtlResStream.sink.add(ResStream.error(e.toString()));
    }
  }

//"검색"버튼 클릭 시 호출
  Future<ResData> getCntrDtl(String loanNo) async {
    try {
      cntrDtlResStream.sink.add(ResStream.loading());
      CntrDetailRepo cntrDetailRepo = CntrDetailRepo();
      ResData cntrResData = await cntrDetailRepo.searchCntrDtl(loanNo);
      if (cntrResData.code != '00') {
        cntrDtlResStream.sink.add(ResStream.error(cntrResData.msg.toString()));
        return cntrResData;
      }
      cntrDetailResData = CntrDetailResData.fromMap(cntrResData.data[0]);
      cntrDtlResStream.sink.add(ResStream.completed(cntrDetailResData));

      //지급정보 조회
      paymentResStream.sink.add(ResStream.loading());
      PaymentRepo paymentRepo = PaymentRepo();
      ResData payResData = await paymentRepo.searchPaymentList(loanNo);
      if (payResData.code != '00') {
        Lo.g('지급정보 조회 실패 >>>>>>>>>>> ${cntrResData.msg.toString()}');
        paymentResStream.sink.add(ResStream.completed([]));
        return cntrResData;
      }

      List<PaymentListResData> paymentListResData = ((payResData.data) as List)
          .map((data) => PaymentListResData.fromMap(data))
          .toList();

      paymentResStream.sink.add(ResStream.completed(paymentListResData));

      // 전문 기록 조회
      await Get.find<HomeCtrl>().getTrnsHist(trnsHistResListStream , loanNo);


      return cntrResData;
    } catch (e) {
      Lo.g(e);
      cntrDtlResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }


  Future<ResData> getTrnsDtl(String loanNo) async {
    try {
      trnsDtlResStream.sink.add(ResStream.loading());
      TrnsDetailRepo trnsDetailRepo  = TrnsDetailRepo();
      ResData resData = await trnsDetailRepo.searchTransDb6300Dtl(loanNo);

      if (resData.code != '00') {
        trnsDtlResStream.sink.add(ResStream.error("오류 >>${resData.msg}"));
        return resData;
      }
      lndStatDbTranResData = LndStatDbTranResData.fromMap(resData.data[0]);
      trnsDtlResStream.sink.add(ResStream.completed(lndStatDbTranResData));
      return resData;
    } catch (e) {
      Lo.g("에러 >> $e");
      trnsDtlResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }

  Future<ResData> setSendLndStat(LndStatDbSendReqData reqData) async {
    try {
      trnSendResStream.sink.add(ResStream.loading());
      TrnsSendRepo trnsSendRepo = TrnsSendRepo();
      ResData resData = await trnsSendRepo.sendDbLndStat(reqData);
      Lo.g("resData ctrl : ${resData}");
      if (resData.code != '00') {
        trnSendResStream.sink.add(ResStream.error(resData.msg.toString()));
        return resData;
      }
      lndStatDbSendResData = LndStatDbSendResData.fromMap(resData.data);
      trnSendResStream.sink.add(ResStream.completed(lndStatDbSendResData));

      // 전문 기록 조회
      await Get.find<HomeCtrl>().getTrnsHist(trnsHistResListStream , reqData.loanNo ?? '');

      return resData;
    } catch (e) {
      Lo.g(e);
      trnSendResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }
}
