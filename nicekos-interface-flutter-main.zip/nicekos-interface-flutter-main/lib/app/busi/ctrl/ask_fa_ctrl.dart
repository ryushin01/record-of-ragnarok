import 'dart:async';

import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/repo/cntr_detail_repo.dart';
import 'package:nicekos_interface_flutter/repo/data/cntr_detail_data.dart';

import '../../../repo/data/search_payment_list_data.dart';
import '../../../repo/data/trans_6100_detail_data.dart';
import '../../../repo/data/trns_6100_send_data.dart';
import '../../../repo/data/trns_hist_data.dart';
import '../../../repo/payment_repo.dart';
import '../../../repo/response/res_data.dart';
import '../../../repo/response/res_stream.dart';
import '../../../repo/trns_detail_repo.dart';
import '../../../repo/trns_send_repo.dart';
import '../../../utils/log_utils.dart';
import 'home_ctrl.dart';

class AskBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AskCtrl>(
          () => AskCtrl(),
    );
  }
}

class AskCtrl extends GetxController {
  static AskCtrl get to => Get.find();

  CntrDetailResData cntrDetailResData = CntrDetailResData();
  Trns6100DetailResData trns6100DetailResData = Trns6100DetailResData();

  StreamController<ResStream<CntrDetailResData>> cntrDtlResStream =
  StreamController<ResStream<CntrDetailResData>>();
  StreamController<ResStream<Trns6100DetailResData>> trnsDtlResStream =
  StreamController<ResStream<Trns6100DetailResData>>();

  StreamController<ResStream<Trns6100SendResData>> trnsSendResStream =
  StreamController<ResStream<Trns6100SendResData>>.broadcast();

  StreamController<ResStream<List<PaymentListResData>>> paymentResStream =
  StreamController<ResStream<List<PaymentListResData>>>();


  Trns6100SendResData trnsSendResData = Trns6100SendResData();

  StreamController<ResStream<List<TrnsHistResData>>> trnsHistResListStream =
  StreamController<ResStream<List<TrnsHistResData>>>();



  Future<void> fetchData() async {
    try {
      cntrDtlResStream.sink.add(ResStream.loading());
      CntrDetailRepo cntrDetailRepo = CntrDetailRepo();
      ResData resData = await cntrDetailRepo.searchCntrDtl('');
      if (resData.code != '00') {
        cntrDtlResStream.sink.add(ResStream.error(resData.msg.toString()));
        return;
      }
      cntrDetailResData = CntrDetailResData.fromMap(resData.data[0]);
      cntrDtlResStream.sink.add(ResStream.completed(cntrDetailResData));
    } catch (e) {
      Lo.g(e);
      cntrDtlResStream.sink.add(ResStream.error(e.toString()));
    }
  }

//"검색"버튼 클릭 시 호출
  Future<ResData> getCntrDtl(String loanNo) async {
    try {
      cntrDtlResStream.sink.add(ResStream.loading());
      CntrDetailRepo cntrDetailRepo = CntrDetailRepo();
      ResData cntrResData = await cntrDetailRepo.searchCntrDtl(loanNo);
      if (cntrResData.code != '00') {
        cntrDtlResStream.sink.add(ResStream.error(cntrResData.msg.toString()));
        return cntrResData;
      }
      cntrDetailResData = CntrDetailResData.fromMap(cntrResData.data[0]);
      cntrDtlResStream.sink.add(ResStream.completed(cntrDetailResData));

      //지급정보 조회
      paymentResStream.sink.add(ResStream.loading());
      PaymentRepo paymentRepo = PaymentRepo();
      ResData payResData = await paymentRepo.searchPaymentList(loanNo);
      if (payResData.code != '00') {
        Lo.g('지급정보 조회 실패 >>>>>>>>>>> ${cntrResData.msg.toString()}');
        paymentResStream.sink.add(ResStream.completed([]));
        return cntrResData;
      }

      List<PaymentListResData> paymentListResData = ((payResData.data) as List)
          .map((data) => PaymentListResData.fromMap(data))
          .toList();

      paymentResStream.sink.add(ResStream.completed(paymentListResData));

      // 전문 기록 조회
      await Get.find<HomeCtrl>().getTrnsHist(trnsHistResListStream , loanNo);


      return cntrResData;
    } catch (e) {
      Lo.g(e);
      cntrDtlResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }


  Future<ResData> getTrnsDtl(String loanNo) async {
    try {
      trnsDtlResStream.sink.add(ResStream.loading());
      TrnsDetailRepo trnsDetailRepo  = TrnsDetailRepo();
      ResData resData = await trnsDetailRepo.searchTrans6100Dtl(loanNo);

      if (resData.code != '00') {
        trnsDtlResStream.sink.add(ResStream.error("오류 >>${resData.msg}"));
        return resData;
      }
      trns6100DetailResData = Trns6100DetailResData.fromMap(resData.data[0]);
      trnsDtlResStream.sink.add(ResStream.completed(trns6100DetailResData));
      return resData;
    } catch (e) {
      Lo.g("에러 >> $e");
      trnsDtlResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }

  Future<ResData> setSendAsk(Trns6100SendReqData reqData) async {
    try {
      trnsSendResStream.sink.add(ResStream.loading());
      TrnsSendRepo trnsSendRepo = TrnsSendRepo();
      ResData resData = await trnsSendRepo.sendFaAsk(reqData);
      Lo.g("resData ctrl : ${resData}");
      if (resData.code != '00') {
        trnsSendResStream.sink.add(ResStream.error(resData.msg.toString()));
        return resData;
      }
      trnsSendResData = Trns6100SendResData.fromMap(resData.data);
      trnsSendResStream.sink.add(ResStream.completed(trnsSendResData));

      // 전문 기록 조회
      await Get.find<HomeCtrl>().getTrnsHist(trnsHistResListStream , reqData.loanNo ?? '');

      return resData;
    } catch (e) {
      Lo.g(e);
      trnsSendResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }
}
