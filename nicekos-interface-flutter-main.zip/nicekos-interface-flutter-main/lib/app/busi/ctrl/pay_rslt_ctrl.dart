import 'dart:async';

import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/bindings_interface.dart';

import 'package:nicekos_interface_flutter/repo/trns_send_repo.dart';

import '../../../repo/cntr_detail_repo.dart';
import '../../../repo/data/cntr_detail_data.dart';
import '../../../repo/data/search_payment_list_data.dart';
import '../../../repo/data/trans_A400_detail_data.dart';
import '../../../repo/data/trns_A400_send_data.dart';
import '../../../repo/data/trns_hist_data.dart';
import '../../../repo/payment_repo.dart';
import '../../../repo/response/res_data.dart';
import '../../../repo/response/res_stream.dart';
import '../../../repo/trns_detail_repo.dart';
import '../../../repo/trns_hist_repo.dart';
import '../../../utils/log_utils.dart';
import 'home_ctrl.dart';

class PayRsltBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<PayRsltCtrl>(
          () => PayRsltCtrl(),
    );
  }
}

class PayRsltCtrl extends GetxController {

  static PayRsltCtrl get to => Get.find();

  CntrDetailResData cntrDetailResData = CntrDetailResData();


  TrnA400ResData trnA400ResData = TrnA400ResData();

  TrnsA400SendResData trnsA400SendResData = TrnsA400SendResData();

  StreamController<ResStream<CntrDetailResData>> cntrDtlResStream =
  StreamController<ResStream<CntrDetailResData>>();

  StreamController<ResStream<List<PaymentListResData>>> paymentResStream =
  StreamController<ResStream<List<PaymentListResData>>>();

  StreamController<ResStream<TrnA400ResData>> trnResStream =
  StreamController<ResStream<TrnA400ResData>>();

  StreamController<ResStream<TrnsA400SendResData>> trnSendResStream =
  StreamController<ResStream<TrnsA400SendResData>>();

  StreamController<ResStream<List<TrnsHistResData>>> trnsHistResListStream =
  StreamController<ResStream<List<TrnsHistResData>>>();


  Future<void> fetchData() async {
    try {
      cntrDtlResStream.sink.add(ResStream.loading());
      CntrDetailRepo cntrDetailRepo = CntrDetailRepo();
      ResData resData = await cntrDetailRepo.searchCntrDtl('');
      if (resData.code != '00') {
        cntrDtlResStream.sink.add(ResStream.error(resData.msg.toString()));
        return;
      }
      cntrDetailResData = CntrDetailResData.fromMap(resData.data[0]);
      cntrDtlResStream.sink.add(ResStream.completed(cntrDetailResData));
    } catch (e) {
      Lo.g(e);
      cntrDtlResStream.sink.add(ResStream.error(e.toString()));
    }
  }

  //"검색"버튼 클릭 시 호출
  Future<ResData> getCntrDtl(String loanNo) async {
    try {
      //원장 정보 조회
      cntrDtlResStream.sink.add(ResStream.loading());
      CntrDetailRepo cntrDetailRepo = CntrDetailRepo();
      ResData cntrResData = await cntrDetailRepo.searchCntrDtl(loanNo);
      if (cntrResData.code != '00') {
        cntrDtlResStream.sink.add(ResStream.error(cntrResData.msg.toString()));
        return cntrResData;
      }
      cntrDetailResData = CntrDetailResData.fromMap(cntrResData.data[0]);
      cntrDtlResStream.sink.add(ResStream.completed(cntrDetailResData));

      //지급정보 조회
      paymentResStream.sink.add(ResStream.loading());
      PaymentRepo paymentRepo = PaymentRepo();
      ResData payResData = await paymentRepo.searchPaymentList(loanNo);
      if (payResData.code != '00') {
        Lo.g('지급정보 조회 실패 >>>>>>>>>>> ${cntrResData.msg.toString()}');
        paymentResStream.sink.add(ResStream.completed([]));
        return cntrResData;
      }

      List<PaymentListResData> paymentListResData = ((payResData.data) as List)
          .map((data) => PaymentListResData.fromMap(data))
          .toList();

      paymentResStream.sink.add(ResStream.completed(paymentListResData));

      // 전문 기록 조회
     await Get.find<HomeCtrl>().getTrnsHist(trnsHistResListStream , loanNo);

      return cntrResData;
    } catch (e) {
      Lo.g(e);
      cntrDtlResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }



  //"전문복사" 버튼
  Future<ResData> getTrnsDtl(String loanNo) async {
    try {
      trnResStream.sink.add(ResStream.loading());
      TrnsDetailRepo trnsDetailRepo  = TrnsDetailRepo();
      ResData resData = await trnsDetailRepo.searchTrnA400Dtl(loanNo);
      if (resData.code != '00') {
        trnResStream.sink.add(ResStream.error(resData.msg.toString()));
        return resData;
      }
      trnA400ResData = TrnA400ResData.fromMap(resData.data);
      trnResStream.sink.add(ResStream.completed(trnA400ResData));
      return resData;
    } catch (e) {
      Lo.g(e);
      trnResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }

  //"전문송신" 버튼
  Future<ResData> setSendPayRslt(TrnsA400SendReqData reqData) async {
    try {
      trnSendResStream.sink.add(ResStream.loading());
      TrnsSendRepo trnsSendRepo = TrnsSendRepo();
      ResData resData = await trnsSendRepo.sendPayRslt(reqData);
      if (resData.code != '00') {
        trnSendResStream.sink.add(ResStream.error(resData.msg.toString()));
        return resData;
      }
      trnsA400SendResData = TrnsA400SendResData.fromMap(resData.data);
      trnSendResStream.sink.add(ResStream.completed(trnsA400SendResData));

      // 전문 기록 조회
      await Get.find<HomeCtrl>().getTrnsHist(trnsHistResListStream , reqData.loanNo ?? '');

      return resData;
    } catch (e) {
      Lo.g(e);
      trnSendResStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }


  // 전문 발송내역 조회
  Future<ResData> getTrnsHist(String loanNo) async {
    try {

      trnsHistResListStream.sink.add(ResStream.loading());
      TrnsHistRepo trnsHistRepo = TrnsHistRepo();
      ResData resData = await trnsHistRepo.searchTrnHist(loanNo);

     if (resData.code != '00') {
        trnsHistResListStream.sink.add(ResStream.completed([]));
        return resData;
      }

      List<TrnsHistResData> list = ((resData.data) as List)
          .map((data) => TrnsHistResData.fromMap(data))
          .toList();

      trnsHistResListStream.sink.add(ResStream.completed(list));

      return resData;
    } catch (e) {
      Lo.g(e);
      trnsHistResListStream.sink.add(ResStream.error(e.toString()));
      return ResData();
    }
  }



}

