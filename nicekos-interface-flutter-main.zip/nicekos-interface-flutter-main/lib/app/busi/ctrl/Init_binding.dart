import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_instance/src/bindings_interface.dart';
import 'package:nicekos_interface_flutter/app/busi/ctrl/page_index_ctrl.dart';

class InitBinding extends Bindings {

  @override
  void dependencies() {
    Get.lazyPut<BindingCtrl>(
        () => BindingCtrl(),
    );
  }
}

class BindingCtrl extends GetxController {

  @override
  void onInit() async {
    super.onInit();
  }

  @override
  void dispose() {
    super.dispose();
  }

  void initBinding() async {
    Get.toNamed('/Binding');
  }
}