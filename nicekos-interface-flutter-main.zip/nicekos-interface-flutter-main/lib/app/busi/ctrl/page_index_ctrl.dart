import 'package:get/get.dart';

class PageIndexCtrl extends GetxController {



  String getTitleByIndex(int index) {
    switch (index) {
      case 0:
        return 'FA 사전의뢰(F5000)';
      case 1:
        return 'FA 청약의뢰(F1000)';
      case 2:
        return 'FA 조사 확인 결과서(F3000)';
      case 3:
        return 'DB 청약 의뢰(W1000)';
      case 4:
        return 'DB 진행 상태 전문(W3000)';
      case 5:
        return '대출 실행 통보(A700)';
      case 6:
        return '지급 결과 통지(A400)';
      case 7:
        return '이미지 전송 결과(B700)';
      default:
        return 'Not found page';
    }
  }
}