import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:nicekos_interface_flutter/app/busi/ctrl/page_index_ctrl.dart';
import 'package:nicekos_interface_flutter/theme/text_style.dart';
import 'package:sidebarx/sidebarx.dart';

import '../../theme/colors.dart';
import '../../widget/main_screen.dart';
import '../../widget/menu_side_bar.dart';
import 'ctrl/home_ctrl.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<StatefulWidget> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final _controller = SidebarXController(selectedIndex: 0, extended: true);
  final _key = GlobalKey<ScaffoldState>();
  final PageIndexCtrl pageIndexCtrl = Get.put(PageIndexCtrl());
  final HomeCtrl homeCtrl = Get.put(HomeCtrl());

  @override
  Widget build(BuildContext context) {
    return Builder(
        builder: (context) {
          final isSmallScreen = MediaQuery.of(context).size.width < 600;
          return Scaffold(
            key: _key,
            appBar: isSmallScreen
                ? AppBar(
              backgroundColor: canvasColor,
              title: Text(pageIndexCtrl.getTitleByIndex(_controller
                  .selectedIndex),
              style: TextSyle.title(),),
              leading: IconButton(
                onPressed: () {
                  _controller.setExtended(true);
                  _key.currentState?.openDrawer();
                },
                icon: const Icon(Icons.menu),
              ),
            )
                : null,
            drawer: MenuSideBar(controller: _controller,),
            body: Row(
              children: [
                if (!isSmallScreen) MenuSideBar(controller: _controller),
                Expanded(
                  child: Center(
                    child: MainScreen(
                      controller: _controller,
                    ),
                  ),
                ),
              ],
            ),
          );
        }
    );
  }
}
