import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class IfContainer extends StatelessWidget {

  final String? text;

  const IfContainer({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      width: Get.width * 0.1,
      height: Get.height * 0.1,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: const BoxDecoration(
        color: Color(0x0C112692),
        border: Border(),
      ),
      child: Text(
        text!,
        maxLines: 1,
        overflow: TextOverflow.clip,
        style: const TextStyle(
          color: Color(0xFF333333),
          fontSize: 14,
          fontFamily: 'Noto Sans KR',
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}