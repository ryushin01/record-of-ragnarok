import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/theme/colors.dart';
import 'package:nicekos_interface_flutter/theme/text_style.dart';

class IfTextFormField extends StatelessWidget {
  final TextEditingController? controller;
  final double? height;
  final double? width;
  final TextStyle? textStyle;
  final EdgeInsetsGeometry? contentPadding;
  final bool filled;
  final String? labelText;
  final FloatingLabelBehavior floatingLabelBehavior;
  TextStyle? labelStyle;
  TextStyle? counterStyle;
  Widget? suffixIcon;
  int? maxLength;
  final VoidCallback? onSuffixIconTap;


  IfTextFormField({
    super.key,
    required this.controller,
    required this.textStyle,
    this.height = 0.1,
    this.width = 0.05,
    this.contentPadding =
        const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
    this.filled = false,
    this.labelText = '',
    this.floatingLabelBehavior = FloatingLabelBehavior.never,
    this.onSuffixIconTap,
  });

  IfTextFormField.search({
    super.key,
    required this.controller,
    required this.textStyle,
    this.height = 0.07,
    this.width = 0.08,
    this.contentPadding =
        const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
    this.filled = false,
    this.labelText = '여신번호 입력',
    this.floatingLabelBehavior = FloatingLabelBehavior.always,
    this.maxLength = 11,
    this.onSuffixIconTap,
  });

  IfTextFormField.trans({
    super.key,
    required this.controller,
    required this.textStyle,
    this.height = 0.03,
    this.width = 0.12,
    this.contentPadding =
        const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
    this.filled = true,
    this.labelText = '',
    this.floatingLabelBehavior = FloatingLabelBehavior.never,
    this.suffixIcon =  const Icon(size: 16, Icons.cancel),
    VoidCallback? onSuffixIconTap,
  }) : onSuffixIconTap = onSuffixIconTap ?? (() => controller?.clear());

  IfTextFormField.contract({
    super.key,
    required this.controller,
    required this.textStyle,
    this.height = 0.03,
    this.width = 0.1,
    this.contentPadding =
    const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
    this.filled = false,
    this.labelText = '',
    this.floatingLabelBehavior = FloatingLabelBehavior.never,
    this.onSuffixIconTap,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: Get.width * width!,
      height: Get.height * height!,
      child: TextFormField(
        textAlignVertical: TextAlignVertical.center,
        style: textStyle,
        controller: controller,
        maxLength: maxLength,
        decoration: InputDecoration(
            contentPadding: contentPadding,
            filled: filled,
            fillColor: white,
            floatingLabelBehavior: floatingLabelBehavior,
            labelText: labelText,
            labelStyle: textStyle,
            counterStyle: textStyle,
            suffixIcon: suffixIcon != null
                ? GestureDetector(
              onTap: onSuffixIconTap, // 클릭 이벤트 추가
              child: suffixIcon,
            )
                : null,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5),
                borderSide: const BorderSide(color: white))),
      ),
    );
  }
}
