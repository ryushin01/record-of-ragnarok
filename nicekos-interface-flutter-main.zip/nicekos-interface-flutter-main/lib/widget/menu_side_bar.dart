import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sidebarx/sidebarx.dart';

import '../theme/colors.dart';

class MenuSideBar extends StatelessWidget {
  const MenuSideBar({Key? key, required SidebarXController controller})
      : _controller = controller,
        super(key: key);
  final SidebarXController _controller;

  @override
  Widget build(BuildContext context) {
    return SidebarX(
      controller: _controller,
      theme: SidebarXTheme(
        margin: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: canvasColor,
          borderRadius: BorderRadius.circular(20),
        ),
        hoverColor: scaffoldBackgroundColor,
        textStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
        selectedTextStyle: const TextStyle(color: Colors.white),
        itemTextPadding: const EdgeInsets.only(left: 30),
        selectedItemTextPadding: const EdgeInsets.only(left: 30),
        itemDecoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: canvasColor),
        ),
        selectedItemDecoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: actionColor.withOpacity(0.37),
          ),
          gradient: const LinearGradient(
            colors: [accentCanvasColor, canvasColor],
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.28),
              blurRadius: 30,
            )
          ],
        ),
        iconTheme: IconThemeData(
          color: Colors.white.withOpacity(0.7),
          size: 20,
        ),
        selectedIconTheme: const IconThemeData(
          color: Colors.white,
          size: 20,
        ),
      ),
      extendedTheme: const SidebarXTheme(
        width: 250,
        decoration: BoxDecoration(
          color: canvasColor,
        ),
      ),
      footerDivider: divider,
      headerBuilder: (context, extended) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Text('코스 뱅크',
                  style: GoogleFonts.raleway(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    letterSpacing: 1,
                  ),),
                // SizedBox(
                //   height: 50,
                //   child: Padding(
                //     padding: const EdgeInsets.only(top: 5, bottom: 5, right:
                //     5),
                //     child: Image.asset('icon/logo.png'),
                //   ),
                // ),
              ],
            ),
            // Text('hibike console', style: TextStyle(fontSize: 17),)
          ],
        );
      },
      items: const [
        SidebarXItem(
          icon: Icons.home,
          label: 'FA 사전 의뢰(F5000)',
        ),
        SidebarXItem(
          icon: Icons.search,
          label: 'FA 청약 의뢰(F1000)',
        ),
        SidebarXItem(
          icon: Icons.favorite,
          label: 'FA 진행 상태 전문(F3000)',
        ),
        SidebarXItem(
          icon: Icons.favorite,
          label: 'DB 청약 의뢰(W1000)',
        ),
        SidebarXItem(
          icon: Icons.dark_mode_rounded,
          label: 'DB 진행 상태 전문(W3000)',
        ),
        SidebarXItem(
          icon: Icons.flag,
          label: '대출 실행 통보 (A700)',
        ),
        SidebarXItem(
          icon: Icons.access_time,
          label: '지급 결과 통지 (A400)',
        ),
        SidebarXItem(
          icon: Icons.image,
          label: '이미지 전송 결과 (B700)',
        ),
      ],
    );
  }
}