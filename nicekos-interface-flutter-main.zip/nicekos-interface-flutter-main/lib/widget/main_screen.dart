import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:nicekos_interface_flutter/app/busi/ask_fa_page.dart';
import 'package:nicekos_interface_flutter/app/busi/ctrl/page_index_ctrl.dart';
import 'package:nicekos_interface_flutter/app/busi/ctrl/pre_ask_fa_ctrl.dart';
import 'package:nicekos_interface_flutter/app/busi/loan_exe_page.dart';
import 'package:nicekos_interface_flutter/app/busi/pre_ask_fa_page.dart';
import 'package:sidebarx/sidebarx.dart';

import '../app/busi/image_send_rslt_page.dart';
import '../app/busi/lnd_stat_db_page.dart';
import '../app/busi/pay_rslt_page.dart';
import '../app/busi/ask_db_page.dart';
import '../app/busi/lnd_stat_page.dart';

class MainScreen extends StatelessWidget {
  MainScreen({super.key, required this.controller,});

  final SidebarXController controller;
  final PageIndexCtrl pageIndexController = Get.find();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        final pageTitle = pageIndexController.getTitleByIndex(controller.selectedIndex);
        switch (controller.selectedIndex) {
          case 0:
            return const PreAskFaPage();
          case 1:
            return AskFaPage();
          case 2:
            return const LndStatPage();
          case 3:
            return AskDbPage();
          case 4:
            return const LndStatDbPage();
          case 5:
            return const LoanExePage();
          case 6:
            return const A400Page();
          case 7:
            return const ImageSendRsltPage();
          default:
            return Text(
              pageTitle,
              style: theme.textTheme.headline5,
            );
        }
      },
    );
  }
}