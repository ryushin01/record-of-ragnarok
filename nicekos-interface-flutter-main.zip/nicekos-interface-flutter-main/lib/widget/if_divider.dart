import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import '../theme/colors.dart';

class IfDivider extends StatelessWidget {

  final double width;

  IfDivider({super.key, required this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: Get.width * width,
      decoration: const ShapeDecoration(
        shape: RoundedRectangleBorder(
          side: BorderSide(
            strokeAlign: BorderSide.strokeAlignCenter,
            color: white,
          ),
        ),
      ),
    );
  }}