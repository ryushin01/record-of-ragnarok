import 'package:dio/dio.dart';
import 'package:nicekos_interface_flutter/repo/data/trns_A400_send_data.dart';
import 'package:nicekos_interface_flutter/repo/data/trns_B700_send_data.dart';
import 'package:nicekos_interface_flutter/repo/response/res_data.dart';

import '../config/url_config.dart';
import '../utils/log_utils.dart';
import 'api/auth_dio.dart';
import 'data/ask_db_send_data.dart';
import 'data/lnd_stat_db_send_data.dart';
import 'data/preask_fa_send_data.dart';
import 'data/trns_6100_send_data.dart';
import 'data/trns_6300_send_data.dart';
import 'data/trns_A700_send_data.dart';

class TrnsSendRepo {

  Future<ResData> sendFaPreAsk(TrnsSendReqData trnsSendReqData) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/sendfapreask";
      var response = await AuthDio.run().post(url, data: trnsSendReqData.toJson());
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> sendFaAsk(Trns6100SendReqData trans6100SendReqData) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/sendfaask";
      var response = await AuthDio.run().post(url, data: trans6100SendReqData.toJson());
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> sendLndStat(Trns6300SendReqData trns6300SendReqData) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/sendlndstat";
      var response = await AuthDio.run().post(url, data: trns6300SendReqData.toJson());
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> sendLoanExe(TrnsA700SendReqData reqData) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/sendloanexe";
      var response = await AuthDio.run().post(url, data: reqData.toJson());
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> sendDbAsk(AskDbSendReqData reqData) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/senddbask";
      var response = await AuthDio.run().post(url, data: reqData.toJson());
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> sendDbLndStat(LndStatDbSendReqData reqData) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/senddblndstat";
      var response = await AuthDio.run().post(url, data: reqData.toJson());
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> sendPayRslt(TrnsA400SendReqData reqData) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/sendpayrslt";
      var response = await AuthDio.run().post(url, data: reqData.toJson());
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> sendImageSendRslt(TrnsB700SendReqData reqData) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/sendimagesendrslt";
      var response = await AuthDio.run().post(url, data: reqData.toJson());
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

}