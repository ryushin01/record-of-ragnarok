import 'package:dio/dio.dart';
import 'package:nicekos_interface_flutter/repo/response/res_data.dart';

import '../../config/url_config.dart';
import 'data/search_comm_code_data.dart';
import 'api/auth_dio.dart';

class CommRepo {
  Future<ResData> searchCommCode(SearchCommCodeReq reqData) async {
    try {
      // Rest api uri
      String CusUrl = "${UrlConfig.bankifURL}/comm/code/searchcommcode";
      var requestData = reqData;
      Response response =
          await AuthDio.run().post(CusUrl, data: requestData.toJson());
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      return AuthDio.dioException(e);
    }
  }
}
