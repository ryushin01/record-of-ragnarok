import 'package:dio/dio.dart';
import 'package:nicekos_interface_flutter/repo/response/res_data.dart';

import '../config/url_config.dart';
import '../utils/log_utils.dart';
import 'api/auth_dio.dart';

class TrnsDetailRepo {

  Future<ResData> searchTransDtl(String loanNo) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/searchtrnsdetail/$loanNo";
      var response = await AuthDio.run().post(url);
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> searchTrans6100Dtl(String loanNo) async {
    try {
      Lo.g("searchtrns6100detail repo 실행부");
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/searchtrns6100detail/$loanNo";
      var response = await AuthDio.run().post(url);
      Lo.g("searchtrns6100detail repo 종료부");
      return AuthDio.dioResponse(response);

    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> searchTrans6300Dtl(String loanNo) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/searchtrns6300detail/$loanNo";
      var response = await AuthDio.run().post(url);
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> searchTrnA700Dtl(String loanNo) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/searchloanexe/$loanNo";
      var response = await AuthDio.run().post(url);
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> searchTrnA400Dtl(String loanNo) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/searchpayrslt/$loanNo";
      var response = await AuthDio.run().post(url);
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> searchTrnAskDb(String loanNo) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/searchaskdb/$loanNo";
      var response = await AuthDio.run().post(url);
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> searchTransDb6300Dtl(String loanNo) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/searchtrnsdb6300detail/$loanNo";
      var response = await AuthDio.run().post(url);
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> searchTrnB700Dtl(String loanNo) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/trn/searchimagesendrslt/$loanNo";
      var response = await AuthDio.run().post(url);
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

}