// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

import 'package:flutter/foundation.dart';

class TrnsHistResList {
  List<TrnsHistResData>? list;
  TrnsHistResList({
    this.list,
  });

  TrnsHistResList copyWith({
    List<TrnsHistResData>? list,
  }) {
    return TrnsHistResList(
      list: list ?? this.list,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'list': list?.map((x) => x?.toMap()).toList(),
    };
  }

  factory TrnsHistResList.fromMap(Map<String, dynamic> map) {
    return TrnsHistResList(
      list: map['list'] != null ? List<TrnsHistResData>.from((map['list'] as
      List<dynamic>).map<TrnsHistResData?>((x) => TrnsHistResData.fromMap(x as
      Map<String,dynamic>),),) : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnsHistResList.fromJson(String source) => TrnsHistResList.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() => 'TrnsHistResList(list: $list)';

  @override
  bool operator ==(covariant TrnsHistResList other) {
    if (identical(this, other)) return true;

    return listEquals(other.list, list);
  }

  @override
  int get hashCode => list.hashCode;
}


class TrnsHistResData {
  String? seq;
  String? trnName;
  String? trnKnd;
  String? resYn;
  String? resCd;
  String? reqDttm;
  TrnsHistResData({
    this.seq,
    this.trnName,
    this.trnKnd,
    this.resYn,
    this.resCd,
    this.reqDttm,
  });

  TrnsHistResData copyWith({
    String? seq,
    String? trnName,
    String? trnKnd,
    String? resYn,
    String? resCd,
    String? reqDttm,
  }) {
    return TrnsHistResData(
      seq: seq ?? this.seq,
      trnName: trnName ?? this.trnName,
      trnKnd: trnKnd ?? this.trnKnd,
      resYn: resYn ?? this.resYn,
      resCd: resCd ?? this.resCd,
      reqDttm: reqDttm ?? this.reqDttm,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'seq': seq,
      'trnName': trnName,
      'trnKnd': trnKnd,
      'resYn': resYn,
      'resCd': resCd,
      'reqDttm': reqDttm,
    };
  }

  factory TrnsHistResData.fromMap(Map<String, dynamic> map) {
    return TrnsHistResData(
      seq: map['seq'] != null ? map['seq'] as String : null,
      trnName: map['trnName'] != null ? map['trnName'] as String : null,
      trnKnd: map['trnKnd'] != null ? map['trnKnd'] as String : null,
      resYn: map['resYn'] != null ? map['resYn'] as String : null,
      resCd: map['resCd'] != null ? map['resCd'] as String : null,
      reqDttm: map['reqDttm'] != null ? map['reqDttm'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnsHistResData.fromJson(String source) => TrnsHistResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TrnsHistResData(seq: $seq, trnName: $trnName, trnKnd: $trnKnd, resYn: $resYn, resCd: $resCd, reqDttm: $reqDttm)';
  }

  @override
  bool operator ==(covariant TrnsHistResData other) {
    if (identical(this, other)) return true;

    return
      other.seq == seq &&
          other.trnName == trnName &&
          other.trnKnd == trnKnd &&
          other.resYn == resYn &&
          other.resCd == resCd &&
          other.reqDttm == reqDttm;
  }

  @override
  int get hashCode {
    return seq.hashCode ^
    trnName.hashCode ^
    trnKnd.hashCode ^
    resYn.hashCode ^
    resCd.hashCode ^
    reqDttm.hashCode;
  }
}

