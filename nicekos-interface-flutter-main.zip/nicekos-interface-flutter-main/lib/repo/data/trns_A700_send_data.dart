// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class TrnsA700SendReqData {
  String? loanNo;
  String? newLoanNo;
  String? trLn;
  String? trCd;
  String? trTpCd;
  String? loNo;
  String? trSq;
  String? reqDttm;
  String? resDttm;
  String? resCd;
  String? approvalNum;
  String? exeDtm;
  String? procDvsn;
  String? exeAmt;
  String? categoryCd;
  String? docTax;
  String? debtDcAmt;
  String? etcAmt;
  TrnsA700SendReqData({
    this.loanNo,
    this.newLoanNo,
    this.trLn,
    this.trCd,
    this.trTpCd,
    this.loNo,
    this.trSq,
    this.reqDttm,
    this.resDttm,
    this.resCd,
    this.approvalNum,
    this.exeDtm,
    this.procDvsn,
    this.exeAmt,
    this.categoryCd,
    this.docTax,
    this.debtDcAmt,
    this.etcAmt,
  });

  TrnsA700SendReqData copyWith({
    String? loanNo,
    String? newLoanNo,
    String? trLn,
    String? trCd,
    String? trTpCd,
    String? loNo,
    String? trSq,
    String? reqDttm,
    String? resDttm,
    String? resCd,
    String? approvalNum,
    String? exeDtm,
    String? procDvsn,
    String? exeAmt,
    String? categoryCd,
    String? docTax,
    String? debtDcAmt,
    String? etcAmt,
  }) {
    return TrnsA700SendReqData(
      loanNo: loanNo ?? this.loanNo,
      newLoanNo: newLoanNo ?? this.newLoanNo,
      trLn: trLn ?? this.trLn,
      trCd: trCd ?? this.trCd,
      trTpCd: trTpCd ?? this.trTpCd,
      loNo: loNo ?? this.loNo,
      trSq: trSq ?? this.trSq,
      reqDttm: reqDttm ?? this.reqDttm,
      resDttm: resDttm ?? this.resDttm,
      resCd: resCd ?? this.resCd,
      approvalNum: approvalNum ?? this.approvalNum,
      exeDtm: exeDtm ?? this.exeDtm,
      procDvsn: procDvsn ?? this.procDvsn,
      exeAmt: exeAmt ?? this.exeAmt,
      categoryCd: categoryCd ?? this.categoryCd,
      docTax: docTax ?? this.docTax,
      debtDcAmt: debtDcAmt ?? this.debtDcAmt,
      etcAmt: etcAmt ?? this.etcAmt,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'newLoanNo': newLoanNo,
      'trLn': trLn,
      'trCd': trCd,
      'trTpCd': trTpCd,
      'loNo': loNo,
      'trSq': trSq,
      'reqDttm': reqDttm,
      'resDttm': resDttm,
      'resCd': resCd,
      'approvalNum': approvalNum,
      'exeDtm': exeDtm,
      'procDvsn': procDvsn,
      'exeAmt': exeAmt,
      'categoryCd': categoryCd,
      'docTax': docTax,
      'debtDcAmt': debtDcAmt,
      'etcAmt': etcAmt,
    };
  }

  factory TrnsA700SendReqData.fromMap(Map<String, dynamic> map) {
    return TrnsA700SendReqData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      newLoanNo: map['newLoanNo'] != null ? map['newLoanNo'] as String : null,
      trLn: map['trLn'] != null ? map['trLn'] as String : null,
      trCd: map['trCd'] != null ? map['trCd'] as String : null,
      trTpCd: map['trTpCd'] != null ? map['trTpCd'] as String : null,
      loNo: map['loNo'] != null ? map['loNo'] as String : null,
      trSq: map['trSq'] != null ? map['trSq'] as String : null,
      reqDttm: map['reqDttm'] != null ? map['reqDttm'] as String : null,
      resDttm: map['resDttm'] != null ? map['resDttm'] as String : null,
      resCd: map['resCd'] != null ? map['resCd'] as String : null,
      approvalNum: map['approvalNum'] != null ? map['approvalNum'] as String : null,
      exeDtm: map['exeDtm'] != null ? map['exeDtm'] as String : null,
      procDvsn: map['procDvsn'] != null ? map['procDvsn'] as String : null,
      exeAmt: map['exeAmt'] != null ? map['exeAmt'] as String : null,
      categoryCd: map['categoryCd'] != null ? map['categoryCd'] as String : null,
      docTax: map['docTax'] != null ? map['docTax'] as String : null,
      debtDcAmt: map['debtDcAmt'] != null ? map['debtDcAmt'] as String : null,
      etcAmt: map['etcAmt'] != null ? map['etcAmt'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnsA700SendReqData.fromJson(String source) => TrnsA700SendReqData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TrnsA700SendReqData(loanNo: $loanNo, newLoanNo: $newLoanNo, trLn: $trLn, trCd: $trCd, trTpCd: $trTpCd, loNo: $loNo, trSq: $trSq, reqDttm: $reqDttm, resDttm: $resDttm, resCd: $resCd, approvalNum: $approvalNum, exeDtm: $exeDtm, procDvsn: $procDvsn, exeAmt: $exeAmt, categoryCd: $categoryCd, docTax: $docTax, debtDcAmt: $debtDcAmt, etcAmt: $etcAmt)';
  }

  @override
  bool operator ==(covariant TrnsA700SendReqData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.newLoanNo == newLoanNo &&
          other.trLn == trLn &&
          other.trCd == trCd &&
          other.trTpCd == trTpCd &&
          other.loNo == loNo &&
          other.trSq == trSq &&
          other.reqDttm == reqDttm &&
          other.resDttm == resDttm &&
          other.resCd == resCd &&
          other.approvalNum == approvalNum &&
          other.exeDtm == exeDtm &&
          other.procDvsn == procDvsn &&
          other.exeAmt == exeAmt &&
          other.categoryCd == categoryCd &&
          other.docTax == docTax &&
          other.debtDcAmt == debtDcAmt &&
          other.etcAmt == etcAmt;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    newLoanNo.hashCode ^
    trLn.hashCode ^
    trCd.hashCode ^
    trTpCd.hashCode ^
    loNo.hashCode ^
    trSq.hashCode ^
    reqDttm.hashCode ^
    resDttm.hashCode ^
    resCd.hashCode ^
    approvalNum.hashCode ^
    exeDtm.hashCode ^
    procDvsn.hashCode ^
    exeAmt.hashCode ^
    categoryCd.hashCode ^
    docTax.hashCode ^
    debtDcAmt.hashCode ^
    etcAmt.hashCode;
  }
}

class TrnsA700SendResData {
  String? loanNo;
  String? trLn;
  String? trCd;
  String? trTpCd;
  String? loNo;
  String? trSq;
  String? reqDttm;
  String? resDttm;
  String? resCd;
  String? approvalNum;
  String? exeDtm;
  String? procDvsn;
  String? exeAmt;
  String? categoryCd;
  String? docTax;
  String? debtDcAmt;
  String? etcAmt;
  TrnsA700SendResData({
    this.loanNo,
    this.trLn,
    this.trCd,
    this.trTpCd,
    this.loNo,
    this.trSq,
    this.reqDttm,
    this.resDttm,
    this.resCd,
    this.approvalNum,
    this.exeDtm,
    this.procDvsn,
    this.exeAmt,
    this.categoryCd,
    this.docTax,
    this.debtDcAmt,
    this.etcAmt,
  });

  TrnsA700SendResData copyWith({
    String? loanNo,
    String? trLn,
    String? trCd,
    String? trTpCd,
    String? loNo,
    String? trSq,
    String? reqDttm,
    String? resDttm,
    String? resCd,
    String? approvalNum,
    String? exeDtm,
    String? procDvsn,
    String? exeAmt,
    String? categoryCd,
    String? docTax,
    String? debtDcAmt,
    String? etcAmt,
  }) {
    return TrnsA700SendResData(
      loanNo: loanNo ?? this.loanNo,
      trLn: trLn ?? this.trLn,
      trCd: trCd ?? this.trCd,
      trTpCd: trTpCd ?? this.trTpCd,
      loNo: loNo ?? this.loNo,
      trSq: trSq ?? this.trSq,
      reqDttm: reqDttm ?? this.reqDttm,
      resDttm: resDttm ?? this.resDttm,
      resCd: resCd ?? this.resCd,
      approvalNum: approvalNum ?? this.approvalNum,
      exeDtm: exeDtm ?? this.exeDtm,
      procDvsn: procDvsn ?? this.procDvsn,
      exeAmt: exeAmt ?? this.exeAmt,
      categoryCd: categoryCd ?? this.categoryCd,
      docTax: docTax ?? this.docTax,
      debtDcAmt: debtDcAmt ?? this.debtDcAmt,
      etcAmt: etcAmt ?? this.etcAmt,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'trLn': trLn,
      'trCd': trCd,
      'trTpCd': trTpCd,
      'loNo': loNo,
      'trSq': trSq,
      'reqDttm': reqDttm,
      'resDttm': resDttm,
      'resCd': resCd,
      'approvalNum': approvalNum,
      'exeDtm': exeDtm,
      'procDvsn': procDvsn,
      'exeAmt': exeAmt,
      'categoryCd': categoryCd,
      'docTax': docTax,
      'debtDcAmt': debtDcAmt,
      'etcAmt': etcAmt,
    };
  }

  factory TrnsA700SendResData.fromMap(Map<String, dynamic> map) {
    return TrnsA700SendResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      trLn: map['trLn'] != null ? map['trLn'] as String : null,
      trCd: map['trCd'] != null ? map['trCd'] as String : null,
      trTpCd: map['trTpCd'] != null ? map['trTpCd'] as String : null,
      loNo: map['loNo'] != null ? map['loNo'] as String : null,
      trSq: map['trSq'] != null ? map['trSq'] as String : null,
      reqDttm: map['reqDttm'] != null ? map['reqDttm'] as String : null,
      resDttm: map['resDttm'] != null ? map['resDttm'] as String : null,
      resCd: map['resCd'] != null ? map['resCd'] as String : null,
      approvalNum: map['approvalNum'] != null ? map['approvalNum'] as String : null,
      exeDtm: map['exeDtm'] != null ? map['exeDtm'] as String : null,
      procDvsn: map['procDvsn'] != null ? map['procDvsn'] as String : null,
      exeAmt: map['exeAmt'] != null ? map['exeAmt'] as String : null,
      categoryCd: map['categoryCd'] != null ? map['categoryCd'] as String : null,
      docTax: map['docTax'] != null ? map['docTax'] as String : null,
      debtDcAmt: map['debtDcAmt'] != null ? map['debtDcAmt'] as String : null,
      etcAmt: map['etcAmt'] != null ? map['etcAmt'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnsA700SendResData.fromJson(String source) => TrnsA700SendResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TrnsA700SendResData(loanNo: $loanNo, trLn: $trLn, trCd: $trCd, trTpCd: $trTpCd, loNo: $loNo, trSq: $trSq, reqDttm: $reqDttm, resDttm: $resDttm, resCd: $resCd, approvalNum: $approvalNum, exeDtm: $exeDtm, procDvsn: $procDvsn, exeAmt: $exeAmt, categoryCd: $categoryCd, docTax: $docTax, debtDcAmt: $debtDcAmt, etcAmt: $etcAmt)';
  }

  @override
  bool operator ==(covariant TrnsA700SendResData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.trLn == trLn &&
          other.trCd == trCd &&
          other.trTpCd == trTpCd &&
          other.loNo == loNo &&
          other.trSq == trSq &&
          other.reqDttm == reqDttm &&
          other.resDttm == resDttm &&
          other.resCd == resCd &&
          other.approvalNum == approvalNum &&
          other.exeDtm == exeDtm &&
          other.procDvsn == procDvsn &&
          other.exeAmt == exeAmt &&
          other.categoryCd == categoryCd &&
          other.docTax == docTax &&
          other.debtDcAmt == debtDcAmt &&
          other.etcAmt == etcAmt;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    trLn.hashCode ^
    trCd.hashCode ^
    trTpCd.hashCode ^
    loNo.hashCode ^
    trSq.hashCode ^
    reqDttm.hashCode ^
    resDttm.hashCode ^
    resCd.hashCode ^
    approvalNum.hashCode ^
    exeDtm.hashCode ^
    procDvsn.hashCode ^
    exeAmt.hashCode ^
    categoryCd.hashCode ^
    docTax.hashCode ^
    debtDcAmt.hashCode ^
    etcAmt.hashCode;
  }
}
