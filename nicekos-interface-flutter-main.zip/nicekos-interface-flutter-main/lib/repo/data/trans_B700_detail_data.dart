// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class TrnB700ResData {
  String? loanNo;
  String? trLn;
  String? trCd;
  String? trTpCd;
  String? loNo;
  String? imgTp;
  String? imgCheckYn;
  String? imgKey;
  String? imgPageCnt;
  String? seqNo;
  String? imgFileName;
  String? resultCd;
  TrnB700ResData({
    this.loanNo,
    this.trLn,
    this.trCd,
    this.trTpCd,
    this.loNo,
    this.imgTp,
    this.imgCheckYn,
    this.imgKey,
    this.imgPageCnt,
    this.seqNo,
    this.imgFileName,
    this.resultCd,
  });

  TrnB700ResData copyWith({
    String? loanNo,
    String? trLn,
    String? trCd,
    String? trTpCd,
    String? loNo,
    String? imgTp,
    String? imgCheckYn,
    String? imgKey,
    String? imgPageCnt,
    String? seqNo,
    String? imgFileName,
    String? resultCd,
  }) {
    return TrnB700ResData(
      loanNo: loanNo ?? this.loanNo,
      trLn: trLn ?? this.trLn,
      trCd: trCd ?? this.trCd,
      trTpCd: trTpCd ?? this.trTpCd,
      loNo: loNo ?? this.loNo,
      imgTp: imgTp ?? this.imgTp,
      imgCheckYn: imgCheckYn ?? this.imgCheckYn,
      imgKey: imgKey ?? this.imgKey,
      imgPageCnt: imgPageCnt ?? this.imgPageCnt,
      seqNo: seqNo ?? this.seqNo,
      imgFileName: imgFileName ?? this.imgFileName,
      resultCd: resultCd ?? this.resultCd,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'trLn': trLn,
      'trCd': trCd,
      'trTpCd': trTpCd,
      'loNo': loNo,
      'imgTp': imgTp,
      'imgCheckYn': imgCheckYn,
      'imgKey': imgKey,
      'imgPageCnt': imgPageCnt,
      'seqNo': seqNo,
      'imgFileName': imgFileName,
      'resultCd': resultCd,
    };
  }

  factory TrnB700ResData.fromMap(Map<String, dynamic> map) {
    return TrnB700ResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      trLn: map['trLn'] != null ? map['trLn'] as String : null,
      trCd: map['trCd'] != null ? map['trCd'] as String : null,
      trTpCd: map['trTpCd'] != null ? map['trTpCd'] as String : null,
      loNo: map['loNo'] != null ? map['loNo'] as String : null,
      imgTp: map['imgTp'] != null ? map['imgTp'] as String : null,
      imgCheckYn: map['imgCheckYn'] != null ? map['imgCheckYn'] as String : null,
      imgKey: map['imgKey'] != null ? map['imgKey'] as String : null,
      imgPageCnt: map['imgPageCnt'] != null ? map['imgPageCnt'] as String : null,
      seqNo: map['seqNo'] != null ? map['seqNo'] as String : null,
      imgFileName: map['imgFileName'] != null ? map['imgFileName'] as String : null,
      resultCd: map['resultCd'] != null ? map['resultCd'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnB700ResData.fromJson(String source) => TrnB700ResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TrnB700ResData(loanNo: $loanNo, trLn: $trLn, trCd: $trCd, trTpCd: $trTpCd, loNo: $loNo, imgTp: $imgTp, imgCheckYn: $imgCheckYn, imgKey: $imgKey, imgPageCnt: $imgPageCnt, seqNo: $seqNo, imgFileName: $imgFileName, resultCd: $resultCd)';
  }

  @override
  bool operator ==(covariant TrnB700ResData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.trLn == trLn &&
          other.trCd == trCd &&
          other.trTpCd == trTpCd &&
          other.loNo == loNo &&
          other.imgTp == imgTp &&
          other.imgCheckYn == imgCheckYn &&
          other.imgKey == imgKey &&
          other.imgPageCnt == imgPageCnt &&
          other.seqNo == seqNo &&
          other.imgFileName == imgFileName &&
          other.resultCd == resultCd;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    trLn.hashCode ^
    trCd.hashCode ^
    trTpCd.hashCode ^
    loNo.hashCode ^
    imgTp.hashCode ^
    imgCheckYn.hashCode ^
    imgKey.hashCode ^
    imgPageCnt.hashCode ^
    seqNo.hashCode ^
    imgFileName.hashCode ^
    resultCd.hashCode;
  }
}
