// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class AskDbTranResData {
  String? loanNo;
  String? newLoanNo;
  int? tgLen;
  String? tgDsc;
  String? resCd;
  String? lndAgncCd;
  String? bnkTgTrnsDtm;
  String? dbTgTrnsDtm;
  String? bnkTgNo;
  int? dbTgNo;
  String? rsrvItmH;
  String? bnkAskNo;
  String? dbMngNo;
  String? kosTgTrnsDtm;
  String? kosTgNo;
  String? procDvsnCd;
  String? rthIsrnEntrYn;
  String? rthIsrnEntrCmpy;
  String? rthIsrnScrtNo;
  String? pstNo;
  String? crtdnCd;
  String? trgtAddr;
  String? trgtDtlAddr;
  String? rgstrUnqNo1;
  String? rgstrUnqNo2;
  String? rgstrUnqNo3;
  String? lndKndCd;
  String? fndYn;
  String? prdtNm;
  String? prdtCd;
  String? grntAgncCd;
  String? srvTrgtYn;
  String? stndTrgtYn;
  String? rrcpChrgTrgtYn;
  String? rvsnCntrctChrgTrgtYn;
  String? sscptAskDt;
  String? lndPlnDt;
  String? rntlPrdEndDt;
  String? lndExprdDt;
  int? lndPrd;
  int? lndAmt;
  int? isrnEntrAmt;
  int? objtEbnkRgstrRnk;
  int? objtEbnkBndMaxAmt;
  int? mggFnlOdprtAmt;
  int? trolFnlOdprtAmt;
  String? srvcEndDt;
  String? dbtrNm;
  String? dbtrRrno;
  String? dbtrPstNo;
  String? dbtrAddr;
  String? dbtrPhno;
  String? dbtrHpno;
  String? wdngPlnYn;
  String? wdngPlnDt;
  String? hshldrCnddtYn;
  String? unmrdHshldr25agLstnYn;
  String? acptDsc;
  String? lwfmNm;
  String? lwfmBizno;
  String? askBrnchCd;
  String? askBrnchNm;
  String? askBrnchDrctrNm;
  String? askBrnchPhno;
  String? bnkLesDsc;
  String? fndLesDsc;
  String? cndtlCnts;
  String? isrnPrmm;
  String? rsrvItmB;
  String? regDtm;
  String? loanAprvNo2;
  AskDbTranResData({
    this.loanNo,
    this.newLoanNo,
    this.tgLen,
    this.tgDsc,
    this.resCd,
    this.lndAgncCd,
    this.bnkTgTrnsDtm,
    this.dbTgTrnsDtm,
    this.bnkTgNo,
    this.dbTgNo,
    this.rsrvItmH,
    this.bnkAskNo,
    this.dbMngNo,
    this.kosTgTrnsDtm,
    this.kosTgNo,
    this.procDvsnCd,
    this.rthIsrnEntrYn,
    this.rthIsrnEntrCmpy,
    this.rthIsrnScrtNo,
    this.pstNo,
    this.crtdnCd,
    this.trgtAddr,
    this.trgtDtlAddr,
    this.rgstrUnqNo1,
    this.rgstrUnqNo2,
    this.rgstrUnqNo3,
    this.lndKndCd,
    this.fndYn,
    this.prdtNm,
    this.prdtCd,
    this.grntAgncCd,
    this.srvTrgtYn,
    this.stndTrgtYn,
    this.rrcpChrgTrgtYn,
    this.rvsnCntrctChrgTrgtYn,
    this.sscptAskDt,
    this.lndPlnDt,
    this.rntlPrdEndDt,
    this.lndExprdDt,
    this.lndPrd,
    this.lndAmt,
    this.isrnEntrAmt,
    this.objtEbnkRgstrRnk,
    this.objtEbnkBndMaxAmt,
    this.mggFnlOdprtAmt,
    this.trolFnlOdprtAmt,
    this.srvcEndDt,
    this.dbtrNm,
    this.dbtrRrno,
    this.dbtrPstNo,
    this.dbtrAddr,
    this.dbtrPhno,
    this.dbtrHpno,
    this.wdngPlnYn,
    this.wdngPlnDt,
    this.hshldrCnddtYn,
    this.unmrdHshldr25agLstnYn,
    this.acptDsc,
    this.lwfmNm,
    this.lwfmBizno,
    this.askBrnchCd,
    this.askBrnchNm,
    this.askBrnchDrctrNm,
    this.askBrnchPhno,
    this.bnkLesDsc,
    this.fndLesDsc,
    this.cndtlCnts,
    this.isrnPrmm,
    this.rsrvItmB,
    this.regDtm,
    this.loanAprvNo2,
  });

  AskDbTranResData copyWith({
    String? loanNo,
    String? newLoanNo,
    int? tgLen,
    String? tgDsc,
    String? resCd,
    String? lndAgncCd,
    String? bnkTgTrnsDtm,
    String? dbTgTrnsDtm,
    String? bnkTgNo,
    int? dbTgNo,
    String? rsrvItmH,
    String? bnkAskNo,
    String? dbMngNo,
    String? kosTgTrnsDtm,
    String? kosTgNo,
    String? procDvsnCd,
    String? rthIsrnEntrYn,
    String? rthIsrnEntrCmpy,
    String? rthIsrnScrtNo,
    String? pstNo,
    String? crtdnCd,
    String? trgtAddr,
    String? trgtDtlAddr,
    String? rgstrUnqNo1,
    String? rgstrUnqNo2,
    String? rgstrUnqNo3,
    String? lndKndCd,
    String? fndYn,
    String? prdtNm,
    String? prdtCd,
    String? grntAgncCd,
    String? srvTrgtYn,
    String? stndTrgtYn,
    String? rrcpChrgTrgtYn,
    String? rvsnCntrctChrgTrgtYn,
    String? sscptAskDt,
    String? lndPlnDt,
    String? rntlPrdEndDt,
    String? lndExprdDt,
    int? lndPrd,
    int? lndAmt,
    int? isrnEntrAmt,
    int? objtEbnkRgstrRnk,
    int? objtEbnkBndMaxAmt,
    int? mggFnlOdprtAmt,
    int? trolFnlOdprtAmt,
    String? srvcEndDt,
    String? dbtrNm,
    String? dbtrRrno,
    String? dbtrPstNo,
    String? dbtrAddr,
    String? dbtrPhno,
    String? dbtrHpno,
    String? wdngPlnYn,
    String? wdngPlnDt,
    String? hshldrCnddtYn,
    String? unmrdHshldr25agLstnYn,
    String? acptDsc,
    String? lwfmNm,
    String? lwfmBizno,
    String? askBrnchCd,
    String? askBrnchNm,
    String? askBrnchDrctrNm,
    String? askBrnchPhno,
    String? bnkLesDsc,
    String? fndLesDsc,
    String? cndtlCnts,
    String? isrnPrmm,
    String? rsrvItmB,
    String? regDtm,
    String? loanAprvNo2,
  }) {
    return AskDbTranResData(
      loanNo: loanNo ?? this.loanNo,
      newLoanNo: newLoanNo ?? this.newLoanNo,
      tgLen: tgLen ?? this.tgLen,
      tgDsc: tgDsc ?? this.tgDsc,
      resCd: resCd ?? this.resCd,
      lndAgncCd: lndAgncCd ?? this.lndAgncCd,
      bnkTgTrnsDtm: bnkTgTrnsDtm ?? this.bnkTgTrnsDtm,
      dbTgTrnsDtm: dbTgTrnsDtm ?? this.dbTgTrnsDtm,
      bnkTgNo: bnkTgNo ?? this.bnkTgNo,
      dbTgNo: dbTgNo ?? this.dbTgNo,
      rsrvItmH: rsrvItmH ?? this.rsrvItmH,
      bnkAskNo: bnkAskNo ?? this.bnkAskNo,
      dbMngNo: dbMngNo ?? this.dbMngNo,
      kosTgTrnsDtm: kosTgTrnsDtm ?? this.kosTgTrnsDtm,
      kosTgNo: kosTgNo ?? this.kosTgNo,
      procDvsnCd: procDvsnCd ?? this.procDvsnCd,
      rthIsrnEntrYn: rthIsrnEntrYn ?? this.rthIsrnEntrYn,
      rthIsrnEntrCmpy: rthIsrnEntrCmpy ?? this.rthIsrnEntrCmpy,
      rthIsrnScrtNo: rthIsrnScrtNo ?? this.rthIsrnScrtNo,
      pstNo: pstNo ?? this.pstNo,
      crtdnCd: crtdnCd ?? this.crtdnCd,
      trgtAddr: trgtAddr ?? this.trgtAddr,
      trgtDtlAddr: trgtDtlAddr ?? this.trgtDtlAddr,
      rgstrUnqNo1: rgstrUnqNo1 ?? this.rgstrUnqNo1,
      rgstrUnqNo2: rgstrUnqNo2 ?? this.rgstrUnqNo2,
      rgstrUnqNo3: rgstrUnqNo3 ?? this.rgstrUnqNo3,
      lndKndCd: lndKndCd ?? this.lndKndCd,
      fndYn: fndYn ?? this.fndYn,
      prdtNm: prdtNm ?? this.prdtNm,
      prdtCd: prdtCd ?? this.prdtCd,
      grntAgncCd: grntAgncCd ?? this.grntAgncCd,
      srvTrgtYn: srvTrgtYn ?? this.srvTrgtYn,
      stndTrgtYn: stndTrgtYn ?? this.stndTrgtYn,
      rrcpChrgTrgtYn: rrcpChrgTrgtYn ?? this.rrcpChrgTrgtYn,
      rvsnCntrctChrgTrgtYn: rvsnCntrctChrgTrgtYn ?? this.rvsnCntrctChrgTrgtYn,
      sscptAskDt: sscptAskDt ?? this.sscptAskDt,
      lndPlnDt: lndPlnDt ?? this.lndPlnDt,
      rntlPrdEndDt: rntlPrdEndDt ?? this.rntlPrdEndDt,
      lndExprdDt: lndExprdDt ?? this.lndExprdDt,
      lndPrd: lndPrd ?? this.lndPrd,
      lndAmt: lndAmt ?? this.lndAmt,
      isrnEntrAmt: isrnEntrAmt ?? this.isrnEntrAmt,
      objtEbnkRgstrRnk: objtEbnkRgstrRnk ?? this.objtEbnkRgstrRnk,
      objtEbnkBndMaxAmt: objtEbnkBndMaxAmt ?? this.objtEbnkBndMaxAmt,
      mggFnlOdprtAmt: mggFnlOdprtAmt ?? this.mggFnlOdprtAmt,
      trolFnlOdprtAmt: trolFnlOdprtAmt ?? this.trolFnlOdprtAmt,
      srvcEndDt: srvcEndDt ?? this.srvcEndDt,
      dbtrNm: dbtrNm ?? this.dbtrNm,
      dbtrRrno: dbtrRrno ?? this.dbtrRrno,
      dbtrPstNo: dbtrPstNo ?? this.dbtrPstNo,
      dbtrAddr: dbtrAddr ?? this.dbtrAddr,
      dbtrPhno: dbtrPhno ?? this.dbtrPhno,
      dbtrHpno: dbtrHpno ?? this.dbtrHpno,
      wdngPlnYn: wdngPlnYn ?? this.wdngPlnYn,
      wdngPlnDt: wdngPlnDt ?? this.wdngPlnDt,
      hshldrCnddtYn: hshldrCnddtYn ?? this.hshldrCnddtYn,
      unmrdHshldr25agLstnYn: unmrdHshldr25agLstnYn ?? this.unmrdHshldr25agLstnYn,
      acptDsc: acptDsc ?? this.acptDsc,
      lwfmNm: lwfmNm ?? this.lwfmNm,
      lwfmBizno: lwfmBizno ?? this.lwfmBizno,
      askBrnchCd: askBrnchCd ?? this.askBrnchCd,
      askBrnchNm: askBrnchNm ?? this.askBrnchNm,
      askBrnchDrctrNm: askBrnchDrctrNm ?? this.askBrnchDrctrNm,
      askBrnchPhno: askBrnchPhno ?? this.askBrnchPhno,
      bnkLesDsc: bnkLesDsc ?? this.bnkLesDsc,
      fndLesDsc: fndLesDsc ?? this.fndLesDsc,
      cndtlCnts: cndtlCnts ?? this.cndtlCnts,
      isrnPrmm: isrnPrmm ?? this.isrnPrmm,
      rsrvItmB: rsrvItmB ?? this.rsrvItmB,
      regDtm: regDtm ?? this.regDtm,
      loanAprvNo2: loanAprvNo2 ?? this.loanAprvNo2,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'newLoanNo': newLoanNo,
      'tgLen': tgLen,
      'tgDsc': tgDsc,
      'resCd': resCd,
      'lndAgncCd': lndAgncCd,
      'bnkTgTrnsDtm': bnkTgTrnsDtm,
      'dbTgTrnsDtm': dbTgTrnsDtm,
      'bnkTgNo': bnkTgNo,
      'dbTgNo': dbTgNo,
      'rsrvItmH': rsrvItmH,
      'bnkAskNo': bnkAskNo,
      'dbMngNo': dbMngNo,
      'kosTgTrnsDtm': kosTgTrnsDtm,
      'kosTgNo': kosTgNo,
      'procDvsnCd': procDvsnCd,
      'rthIsrnEntrYn': rthIsrnEntrYn,
      'rthIsrnEntrCmpy': rthIsrnEntrCmpy,
      'rthIsrnScrtNo': rthIsrnScrtNo,
      'pstNo': pstNo,
      'crtdnCd': crtdnCd,
      'trgtAddr': trgtAddr,
      'trgtDtlAddr': trgtDtlAddr,
      'rgstrUnqNo1': rgstrUnqNo1,
      'rgstrUnqNo2': rgstrUnqNo2,
      'rgstrUnqNo3': rgstrUnqNo3,
      'lndKndCd': lndKndCd,
      'fndYn': fndYn,
      'prdtNm': prdtNm,
      'prdtCd': prdtCd,
      'grntAgncCd': grntAgncCd,
      'srvTrgtYn': srvTrgtYn,
      'stndTrgtYn': stndTrgtYn,
      'rrcpChrgTrgtYn': rrcpChrgTrgtYn,
      'rvsnCntrctChrgTrgtYn': rvsnCntrctChrgTrgtYn,
      'sscptAskDt': sscptAskDt,
      'lndPlnDt': lndPlnDt,
      'rntlPrdEndDt': rntlPrdEndDt,
      'lndExprdDt': lndExprdDt,
      'lndPrd': lndPrd,
      'lndAmt': lndAmt,
      'isrnEntrAmt': isrnEntrAmt,
      'objtEbnkRgstrRnk': objtEbnkRgstrRnk,
      'objtEbnkBndMaxAmt': objtEbnkBndMaxAmt,
      'mggFnlOdprtAmt': mggFnlOdprtAmt,
      'trolFnlOdprtAmt': trolFnlOdprtAmt,
      'srvcEndDt': srvcEndDt,
      'dbtrNm': dbtrNm,
      'dbtrRrno': dbtrRrno,
      'dbtrPstNo': dbtrPstNo,
      'dbtrAddr': dbtrAddr,
      'dbtrPhno': dbtrPhno,
      'dbtrHpno': dbtrHpno,
      'wdngPlnYn': wdngPlnYn,
      'wdngPlnDt': wdngPlnDt,
      'hshldrCnddtYn': hshldrCnddtYn,
      'unmrdHshldr25agLstnYn': unmrdHshldr25agLstnYn,
      'acptDsc': acptDsc,
      'lwfmNm': lwfmNm,
      'lwfmBizno': lwfmBizno,
      'askBrnchCd': askBrnchCd,
      'askBrnchNm': askBrnchNm,
      'askBrnchDrctrNm': askBrnchDrctrNm,
      'askBrnchPhno': askBrnchPhno,
      'bnkLesDsc': bnkLesDsc,
      'fndLesDsc': fndLesDsc,
      'cndtlCnts': cndtlCnts,
      'isrnPrmm': isrnPrmm,
      'rsrvItmB': rsrvItmB,
      'regDtm': regDtm,
      'loanAprvNo2': loanAprvNo2,
    };
  }

  factory AskDbTranResData.fromMap(Map<String, dynamic> map) {
    return AskDbTranResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      newLoanNo: map['newLoanNo'] != null ? map['newLoanNo'] as String : null,
      tgLen: map['tgLen'] != null ? map['tgLen'] as int : null,
      tgDsc: map['tgDsc'] != null ? map['tgDsc'] as String : null,
      resCd: map['resCd'] != null ? map['resCd'] as String : null,
      lndAgncCd: map['lndAgncCd'] != null ? map['lndAgncCd'] as String : null,
      bnkTgTrnsDtm: map['bnkTgTrnsDtm'] != null ? map['bnkTgTrnsDtm'] as String : null,
      dbTgTrnsDtm: map['dbTgTrnsDtm'] != null ? map['dbTgTrnsDtm'] as String : null,
      bnkTgNo: map['bnkTgNo'] != null ? map['bnkTgNo'] as String : null,
      dbTgNo: map['dbTgNo'] != null ? map['dbTgNo'] as int : null,
      rsrvItmH: map['rsrvItmH'] != null ? map['rsrvItmH'] as String : null,
      bnkAskNo: map['bnkAskNo'] != null ? map['bnkAskNo'] as String : null,
      dbMngNo: map['dbMngNo'] != null ? map['dbMngNo'] as String : null,
      kosTgTrnsDtm: map['kosTgTrnsDtm'] != null ? map['kosTgTrnsDtm'] as String : null,
      kosTgNo: map['kosTgNo'] != null ? map['kosTgNo'] as String : null,
      procDvsnCd: map['procDvsnCd'] != null ? map['procDvsnCd'] as String : null,
      rthIsrnEntrYn: map['rthIsrnEntrYn'] != null ? map['rthIsrnEntrYn'] as String : null,
      rthIsrnEntrCmpy: map['rthIsrnEntrCmpy'] != null ? map['rthIsrnEntrCmpy'] as String : null,
      rthIsrnScrtNo: map['rthIsrnScrtNo'] != null ? map['rthIsrnScrtNo'] as String : null,
      pstNo: map['pstNo'] != null ? map['pstNo'] as String : null,
      crtdnCd: map['crtdnCd'] != null ? map['crtdnCd'] as String : null,
      trgtAddr: map['trgtAddr'] != null ? map['trgtAddr'] as String : null,
      trgtDtlAddr: map['trgtDtlAddr'] != null ? map['trgtDtlAddr'] as String : null,
      rgstrUnqNo1: map['rgstrUnqNo1'] != null ? map['rgstrUnqNo1'] as String : null,
      rgstrUnqNo2: map['rgstrUnqNo2'] != null ? map['rgstrUnqNo2'] as String : null,
      rgstrUnqNo3: map['rgstrUnqNo3'] != null ? map['rgstrUnqNo3'] as String : null,
      lndKndCd: map['lndKndCd'] != null ? map['lndKndCd'] as String : null,
      fndYn: map['fndYn'] != null ? map['fndYn'] as String : null,
      prdtNm: map['prdtNm'] != null ? map['prdtNm'] as String : null,
      prdtCd: map['prdtCd'] != null ? map['prdtCd'] as String : null,
      grntAgncCd: map['grntAgncCd'] != null ? map['grntAgncCd'] as String : null,
      srvTrgtYn: map['srvTrgtYn'] != null ? map['srvTrgtYn'] as String : null,
      stndTrgtYn: map['stndTrgtYn'] != null ? map['stndTrgtYn'] as String : null,
      rrcpChrgTrgtYn: map['rrcpChrgTrgtYn'] != null ? map['rrcpChrgTrgtYn'] as String : null,
      rvsnCntrctChrgTrgtYn: map['rvsnCntrctChrgTrgtYn'] != null ? map['rvsnCntrctChrgTrgtYn'] as String : null,
      sscptAskDt: map['sscptAskDt'] != null ? map['sscptAskDt'] as String : null,
      lndPlnDt: map['lndPlnDt'] != null ? map['lndPlnDt'] as String : null,
      rntlPrdEndDt: map['rntlPrdEndDt'] != null ? map['rntlPrdEndDt'] as String : null,
      lndExprdDt: map['lndExprdDt'] != null ? map['lndExprdDt'] as String : null,
      lndPrd: map['lndPrd'] != null ? map['lndPrd'] as int : null,
      lndAmt: map['lndAmt'] != null ? map['lndAmt'] as int : null,
      isrnEntrAmt: map['isrnEntrAmt'] != null ? map['isrnEntrAmt'] as int : null,
      objtEbnkRgstrRnk: map['objtEbnkRgstrRnk'] != null ? map['objtEbnkRgstrRnk'] as int : null,
      objtEbnkBndMaxAmt: map['objtEbnkBndMaxAmt'] != null ? map['objtEbnkBndMaxAmt'] as int : null,
      mggFnlOdprtAmt: map['mggFnlOdprtAmt'] != null ? map['mggFnlOdprtAmt'] as int : null,
      trolFnlOdprtAmt: map['trolFnlOdprtAmt'] != null ? map['trolFnlOdprtAmt'] as int : null,
      srvcEndDt: map['srvcEndDt'] != null ? map['srvcEndDt'] as String : null,
      dbtrNm: map['dbtrNm'] != null ? map['dbtrNm'] as String : null,
      dbtrRrno: map['dbtrRrno'] != null ? map['dbtrRrno'] as String : null,
      dbtrPstNo: map['dbtrPstNo'] != null ? map['dbtrPstNo'] as String : null,
      dbtrAddr: map['dbtrAddr'] != null ? map['dbtrAddr'] as String : null,
      dbtrPhno: map['dbtrPhno'] != null ? map['dbtrPhno'] as String : null,
      dbtrHpno: map['dbtrHpno'] != null ? map['dbtrHpno'] as String : null,
      wdngPlnYn: map['wdngPlnYn'] != null ? map['wdngPlnYn'] as String : null,
      wdngPlnDt: map['wdngPlnDt'] != null ? map['wdngPlnDt'] as String : null,
      hshldrCnddtYn: map['hshldrCnddtYn'] != null ? map['hshldrCnddtYn'] as String : null,
      unmrdHshldr25agLstnYn: map['unmrdHshldr25agLstnYn'] != null ? map['unmrdHshldr25agLstnYn'] as String : null,
      acptDsc: map['acptDsc'] != null ? map['acptDsc'] as String : null,
      lwfmNm: map['lwfmNm'] != null ? map['lwfmNm'] as String : null,
      lwfmBizno: map['lwfmBizno'] != null ? map['lwfmBizno'] as String : null,
      askBrnchCd: map['askBrnchCd'] != null ? map['askBrnchCd'] as String : null,
      askBrnchNm: map['askBrnchNm'] != null ? map['askBrnchNm'] as String : null,
      askBrnchDrctrNm: map['askBrnchDrctrNm'] != null ? map['askBrnchDrctrNm'] as String : null,
      askBrnchPhno: map['askBrnchPhno'] != null ? map['askBrnchPhno'] as String : null,
      bnkLesDsc: map['bnkLesDsc'] != null ? map['bnkLesDsc'] as String : null,
      fndLesDsc: map['fndLesDsc'] != null ? map['fndLesDsc'] as String : null,
      cndtlCnts: map['cndtlCnts'] != null ? map['cndtlCnts'] as String : null,
      isrnPrmm: map['isrnPrmm'] != null ? map['isrnPrmm'] as String : null,
      rsrvItmB: map['rsrvItmB'] != null ? map['rsrvItmB'] as String : null,
      regDtm: map['regDtm'] != null ? map['regDtm'] as String : null,
      loanAprvNo2: map['loanAprvNo2'] != null ? map['loanAprvNo2'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory AskDbTranResData.fromJson(String source) => AskDbTranResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'AskDbTranResData(loanNo: $loanNo, newLoanNo: $newLoanNo, tgLen: $tgLen, tgDsc: $tgDsc, resCd: $resCd, lndAgncCd: $lndAgncCd, bnkTgTrnsDtm: $bnkTgTrnsDtm, dbTgTrnsDtm: $dbTgTrnsDtm, bnkTgNo: $bnkTgNo, dbTgNo: $dbTgNo, rsrvItmH: $rsrvItmH, bnkAskNo: $bnkAskNo, dbMngNo: $dbMngNo, kosTgTrnsDtm: $kosTgTrnsDtm, kosTgNo: $kosTgNo, procDvsnCd: $procDvsnCd, rthIsrnEntrYn: $rthIsrnEntrYn, rthIsrnEntrCmpy: $rthIsrnEntrCmpy, rthIsrnScrtNo: $rthIsrnScrtNo, pstNo: $pstNo, crtdnCd: $crtdnCd, trgtAddr: $trgtAddr, trgtDtlAddr: $trgtDtlAddr, rgstrUnqNo1: $rgstrUnqNo1, rgstrUnqNo2: $rgstrUnqNo2, rgstrUnqNo3: $rgstrUnqNo3, lndKndCd: $lndKndCd, fndYn: $fndYn, prdtNm: $prdtNm, prdtCd: $prdtCd, grntAgncCd: $grntAgncCd, srvTrgtYn: $srvTrgtYn, stndTrgtYn: $stndTrgtYn, rrcpChrgTrgtYn: $rrcpChrgTrgtYn, rvsnCntrctChrgTrgtYn: $rvsnCntrctChrgTrgtYn, sscptAskDt: $sscptAskDt, lndPlnDt: $lndPlnDt, rntlPrdEndDt: $rntlPrdEndDt, lndExprdDt: $lndExprdDt, lndPrd: $lndPrd, lndAmt: $lndAmt, isrnEntrAmt: $isrnEntrAmt, objtEbnkRgstrRnk: $objtEbnkRgstrRnk, objtEbnkBndMaxAmt: $objtEbnkBndMaxAmt, mggFnlOdprtAmt: $mggFnlOdprtAmt, trolFnlOdprtAmt: $trolFnlOdprtAmt, srvcEndDt: $srvcEndDt, dbtrNm: $dbtrNm, dbtrRrno: $dbtrRrno, dbtrPstNo: $dbtrPstNo, dbtrAddr: $dbtrAddr, dbtrPhno: $dbtrPhno, dbtrHpno: $dbtrHpno, wdngPlnYn: $wdngPlnYn, wdngPlnDt: $wdngPlnDt, hshldrCnddtYn: $hshldrCnddtYn, unmrdHshldr25agLstnYn: $unmrdHshldr25agLstnYn, acptDsc: $acptDsc, lwfmNm: $lwfmNm, lwfmBizno: $lwfmBizno, askBrnchCd: $askBrnchCd, askBrnchNm: $askBrnchNm, askBrnchDrctrNm: $askBrnchDrctrNm, askBrnchPhno: $askBrnchPhno, bnkLesDsc: $bnkLesDsc, fndLesDsc: $fndLesDsc, cndtlCnts: $cndtlCnts, isrnPrmm: $isrnPrmm, rsrvItmB: $rsrvItmB, regDtm: $regDtm, loanAprvNo2: $loanAprvNo2)';
  }

  @override
  bool operator ==(covariant AskDbTranResData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.newLoanNo == newLoanNo &&
          other.tgLen == tgLen &&
          other.tgDsc == tgDsc &&
          other.resCd == resCd &&
          other.lndAgncCd == lndAgncCd &&
          other.bnkTgTrnsDtm == bnkTgTrnsDtm &&
          other.dbTgTrnsDtm == dbTgTrnsDtm &&
          other.bnkTgNo == bnkTgNo &&
          other.dbTgNo == dbTgNo &&
          other.rsrvItmH == rsrvItmH &&
          other.bnkAskNo == bnkAskNo &&
          other.dbMngNo == dbMngNo &&
          other.kosTgTrnsDtm == kosTgTrnsDtm &&
          other.kosTgNo == kosTgNo &&
          other.procDvsnCd == procDvsnCd &&
          other.rthIsrnEntrYn == rthIsrnEntrYn &&
          other.rthIsrnEntrCmpy == rthIsrnEntrCmpy &&
          other.rthIsrnScrtNo == rthIsrnScrtNo &&
          other.pstNo == pstNo &&
          other.crtdnCd == crtdnCd &&
          other.trgtAddr == trgtAddr &&
          other.trgtDtlAddr == trgtDtlAddr &&
          other.rgstrUnqNo1 == rgstrUnqNo1 &&
          other.rgstrUnqNo2 == rgstrUnqNo2 &&
          other.rgstrUnqNo3 == rgstrUnqNo3 &&
          other.lndKndCd == lndKndCd &&
          other.fndYn == fndYn &&
          other.prdtNm == prdtNm &&
          other.prdtCd == prdtCd &&
          other.grntAgncCd == grntAgncCd &&
          other.srvTrgtYn == srvTrgtYn &&
          other.stndTrgtYn == stndTrgtYn &&
          other.rrcpChrgTrgtYn == rrcpChrgTrgtYn &&
          other.rvsnCntrctChrgTrgtYn == rvsnCntrctChrgTrgtYn &&
          other.sscptAskDt == sscptAskDt &&
          other.lndPlnDt == lndPlnDt &&
          other.rntlPrdEndDt == rntlPrdEndDt &&
          other.lndExprdDt == lndExprdDt &&
          other.lndPrd == lndPrd &&
          other.lndAmt == lndAmt &&
          other.isrnEntrAmt == isrnEntrAmt &&
          other.objtEbnkRgstrRnk == objtEbnkRgstrRnk &&
          other.objtEbnkBndMaxAmt == objtEbnkBndMaxAmt &&
          other.mggFnlOdprtAmt == mggFnlOdprtAmt &&
          other.trolFnlOdprtAmt == trolFnlOdprtAmt &&
          other.srvcEndDt == srvcEndDt &&
          other.dbtrNm == dbtrNm &&
          other.dbtrRrno == dbtrRrno &&
          other.dbtrPstNo == dbtrPstNo &&
          other.dbtrAddr == dbtrAddr &&
          other.dbtrPhno == dbtrPhno &&
          other.dbtrHpno == dbtrHpno &&
          other.wdngPlnYn == wdngPlnYn &&
          other.wdngPlnDt == wdngPlnDt &&
          other.hshldrCnddtYn == hshldrCnddtYn &&
          other.unmrdHshldr25agLstnYn == unmrdHshldr25agLstnYn &&
          other.acptDsc == acptDsc &&
          other.lwfmNm == lwfmNm &&
          other.lwfmBizno == lwfmBizno &&
          other.askBrnchCd == askBrnchCd &&
          other.askBrnchNm == askBrnchNm &&
          other.askBrnchDrctrNm == askBrnchDrctrNm &&
          other.askBrnchPhno == askBrnchPhno &&
          other.bnkLesDsc == bnkLesDsc &&
          other.fndLesDsc == fndLesDsc &&
          other.cndtlCnts == cndtlCnts &&
          other.isrnPrmm == isrnPrmm &&
          other.rsrvItmB == rsrvItmB &&
          other.regDtm == regDtm &&
          other.loanAprvNo2 == loanAprvNo2;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    newLoanNo.hashCode ^
    tgLen.hashCode ^
    tgDsc.hashCode ^
    resCd.hashCode ^
    lndAgncCd.hashCode ^
    bnkTgTrnsDtm.hashCode ^
    dbTgTrnsDtm.hashCode ^
    bnkTgNo.hashCode ^
    dbTgNo.hashCode ^
    rsrvItmH.hashCode ^
    bnkAskNo.hashCode ^
    dbMngNo.hashCode ^
    kosTgTrnsDtm.hashCode ^
    kosTgNo.hashCode ^
    procDvsnCd.hashCode ^
    rthIsrnEntrYn.hashCode ^
    rthIsrnEntrCmpy.hashCode ^
    rthIsrnScrtNo.hashCode ^
    pstNo.hashCode ^
    crtdnCd.hashCode ^
    trgtAddr.hashCode ^
    trgtDtlAddr.hashCode ^
    rgstrUnqNo1.hashCode ^
    rgstrUnqNo2.hashCode ^
    rgstrUnqNo3.hashCode ^
    lndKndCd.hashCode ^
    fndYn.hashCode ^
    prdtNm.hashCode ^
    prdtCd.hashCode ^
    grntAgncCd.hashCode ^
    srvTrgtYn.hashCode ^
    stndTrgtYn.hashCode ^
    rrcpChrgTrgtYn.hashCode ^
    rvsnCntrctChrgTrgtYn.hashCode ^
    sscptAskDt.hashCode ^
    lndPlnDt.hashCode ^
    rntlPrdEndDt.hashCode ^
    lndExprdDt.hashCode ^
    lndPrd.hashCode ^
    lndAmt.hashCode ^
    isrnEntrAmt.hashCode ^
    objtEbnkRgstrRnk.hashCode ^
    objtEbnkBndMaxAmt.hashCode ^
    mggFnlOdprtAmt.hashCode ^
    trolFnlOdprtAmt.hashCode ^
    srvcEndDt.hashCode ^
    dbtrNm.hashCode ^
    dbtrRrno.hashCode ^
    dbtrPstNo.hashCode ^
    dbtrAddr.hashCode ^
    dbtrPhno.hashCode ^
    dbtrHpno.hashCode ^
    wdngPlnYn.hashCode ^
    wdngPlnDt.hashCode ^
    hshldrCnddtYn.hashCode ^
    unmrdHshldr25agLstnYn.hashCode ^
    acptDsc.hashCode ^
    lwfmNm.hashCode ^
    lwfmBizno.hashCode ^
    askBrnchCd.hashCode ^
    askBrnchNm.hashCode ^
    askBrnchDrctrNm.hashCode ^
    askBrnchPhno.hashCode ^
    bnkLesDsc.hashCode ^
    fndLesDsc.hashCode ^
    cndtlCnts.hashCode ^
    isrnPrmm.hashCode ^
    rsrvItmB.hashCode ^
    regDtm.hashCode ^
    loanAprvNo2.hashCode;
  }
}
