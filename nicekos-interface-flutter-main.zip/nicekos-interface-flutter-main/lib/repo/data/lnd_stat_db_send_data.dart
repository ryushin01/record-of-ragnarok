import 'dart:convert';
class LndStatDbSendReqData {
  String? loanNo;
  String? newLoanNo;
  int? tgLen;
  String? tgDsc;
  String? resCd;
  String? lndAgncCd;
  String? bnkTgTrnsDtm;
  String? dbTgTrnsDtm;
  String? bnkTgNo;
  int? dbTgNo;
  String? rsrvItmH;
  String? bnkAskNo;
  String? dbMngNo;
  String? kosTgTrnsDtm;
  String? kosTgNo;
  String? nttnYn;
  String? endNotiDt;
  String? endNotiTm;
  String? bnkDrctrNm;
  String? bnkDrctrPhno;
  String? rsrvItmB;
  String? regDtm;
  String? chgDtm;

  LndStatDbSendReqData({
    this.loanNo,
    this.newLoanNo,
    this.tgLen,
    this.tgDsc,
    this.resCd,
    this.lndAgncCd,
    this.bnkTgTrnsDtm,
    this.dbTgTrnsDtm,
    this.bnkTgNo,
    this.dbTgNo,
    this.rsrvItmH,
    this.bnkAskNo,
    this.dbMngNo,
    this.kosTgTrnsDtm,
    this.kosTgNo,
    this.nttnYn,
    this.endNotiDt,
    this.endNotiTm,
    this.bnkDrctrNm,
    this.bnkDrctrPhno,
    this.rsrvItmB,
    this.regDtm,
    this.chgDtm,
  });

  Map<String, dynamic> toMap() {
    return {
      'loanNo': loanNo,
      'newLoanNo': newLoanNo,
      'tgLen': tgLen,
      'tgDsc': tgDsc,
      'resCd': resCd,
      'lndAgncCd': lndAgncCd,
      'bnkTgTrnsDtm': bnkTgTrnsDtm,
      'dbTgTrnsDtm': dbTgTrnsDtm,
      'bnkTgNo': bnkTgNo,
      'dbTgNo': dbTgNo,
      'rsrvItmH': rsrvItmH,
      'bnkAskNo': bnkAskNo,
      'dbMngNo': dbMngNo,
      'kosTgTrnsDtm': kosTgTrnsDtm,
      'kosTgNo': kosTgNo,
      'nttnYn': nttnYn,
      'endNotiDt': endNotiDt,
      'endNotiTm': endNotiTm,
      'bnkDrctrNm': bnkDrctrNm,
      'bnkDrctrPhno': bnkDrctrPhno,
      'rsrvItmB': rsrvItmB,
      'regDtm': regDtm,
      'chgDtm': chgDtm,
    };
  }

  factory LndStatDbSendReqData.fromMap(dynamic map) {
    return LndStatDbSendReqData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      newLoanNo: map['newLoanNo'] != null ? map['newLoanNo'] as String : null,
      tgLen: map['tgLen'] != null ? map['tgLen'] as int : null,
      tgDsc: map['tgDsc'] != null ? map['tgDsc'] as String : null,
      resCd: map['resCd'] != null ? map['resCd'] as String : null,
      lndAgncCd: map['lndAgncCd'] != null ? map['lndAgncCd'] as String : null,
      bnkTgTrnsDtm: map['bnkTgTrnsDtm'] != null ? map['bnkTgTrnsDtm'] as String : null,
      dbTgTrnsDtm: map['dbTgTrnsDtm'] != null ? map['dbTgTrnsDtm'] as String : null,
      bnkTgNo: map['bnkTgNo'] != null ? map['bnkTgNo'] as String : null,
      dbTgNo: map['dbTgNo'] != null ? map['dbTgNo'] as int : null,
      rsrvItmH: map['rsrvItmH'] != null ? map['rsrvItmH'] as String : null,
      bnkAskNo: map['bnkAskNo'] != null ? map['bnkAskNo'] as String : null,
      dbMngNo: map['dbMngNo'] != null ? map['dbMngNo'] as String : null,
      kosTgTrnsDtm: map['kosTgTrnsDtm'] != null ? map['kosTgTrnsDtm'] as String : null,
      kosTgNo: map['kosTgNo'] != null ? map['kosTgNo'] as String : null,
      nttnYn: map['nttnYn'] != null ? map['nttnYn'] as String : null,
      endNotiDt: map['endNotiDt'] != null ? map['endNotiDt'] as String : null,
      endNotiTm: map['endNotiTm'] != null ? map['endNotiTm'] as String : null,
      bnkDrctrNm: map['bnkDrctrNm'] != null ? map['bnkDrctrNm'] as String : null,
      bnkDrctrPhno: map['bnkDrctrPhno'] != null ? map['bnkDrctrPhno'] as String : null,
      rsrvItmB: map['rsrvItmB'] != null ? map['rsrvItmB'] as String : null,
      regDtm: map['regDtm'] != null ? map['regDtm'] as String : null,
      chgDtm: map['chgDtm'] != null ? map['chgDtm'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory LndStatDbSendReqData.fromJson(String source) => LndStatDbSendReqData.fromMap(json.decode(source) as Map<String, dynamic>);
}
class LndStatDbSendResData {
  String? loanNo;
  String? newLoanNo;
  int? tgLen;
  String? tgDsc;
  String? resCd;
  String? lndAgncCd;
  String? bnkTgTrnsDtm;
  String? dbTgTrnsDtm;
  String? bnkTgNo;
  int? dbTgNo;
  String? rsrvItmH;
  String? bnkAskNo;
  String? dbMngNo;
  String? kosTgTrnsDtm;
  String? kosTgNo;
  String? nttnYn;
  String? endNotiDt;
  String? endNotiTm;
  String? bnkDrctrNm;
  String? bnkDrctrPhno;
  String? rsrvItmB;
  String? regDtm;
  String? chgDtm;

  LndStatDbSendResData({
    this.loanNo,
    this.newLoanNo,
    this.tgLen,
    this.tgDsc,
    this.resCd,
    this.lndAgncCd,
    this.bnkTgTrnsDtm,
    this.dbTgTrnsDtm,
    this.bnkTgNo,
    this.dbTgNo,
    this.rsrvItmH,
    this.bnkAskNo,
    this.dbMngNo,
    this.kosTgTrnsDtm,
    this.kosTgNo,
    this.nttnYn,
    this.endNotiDt,
    this.endNotiTm,
    this.bnkDrctrNm,
    this.bnkDrctrPhno,
    this.rsrvItmB,
    this.regDtm,
    this.chgDtm,
  });

  Map<String, dynamic> toMap() {
    return {
      'loanNo': loanNo,
      'newLoanNo': newLoanNo,
      'tgLen': tgLen,
      'tgDsc': tgDsc,
      'resCd': resCd,
      'lndAgncCd': lndAgncCd,
      'bnkTgTrnsDtm': bnkTgTrnsDtm,
      'dbTgTrnsDtm': dbTgTrnsDtm,
      'bnkTgNo': bnkTgNo,
      'dbTgNo': dbTgNo,
      'rsrvItmH': rsrvItmH,
      'bnkAskNo': bnkAskNo,
      'dbMngNo': dbMngNo,
      'kosTgTrnsDtm': kosTgTrnsDtm,
      'kosTgNo': kosTgNo,
      'nttnYn': nttnYn,
      'endNotiDt': endNotiDt,
      'endNotiTm': endNotiTm,
      'bnkDrctrNm': bnkDrctrNm,
      'bnkDrctrPhno': bnkDrctrPhno,
      'rsrvItmB': rsrvItmB,
      'regDtm': regDtm,
      'chgDtm': chgDtm,
    };
  }

  factory LndStatDbSendResData.fromMap(dynamic map) {
    return LndStatDbSendResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      newLoanNo: map['newLoanNo'] != null ? map['newLoanNo'] as String : null,
      tgLen: map['tgLen'] != null ? map['tgLen'] as int : null,
      tgDsc: map['tgDsc'] != null ? map['tgDsc'] as String : null,
      resCd: map['resCd'] != null ? map['resCd'] as String : null,
      lndAgncCd: map['lndAgncCd'] != null ? map['lndAgncCd'] as String : null,
      bnkTgTrnsDtm: map['bnkTgTrnsDtm'] != null ? map['bnkTgTrnsDtm'] as String : null,
      dbTgTrnsDtm: map['dbTgTrnsDtm'] != null ? map['dbTgTrnsDtm'] as String : null,
      bnkTgNo: map['bnkTgNo'] != null ? map['bnkTgNo'] as String : null,
      dbTgNo: map['dbTgNo'] != null ? map['dbTgNo'] as int : null,
      rsrvItmH: map['rsrvItmH'] != null ? map['rsrvItmH'] as String : null,
      bnkAskNo: map['bnkAskNo'] != null ? map['bnkAskNo'] as String : null,
      dbMngNo: map['dbMngNo'] != null ? map['dbMngNo'] as String : null,
      kosTgTrnsDtm: map['kosTgTrnsDtm'] != null ? map['kosTgTrnsDtm'] as String : null,
      kosTgNo: map['kosTgNo'] != null ? map['kosTgNo'] as String : null,
      nttnYn: map['nttnYn'] != null ? map['nttnYn'] as String : null,
      endNotiDt: map['endNotiDt'] != null ? map['endNotiDt'] as String : null,
      endNotiTm: map['endNotiTm'] != null ? map['endNotiTm'] as String : null,
      bnkDrctrNm: map['bnkDrctrNm'] != null ? map['bnkDrctrNm'] as String : null,
      bnkDrctrPhno: map['bnkDrctrPhno'] != null ? map['bnkDrctrPhno'] as String : null,
      rsrvItmB: map['rsrvItmB'] != null ? map['rsrvItmB'] as String : null,
      regDtm: map['regDtm'] != null ? map['regDtm'] as String : null,
      chgDtm: map['chgDtm'] != null ? map['chgDtm'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory LndStatDbSendResData.fromJson(String source) => LndStatDbSendResData.fromMap(json.decode(source) as Map<String, dynamic>);
}