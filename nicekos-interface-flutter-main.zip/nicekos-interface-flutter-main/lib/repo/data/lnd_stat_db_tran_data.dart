// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class LndStatDbTranResData {
  String? loanNo;
  String? chgDtm;
  int? tgLen;
  String? tgDsc;
  String? resCd;
  String? lndAgncCd;
  String? bnkTgTrnsDtm;
  String? dbTgTrnsDtm;
  String? bnkTgNo;
  int? dbTgNo;
  String? rsrvItmH;
  String? bnkAskNo;
  String? dbMngNo;
  String? kosTgTrnsDtm;
  String? kosTgNo;
  String? nttnYn;
  String? endNotiDt;
  String? endNotiTm;
  String? bnkDrctrNm;
  String? bnkDrctrPhno;
  String? rsrvItmB;
  String? regDtm;
  LndStatDbTranResData({
    this.loanNo,
    this.chgDtm,
    this.tgLen,
    this.tgDsc,
    this.resCd,
    this.lndAgncCd,
    this.bnkTgTrnsDtm,
    this.dbTgTrnsDtm,
    this.bnkTgNo,
    this.dbTgNo,
    this.rsrvItmH,
    this.bnkAskNo,
    this.dbMngNo,
    this.kosTgTrnsDtm,
    this.kosTgNo,
    this.nttnYn,
    this.endNotiDt,
    this.endNotiTm,
    this.bnkDrctrNm,
    this.bnkDrctrPhno,
    this.rsrvItmB,
    this.regDtm,
  });

  LndStatDbTranResData copyWith({
    String? loanNo,
    String? chgDtm,
    int? tgLen,
    String? tgDsc,
    String? resCd,
    String? lndAgncCd,
    String? bnkTgTrnsDtm,
    String? dbTgTrnsDtm,
    String? bnkTgNo,
    int? dbTgNo,
    String? rsrvItmH,
    String? bnkAskNo,
    String? dbMngNo,
    String? kosTgTrnsDtm,
    String? kosTgNo,
    String? nttnYn,
    String? endNotiDt,
    String? endNotiTm,
    String? bnkDrctrNm,
    String? bnkDrctrPhno,
    String? rsrvItmB,
    String? regDtm,
  }) {
    return LndStatDbTranResData(
      loanNo: loanNo ?? this.loanNo,
      chgDtm: chgDtm ?? this.chgDtm,
      tgLen: tgLen ?? this.tgLen,
      tgDsc: tgDsc ?? this.tgDsc,
      resCd: resCd ?? this.resCd,
      lndAgncCd: lndAgncCd ?? this.lndAgncCd,
      bnkTgTrnsDtm: bnkTgTrnsDtm ?? this.bnkTgTrnsDtm,
      dbTgTrnsDtm: dbTgTrnsDtm ?? this.dbTgTrnsDtm,
      bnkTgNo: bnkTgNo ?? this.bnkTgNo,
      dbTgNo: dbTgNo ?? this.dbTgNo,
      rsrvItmH: rsrvItmH ?? this.rsrvItmH,
      bnkAskNo: bnkAskNo ?? this.bnkAskNo,
      dbMngNo: dbMngNo ?? this.dbMngNo,
      kosTgTrnsDtm: kosTgTrnsDtm ?? this.kosTgTrnsDtm,
      kosTgNo: kosTgNo ?? this.kosTgNo,
      nttnYn: nttnYn ?? this.nttnYn,
      endNotiDt: endNotiDt ?? this.endNotiDt,
      endNotiTm: endNotiTm ?? this.endNotiTm,
      bnkDrctrNm: bnkDrctrNm ?? this.bnkDrctrNm,
      bnkDrctrPhno: bnkDrctrPhno ?? this.bnkDrctrPhno,
      rsrvItmB: rsrvItmB ?? this.rsrvItmB,
      regDtm: regDtm ?? this.regDtm,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'chgDtm': chgDtm,
      'tgLen': tgLen,
      'tgDsc': tgDsc,
      'resCd': resCd,
      'lndAgncCd': lndAgncCd,
      'bnkTgTrnsDtm': bnkTgTrnsDtm,
      'dbTgTrnsDtm': dbTgTrnsDtm,
      'bnkTgNo': bnkTgNo,
      'dbTgNo': dbTgNo,
      'rsrvItmH': rsrvItmH,
      'bnkAskNo': bnkAskNo,
      'dbMngNo': dbMngNo,
      'kosTgTrnsDtm': kosTgTrnsDtm,
      'kosTgNo': kosTgNo,
      'nttnYn': nttnYn,
      'endNotiDt': endNotiDt,
      'endNotiTm': endNotiTm,
      'bnkDrctrNm': bnkDrctrNm,
      'bnkDrctrPhno': bnkDrctrPhno,
      'rsrvItmB': rsrvItmB,
      'regDtm': regDtm,
    };
  }

  factory LndStatDbTranResData.fromMap(Map<String, dynamic> map) {
    return LndStatDbTranResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      chgDtm: map['chgDtm'] != null ? map['chgDtm'] as String : null,
      tgLen: map['tgLen'] != null ? map['tgLen'] as int : null,
      tgDsc: map['tgDsc'] != null ? map['tgDsc'] as String : null,
      resCd: map['resCd'] != null ? map['resCd'] as String : null,
      lndAgncCd: map['lndAgncCd'] != null ? map['lndAgncCd'] as String : null,
      bnkTgTrnsDtm: map['bnkTgTrnsDtm'] != null ? map['bnkTgTrnsDtm'] as String : null,
      dbTgTrnsDtm: map['dbTgTrnsDtm'] != null ? map['dbTgTrnsDtm'] as String : null,
      bnkTgNo: map['bnkTgNo'] != null ? map['bnkTgNo'] as String : null,
      dbTgNo: map['dbTgNo'] != null ? map['dbTgNo'] as int : null,
      rsrvItmH: map['rsrvItmH'] != null ? map['rsrvItmH'] as String : null,
      bnkAskNo: map['bnkAskNo'] != null ? map['bnkAskNo'] as String : null,
      dbMngNo: map['dbMngNo'] != null ? map['dbMngNo'] as String : null,
      kosTgTrnsDtm: map['kosTgTrnsDtm'] != null ? map['kosTgTrnsDtm'] as String : null,
      kosTgNo: map['kosTgNo'] != null ? map['kosTgNo'] as String : null,
      nttnYn: map['nttnYn'] != null ? map['nttnYn'] as String : null,
      endNotiDt: map['endNotiDt'] != null ? map['endNotiDt'] as String : null,
      endNotiTm: map['endNotiTm'] != null ? map['endNotiTm'] as String : null,
      bnkDrctrNm: map['bnkDrctrNm'] != null ? map['bnkDrctrNm'] as String : null,
      bnkDrctrPhno: map['bnkDrctrPhno'] != null ? map['bnkDrctrPhno'] as String : null,
      rsrvItmB: map['rsrvItmB'] != null ? map['rsrvItmB'] as String : null,
      regDtm: map['regDtm'] != null ? map['regDtm'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory LndStatDbTranResData.fromJson(String source) => LndStatDbTranResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'LndStatDbTranResData(loanNo: $loanNo, chgDtm: $chgDtm, tgLen: $tgLen, tgDsc: $tgDsc, resCd: $resCd, lndAgncCd: $lndAgncCd, bnkTgTrnsDtm: $bnkTgTrnsDtm, dbTgTrnsDtm: $dbTgTrnsDtm, bnkTgNo: $bnkTgNo, dbTgNo: $dbTgNo, rsrvItmH: $rsrvItmH, bnkAskNo: $bnkAskNo, dbMngNo: $dbMngNo, kosTgTrnsDtm: $kosTgTrnsDtm, kosTgNo: $kosTgNo, nttnYn: $nttnYn, endNotiDt: $endNotiDt, endNotiTm: $endNotiTm, bnkDrctrNm: $bnkDrctrNm, bnkDrctrPhno: $bnkDrctrPhno, rsrvItmB: $rsrvItmB, regDtm: $regDtm)';
  }

  @override
  bool operator ==(covariant LndStatDbTranResData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.chgDtm == chgDtm &&
          other.tgLen == tgLen &&
          other.tgDsc == tgDsc &&
          other.resCd == resCd &&
          other.lndAgncCd == lndAgncCd &&
          other.bnkTgTrnsDtm == bnkTgTrnsDtm &&
          other.dbTgTrnsDtm == dbTgTrnsDtm &&
          other.bnkTgNo == bnkTgNo &&
          other.dbTgNo == dbTgNo &&
          other.rsrvItmH == rsrvItmH &&
          other.bnkAskNo == bnkAskNo &&
          other.dbMngNo == dbMngNo &&
          other.kosTgTrnsDtm == kosTgTrnsDtm &&
          other.kosTgNo == kosTgNo &&
          other.nttnYn == nttnYn &&
          other.endNotiDt == endNotiDt &&
          other.endNotiTm == endNotiTm &&
          other.bnkDrctrNm == bnkDrctrNm &&
          other.bnkDrctrPhno == bnkDrctrPhno &&
          other.rsrvItmB == rsrvItmB &&
          other.regDtm == regDtm;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    chgDtm.hashCode ^
    tgLen.hashCode ^
    tgDsc.hashCode ^
    resCd.hashCode ^
    lndAgncCd.hashCode ^
    bnkTgTrnsDtm.hashCode ^
    dbTgTrnsDtm.hashCode ^
    bnkTgNo.hashCode ^
    dbTgNo.hashCode ^
    rsrvItmH.hashCode ^
    bnkAskNo.hashCode ^
    dbMngNo.hashCode ^
    kosTgTrnsDtm.hashCode ^
    kosTgNo.hashCode ^
    nttnYn.hashCode ^
    endNotiDt.hashCode ^
    endNotiTm.hashCode ^
    bnkDrctrNm.hashCode ^
    bnkDrctrPhno.hashCode ^
    rsrvItmB.hashCode ^
    regDtm.hashCode;
  }
}