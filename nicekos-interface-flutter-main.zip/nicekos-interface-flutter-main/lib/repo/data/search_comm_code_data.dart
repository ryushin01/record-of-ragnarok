import 'dart:convert';

class SearchCommCodeReq {
  String? grpCd;
  String? code;
  String? codeNm;
  String? grpNm;
  String? grpDesc;
  int? num;
  String? etc1;
  String? etc2;
  String? etc3;
  String? useYn;

  SearchCommCodeReq({
    this.grpCd,
    this.code,
    this.codeNm,
    this.grpNm,
    this.grpDesc,
    this.num,
    this.etc1,
    this.etc2,
    this.etc3,
    this.useYn,
  });

  SearchCommCodeReq copyWith({
    String? grpCd,
    String? code,
    String? codeNm,
    String? grpNm,
    String? grpDesc,
    int? num,
    String? etc1,
    String? etc2,
    String? etc3,
    String? useYn,
  }) {
    return SearchCommCodeReq(
      grpCd: grpCd ?? this.grpCd,
      code: code ?? this.code,
      codeNm: codeNm ?? this.codeNm,
      grpNm: grpNm ?? this.grpNm,
      grpDesc: grpDesc ?? this.grpDesc,
      num: num ?? this.num,
      etc1: etc1 ?? this.etc1,
      etc2: etc2 ?? this.etc2,
      etc3: etc3 ?? this.etc3,
      useYn: useYn ?? this.useYn,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'grpCd': grpCd,
      'code': code,
      'codeNm': codeNm,
      'grpNm': grpNm,
      'grpDesc': grpDesc,
      'num': num,
      'etc1': etc1,
      'etc2': etc2,
      'etc3': etc3,
      'useYn': useYn,
    };
  }

  factory SearchCommCodeReq.fromMap(Map<String, dynamic> map) {
    return SearchCommCodeReq(
      grpCd: map['grpCd'] != null ? map['grpCd'] as String : null,
      code: map['code'] != null ? map['code'] as String : null,
      codeNm: map['codeNm'] != null ? map['codeNm'] as String : null,
      grpNm: map['grpNm'] != null ? map['grpNm'] as String : null,
      grpDesc: map['grpDesc'] != null ? map['grpDesc'] as String : null,
      num: map['num'] != null ? map['num'] as int : null,
      etc1: map['etc1'] != null ? map['etc1'] as String : null,
      etc2: map['etc2'] != null ? map['etc2'] as String : null,
      etc3: map['etc3'] != null ? map['etc3'] as String : null,
      useYn: map['useYn'] != null ? map['useYn'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory SearchCommCodeReq.fromJson(String source) =>
      SearchCommCodeReq.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'CommCodeSearchReqData(grpCd: $grpCd, code: $code, codeNm: $codeNm, '
        'grpNm: $grpNm, grpDesc: $grpDesc, num: $num, etc1: $etc1, etc2: $etc2, etc3: $etc3, useYn: $useYn)';
  }

  @override
  bool operator ==(covariant SearchCommCodeReq other) {
    if (identical(this, other)) return true;

    return other.grpCd == grpCd &&
        other.code == code &&
        other.codeNm == codeNm &&
        other.grpNm == grpNm &&
        other.grpDesc == grpDesc &&
        other.num == num &&
        other.etc1 == etc1 &&
        other.etc2 == etc2 &&
        other.etc3 == etc3 &&
        other.useYn == useYn;
  }

  @override
  int get hashCode {
    return grpCd.hashCode ^
        code.hashCode ^
        codeNm.hashCode ^
        grpNm.hashCode ^
        grpDesc.hashCode ^
        num.hashCode ^
        etc1.hashCode ^
        etc2.hashCode ^
        etc3.hashCode ^
        useYn.hashCode;
  }
}

class SearchCommCodeRes {
  String? grpCd;
  String? code;
  String? codeNm;
  String? grpNm;
  String? grpDesc;
  int? num;
  String? etc1;
  String? etc2;
  String? etc3;
  String? useYn;
  String? crtDtm;
  String? crtMembNo;
  String? chgDtm;
  String? chgMembNo;

  SearchCommCodeRes({
    this.grpCd,
    this.code,
    this.codeNm,
    this.grpNm,
    this.grpDesc,
    this.num,
    this.etc1,
    this.etc2,
    this.etc3,
    this.useYn,
    this.crtDtm,
    this.crtMembNo,
    this.chgDtm,
    this.chgMembNo,
  });

  SearchCommCodeRes copyWith({
    String? grpCd,
    String? code,
    String? codeNm,
    String? grpNm,
    String? grpDesc,
    int? num,
    String? etc1,
    String? etc2,
    String? etc3,
    String? useYn,
    String? crtDtm,
    String? crtMembNo,
    String? chgDtm,
    String? chgMembNo,
  }) {
    return SearchCommCodeRes(
      grpCd: grpCd ?? this.grpCd,
      code: code ?? this.code,
      codeNm: codeNm ?? this.codeNm,
      grpNm: grpNm ?? this.grpNm,
      grpDesc: grpDesc ?? this.grpDesc,
      num: num ?? this.num,
      etc1: etc1 ?? this.etc1,
      etc2: etc2 ?? this.etc2,
      etc3: etc3 ?? this.etc3,
      useYn: useYn ?? this.useYn,
      crtDtm: crtDtm ?? this.crtDtm,
      crtMembNo: crtMembNo ?? this.crtMembNo,
      chgDtm: chgDtm ?? this.chgDtm,
      chgMembNo: chgMembNo ?? this.chgMembNo,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'grpCd': grpCd,
      'code': code,
      'codeNm': codeNm,
      'grpNm': grpNm,
      'grpDesc': grpDesc,
      'num': num,
      'etc1': etc1,
      'etc2': etc2,
      'etc3': etc3,
      'useYn': useYn,
      'crtDtm': crtDtm,
      'crtMembNo': crtMembNo,
      'chgDtm': chgDtm,
      'chgMembNo': chgMembNo,
    };
  }

  factory SearchCommCodeRes.fromMap(Map<String, dynamic> map) {
    return SearchCommCodeRes(
      grpCd: map['grpCd'],
      code: map['code'],
      codeNm: map['codeNm'],
      grpNm: map['grpNm'],
      grpDesc: map['grpDesc'],
      num: map['num'],
      etc1: map['etc1'],
      etc2: map['etc2'],
      etc3: map['etc3'],
      useYn: map['useYn'],
      crtDtm: map['crtDtm'],
      crtMembNo: map['crtMembNo'],
      chgDtm: map['chgDtm'],
      chgMembNo: map['chgMembNo'],
    );
  }

  String toJson() => json.encode(toMap());

  factory SearchCommCodeRes.fromJson(String source) =>
      SearchCommCodeRes.fromMap(json.decode(source));

  @override
  String toString() {
    return 'CommCodeSearchResData(grpCd: $grpCd, code: $code, codeNm: $codeNm, grpNm: $grpNm, grpDesc: $grpDesc, num: $num, etc1: $etc1, etc2: $etc2, etc3: $etc3, useYn: $useYn, crtDtm: $crtDtm, crtMembNo: $crtMembNo, chgDtm: $chgDtm, chgMembNo: $chgMembNo)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is SearchCommCodeRes &&
        other.grpCd == grpCd &&
        other.code == code &&
        other.codeNm == codeNm &&
        other.grpNm == grpNm &&
        other.grpDesc == grpDesc &&
        other.num == num &&
        other.etc1 == etc1 &&
        other.etc2 == etc2 &&
        other.etc3 == etc3 &&
        other.useYn == useYn &&
        other.crtDtm == crtDtm &&
        other.crtMembNo == crtMembNo &&
        other.chgDtm == chgDtm &&
        other.chgMembNo == chgMembNo;
  }

  @override
  int get hashCode {
    return grpCd.hashCode ^
        code.hashCode ^
        codeNm.hashCode ^
        grpNm.hashCode ^
        grpDesc.hashCode ^
        num.hashCode ^
        etc1.hashCode ^
        etc2.hashCode ^
        etc3.hashCode ^
        useYn.hashCode ^
        crtDtm.hashCode ^
        crtMembNo.hashCode ^
        chgDtm.hashCode ^
        chgMembNo.hashCode;
  }
}

//불변공통코드는 데이터베이스를 거쳐 리스트를 가져오는것이 아닌
//StaticCommCode class를 통하여 출력하여준다.
class StaticCommCode {
  StaticCommCode._();

  //지역번호
  static List<SearchCommCodeRes> regnNoList = [
    SearchCommCodeRes(code: "02", codeNm: "02"),
    SearchCommCodeRes(code: "031", codeNm: "031"),
    SearchCommCodeRes(code: "032", codeNm: "032"),
    SearchCommCodeRes(code: "033", codeNm: "033"),
    SearchCommCodeRes(code: "041", codeNm: "041"),
    SearchCommCodeRes(code: "042", codeNm: "042"),
    SearchCommCodeRes(code: "043", codeNm: "043"),
    SearchCommCodeRes(code: "044", codeNm: "044"),
    SearchCommCodeRes(code: "051", codeNm: "051"),
    SearchCommCodeRes(code: "052", codeNm: "052"),
    SearchCommCodeRes(code: "053", codeNm: "053"),
    SearchCommCodeRes(code: "054", codeNm: "054"),
    SearchCommCodeRes(code: "055", codeNm: "055"),
    SearchCommCodeRes(code: "061", codeNm: "061"),
    SearchCommCodeRes(code: "062", codeNm: "062"),
    SearchCommCodeRes(code: "063", codeNm: "063"),
    SearchCommCodeRes(code: "064", codeNm: "064"),
    SearchCommCodeRes(code: "070", codeNm: "070"),
  ];

  //통신사 코드
  static List<SearchCommCodeRes> tlcpList = [
    SearchCommCodeRes(code: '01', codeNm: "SKT"),
    SearchCommCodeRes(code: '02', codeNm: "KT"),
    SearchCommCodeRes(code: '03', codeNm: "LGU+"),
    SearchCommCodeRes(code: '04', codeNm: "SKT 알뜰폰"),
    SearchCommCodeRes(code: '05', codeNm: "KT 알뜰폰"),
    SearchCommCodeRes(code: '06', codeNm: "LGU+ 알뜰폰"),
  ];
}
