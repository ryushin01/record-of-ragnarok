// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class Trns6100DetailResData {
  String? loanNo;
  String? newLoanNo;
  int? tgLen;
  String? tgDsc;
  String? bnkTgNo;
  String? faTgNo;
  String? kosTgSndNo;
  String? tgSndDtm;
  String? tgRcvDtm;
  String? resCd;
  String? rsrvItmH;
  String? bnkTtlReqNo;
  String? ttlArdEntrEane;
  String? ttlEntrcmpy;
  String? ttlScrtNo;
  String? lndDsc;
  String? lndKndCd;
  String? fndUseCd;
  String? bnkLndPrdtCd;
  String? bnkLndPrdtNm;
  String? grntDsc;
  String? stndAplYn;
  String? rrcpCnfmReqYn;
  String? mvhrCnfmReqYn;
  String? bfSrvtrgtReqYn;
  String? afSrvtrgtReqYn;
  String? rgstrUnqNo1;
  String? rgstrUnqNo2;
  String? rgstrUnqNo3;
  String? rgstrUnqNo4;
  String? rgstrUnqNo5;
  String? rlesDsc;
  String? trgtRlesDsc;
  String? trgtRlesAddr;
  String? sscptAskDt;
  String? lndPlnDt;
  String? lndExprdDt;
  int? slPrc;
  int? isrnEntrAmt;
  int? lndPrd;
  int? lndAmt;
  int? bnkFxcltRgstrRnk;
  int? bnkFxcltBndMaxAmt;
  String? dbtrNm;
  String? dbtrBirthDt;
  String? dbtrAddr;
  String? dbtrPhno;
  String? dbtrHpno;
  String? pwpsNm;
  String? pwpsBirthDt;
  String? pwpsAddr;
  String? pwpsPhno;
  String? pwpsHpno;
  String? rmkFct;
  String? lndHndgSlfDsc;
  String? bnkBrnchNm;
  String? bnkDrctrNm;
  String? bnkBrnchPhno;
  String? bnkDrctrHp;
  String? bnkBrnchFax;
  String? bnkBrnchAddr;
  String? slmnCmpyNm;
  String? slmnNm;
  String? slmnPhno;
  String? lwfmNm;
  String? lwfmBizNo;
  String? dbtrWdngPlnYn;
  String? rrcpCnfmYn;
  String? spusNm;
  String? wdngPlnDt;
  String? rschWkDdlnReqDt;
  int? isrnPrmm;
  String? rfrLnAprvNo;
  String? rgstrMtdDsc;
  String? rgstrReqNo;
  String? odprtRpyEane;
  String? eltnEstbsLwyrNm;
  String? eltnEstbsLywrBizNo;
  String? eltnRpyLoaAplYn;
  String? eltnRpyLoaSqn;
  String? eltnRpyLoaCtfcNo;
  int? whlRpyCnt;
  int? whlRpyAmt;
  int? ebnkRpyTotAmt;
  int? dfbnkRpyTotAmt;
  String? rpyTrgtRnkNo1;
  String? rpyTrgtAcptDt1;
  String? rpyTrgtAcptNo1;
  int? rpyTrgtBndAmt1;
  String? rpyTrgtRnkNo2;
  String? rpyTrgtAcptDt2;
  String? rpyTrgtAcptNo2;
  int? rpyTrgtBndAmt2;
  String? rpyTrgtRnkNo3;
  String? rpyTrgtAcptDt3;
  String? rpyTrgtAcptNo3;
  int? rpyTrgtBndAmt3;
  String? rpyTrgtRnkNo4;
  String? rpyTrgtAcptDt4;
  String? rpyTrgtAcptNo4;
  int? rpyTrgtBndAmt4;
  String? rpyTrgtRnkNo5;
  String? rpyTrgtAcptDt5;
  String? rpyTrgtAcptNo5;
  int? rpyTrgtBndAmt5;
  String? afrgstrScrtYn;
  String? slmnLndProc;
  String? srMembNo;
  int? trAmt;
  String? sllNm1;
  String? sllBrDay1;
  String? sllNm2;
  String? sllBrDay2;
  int? ownLoanMaxAmt;
  int? ownLoanPlnAmt;
  String? ownLoanBnkNm1;
  String? ownLoanBnkNm2;
  String? ownLoanBnkNm3;
  String? ownLoanBnkNm4;
  String? ownLoanBnkNm5;
  String? cnsgnNm;
  String? trstNm;
  String? bnfrNm;
  String? nowLessNm;
  String? rsrvItmB;
  String? regDtm;
  String? oblMLnAprvNo;
  int? oblTotCnt;
  int? oblGrpRnkNo;
  String? lnAprvNo2;

  Trns6100DetailResData({
    this.loanNo,
    this.newLoanNo,
    this.tgLen,
    this.tgDsc,
    this.bnkTgNo,
    this.faTgNo,
    this.kosTgSndNo,
    this.tgSndDtm,
    this.tgRcvDtm,
    this.resCd,
    this.rsrvItmH,
    this.bnkTtlReqNo,
    this.ttlArdEntrEane,
    this.ttlEntrcmpy,
    this.ttlScrtNo,
    this.lndDsc,
    this.lndKndCd,
    this.fndUseCd,
    this.bnkLndPrdtCd,
    this.bnkLndPrdtNm,
    this.grntDsc,
    this.stndAplYn,
    this.rrcpCnfmReqYn,
    this.mvhrCnfmReqYn,
    this.bfSrvtrgtReqYn,
    this.afSrvtrgtReqYn,
    this.rgstrUnqNo1,
    this.rgstrUnqNo2,
    this.rgstrUnqNo3,
    this.rgstrUnqNo4,
    this.rgstrUnqNo5,
    this.rlesDsc,
    this.trgtRlesDsc,
    this.trgtRlesAddr,
    this.sscptAskDt,
    this.lndPlnDt,
    this.lndExprdDt,
    this.slPrc,
    this.isrnEntrAmt,
    this.lndPrd,
    this.lndAmt,
    this.bnkFxcltRgstrRnk,
    this.bnkFxcltBndMaxAmt,
    this.dbtrNm,
    this.dbtrBirthDt,
    this.dbtrAddr,
    this.dbtrPhno,
    this.dbtrHpno,
    this.pwpsNm,
    this.pwpsBirthDt,
    this.pwpsAddr,
    this.pwpsPhno,
    this.pwpsHpno,
    this.rmkFct,
    this.lndHndgSlfDsc,
    this.bnkBrnchNm,
    this.bnkDrctrNm,
    this.bnkBrnchPhno,
    this.bnkDrctrHp,
    this.bnkBrnchFax,
    this.bnkBrnchAddr,
    this.slmnCmpyNm,
    this.slmnNm,
    this.slmnPhno,
    this.lwfmNm,
    this.lwfmBizNo,
    this.dbtrWdngPlnYn,
    this.rrcpCnfmYn,
    this.spusNm,
    this.wdngPlnDt,
    this.rschWkDdlnReqDt,
    this.isrnPrmm,
    this.rfrLnAprvNo,
    this.rgstrMtdDsc,
    this.rgstrReqNo,
    this.odprtRpyEane,
    this.eltnEstbsLwyrNm,
    this.eltnEstbsLywrBizNo,
    this.eltnRpyLoaAplYn,
    this.eltnRpyLoaSqn,
    this.eltnRpyLoaCtfcNo,
    this.whlRpyCnt,
    this.whlRpyAmt,
    this.ebnkRpyTotAmt,
    this.dfbnkRpyTotAmt,
    this.rpyTrgtRnkNo1,
    this.rpyTrgtAcptDt1,
    this.rpyTrgtAcptNo1,
    this.rpyTrgtBndAmt1,
    this.rpyTrgtRnkNo2,
    this.rpyTrgtAcptDt2,
    this.rpyTrgtAcptNo2,
    this.rpyTrgtBndAmt2,
    this.rpyTrgtRnkNo3,
    this.rpyTrgtAcptDt3,
    this.rpyTrgtAcptNo3,
    this.rpyTrgtBndAmt3,
    this.rpyTrgtRnkNo4,
    this.rpyTrgtAcptDt4,
    this.rpyTrgtAcptNo4,
    this.rpyTrgtBndAmt4,
    this.rpyTrgtRnkNo5,
    this.rpyTrgtAcptDt5,
    this.rpyTrgtAcptNo5,
    this.rpyTrgtBndAmt5,
    this.afrgstrScrtYn,
    this.slmnLndProc,
    this.srMembNo,
    this.trAmt,
    this.sllNm1,
    this.sllBrDay1,
    this.sllNm2,
    this.sllBrDay2,
    this.ownLoanMaxAmt,
    this.ownLoanPlnAmt,
    this.ownLoanBnkNm1,
    this.ownLoanBnkNm2,
    this.ownLoanBnkNm3,
    this.ownLoanBnkNm4,
    this.ownLoanBnkNm5,
    this.cnsgnNm,
    this.trstNm,
    this.bnfrNm,
    this.nowLessNm,
    this.rsrvItmB,
    this.regDtm,
    this.oblMLnAprvNo,
    this.oblTotCnt,
    this.oblGrpRnkNo,
    this.lnAprvNo2,
  });

  Trns6100DetailResData copyWith({
    String? loanNo,
    String? newLoanNo,
    int? tgLen,
    String? tgDsc,
    String? bnkTgNo,
    String? faTgNo,
    String? kosTgSndNo,
    String? tgSndDtm,
    String? tgRcvDtm,
    String? resCd,
    String? rsrvItmH,
    String? bnkTtlReqNo,
    String? ttlArdEntrEane,
    String? ttlEntrcmpy,
    String? ttlScrtNo,
    String? lndDsc,
    String? lndKndCd,
    String? fndUseCd,
    String? bnkLndPrdtCd,
    String? bnkLndPrdtNm,
    String? grntDsc,
    String? stndAplYn,
    String? rrcpCnfmReqYn,
    String? mvhrCnfmReqYn,
    String? bfSrvtrgtReqYn,
    String? afSrvtrgtReqYn,
    String? rgstrUnqNo1,
    String? rgstrUnqNo2,
    String? rgstrUnqNo3,
    String? rgstrUnqNo4,
    String? rgstrUnqNo5,
    String? rlesDsc,
    String? trgtRlesDsc,
    String? trgtRlesAddr,
    String? sscptAskDt,
    String? lndPlnDt,
    String? lndExprdDt,
    int? slPrc,
    int? isrnEntrAmt,
    int? lndPrd,
    int? lndAmt,
    int? bnkFxcltRgstrRnk,
    int? bnkFxcltBndMaxAmt,
    String? dbtrNm,
    String? dbtrBirthDt,
    String? dbtrAddr,
    String? dbtrPhno,
    String? dbtrHpno,
    String? pwpsNm,
    String? pwpsBirthDt,
    String? pwpsAddr,
    String? pwpsPhno,
    String? pwpsHpno,
    String? rmkFct,
    String? lndHndgSlfDsc,
    String? bnkBrnchNm,
    String? bnkDrctrNm,
    String? bnkBrnchPhno,
    String? bnkDrctrHp,
    String? bnkBrnchFax,
    String? bnkBrnchAddr,
    String? slmnCmpyNm,
    String? slmnNm,
    String? slmnPhno,
    String? lwfmNm,
    String? lwfmBizNo,
    String? dbtrWdngPlnYn,
    String? rrcpCnfmYn,
    String? spusNm,
    String? wdngPlnDt,
    String? rschWkDdlnReqDt,
    int? isrnPrmm,
    String? rfrLnAprvNo,
    String? rgstrMtdDsc,
    String? rgstrReqNo,
    String? odprtRpyEane,
    String? eltnEstbsLwyrNm,
    String? eltnEstbsLywrBizNo,
    String? eltnRpyLoaAplYn,
    String? eltnRpyLoaSqn,
    String? eltnRpyLoaCtfcNo,
    int? whlRpyCnt,
    int? whlRpyAmt,
    int? ebnkRpyTotAmt,
    int? dfbnkRpyTotAmt,
    String? rpyTrgtRnkNo1,
    String? rpyTrgtAcptDt1,
    String? rpyTrgtAcptNo1,
    int? rpyTrgtBndAmt1,
    String? rpyTrgtRnkNo2,
    String? rpyTrgtAcptDt2,
    String? rpyTrgtAcptNo2,
    int? rpyTrgtBndAmt2,
    String? rpyTrgtRnkNo3,
    String? rpyTrgtAcptDt3,
    String? rpyTrgtAcptNo3,
    int? rpyTrgtBndAmt3,
    String? rpyTrgtRnkNo4,
    String? rpyTrgtAcptDt4,
    String? rpyTrgtAcptNo4,
    int? rpyTrgtBndAmt4,
    String? rpyTrgtRnkNo5,
    String? rpyTrgtAcptDt5,
    String? rpyTrgtAcptNo5,
    int? rpyTrgtBndAmt5,
    String? afrgstrScrtYn,
    String? slmnLndProc,
    String? srMembNo,
    int? trAmt,
    String? sllNm1,
    String? sllBrDay1,
    String? sllNm2,
    String? sllBrDay2,
    int? ownLoanMaxAmt,
    int? ownLoanPlnAmt,
    String? ownLoanBnkNm1,
    String? ownLoanBnkNm2,
    String? ownLoanBnkNm3,
    String? ownLoanBnkNm4,
    String? ownLoanBnkNm5,
    String? cnsgnNm,
    String? trstNm,
    String? bnfrNm,
    String? nowLessNm,
    String? rsrvItmB,
    String? regDtm,
    String? oblMLnAprvNo,
    int? oblTotCnt,
    int? oblGrpRnkNo,
    String? lnAprvNo2,
  }) {
    return Trns6100DetailResData(
      loanNo: loanNo ?? this.loanNo,
      newLoanNo: newLoanNo ?? this.newLoanNo,
      tgLen: tgLen ?? this.tgLen,
      tgDsc: tgDsc ?? this.tgDsc,
      bnkTgNo: bnkTgNo ?? this.bnkTgNo,
      faTgNo: faTgNo ?? this.faTgNo,
      kosTgSndNo: kosTgSndNo ?? this.kosTgSndNo,
      tgSndDtm: tgSndDtm ?? this.tgSndDtm,
      tgRcvDtm: tgRcvDtm ?? this.tgRcvDtm,
      resCd: resCd ?? this.resCd,
      rsrvItmH: rsrvItmH ?? this.rsrvItmH,
      bnkTtlReqNo: bnkTtlReqNo ?? this.bnkTtlReqNo,
      ttlArdEntrEane: ttlArdEntrEane ?? this.ttlArdEntrEane,
      ttlEntrcmpy: ttlEntrcmpy ?? this.ttlEntrcmpy,
      ttlScrtNo: ttlScrtNo ?? this.ttlScrtNo,
      lndDsc: lndDsc ?? this.lndDsc,
      lndKndCd: lndKndCd ?? this.lndKndCd,
      fndUseCd: fndUseCd ?? this.fndUseCd,
      bnkLndPrdtCd: bnkLndPrdtCd ?? this.bnkLndPrdtCd,
      bnkLndPrdtNm: bnkLndPrdtNm ?? this.bnkLndPrdtNm,
      grntDsc: grntDsc ?? this.grntDsc,
      stndAplYn: stndAplYn ?? this.stndAplYn,
      rrcpCnfmReqYn: rrcpCnfmReqYn ?? this.rrcpCnfmReqYn,
      mvhrCnfmReqYn: mvhrCnfmReqYn ?? this.mvhrCnfmReqYn,
      bfSrvtrgtReqYn: bfSrvtrgtReqYn ?? this.bfSrvtrgtReqYn,
      afSrvtrgtReqYn: afSrvtrgtReqYn ?? this.afSrvtrgtReqYn,
      rgstrUnqNo1: rgstrUnqNo1 ?? this.rgstrUnqNo1,
      rgstrUnqNo2: rgstrUnqNo2 ?? this.rgstrUnqNo2,
      rgstrUnqNo3: rgstrUnqNo3 ?? this.rgstrUnqNo3,
      rgstrUnqNo4: rgstrUnqNo4 ?? this.rgstrUnqNo4,
      rgstrUnqNo5: rgstrUnqNo5 ?? this.rgstrUnqNo5,
      rlesDsc: rlesDsc ?? this.rlesDsc,
      trgtRlesDsc: trgtRlesDsc ?? this.trgtRlesDsc,
      trgtRlesAddr: trgtRlesAddr ?? this.trgtRlesAddr,
      sscptAskDt: sscptAskDt ?? this.sscptAskDt,
      lndPlnDt: lndPlnDt ?? this.lndPlnDt,
      lndExprdDt: lndExprdDt ?? this.lndExprdDt,
      slPrc: slPrc ?? this.slPrc,
      isrnEntrAmt: isrnEntrAmt ?? this.isrnEntrAmt,
      lndPrd: lndPrd ?? this.lndPrd,
      lndAmt: lndAmt ?? this.lndAmt,
      bnkFxcltRgstrRnk: bnkFxcltRgstrRnk ?? this.bnkFxcltRgstrRnk,
      bnkFxcltBndMaxAmt: bnkFxcltBndMaxAmt ?? this.bnkFxcltBndMaxAmt,
      dbtrNm: dbtrNm ?? this.dbtrNm,
      dbtrBirthDt: dbtrBirthDt ?? this.dbtrBirthDt,
      dbtrAddr: dbtrAddr ?? this.dbtrAddr,
      dbtrPhno: dbtrPhno ?? this.dbtrPhno,
      dbtrHpno: dbtrHpno ?? this.dbtrHpno,
      pwpsNm: pwpsNm ?? this.pwpsNm,
      pwpsBirthDt: pwpsBirthDt ?? this.pwpsBirthDt,
      pwpsAddr: pwpsAddr ?? this.pwpsAddr,
      pwpsPhno: pwpsPhno ?? this.pwpsPhno,
      pwpsHpno: pwpsHpno ?? this.pwpsHpno,
      rmkFct: rmkFct ?? this.rmkFct,
      lndHndgSlfDsc: lndHndgSlfDsc ?? this.lndHndgSlfDsc,
      bnkBrnchNm: bnkBrnchNm ?? this.bnkBrnchNm,
      bnkDrctrNm: bnkDrctrNm ?? this.bnkDrctrNm,
      bnkBrnchPhno: bnkBrnchPhno ?? this.bnkBrnchPhno,
      bnkDrctrHp: bnkDrctrHp ?? this.bnkDrctrHp,
      bnkBrnchFax: bnkBrnchFax ?? this.bnkBrnchFax,
      bnkBrnchAddr: bnkBrnchAddr ?? this.bnkBrnchAddr,
      slmnCmpyNm: slmnCmpyNm ?? this.slmnCmpyNm,
      slmnNm: slmnNm ?? this.slmnNm,
      slmnPhno: slmnPhno ?? this.slmnPhno,
      lwfmNm: lwfmNm ?? this.lwfmNm,
      lwfmBizNo: lwfmBizNo ?? this.lwfmBizNo,
      dbtrWdngPlnYn: dbtrWdngPlnYn ?? this.dbtrWdngPlnYn,
      rrcpCnfmYn: rrcpCnfmYn ?? this.rrcpCnfmYn,
      spusNm: spusNm ?? this.spusNm,
      wdngPlnDt: wdngPlnDt ?? this.wdngPlnDt,
      rschWkDdlnReqDt: rschWkDdlnReqDt ?? this.rschWkDdlnReqDt,
      isrnPrmm: isrnPrmm ?? this.isrnPrmm,
      rfrLnAprvNo: rfrLnAprvNo ?? this.rfrLnAprvNo,
      rgstrMtdDsc: rgstrMtdDsc ?? this.rgstrMtdDsc,
      rgstrReqNo: rgstrReqNo ?? this.rgstrReqNo,
      odprtRpyEane: odprtRpyEane ?? this.odprtRpyEane,
      eltnEstbsLwyrNm: eltnEstbsLwyrNm ?? this.eltnEstbsLwyrNm,
      eltnEstbsLywrBizNo: eltnEstbsLywrBizNo ?? this.eltnEstbsLywrBizNo,
      eltnRpyLoaAplYn: eltnRpyLoaAplYn ?? this.eltnRpyLoaAplYn,
      eltnRpyLoaSqn: eltnRpyLoaSqn ?? this.eltnRpyLoaSqn,
      eltnRpyLoaCtfcNo: eltnRpyLoaCtfcNo ?? this.eltnRpyLoaCtfcNo,
      whlRpyCnt: whlRpyCnt ?? this.whlRpyCnt,
      whlRpyAmt: whlRpyAmt ?? this.whlRpyAmt,
      ebnkRpyTotAmt: ebnkRpyTotAmt ?? this.ebnkRpyTotAmt,
      dfbnkRpyTotAmt: dfbnkRpyTotAmt ?? this.dfbnkRpyTotAmt,
      rpyTrgtRnkNo1: rpyTrgtRnkNo1 ?? this.rpyTrgtRnkNo1,
      rpyTrgtAcptDt1: rpyTrgtAcptDt1 ?? this.rpyTrgtAcptDt1,
      rpyTrgtAcptNo1: rpyTrgtAcptNo1 ?? this.rpyTrgtAcptNo1,
      rpyTrgtBndAmt1: rpyTrgtBndAmt1 ?? this.rpyTrgtBndAmt1,
      rpyTrgtRnkNo2: rpyTrgtRnkNo2 ?? this.rpyTrgtRnkNo2,
      rpyTrgtAcptDt2: rpyTrgtAcptDt2 ?? this.rpyTrgtAcptDt2,
      rpyTrgtAcptNo2: rpyTrgtAcptNo2 ?? this.rpyTrgtAcptNo2,
      rpyTrgtBndAmt2: rpyTrgtBndAmt2 ?? this.rpyTrgtBndAmt2,
      rpyTrgtRnkNo3: rpyTrgtRnkNo3 ?? this.rpyTrgtRnkNo3,
      rpyTrgtAcptDt3: rpyTrgtAcptDt3 ?? this.rpyTrgtAcptDt3,
      rpyTrgtAcptNo3: rpyTrgtAcptNo3 ?? this.rpyTrgtAcptNo3,
      rpyTrgtBndAmt3: rpyTrgtBndAmt3 ?? this.rpyTrgtBndAmt3,
      rpyTrgtRnkNo4: rpyTrgtRnkNo4 ?? this.rpyTrgtRnkNo4,
      rpyTrgtAcptDt4: rpyTrgtAcptDt4 ?? this.rpyTrgtAcptDt4,
      rpyTrgtAcptNo4: rpyTrgtAcptNo4 ?? this.rpyTrgtAcptNo4,
      rpyTrgtBndAmt4: rpyTrgtBndAmt4 ?? this.rpyTrgtBndAmt4,
      rpyTrgtRnkNo5: rpyTrgtRnkNo5 ?? this.rpyTrgtRnkNo5,
      rpyTrgtAcptDt5: rpyTrgtAcptDt5 ?? this.rpyTrgtAcptDt5,
      rpyTrgtAcptNo5: rpyTrgtAcptNo5 ?? this.rpyTrgtAcptNo5,
      rpyTrgtBndAmt5: rpyTrgtBndAmt5 ?? this.rpyTrgtBndAmt5,
      afrgstrScrtYn: afrgstrScrtYn ?? this.afrgstrScrtYn,
      slmnLndProc: slmnLndProc ?? this.slmnLndProc,
      srMembNo: srMembNo ?? this.srMembNo,
      trAmt: trAmt ?? this.trAmt,
      sllNm1: sllNm1 ?? this.sllNm1,
      sllBrDay1: sllBrDay1 ?? this.sllBrDay1,
      sllNm2: sllNm2 ?? this.sllNm2,
      sllBrDay2: sllBrDay2 ?? this.sllBrDay2,
      ownLoanMaxAmt: ownLoanMaxAmt ?? this.ownLoanMaxAmt,
      ownLoanPlnAmt: ownLoanPlnAmt ?? this.ownLoanPlnAmt,
      ownLoanBnkNm1: ownLoanBnkNm1 ?? this.ownLoanBnkNm1,
      ownLoanBnkNm2: ownLoanBnkNm2 ?? this.ownLoanBnkNm2,
      ownLoanBnkNm3: ownLoanBnkNm3 ?? this.ownLoanBnkNm3,
      ownLoanBnkNm4: ownLoanBnkNm4 ?? this.ownLoanBnkNm4,
      ownLoanBnkNm5: ownLoanBnkNm5 ?? this.ownLoanBnkNm5,
      cnsgnNm: cnsgnNm ?? this.cnsgnNm,
      trstNm: trstNm ?? this.trstNm,
      bnfrNm: bnfrNm ?? this.bnfrNm,
      nowLessNm: nowLessNm ?? this.nowLessNm,
      rsrvItmB: rsrvItmB ?? this.rsrvItmB,
      regDtm: regDtm ?? this.regDtm,
      oblMLnAprvNo: oblMLnAprvNo ?? this.oblMLnAprvNo,
      oblTotCnt: oblTotCnt ?? this.oblTotCnt,
      oblGrpRnkNo: oblGrpRnkNo ?? this.oblGrpRnkNo,
      lnAprvNo2: lnAprvNo2 ?? this.lnAprvNo2,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'newLoanNo': newLoanNo,
      'tgLen': tgLen,
      'tgDsc': tgDsc,
      'bnkTgNo': bnkTgNo,
      'faTgNo': faTgNo,
      'kosTgSndNo': kosTgSndNo,
      'tgSndDtm': tgSndDtm,
      'tgRcvDtm': tgRcvDtm,
      'resCd': resCd,
      'rsrvItmH': rsrvItmH,
      'bnkTtlReqNo': bnkTtlReqNo,
      'ttlArdEntrEane': ttlArdEntrEane,
      'ttlEntrcmpy': ttlEntrcmpy,
      'ttlScrtNo': ttlScrtNo,
      'lndDsc': lndDsc,
      'lndKndCd': lndKndCd,
      'fndUseCd': fndUseCd,
      'bnkLndPrdtCd': bnkLndPrdtCd,
      'bnkLndPrdtNm': bnkLndPrdtNm,
      'grntDsc': grntDsc,
      'stndAplYn': stndAplYn,
      'rrcpCnfmReqYn': rrcpCnfmReqYn,
      'mvhrCnfmReqYn': mvhrCnfmReqYn,
      'bfSrvtrgtReqYn': bfSrvtrgtReqYn,
      'afSrvtrgtReqYn': afSrvtrgtReqYn,
      'rgstrUnqNo1': rgstrUnqNo1,
      'rgstrUnqNo2': rgstrUnqNo2,
      'rgstrUnqNo3': rgstrUnqNo3,
      'rgstrUnqNo4': rgstrUnqNo4,
      'rgstrUnqNo5': rgstrUnqNo5,
      'rlesDsc': rlesDsc,
      'trgtRlesDsc': trgtRlesDsc,
      'trgtRlesAddr': trgtRlesAddr,
      'sscptAskDt': sscptAskDt,
      'lndPlnDt': lndPlnDt,
      'lndExprdDt': lndExprdDt,
      'slPrc': slPrc,
      'isrnEntrAmt': isrnEntrAmt,
      'lndPrd': lndPrd,
      'lndAmt': lndAmt,
      'bnkFxcltRgstrRnk': bnkFxcltRgstrRnk,
      'bnkFxcltBndMaxAmt': bnkFxcltBndMaxAmt,
      'dbtrNm': dbtrNm,
      'dbtrBirthDt': dbtrBirthDt,
      'dbtrAddr': dbtrAddr,
      'dbtrPhno': dbtrPhno,
      'dbtrHpno': dbtrHpno,
      'pwpsNm': pwpsNm,
      'pwpsBirthDt': pwpsBirthDt,
      'pwpsAddr': pwpsAddr,
      'pwpsPhno': pwpsPhno,
      'pwpsHpno': pwpsHpno,
      'rmkFct': rmkFct,
      'lndHndgSlfDsc': lndHndgSlfDsc,
      'bnkBrnchNm': bnkBrnchNm,
      'bnkDrctrNm': bnkDrctrNm,
      'bnkBrnchPhno': bnkBrnchPhno,
      'bnkDrctrHp': bnkDrctrHp,
      'bnkBrnchFax': bnkBrnchFax,
      'bnkBrnchAddr': bnkBrnchAddr,
      'slmnCmpyNm': slmnCmpyNm,
      'slmnNm': slmnNm,
      'slmnPhno': slmnPhno,
      'lwfmNm': lwfmNm,
      'lwfmBizNo': lwfmBizNo,
      'dbtrWdngPlnYn': dbtrWdngPlnYn,
      'rrcpCnfmYn': rrcpCnfmYn,
      'spusNm': spusNm,
      'wdngPlnDt': wdngPlnDt,
      'rschWkDdlnReqDt': rschWkDdlnReqDt,
      'isrnPrmm': isrnPrmm,
      'rfrLnAprvNo': rfrLnAprvNo,
      'rgstrMtdDsc': rgstrMtdDsc,
      'rgstrReqNo': rgstrReqNo,
      'odprtRpyEane': odprtRpyEane,
      'eltnEstbsLwyrNm': eltnEstbsLwyrNm,
      'eltnEstbsLywrBizNo': eltnEstbsLywrBizNo,
      'eltnRpyLoaAplYn': eltnRpyLoaAplYn,
      'eltnRpyLoaSqn': eltnRpyLoaSqn,
      'eltnRpyLoaCtfcNo': eltnRpyLoaCtfcNo,
      'whlRpyCnt': whlRpyCnt,
      'whlRpyAmt': whlRpyAmt,
      'ebnkRpyTotAmt': ebnkRpyTotAmt,
      'dfbnkRpyTotAmt': dfbnkRpyTotAmt,
      'rpyTrgtRnkNo1': rpyTrgtRnkNo1,
      'rpyTrgtAcptDt1': rpyTrgtAcptDt1,
      'rpyTrgtAcptNo1': rpyTrgtAcptNo1,
      'rpyTrgtBndAmt1': rpyTrgtBndAmt1,
      'rpyTrgtRnkNo2': rpyTrgtRnkNo2,
      'rpyTrgtAcptDt2': rpyTrgtAcptDt2,
      'rpyTrgtAcptNo2': rpyTrgtAcptNo2,
      'rpyTrgtBndAmt2': rpyTrgtBndAmt2,
      'rpyTrgtRnkNo3': rpyTrgtRnkNo3,
      'rpyTrgtAcptDt3': rpyTrgtAcptDt3,
      'rpyTrgtAcptNo3': rpyTrgtAcptNo3,
      'rpyTrgtBndAmt3': rpyTrgtBndAmt3,
      'rpyTrgtRnkNo4': rpyTrgtRnkNo4,
      'rpyTrgtAcptDt4': rpyTrgtAcptDt4,
      'rpyTrgtAcptNo4': rpyTrgtAcptNo4,
      'rpyTrgtBndAmt4': rpyTrgtBndAmt4,
      'rpyTrgtRnkNo5': rpyTrgtRnkNo5,
      'rpyTrgtAcptDt5': rpyTrgtAcptDt5,
      'rpyTrgtAcptNo5': rpyTrgtAcptNo5,
      'rpyTrgtBndAmt5': rpyTrgtBndAmt5,
      'afrgstrScrtYn': afrgstrScrtYn,
      'slmnLndProc': slmnLndProc,
      'srMembNo': srMembNo,
      'trAmt': trAmt,
      'sllNm1': sllNm1,
      'sllBrDay1': sllBrDay1,
      'sllNm2': sllNm2,
      'sllBrDay2': sllBrDay2,
      'ownLoanMaxAmt': ownLoanMaxAmt,
      'ownLoanPlnAmt': ownLoanPlnAmt,
      'ownLoanBnkNm1': ownLoanBnkNm1,
      'ownLoanBnkNm2': ownLoanBnkNm2,
      'ownLoanBnkNm3': ownLoanBnkNm3,
      'ownLoanBnkNm4': ownLoanBnkNm4,
      'ownLoanBnkNm5': ownLoanBnkNm5,
      'cnsgnNm': cnsgnNm,
      'trstNm': trstNm,
      'bnfrNm': bnfrNm,
      'nowLessNm': nowLessNm,
      'rsrvItmB': rsrvItmB,
      'regDtm': regDtm,
      'oblMLnAprvNo': oblMLnAprvNo,
      'oblTotCnt': oblTotCnt,
      'oblGrpRnkNo': oblGrpRnkNo,
      'lnAprvNo2': lnAprvNo2,
    };
  }

  factory Trns6100DetailResData.fromMap(Map<String, dynamic> map) {
    return Trns6100DetailResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      newLoanNo: map['newLoanNo'] != null ? map['newLoanNo'] as String : null,
      tgLen: map['tgLen'] != null ? map['tgLen'] as int : null,
      tgDsc: map['tgDsc'] != null ? map['tgDsc'] as String : null,
      bnkTgNo: map['bnkTgNo'] != null ? map['bnkTgNo'] as String : null,
      faTgNo: map['faTgNo'] != null ? map['faTgNo'] as String : null,
      kosTgSndNo:
          map['kosTgSndNo'] != null ? map['kosTgSndNo'] as String : null,
      tgSndDtm: map['tgSndDtm'] != null ? map['tgSndDtm'] as String : null,
      tgRcvDtm: map['tgRcvDtm'] != null ? map['tgRcvDtm'] as String : null,
      resCd: map['resCd'] != null ? map['resCd'] as String : null,
      rsrvItmH: map['rsrvItmH'] != null ? map['rsrvItmH'] as String : null,
      bnkTtlReqNo:
          map['bnkTtlReqNo'] != null ? map['bnkTtlReqNo'] as String : null,
      ttlArdEntrEane: map['ttlArdEntrEane'] != null
          ? map['ttlArdEntrEane'] as String
          : null,
      ttlEntrcmpy:
          map['ttlEntrcmpy'] != null ? map['ttlEntrcmpy'] as String : null,
      ttlScrtNo: map['ttlScrtNo'] != null ? map['ttlScrtNo'] as String : null,
      lndDsc: map['lndDsc'] != null ? map['lndDsc'] as String : null,
      lndKndCd: map['lndKndCd'] != null ? map['lndKndCd'] as String : null,
      fndUseCd: map['fndUseCd'] != null ? map['fndUseCd'] as String : null,
      bnkLndPrdtCd:
          map['bnkLndPrdtCd'] != null ? map['bnkLndPrdtCd'] as String : null,
      bnkLndPrdtNm:
          map['bnkLndPrdtNm'] != null ? map['bnkLndPrdtNm'] as String : null,
      grntDsc: map['grntDsc'] != null ? map['grntDsc'] as String : null,
      stndAplYn: map['stndAplYn'] != null ? map['stndAplYn'] as String : null,
      rrcpCnfmReqYn:
          map['rrcpCnfmReqYn'] != null ? map['rrcpCnfmReqYn'] as String : null,
      mvhrCnfmReqYn:
          map['mvhrCnfmReqYn'] != null ? map['mvhrCnfmReqYn'] as String : null,
      bfSrvtrgtReqYn: map['bfSrvtrgtReqYn'] != null
          ? map['bfSrvtrgtReqYn'] as String
          : null,
      afSrvtrgtReqYn: map['afSrvtrgtReqYn'] != null
          ? map['afSrvtrgtReqYn'] as String
          : null,
      rgstrUnqNo1:
          map['rgstrUnqNo1'] != null ? map['rgstrUnqNo1'] as String : null,
      rgstrUnqNo2:
          map['rgstrUnqNo2'] != null ? map['rgstrUnqNo2'] as String : null,
      rgstrUnqNo3:
          map['rgstrUnqNo3'] != null ? map['rgstrUnqNo3'] as String : null,
      rgstrUnqNo4:
          map['rgstrUnqNo4'] != null ? map['rgstrUnqNo4'] as String : null,
      rgstrUnqNo5:
          map['rgstrUnqNo5'] != null ? map['rgstrUnqNo5'] as String : null,
      rlesDsc: map['rlesDsc'] != null ? map['rlesDsc'] as String : null,
      trgtRlesDsc:
          map['trgtRlesDsc'] != null ? map['trgtRlesDsc'] as String : null,
      trgtRlesAddr:
          map['trgtRlesAddr'] != null ? map['trgtRlesAddr'] as String : null,
      sscptAskDt:
          map['sscptAskDt'] != null ? map['sscptAskDt'] as String : null,
      lndPlnDt: map['lndPlnDt'] != null ? map['lndPlnDt'] as String : null,
      lndExprdDt:
          map['lndExprdDt'] != null ? map['lndExprdDt'] as String : null,
      slPrc: map['slPrc'] != null ? map['slPrc'] as int : null,
      isrnEntrAmt:
          map['isrnEntrAmt'] != null ? map['isrnEntrAmt'] as int : null,
      lndPrd: map['lndPrd'] != null ? map['lndPrd'] as int : null,
      lndAmt: map['lndAmt'] != null ? map['lndAmt'] as int : null,
      bnkFxcltRgstrRnk: map['bnkFxcltRgstrRnk'] != null
          ? map['bnkFxcltRgstrRnk'] as int
          : null,
      bnkFxcltBndMaxAmt: map['bnkFxcltBndMaxAmt'] != null
          ? map['bnkFxcltBndMaxAmt'] as int
          : null,
      dbtrNm: map['dbtrNm'] != null ? map['dbtrNm'] as String : null,
      dbtrBirthDt:
          map['dbtrBirthDt'] != null ? map['dbtrBirthDt'] as String : null,
      dbtrAddr: map['dbtrAddr'] != null ? map['dbtrAddr'] as String : null,
      dbtrPhno: map['dbtrPhno'] != null ? map['dbtrPhno'] as String : null,
      dbtrHpno: map['dbtrHpno'] != null ? map['dbtrHpno'] as String : null,
      pwpsNm: map['pwpsNm'] != null ? map['pwpsNm'] as String : null,
      pwpsBirthDt:
          map['pwpsBirthDt'] != null ? map['pwpsBirthDt'] as String : null,
      pwpsAddr: map['pwpsAddr'] != null ? map['pwpsAddr'] as String : null,
      pwpsPhno: map['pwpsPhno'] != null ? map['pwpsPhno'] as String : null,
      pwpsHpno: map['pwpsHpno'] != null ? map['pwpsHpno'] as String : null,
      rmkFct: map['rmkFct'] != null ? map['rmkFct'] as String : null,
      lndHndgSlfDsc:
          map['lndHndgSlfDsc'] != null ? map['lndHndgSlfDsc'] as String : null,
      bnkBrnchNm:
          map['bnkBrnchNm'] != null ? map['bnkBrnchNm'] as String : null,
      bnkDrctrNm:
          map['bnkDrctrNm'] != null ? map['bnkDrctrNm'] as String : null,
      bnkBrnchPhno:
          map['bnkBrnchPhno'] != null ? map['bnkBrnchPhno'] as String : null,
      bnkDrctrHp:
          map['bnkDrctrHp'] != null ? map['bnkDrctrHp'] as String : null,
      bnkBrnchFax:
          map['bnkBrnchFax'] != null ? map['bnkBrnchFax'] as String : null,
      bnkBrnchAddr:
          map['bnkBrnchAddr'] != null ? map['bnkBrnchAddr'] as String : null,
      slmnCmpyNm:
          map['slmnCmpyNm'] != null ? map['slmnCmpyNm'] as String : null,
      slmnNm: map['slmnNm'] != null ? map['slmnNm'] as String : null,
      slmnPhno: map['slmnPhno'] != null ? map['slmnPhno'] as String : null,
      lwfmNm: map['lwfmNm'] != null ? map['lwfmNm'] as String : null,
      lwfmBizNo: map['lwfmBizNo'] != null ? map['lwfmBizNo'] as String : null,
      dbtrWdngPlnYn:
          map['dbtrWdngPlnYn'] != null ? map['dbtrWdngPlnYn'] as String : null,
      rrcpCnfmYn:
          map['rrcpCnfmYn'] != null ? map['rrcpCnfmYn'] as String : null,
      spusNm: map['spusNm'] != null ? map['spusNm'] as String : null,
      wdngPlnDt: map['wdngPlnDt'] != null ? map['wdngPlnDt'] as String : null,
      rschWkDdlnReqDt: map['rschWkDdlnReqDt'] != null
          ? map['rschWkDdlnReqDt'] as String
          : null,
      isrnPrmm: map['isrnPrmm'] != null ? map['isrnPrmm'] as int : null,
      rfrLnAprvNo:
          map['rfrLnAprvNo'] != null ? map['rfrLnAprvNo'] as String : null,
      rgstrMtdDsc:
          map['rgstrMtdDsc'] != null ? map['rgstrMtdDsc'] as String : null,
      rgstrReqNo:
          map['rgstrReqNo'] != null ? map['rgstrReqNo'] as String : null,
      odprtRpyEane:
          map['odprtRpyEane'] != null ? map['odprtRpyEane'] as String : null,
      eltnEstbsLwyrNm: map['eltnEstbsLwyrNm'] != null
          ? map['eltnEstbsLwyrNm'] as String
          : null,
      eltnEstbsLywrBizNo: map['eltnEstbsLywrBizNo'] != null
          ? map['eltnEstbsLywrBizNo'] as String
          : null,
      eltnRpyLoaAplYn: map['eltnRpyLoaAplYn'] != null
          ? map['eltnRpyLoaAplYn'] as String
          : null,
      eltnRpyLoaSqn:
          map['eltnRpyLoaSqn'] != null ? map['eltnRpyLoaSqn'] as String : null,
      eltnRpyLoaCtfcNo: map['eltnRpyLoaCtfcNo'] != null
          ? map['eltnRpyLoaCtfcNo'] as String
          : null,
      whlRpyCnt: map['whlRpyCnt'] != null ? map['whlRpyCnt'] as int : null,
      whlRpyAmt: map['whlRpyAmt'] != null ? map['whlRpyAmt'] as int : null,
      ebnkRpyTotAmt:
          map['ebnkRpyTotAmt'] != null ? map['ebnkRpyTotAmt'] as int : null,
      dfbnkRpyTotAmt:
          map['dfbnkRpyTotAmt'] != null ? map['dfbnkRpyTotAmt'] as int : null,
      rpyTrgtRnkNo1:
          map['rpyTrgtRnkNo1'] != null ? map['rpyTrgtRnkNo1'] as String : null,
      rpyTrgtAcptDt1: map['rpyTrgtAcptDt1'] != null
          ? map['rpyTrgtAcptDt1'] as String
          : null,
      rpyTrgtAcptNo1: map['rpyTrgtAcptNo1'] != null
          ? map['rpyTrgtAcptNo1'] as String
          : null,
      rpyTrgtBndAmt1:
          map['rpyTrgtBndAmt1'] != null ? map['rpyTrgtBndAmt1'] as int : null,
      rpyTrgtRnkNo2:
          map['rpyTrgtRnkNo2'] != null ? map['rpyTrgtRnkNo2'] as String : null,
      rpyTrgtAcptDt2: map['rpyTrgtAcptDt2'] != null
          ? map['rpyTrgtAcptDt2'] as String
          : null,
      rpyTrgtAcptNo2: map['rpyTrgtAcptNo2'] != null
          ? map['rpyTrgtAcptNo2'] as String
          : null,
      rpyTrgtBndAmt2:
          map['rpyTrgtBndAmt2'] != null ? map['rpyTrgtBndAmt2'] as int : null,
      rpyTrgtRnkNo3:
          map['rpyTrgtRnkNo3'] != null ? map['rpyTrgtRnkNo3'] as String : null,
      rpyTrgtAcptDt3: map['rpyTrgtAcptDt3'] != null
          ? map['rpyTrgtAcptDt3'] as String
          : null,
      rpyTrgtAcptNo3: map['rpyTrgtAcptNo3'] != null
          ? map['rpyTrgtAcptNo3'] as String
          : null,
      rpyTrgtBndAmt3:
          map['rpyTrgtBndAmt3'] != null ? map['rpyTrgtBndAmt3'] as int : null,
      rpyTrgtRnkNo4:
          map['rpyTrgtRnkNo4'] != null ? map['rpyTrgtRnkNo4'] as String : null,
      rpyTrgtAcptDt4: map['rpyTrgtAcptDt4'] != null
          ? map['rpyTrgtAcptDt4'] as String
          : null,
      rpyTrgtAcptNo4: map['rpyTrgtAcptNo4'] != null
          ? map['rpyTrgtAcptNo4'] as String
          : null,
      rpyTrgtBndAmt4:
          map['rpyTrgtBndAmt4'] != null ? map['rpyTrgtBndAmt4'] as int : null,
      rpyTrgtRnkNo5:
          map['rpyTrgtRnkNo5'] != null ? map['rpyTrgtRnkNo5'] as String : null,
      rpyTrgtAcptDt5: map['rpyTrgtAcptDt5'] != null
          ? map['rpyTrgtAcptDt5'] as String
          : null,
      rpyTrgtAcptNo5: map['rpyTrgtAcptNo5'] != null
          ? map['rpyTrgtAcptNo5'] as String
          : null,
      rpyTrgtBndAmt5:
          map['rpyTrgtBndAmt5'] != null ? map['rpyTrgtBndAmt5'] as int : null,
      afrgstrScrtYn:
          map['afrgstrScrtYn'] != null ? map['afrgstrScrtYn'] as String : null,
      slmnLndProc:
          map['slmnLndProc'] != null ? map['slmnLndProc'] as String : null,
      srMembNo: map['srMembNo'] != null ? map['srMembNo'] as String : null,
      trAmt: map['trAmt'] != null ? map['trAmt'] as int : null,
      sllNm1: map['sllNm1'] != null ? map['sllNm1'] as String : null,
      sllBrDay1: map['sllBrDay1'] != null ? map['sllBrDay1'] as String : null,
      sllNm2: map['sllNm2'] != null ? map['sllNm2'] as String : null,
      sllBrDay2: map['sllBrDay2'] != null ? map['sllBrDay2'] as String : null,
      ownLoanMaxAmt:
          map['ownLoanMaxAmt'] != null ? map['ownLoanMaxAmt'] as int : null,
      ownLoanPlnAmt:
          map['ownLoanPlnAmt'] != null ? map['ownLoanPlnAmt'] as int : null,
      ownLoanBnkNm1:
          map['ownLoanBnkNm1'] != null ? map['ownLoanBnkNm1'] as String : null,
      ownLoanBnkNm2:
          map['ownLoanBnkNm2'] != null ? map['ownLoanBnkNm2'] as String : null,
      ownLoanBnkNm3:
          map['ownLoanBnkNm3'] != null ? map['ownLoanBnkNm3'] as String : null,
      ownLoanBnkNm4:
          map['ownLoanBnkNm4'] != null ? map['ownLoanBnkNm4'] as String : null,
      ownLoanBnkNm5:
          map['ownLoanBnkNm5'] != null ? map['ownLoanBnkNm5'] as String : null,
      cnsgnNm: map['cnsgnNm'] != null ? map['cnsgnNm'] as String : null,
      trstNm: map['trstNm'] != null ? map['trstNm'] as String : null,
      bnfrNm: map['bnfrNm'] != null ? map['bnfrNm'] as String : null,
      nowLessNm: map['nowLessNm'] != null ? map['nowLessNm'] as String : null,
      rsrvItmB: map['rsrvItmB'] != null ? map['rsrvItmB'] as String : null,
      regDtm: map['regDtm'] != null ? map['regDtm'] as String : null,
      oblMLnAprvNo:
          map['oblMLnAprvNo'] != null ? map['oblMLnAprvNo'] as String : null,
      oblTotCnt: map['oblTotCnt'] != null ? map['oblTotCnt'] as int : null,
      oblGrpRnkNo:
          map['oblGrpRnkNo'] != null ? map['oblGrpRnkNo'] as int : null,
      lnAprvNo2: map['lnAprvNo2'] != null ? map['lnAprvNo2'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory Trns6100DetailResData.fromJson(String source) =>
      Trns6100DetailResData.fromMap(
          json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'Trns6100DetailResData(loanNo: $loanNo, newLoanNo: $newLoanNo, tgLen: $tgLen, tgDsc: $tgDsc, bnkTgNo: $bnkTgNo, faTgNo: $faTgNo, kosTgSndNo: $kosTgSndNo, tgSndDtm: $tgSndDtm, tgRcvDtm: $tgRcvDtm, resCd: $resCd, rsrvItmH: $rsrvItmH, bnkTtlReqNo: $bnkTtlReqNo, ttlArdEntrEane: $ttlArdEntrEane, ttlEntrcmpy: $ttlEntrcmpy, ttlScrtNo: $ttlScrtNo, lndDsc: $lndDsc, lndKndCd: $lndKndCd, fndUseCd: $fndUseCd, bnkLndPrdtCd: $bnkLndPrdtCd, bnkLndPrdtNm: $bnkLndPrdtNm, grntDsc: $grntDsc, stndAplYn: $stndAplYn, rrcpCnfmReqYn: $rrcpCnfmReqYn, mvhrCnfmReqYn: $mvhrCnfmReqYn, bfSrvtrgtReqYn: $bfSrvtrgtReqYn, afSrvtrgtReqYn: $afSrvtrgtReqYn, rgstrUnqNo1: $rgstrUnqNo1, rgstrUnqNo2: $rgstrUnqNo2, rgstrUnqNo3: $rgstrUnqNo3, rgstrUnqNo4: $rgstrUnqNo4, rgstrUnqNo5: $rgstrUnqNo5, rlesDsc: $rlesDsc, trgtRlesDsc: $trgtRlesDsc, trgtRlesAddr: $trgtRlesAddr, sscptAskDt: $sscptAskDt, lndPlnDt: $lndPlnDt, lndExprdDt: $lndExprdDt, slPrc: $slPrc, isrnEntrAmt: $isrnEntrAmt, lndPrd: $lndPrd, lndAmt: $lndAmt, bnkFxcltRgstrRnk: $bnkFxcltRgstrRnk, bnkFxcltBndMaxAmt: $bnkFxcltBndMaxAmt, dbtrNm: $dbtrNm, dbtrBirthDt: $dbtrBirthDt, dbtrAddr: $dbtrAddr, dbtrPhno: $dbtrPhno, dbtrHpno: $dbtrHpno, pwpsNm: $pwpsNm, pwpsBirthDt: $pwpsBirthDt, pwpsAddr: $pwpsAddr, pwpsPhno: $pwpsPhno, pwpsHpno: $pwpsHpno, rmkFct: $rmkFct, lndHndgSlfDsc: $lndHndgSlfDsc, bnkBrnchNm: $bnkBrnchNm, bnkDrctrNm: $bnkDrctrNm, bnkBrnchPhno: $bnkBrnchPhno, bnkDrctrHp: $bnkDrctrHp, bnkBrnchFax: $bnkBrnchFax, bnkBrnchAddr: $bnkBrnchAddr, slmnCmpyNm: $slmnCmpyNm, slmnNm: $slmnNm, slmnPhno: $slmnPhno, lwfmNm: $lwfmNm, lwfmBizNo: $lwfmBizNo, dbtrWdngPlnYn: $dbtrWdngPlnYn, rrcpCnfmYn: $rrcpCnfmYn, spusNm: $spusNm, wdngPlnDt: $wdngPlnDt, rschWkDdlnReqDt: $rschWkDdlnReqDt, isrnPrmm: $isrnPrmm, rfrLnAprvNo: $rfrLnAprvNo, rgstrMtdDsc: $rgstrMtdDsc, rgstrReqNo: $rgstrReqNo, odprtRpyEane: $odprtRpyEane, eltnEstbsLwyrNm: $eltnEstbsLwyrNm, eltnEstbsLywrBizNo: $eltnEstbsLywrBizNo, eltnRpyLoaAplYn: $eltnRpyLoaAplYn, eltnRpyLoaSqn: $eltnRpyLoaSqn, eltnRpyLoaCtfcNo: $eltnRpyLoaCtfcNo, whlRpyCnt: $whlRpyCnt, whlRpyAmt: $whlRpyAmt, ebnkRpyTotAmt: $ebnkRpyTotAmt, dfbnkRpyTotAmt: $dfbnkRpyTotAmt, rpyTrgtRnkNo1: $rpyTrgtRnkNo1, rpyTrgtAcptDt1: $rpyTrgtAcptDt1, rpyTrgtAcptNo1: $rpyTrgtAcptNo1, rpyTrgtBndAmt1: $rpyTrgtBndAmt1, rpyTrgtRnkNo2: $rpyTrgtRnkNo2, rpyTrgtAcptDt2: $rpyTrgtAcptDt2, rpyTrgtAcptNo2: $rpyTrgtAcptNo2, rpyTrgtBndAmt2: $rpyTrgtBndAmt2, rpyTrgtRnkNo3: $rpyTrgtRnkNo3, rpyTrgtAcptDt3: $rpyTrgtAcptDt3, rpyTrgtAcptNo3: $rpyTrgtAcptNo3, rpyTrgtBndAmt3: $rpyTrgtBndAmt3, rpyTrgtRnkNo4: $rpyTrgtRnkNo4, rpyTrgtAcptDt4: $rpyTrgtAcptDt4, rpyTrgtAcptNo4: $rpyTrgtAcptNo4, rpyTrgtBndAmt4: $rpyTrgtBndAmt4, rpyTrgtRnkNo5: $rpyTrgtRnkNo5, rpyTrgtAcptDt5: $rpyTrgtAcptDt5, rpyTrgtAcptNo5: $rpyTrgtAcptNo5, rpyTrgtBndAmt5: $rpyTrgtBndAmt5, afrgstrScrtYn: $afrgstrScrtYn,slmnLndProc: $slmnLndProc,srMembNo: $srMembNo,trAmt: $trAmt,sllNm1: $sllNm1,sllBrDay1: $sllBrDay1,sllNm2: $sllNm2,sllBrDay2: $sllBrDay2,ownLoanMaxAmt: $ownLoanMaxAmt,ownLoanPlnAmt: $ownLoanPlnAmt,ownLoanBnkNm1: $ownLoanBnkNm1,ownLoanBnkNm2: $ownLoanBnkNm2,ownLoanBnkNm3: $ownLoanBnkNm3,ownLoanBnkNm4: $ownLoanBnkNm4,ownLoanBnkNm5: $ownLoanBnkNm5,cnsgnNm: $cnsgnNm,trstNm: $trstNm,bnfrNm: $bnfrNm,nowLessNm: $nowLessNm, rsrvItmB: $rsrvItmB, regDtm: $regDtm, oblMLnAprvNo: $oblMLnAprvNo, oblTotCnt: $oblTotCnt, oblGrpRnkNo: $oblGrpRnkNo, lnAprvNo2: $lnAprvNo2)';
  }

  @override
  bool operator ==(covariant Trns6100DetailResData other) {
    if (identical(this, other)) return true;

    return other.loanNo == loanNo &&
        other.newLoanNo == newLoanNo &&
        other.tgLen == tgLen &&
        other.tgDsc == tgDsc &&
        other.bnkTgNo == bnkTgNo &&
        other.faTgNo == faTgNo &&
        other.kosTgSndNo == kosTgSndNo &&
        other.tgSndDtm == tgSndDtm &&
        other.tgRcvDtm == tgRcvDtm &&
        other.resCd == resCd &&
        other.rsrvItmH == rsrvItmH &&
        other.bnkTtlReqNo == bnkTtlReqNo &&
        other.ttlArdEntrEane == ttlArdEntrEane &&
        other.ttlEntrcmpy == ttlEntrcmpy &&
        other.ttlScrtNo == ttlScrtNo &&
        other.lndDsc == lndDsc &&
        other.lndKndCd == lndKndCd &&
        other.fndUseCd == fndUseCd &&
        other.bnkLndPrdtCd == bnkLndPrdtCd &&
        other.bnkLndPrdtNm == bnkLndPrdtNm &&
        other.grntDsc == grntDsc &&
        other.stndAplYn == stndAplYn &&
        other.rrcpCnfmReqYn == rrcpCnfmReqYn &&
        other.mvhrCnfmReqYn == mvhrCnfmReqYn &&
        other.bfSrvtrgtReqYn == bfSrvtrgtReqYn &&
        other.afSrvtrgtReqYn == afSrvtrgtReqYn &&
        other.rgstrUnqNo1 == rgstrUnqNo1 &&
        other.rgstrUnqNo2 == rgstrUnqNo2 &&
        other.rgstrUnqNo3 == rgstrUnqNo3 &&
        other.rgstrUnqNo4 == rgstrUnqNo4 &&
        other.rgstrUnqNo5 == rgstrUnqNo5 &&
        other.rlesDsc == rlesDsc &&
        other.trgtRlesDsc == trgtRlesDsc &&
        other.trgtRlesAddr == trgtRlesAddr &&
        other.sscptAskDt == sscptAskDt &&
        other.lndPlnDt == lndPlnDt &&
        other.lndExprdDt == lndExprdDt &&
        other.slPrc == slPrc &&
        other.isrnEntrAmt == isrnEntrAmt &&
        other.lndPrd == lndPrd &&
        other.lndAmt == lndAmt &&
        other.bnkFxcltRgstrRnk == bnkFxcltRgstrRnk &&
        other.bnkFxcltBndMaxAmt == bnkFxcltBndMaxAmt &&
        other.dbtrNm == dbtrNm &&
        other.dbtrBirthDt == dbtrBirthDt &&
        other.dbtrAddr == dbtrAddr &&
        other.dbtrPhno == dbtrPhno &&
        other.dbtrHpno == dbtrHpno &&
        other.pwpsNm == pwpsNm &&
        other.pwpsBirthDt == pwpsBirthDt &&
        other.pwpsAddr == pwpsAddr &&
        other.pwpsPhno == pwpsPhno &&
        other.pwpsHpno == pwpsHpno &&
        other.rmkFct == rmkFct &&
        other.lndHndgSlfDsc == lndHndgSlfDsc &&
        other.bnkBrnchNm == bnkBrnchNm &&
        other.bnkDrctrNm == bnkDrctrNm &&
        other.bnkBrnchPhno == bnkBrnchPhno &&
        other.bnkDrctrHp == bnkDrctrHp &&
        other.bnkBrnchFax == bnkBrnchFax &&
        other.bnkBrnchAddr == bnkBrnchAddr &&
        other.slmnCmpyNm == slmnCmpyNm &&
        other.slmnNm == slmnNm &&
        other.slmnPhno == slmnPhno &&
        other.lwfmNm == lwfmNm &&
        other.lwfmBizNo == lwfmBizNo &&
        other.dbtrWdngPlnYn == dbtrWdngPlnYn &&
        other.rrcpCnfmYn == rrcpCnfmYn &&
        other.spusNm == spusNm &&
        other.wdngPlnDt == wdngPlnDt &&
        other.rschWkDdlnReqDt == rschWkDdlnReqDt &&
        other.isrnPrmm == isrnPrmm &&
        other.rfrLnAprvNo == rfrLnAprvNo &&
        other.rgstrMtdDsc == rgstrMtdDsc &&
        other.rgstrReqNo == rgstrReqNo &&
        other.odprtRpyEane == odprtRpyEane &&
        other.eltnEstbsLwyrNm == eltnEstbsLwyrNm &&
        other.eltnEstbsLywrBizNo == eltnEstbsLywrBizNo &&
        other.eltnRpyLoaAplYn == eltnRpyLoaAplYn &&
        other.eltnRpyLoaSqn == eltnRpyLoaSqn &&
        other.eltnRpyLoaCtfcNo == eltnRpyLoaCtfcNo &&
        other.whlRpyCnt == whlRpyCnt &&
        other.whlRpyAmt == whlRpyAmt &&
        other.ebnkRpyTotAmt == ebnkRpyTotAmt &&
        other.dfbnkRpyTotAmt == dfbnkRpyTotAmt &&
        other.rpyTrgtRnkNo1 == rpyTrgtRnkNo1 &&
        other.rpyTrgtAcptDt1 == rpyTrgtAcptDt1 &&
        other.rpyTrgtAcptNo1 == rpyTrgtAcptNo1 &&
        other.rpyTrgtBndAmt1 == rpyTrgtBndAmt1 &&
        other.rpyTrgtRnkNo2 == rpyTrgtRnkNo2 &&
        other.rpyTrgtAcptDt2 == rpyTrgtAcptDt2 &&
        other.rpyTrgtAcptNo2 == rpyTrgtAcptNo2 &&
        other.rpyTrgtBndAmt2 == rpyTrgtBndAmt2 &&
        other.rpyTrgtRnkNo3 == rpyTrgtRnkNo3 &&
        other.rpyTrgtAcptDt3 == rpyTrgtAcptDt3 &&
        other.rpyTrgtAcptNo3 == rpyTrgtAcptNo3 &&
        other.rpyTrgtBndAmt3 == rpyTrgtBndAmt3 &&
        other.rpyTrgtRnkNo4 == rpyTrgtRnkNo4 &&
        other.rpyTrgtAcptDt4 == rpyTrgtAcptDt4 &&
        other.rpyTrgtAcptNo4 == rpyTrgtAcptNo4 &&
        other.rpyTrgtBndAmt4 == rpyTrgtBndAmt4 &&
        other.rpyTrgtRnkNo5 == rpyTrgtRnkNo5 &&
        other.rpyTrgtAcptDt5 == rpyTrgtAcptDt5 &&
        other.rpyTrgtAcptNo5 == rpyTrgtAcptNo5 &&
        other.rpyTrgtBndAmt5 == rpyTrgtBndAmt5 &&
        other.afrgstrScrtYn == afrgstrScrtYn &&
        other.slmnLndProc == slmnLndProc &&
        other.srMembNo == srMembNo &&
        other.trAmt == trAmt &&
        other.sllNm1 == sllNm1 &&
        other.sllBrDay1 == sllBrDay1 &&
        other.sllNm2 == sllNm2 &&
        other.sllBrDay2 == sllBrDay2 &&
        other.ownLoanMaxAmt == ownLoanMaxAmt &&
        other.ownLoanPlnAmt == ownLoanPlnAmt &&
        other.ownLoanBnkNm1 == ownLoanBnkNm1 &&
        other.ownLoanBnkNm2 == ownLoanBnkNm2 &&
        other.ownLoanBnkNm3 == ownLoanBnkNm3 &&
        other.ownLoanBnkNm4 == ownLoanBnkNm4 &&
        other.ownLoanBnkNm5 == ownLoanBnkNm5 &&
        other.cnsgnNm == cnsgnNm &&
        other.trstNm == trstNm &&
        other.bnfrNm == bnfrNm &&
        other.nowLessNm == nowLessNm &&
        other.rsrvItmB == rsrvItmB &&
        other.regDtm == regDtm &&
        other.oblMLnAprvNo == oblMLnAprvNo &&
        other.oblTotCnt == oblTotCnt &&
        other.oblGrpRnkNo == oblGrpRnkNo &&
        other.lnAprvNo2 == lnAprvNo2;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
        newLoanNo.hashCode ^
        tgLen.hashCode ^
        tgDsc.hashCode ^
        bnkTgNo.hashCode ^
        faTgNo.hashCode ^
        kosTgSndNo.hashCode ^
        tgSndDtm.hashCode ^
        tgRcvDtm.hashCode ^
        resCd.hashCode ^
        rsrvItmH.hashCode ^
        bnkTtlReqNo.hashCode ^
        ttlArdEntrEane.hashCode ^
        ttlEntrcmpy.hashCode ^
        ttlScrtNo.hashCode ^
        lndDsc.hashCode ^
        lndKndCd.hashCode ^
        fndUseCd.hashCode ^
        bnkLndPrdtCd.hashCode ^
        bnkLndPrdtNm.hashCode ^
        grntDsc.hashCode ^
        stndAplYn.hashCode ^
        rrcpCnfmReqYn.hashCode ^
        mvhrCnfmReqYn.hashCode ^
        bfSrvtrgtReqYn.hashCode ^
        afSrvtrgtReqYn.hashCode ^
        rgstrUnqNo1.hashCode ^
        rgstrUnqNo2.hashCode ^
        rgstrUnqNo3.hashCode ^
        rgstrUnqNo4.hashCode ^
        rgstrUnqNo5.hashCode ^
        rlesDsc.hashCode ^
        trgtRlesDsc.hashCode ^
        trgtRlesAddr.hashCode ^
        sscptAskDt.hashCode ^
        lndPlnDt.hashCode ^
        lndExprdDt.hashCode ^
        slPrc.hashCode ^
        isrnEntrAmt.hashCode ^
        lndPrd.hashCode ^
        lndAmt.hashCode ^
        bnkFxcltRgstrRnk.hashCode ^
        bnkFxcltBndMaxAmt.hashCode ^
        dbtrNm.hashCode ^
        dbtrBirthDt.hashCode ^
        dbtrAddr.hashCode ^
        dbtrPhno.hashCode ^
        dbtrHpno.hashCode ^
        pwpsNm.hashCode ^
        pwpsBirthDt.hashCode ^
        pwpsAddr.hashCode ^
        pwpsPhno.hashCode ^
        pwpsHpno.hashCode ^
        rmkFct.hashCode ^
        lndHndgSlfDsc.hashCode ^
        bnkBrnchNm.hashCode ^
        bnkDrctrNm.hashCode ^
        bnkBrnchPhno.hashCode ^
        bnkDrctrHp.hashCode ^
        bnkBrnchFax.hashCode ^
        bnkBrnchAddr.hashCode ^
        slmnCmpyNm.hashCode ^
        slmnNm.hashCode ^
        slmnPhno.hashCode ^
        lwfmNm.hashCode ^
        lwfmBizNo.hashCode ^
        dbtrWdngPlnYn.hashCode ^
        rrcpCnfmYn.hashCode ^
        spusNm.hashCode ^
        wdngPlnDt.hashCode ^
        rschWkDdlnReqDt.hashCode ^
        isrnPrmm.hashCode ^
        rfrLnAprvNo.hashCode ^
        rgstrMtdDsc.hashCode ^
        rgstrReqNo.hashCode ^
        odprtRpyEane.hashCode ^
        eltnEstbsLwyrNm.hashCode ^
        eltnEstbsLywrBizNo.hashCode ^
        eltnRpyLoaAplYn.hashCode ^
        eltnRpyLoaSqn.hashCode ^
        eltnRpyLoaCtfcNo.hashCode ^
        whlRpyCnt.hashCode ^
        whlRpyAmt.hashCode ^
        ebnkRpyTotAmt.hashCode ^
        dfbnkRpyTotAmt.hashCode ^
        rpyTrgtRnkNo1.hashCode ^
        rpyTrgtAcptDt1.hashCode ^
        rpyTrgtAcptNo1.hashCode ^
        rpyTrgtBndAmt1.hashCode ^
        rpyTrgtRnkNo2.hashCode ^
        rpyTrgtAcptDt2.hashCode ^
        rpyTrgtAcptNo2.hashCode ^
        rpyTrgtBndAmt2.hashCode ^
        rpyTrgtRnkNo3.hashCode ^
        rpyTrgtAcptDt3.hashCode ^
        rpyTrgtAcptNo3.hashCode ^
        rpyTrgtBndAmt3.hashCode ^
        rpyTrgtRnkNo4.hashCode ^
        rpyTrgtAcptDt4.hashCode ^
        rpyTrgtAcptNo4.hashCode ^
        rpyTrgtBndAmt4.hashCode ^
        rpyTrgtRnkNo5.hashCode ^
        rpyTrgtAcptDt5.hashCode ^
        rpyTrgtAcptNo5.hashCode ^
        rpyTrgtBndAmt5.hashCode ^
        afrgstrScrtYn.hashCode ^
        slmnLndProc.hashCode ^
        srMembNo.hashCode ^
        trAmt.hashCode ^
        sllNm1.hashCode ^
        sllBrDay1.hashCode ^
        sllNm2.hashCode ^
        sllBrDay2.hashCode ^
        ownLoanMaxAmt.hashCode ^
        ownLoanPlnAmt.hashCode ^
        ownLoanBnkNm1.hashCode ^
        ownLoanBnkNm2.hashCode ^
        ownLoanBnkNm3.hashCode ^
        ownLoanBnkNm4.hashCode ^
        ownLoanBnkNm5.hashCode ^
        cnsgnNm.hashCode ^
        trstNm.hashCode ^
        bnfrNm.hashCode ^
        nowLessNm.hashCode ^
        rsrvItmB.hashCode ^
        regDtm.hashCode ^
        oblMLnAprvNo.hashCode ^
        oblTotCnt.hashCode ^
        oblGrpRnkNo.hashCode ^
        lnAprvNo2.hashCode;
  }
}
