// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class TrnA400ResData {
  String? loanNo;
  String? trLn;
  String? trCd;
  String? trTpCd;
  String? loNo;
  String? payType;
  String? payBankCd;
  String? payAmt;
  String? transResultCd;
  String? filler;
  TrnA400ResData({
    this.loanNo,
    this.trLn,
    this.trCd,
    this.trTpCd,
    this.loNo,
    this.payType,
    this.payBankCd,
    this.payAmt,
    this.transResultCd,
    this.filler,
  });

  TrnA400ResData copyWith({
    String? loanNo,
    String? trLn,
    String? trCd,
    String? trTpCd,
    String? loNo,
    String? payType,
    String? payBankCd,
    String? payAmt,
    String? transResultCd,
    String? filler,
  }) {
    return TrnA400ResData(
      loanNo: loanNo ?? this.loanNo,
      trLn: trLn ?? this.trLn,
      trCd: trCd ?? this.trCd,
      trTpCd: trTpCd ?? this.trTpCd,
      loNo: loNo ?? this.loNo,
      payType: payType ?? this.payType,
      payBankCd: payBankCd ?? this.payBankCd,
      payAmt: payAmt ?? this.payAmt,
      transResultCd: transResultCd ?? this.transResultCd,
      filler: filler ?? this.filler,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'trLn': trLn,
      'trCd': trCd,
      'trTpCd': trTpCd,
      'loNo': loNo,
      'payType': payType,
      'payBankCd': payBankCd,
      'payAmt': payAmt,
      'transResultCd': transResultCd,
      'filler': filler,
    };
  }

  factory TrnA400ResData.fromMap(Map<String, dynamic> map) {
    return TrnA400ResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      trLn: map['trLn'] != null ? map['trLn'] as String : null,
      trCd: map['trCd'] != null ? map['trCd'] as String : null,
      trTpCd: map['trTpCd'] != null ? map['trTpCd'] as String : null,
      loNo: map['loNo'] != null ? map['loNo'] as String : null,
      payType: map['payType'] != null ? map['payType'] as String : null,
      payBankCd: map['payBankCd'] != null ? map['payBankCd'] as String : null,
      payAmt: map['payAmt'] != null ? map['payAmt'] as String : null,
      transResultCd: map['transResultCd'] != null ? map['transResultCd'] as String : null,
      filler: map['filler'] != null ? map['filler'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnA400ResData.fromJson(String source) => TrnA400ResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TrnA400ResData(loanNo: $loanNo, trLn: $trLn, trCd: $trCd, trTpCd: $trTpCd, loNo: $loNo, payType: $payType, payBankCd: $payBankCd, payAmt: $payAmt, transResultCd: $transResultCd, filler: $filler)';
  }

  @override
  bool operator ==(covariant TrnA400ResData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.trLn == trLn &&
          other.trCd == trCd &&
          other.trTpCd == trTpCd &&
          other.loNo == loNo &&
          other.payType == payType &&
          other.payBankCd == payBankCd &&
          other.payAmt == payAmt &&
          other.transResultCd == transResultCd &&
          other.filler == filler;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    trLn.hashCode ^
    trCd.hashCode ^
    trTpCd.hashCode ^
    loNo.hashCode ^
    payType.hashCode ^
    payBankCd.hashCode ^
    payAmt.hashCode ^
    transResultCd.hashCode ^
    filler.hashCode;
  }
}
