// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class PaymentListResData {
  String? loanNo;
  int? no;
  String? payCd;
  String? payNm;
  String? statCd;
  String? statNm;
  String? bankCd;
  String? bankNm;
  int? payAmt;
  String? payReqDt;
  String? payCmplDt;
  String? rcptRegDtm;
  String? rcptBnkTransDtm;
  String? gpsInfo;
  PaymentListResData({
    this.loanNo,
    this.no,
    this.payCd,
    this.payNm,
    this.statCd,
    this.statNm,
    this.bankCd,
    this.bankNm,
    this.payAmt,
    this.payReqDt,
    this.payCmplDt,
    this.rcptRegDtm,
    this.rcptBnkTransDtm,
    this.gpsInfo,
  });

  PaymentListResData copyWith({
    String? loanNo,
    int? no,
    String? payCd,
    String? payNm,
    String? statCd,
    String? statNm,
    String? bankCd,
    String? bankNm,
    int? payAmt,
    String? payReqDt,
    String? payCmplDt,
    String? rcptRegDtm,
    String? rcptBnkTransDtm,
    String? gpsInfo,
  }) {
    return PaymentListResData(
      loanNo: loanNo ?? this.loanNo,
      no: no ?? this.no,
      payCd: payCd ?? this.payCd,
      payNm: payNm ?? this.payNm,
      statCd: statCd ?? this.statCd,
      statNm: statNm ?? this.statNm,
      bankCd: bankCd ?? this.bankCd,
      bankNm: bankNm ?? this.bankNm,
      payAmt: payAmt ?? this.payAmt,
      payReqDt: payReqDt ?? this.payReqDt,
      payCmplDt: payCmplDt ?? this.payCmplDt,
      rcptRegDtm: rcptRegDtm ?? this.rcptRegDtm,
      rcptBnkTransDtm: rcptBnkTransDtm ?? this.rcptBnkTransDtm,
      gpsInfo: gpsInfo ?? this.gpsInfo,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'no': no,
      'payCd': payCd,
      'payNm': payNm,
      'statCd': statCd,
      'statNm': statNm,
      'bankCd': bankCd,
      'bankNm': bankNm,
      'payAmt': payAmt,
      'payReqDt': payReqDt,
      'payCmplDt': payCmplDt,
      'rcptRegDtm': rcptRegDtm,
      'rcptBnkTransDtm': rcptBnkTransDtm,
      'gpsInfo': gpsInfo,
    };
  }

  factory PaymentListResData.fromMap(Map<String, dynamic> map) {
    return PaymentListResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      no: map['no'] != null ? map['no'] as int : null,
      payCd: map['payCd'] != null ? map['payCd'] as String : null,
      payNm: map['payNm'] != null ? map['payNm'] as String : null,
      statCd: map['statCd'] != null ? map['statCd'] as String : null,
      statNm: map['statNm'] != null ? map['statNm'] as String : null,
      bankCd: map['bankCd'] != null ? map['bankCd'] as String : null,
      bankNm: map['bankNm'] != null ? map['bankNm'] as String : null,
      payAmt: map['payAmt'] != null ? map['payAmt'] as int : null,
      payReqDt: map['payReqDt'] != null ? map['payReqDt'] as String : null,
      payCmplDt: map['payCmplDt'] != null ? map['payCmplDt'] as String : null,
      rcptRegDtm: map['rcptRegDtm'] != null ? map['rcptRegDtm'] as String : null,
      rcptBnkTransDtm: map['rcptBnkTransDtm'] != null ? map['rcptBnkTransDtm'] as String : null,
      gpsInfo: map['gpsInfo'] != null ? map['gpsInfo'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory PaymentListResData.fromJson(String source) => PaymentListResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'PaymentListResData(loanNo: $loanNo, no: $no, payCd: $payCd, payNm: $payNm, statCd: $statCd, statNm: $statNm, bankCd: $bankCd, bankNm: $bankNm, payAmt: $payAmt, payReqDt: $payReqDt, payCmplDt: $payCmplDt, rcptRegDtm: $rcptRegDtm, rcptBnkTransDtm: $rcptBnkTransDtm, gpsInfo: $gpsInfo)';
  }

  @override
  bool operator ==(covariant PaymentListResData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.no == no &&
          other.payCd == payCd &&
          other.payNm == payNm &&
          other.statCd == statCd &&
          other.statNm == statNm &&
          other.bankCd == bankCd &&
          other.bankNm == bankNm &&
          other.payAmt == payAmt &&
          other.payReqDt == payReqDt &&
          other.payCmplDt == payCmplDt &&
          other.rcptRegDtm == rcptRegDtm &&
          other.rcptBnkTransDtm == rcptBnkTransDtm &&
          other.gpsInfo == gpsInfo;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    no.hashCode ^
    payCd.hashCode ^
    payNm.hashCode ^
    statCd.hashCode ^
    statNm.hashCode ^
    bankCd.hashCode ^
    bankNm.hashCode ^
    payAmt.hashCode ^
    payReqDt.hashCode ^
    payCmplDt.hashCode ^
    rcptRegDtm.hashCode ^
    rcptBnkTransDtm.hashCode ^
    gpsInfo.hashCode;
  }
}
