// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class CntrChngReqData {
  String? loanNo;
  String? kndCd;
  String? lndKndCd;
  String? rgstrGbCd;
  String? statCd;
  String? lndStatCd;
  int? execPlnAmt;
  int? execAmt;
  String? execPlnDt;
  String? execDt;
  int? slPrc;
  String? bnkBrnchCd;
  String? bizNo;
  int? trnInCnt;
  String? refndAcctRegYn;
  String? refndAcctRegDate;
  String? eltnSecuredYn;
  String? execAmtChangYn;
  String? estmRegYn;
  String? rgstrRegYn;
  String? payRegYn;
  String? estmCnfmYn;
  String? lndAmtPayYn;
  String? revisionCheckYn;
  String? estbsCntrFnYn;
  String? slCntrctEane;
  String? slCntrctFlnm;
  String? mvhhdSbmtYn;
  String? rrcpSbmtYn;
  String? rtalSbmtYn;
  String? cndtCntrYn;
  String? lwyrDiffBankCd8;
  String? lwyrDiffBankCd10;
  CntrChngReqData({
    this.loanNo,
    this.kndCd,
    this.lndKndCd,
    this.rgstrGbCd,
    this.statCd,
    this.lndStatCd,
    this.execPlnAmt,
    this.execAmt,
    this.execPlnDt,
    this.execDt,
    this.slPrc,
    this.bnkBrnchCd,
    this.bizNo,
    this.trnInCnt,
    this.refndAcctRegYn,
    this.refndAcctRegDate,
    this.eltnSecuredYn,
    this.execAmtChangYn,
    this.estmRegYn,
    this.rgstrRegYn,
    this.payRegYn,
    this.estmCnfmYn,
    this.lndAmtPayYn,
    this.revisionCheckYn,
    this.estbsCntrFnYn,
    this.slCntrctEane,
    this.slCntrctFlnm,
    this.mvhhdSbmtYn,
    this.rrcpSbmtYn,
    this.rtalSbmtYn,
    this.cndtCntrYn,
    this.lwyrDiffBankCd8,
    this.lwyrDiffBankCd10,
  });

  CntrChngReqData copyWith({
    String? loanNo,
    String? kndCd,
    String? lndKndCd,
    String? rgstrGbCd,
    String? statCd,
    String? lndStatCd,
    int? execPlnAmt,
    int? execAmt,
    String? execPlnDt,
    String? execDt,
    int? slPrc,
    String? bnkBrnchCd,
    String? bizNo,
    int? trnInCnt,
    String? refndAcctRegYn,
    String? refndAcctRegDate,
    String? eltnSecuredYn,
    String? execAmtChangYn,
    String? estmRegYn,
    String? rgstrRegYn,
    String? payRegYn,
    String? estmCnfmYn,
    String? lndAmtPayYn,
    String? revisionCheckYn,
    String? estbsCntrFnYn,
    String? slCntrctEane,
    String? slCntrctFlnm,
    String? mvhhdSbmtYn,
    String? rrcpSbmtYn,
    String? rtalSbmtYn,
    String? cndtCntrYn,
    String? lwyrDiffBankCd8,
    String? lwyrDiffBankCd10,
  }) {
    return CntrChngReqData(
      loanNo: loanNo ?? this.loanNo,
      kndCd: kndCd ?? this.kndCd,
      lndKndCd: lndKndCd ?? this.lndKndCd,
      rgstrGbCd: rgstrGbCd ?? this.rgstrGbCd,
      statCd: statCd ?? this.statCd,
      lndStatCd: lndStatCd ?? this.lndStatCd,
      execPlnAmt: execPlnAmt ?? this.execPlnAmt,
      execAmt: execAmt ?? this.execAmt,
      execPlnDt: execPlnDt ?? this.execPlnDt,
      execDt: execDt ?? this.execDt,
      slPrc: slPrc ?? this.slPrc,
      bnkBrnchCd: bnkBrnchCd ?? this.bnkBrnchCd,
      bizNo: bizNo ?? this.bizNo,
      trnInCnt: trnInCnt ?? this.trnInCnt,
      refndAcctRegYn: refndAcctRegYn ?? this.refndAcctRegYn,
      refndAcctRegDate: refndAcctRegDate ?? this.refndAcctRegDate,
      eltnSecuredYn: eltnSecuredYn ?? this.eltnSecuredYn,
      execAmtChangYn: execAmtChangYn ?? this.execAmtChangYn,
      estmRegYn: estmRegYn ?? this.estmRegYn,
      rgstrRegYn: rgstrRegYn ?? this.rgstrRegYn,
      payRegYn: payRegYn ?? this.payRegYn,
      estmCnfmYn: estmCnfmYn ?? this.estmCnfmYn,
      lndAmtPayYn: lndAmtPayYn ?? this.lndAmtPayYn,
      revisionCheckYn: revisionCheckYn ?? this.revisionCheckYn,
      estbsCntrFnYn: estbsCntrFnYn ?? this.estbsCntrFnYn,
      slCntrctEane: slCntrctEane ?? this.slCntrctEane,
      slCntrctFlnm: slCntrctFlnm ?? this.slCntrctFlnm,
      mvhhdSbmtYn: mvhhdSbmtYn ?? this.mvhhdSbmtYn,
      rrcpSbmtYn: rrcpSbmtYn ?? this.rrcpSbmtYn,
      rtalSbmtYn: rtalSbmtYn ?? this.rtalSbmtYn,
      cndtCntrYn: cndtCntrYn ?? this.cndtCntrYn,
      lwyrDiffBankCd8: lwyrDiffBankCd8 ?? this.lwyrDiffBankCd8,
      lwyrDiffBankCd10: lwyrDiffBankCd10 ?? this.lwyrDiffBankCd10,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'kndCd': kndCd,
      'lndKndCd': lndKndCd,
      'rgstrGbCd': rgstrGbCd,
      'statCd': statCd,
      'lndStatCd': lndStatCd,
      'execPlnAmt': execPlnAmt,
      'execAmt': execAmt,
      'execPlnDt': execPlnDt,
      'execDt': execDt,
      'slPrc': slPrc,
      'bnkBrnchCd': bnkBrnchCd,
      'bizNo': bizNo,
      'trnInCnt': trnInCnt,
      'refndAcctRegYn': refndAcctRegYn,
      'refndAcctRegDate': refndAcctRegDate,
      'eltnSecuredYn': eltnSecuredYn,
      'execAmtChangYn': execAmtChangYn,
      'estmRegYn': estmRegYn,
      'rgstrRegYn': rgstrRegYn,
      'payRegYn': payRegYn,
      'estmCnfmYn': estmCnfmYn,
      'lndAmtPayYn': lndAmtPayYn,
      'revisionCheckYn': revisionCheckYn,
      'estbsCntrFnYn': estbsCntrFnYn,
      'slCntrctEane': slCntrctEane,
      'slCntrctFlnm': slCntrctFlnm,
      'mvhhdSbmtYn': mvhhdSbmtYn,
      'rrcpSbmtYn': rrcpSbmtYn,
      'rtalSbmtYn': rtalSbmtYn,
      'cndtCntrYn': cndtCntrYn,
      'lwyrDiffBankCd8': lwyrDiffBankCd8,
      'lwyrDiffBankCd10': lwyrDiffBankCd10,
    };
  }

  factory CntrChngReqData.fromMap(Map<String, dynamic> map) {
    return CntrChngReqData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      kndCd: map['kndCd'] != null ? map['kndCd'] as String : null,
      lndKndCd: map['lndKndCd'] != null ? map['lndKndCd'] as String : null,
      rgstrGbCd: map['rgstrGbCd'] != null ? map['rgstrGbCd'] as String : null,
      statCd: map['statCd'] != null ? map['statCd'] as String : null,
      lndStatCd: map['lndStatCd'] != null ? map['lndStatCd'] as String : null,
      execPlnAmt: map['execPlnAmt'] != null ? map['execPlnAmt'] as int : null,
      execAmt: map['execAmt'] != null ? map['execAmt'] as int : null,
      execPlnDt: map['execPlnDt'] != null ? map['execPlnDt'] as String : null,
      execDt: map['execDt'] != null ? map['execDt'] as String : null,
      slPrc: map['slPrc'] != null ? map['slPrc'] as int : null,
      bnkBrnchCd: map['bnkBrnchCd'] != null ? map['bnkBrnchCd'] as String : null,
      bizNo: map['bizNo'] != null ? map['bizNo'] as String : null,
      trnInCnt: map['trnInCnt'] != null ? map['trnInCnt'] as int : null,
      refndAcctRegYn: map['refndAcctRegYn'] != null ? map['refndAcctRegYn'] as String : null,
      refndAcctRegDate: map['refndAcctRegDate'] != null ? map['refndAcctRegDate'] as String : null,
      eltnSecuredYn: map['eltnSecuredYn'] != null ? map['eltnSecuredYn'] as String : null,
      execAmtChangYn: map['execAmtChangYn'] != null ? map['execAmtChangYn'] as String : null,
      estmRegYn: map['estmRegYn'] != null ? map['estmRegYn'] as String : null,
      rgstrRegYn: map['rgstrRegYn'] != null ? map['rgstrRegYn'] as String : null,
      payRegYn: map['payRegYn'] != null ? map['payRegYn'] as String : null,
      estmCnfmYn: map['estmCnfmYn'] != null ? map['estmCnfmYn'] as String : null,
      lndAmtPayYn: map['lndAmtPayYn'] != null ? map['lndAmtPayYn'] as String : null,
      revisionCheckYn: map['revisionCheckYn'] != null ? map['revisionCheckYn'] as String : null,
      estbsCntrFnYn: map['estbsCntrFnYn'] != null ? map['estbsCntrFnYn'] as String : null,
      slCntrctEane: map['slCntrctEane'] != null ? map['slCntrctEane'] as String : null,
      slCntrctFlnm: map['slCntrctFlnm'] != null ? map['slCntrctFlnm'] as String : null,
      mvhhdSbmtYn: map['mvhhdSbmtYn'] != null ? map['mvhhdSbmtYn'] as String : null,
      rrcpSbmtYn: map['rrcpSbmtYn'] != null ? map['rrcpSbmtYn'] as String : null,
      rtalSbmtYn: map['rtalSbmtYn'] != null ? map['rtalSbmtYn'] as String : null,
      cndtCntrYn: map['cndtCntrYn'] != null ? map['cndtCntrYn'] as String : null,
      lwyrDiffBankCd8: map['lwyrDiffBankCd8'] != null ? map['lwyrDiffBankCd8'] as String : null,
      lwyrDiffBankCd10: map['lwyrDiffBankCd10'] != null ? map['lwyrDiffBankCd10'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory CntrChngReqData.fromJson(String source) => CntrChngReqData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'CntrChngReqData(loanNo: $loanNo, kndCd: $kndCd, lndKndCd: $lndKndCd, rgstrGbCd: $rgstrGbCd, statCd: $statCd, lndStatCd: $lndStatCd, execPlnAmt: $execPlnAmt, execAmt: $execAmt, execPlnDt: $execPlnDt, execDt: $execDt, slPrc: $slPrc, bnkBrnchCd: $bnkBrnchCd, bizNo: $bizNo, trnInCnt: $trnInCnt, refndAcctRegYn: $refndAcctRegYn, refndAcctRegDate: $refndAcctRegDate, eltnSecuredYn: $eltnSecuredYn, execAmtChangYn: $execAmtChangYn, estmRegYn: $estmRegYn, rgstrRegYn: $rgstrRegYn, payRegYn: $payRegYn, estmCnfmYn: $estmCnfmYn, lndAmtPayYn: $lndAmtPayYn, revisionCheckYn: $revisionCheckYn, estbsCntrFnYn: $estbsCntrFnYn, slCntrctEane: $slCntrctEane, slCntrctFlnm: $slCntrctFlnm, mvhhdSbmtYn: $mvhhdSbmtYn, rrcpSbmtYn: $rrcpSbmtYn, rtalSbmtYn: $rtalSbmtYn, cndtCntrYn: $cndtCntrYn, lwyrDiffBankCd8: $lwyrDiffBankCd8, lwyrDiffBankCd10: $lwyrDiffBankCd10)';
  }

  @override
  bool operator ==(covariant CntrChngReqData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.kndCd == kndCd &&
          other.lndKndCd == lndKndCd &&
          other.rgstrGbCd == rgstrGbCd &&
          other.statCd == statCd &&
          other.lndStatCd == lndStatCd &&
          other.execPlnAmt == execPlnAmt &&
          other.execAmt == execAmt &&
          other.execPlnDt == execPlnDt &&
          other.execDt == execDt &&
          other.slPrc == slPrc &&
          other.bnkBrnchCd == bnkBrnchCd &&
          other.bizNo == bizNo &&
          other.trnInCnt == trnInCnt &&
          other.refndAcctRegYn == refndAcctRegYn &&
          other.refndAcctRegDate == refndAcctRegDate &&
          other.eltnSecuredYn == eltnSecuredYn &&
          other.execAmtChangYn == execAmtChangYn &&
          other.estmRegYn == estmRegYn &&
          other.rgstrRegYn == rgstrRegYn &&
          other.payRegYn == payRegYn &&
          other.estmCnfmYn == estmCnfmYn &&
          other.lndAmtPayYn == lndAmtPayYn &&
          other.revisionCheckYn == revisionCheckYn &&
          other.estbsCntrFnYn == estbsCntrFnYn &&
          other.slCntrctEane == slCntrctEane &&
          other.slCntrctFlnm == slCntrctFlnm &&
          other.mvhhdSbmtYn == mvhhdSbmtYn &&
          other.rrcpSbmtYn == rrcpSbmtYn &&
          other.rtalSbmtYn == rtalSbmtYn &&
          other.cndtCntrYn == cndtCntrYn &&
          other.lwyrDiffBankCd8 == lwyrDiffBankCd8 &&
          other.lwyrDiffBankCd10 == lwyrDiffBankCd10;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    kndCd.hashCode ^
    lndKndCd.hashCode ^
    rgstrGbCd.hashCode ^
    statCd.hashCode ^
    lndStatCd.hashCode ^
    execPlnAmt.hashCode ^
    execAmt.hashCode ^
    execPlnDt.hashCode ^
    execDt.hashCode ^
    slPrc.hashCode ^
    bnkBrnchCd.hashCode ^
    bizNo.hashCode ^
    trnInCnt.hashCode ^
    refndAcctRegYn.hashCode ^
    refndAcctRegDate.hashCode ^
    eltnSecuredYn.hashCode ^
    execAmtChangYn.hashCode ^
    estmRegYn.hashCode ^
    rgstrRegYn.hashCode ^
    payRegYn.hashCode ^
    estmCnfmYn.hashCode ^
    lndAmtPayYn.hashCode ^
    revisionCheckYn.hashCode ^
    estbsCntrFnYn.hashCode ^
    slCntrctEane.hashCode ^
    slCntrctFlnm.hashCode ^
    mvhhdSbmtYn.hashCode ^
    rrcpSbmtYn.hashCode ^
    rtalSbmtYn.hashCode ^
    cndtCntrYn.hashCode ^
    lwyrDiffBankCd8.hashCode ^
    lwyrDiffBankCd10.hashCode;
  }
}

class CntrChngResData {
  String? loanNo;
  String? kndCd;
  String? lndKndCd;
  String? rgstrGbCd;
  String? statCd;
  String? lndStatCd;
  int? execPlnAmt;
  int? execAmt;
  String? execPlnDt;
  String? execDt;
  int? slPrc;
  String? bnkBrnchCd;
  String? bizNo;
  int? trnInCnt;
  String? refndAcctRegYn;
  String? refndAcctRegDate;
  String? eltnSecuredYn;
  String? execAmtChangYn;
  String? estmRegYn;
  String? rgstrRegYn;
  String? payRegYn;
  String? estmCnfmYn;
  String? lndAmtPayYn;
  String? revisionCheckYn;
  String? estbsCntrFnYn;
  String? slCntrctEane;
  String? slCntrctFlnm;
  String? mvhhdSbmtYn;
  String? rrcpSbmtYn;
  String? rtalSbmtYn;
  String? cndtCntrYn;
  String? lwyrDiffBankCd8;
  String? lwyrDiffBankCd10;
  CntrChngResData({
    this.loanNo,
    this.kndCd,
    this.lndKndCd,
    this.rgstrGbCd,
    this.statCd,
    this.lndStatCd,
    this.execPlnAmt,
    this.execAmt,
    this.execPlnDt,
    this.execDt,
    this.slPrc,
    this.bnkBrnchCd,
    this.bizNo,
    this.trnInCnt,
    this.refndAcctRegYn,
    this.refndAcctRegDate,
    this.eltnSecuredYn,
    this.execAmtChangYn,
    this.estmRegYn,
    this.rgstrRegYn,
    this.payRegYn,
    this.estmCnfmYn,
    this.lndAmtPayYn,
    this.revisionCheckYn,
    this.estbsCntrFnYn,
    this.slCntrctEane,
    this.slCntrctFlnm,
    this.mvhhdSbmtYn,
    this.rrcpSbmtYn,
    this.rtalSbmtYn,
    this.cndtCntrYn,
    this.lwyrDiffBankCd8,
    this.lwyrDiffBankCd10,
  });

  CntrChngResData copyWith({
    String? loanNo,
    String? kndCd,
    String? lndKndCd,
    String? rgstrGbCd,
    String? statCd,
    String? lndStatCd,
    int? execPlnAmt,
    int? execAmt,
    String? execPlnDt,
    String? execDt,
    int? slPrc,
    String? bnkBrnchCd,
    String? bizNo,
    int? trnInCnt,
    String? refndAcctRegYn,
    String? refndAcctRegDate,
    String? eltnSecuredYn,
    String? execAmtChangYn,
    String? estmRegYn,
    String? rgstrRegYn,
    String? payRegYn,
    String? estmCnfmYn,
    String? lndAmtPayYn,
    String? revisionCheckYn,
    String? estbsCntrFnYn,
    String? slCntrctEane,
    String? slCntrctFlnm,
    String? mvhhdSbmtYn,
    String? rrcpSbmtYn,
    String? rtalSbmtYn,
    String? cndtCntrYn,
    String? lwyrDiffBankCd8,
    String? lwyrDiffBankCd10,
  }) {
    return CntrChngResData(
      loanNo: loanNo ?? this.loanNo,
      kndCd: kndCd ?? this.kndCd,
      lndKndCd: lndKndCd ?? this.lndKndCd,
      rgstrGbCd: rgstrGbCd ?? this.rgstrGbCd,
      statCd: statCd ?? this.statCd,
      lndStatCd: lndStatCd ?? this.lndStatCd,
      execPlnAmt: execPlnAmt ?? this.execPlnAmt,
      execAmt: execAmt ?? this.execAmt,
      execPlnDt: execPlnDt ?? this.execPlnDt,
      execDt: execDt ?? this.execDt,
      slPrc: slPrc ?? this.slPrc,
      bnkBrnchCd: bnkBrnchCd ?? this.bnkBrnchCd,
      bizNo: bizNo ?? this.bizNo,
      trnInCnt: trnInCnt ?? this.trnInCnt,
      refndAcctRegYn: refndAcctRegYn ?? this.refndAcctRegYn,
      refndAcctRegDate: refndAcctRegDate ?? this.refndAcctRegDate,
      eltnSecuredYn: eltnSecuredYn ?? this.eltnSecuredYn,
      execAmtChangYn: execAmtChangYn ?? this.execAmtChangYn,
      estmRegYn: estmRegYn ?? this.estmRegYn,
      rgstrRegYn: rgstrRegYn ?? this.rgstrRegYn,
      payRegYn: payRegYn ?? this.payRegYn,
      estmCnfmYn: estmCnfmYn ?? this.estmCnfmYn,
      lndAmtPayYn: lndAmtPayYn ?? this.lndAmtPayYn,
      revisionCheckYn: revisionCheckYn ?? this.revisionCheckYn,
      estbsCntrFnYn: estbsCntrFnYn ?? this.estbsCntrFnYn,
      slCntrctEane: slCntrctEane ?? this.slCntrctEane,
      slCntrctFlnm: slCntrctFlnm ?? this.slCntrctFlnm,
      mvhhdSbmtYn: mvhhdSbmtYn ?? this.mvhhdSbmtYn,
      rrcpSbmtYn: rrcpSbmtYn ?? this.rrcpSbmtYn,
      rtalSbmtYn: rtalSbmtYn ?? this.rtalSbmtYn,
      cndtCntrYn: cndtCntrYn ?? this.cndtCntrYn,
      lwyrDiffBankCd8: lwyrDiffBankCd8 ?? this.lwyrDiffBankCd8,
      lwyrDiffBankCd10: lwyrDiffBankCd10 ?? this.lwyrDiffBankCd10,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'kndCd': kndCd,
      'lndKndCd': lndKndCd,
      'rgstrGbCd': rgstrGbCd,
      'statCd': statCd,
      'lndStatCd': lndStatCd,
      'execPlnAmt': execPlnAmt,
      'execAmt': execAmt,
      'execPlnDt': execPlnDt,
      'execDt': execDt,
      'slPrc': slPrc,
      'bnkBrnchCd': bnkBrnchCd,
      'bizNo': bizNo,
      'trnInCnt': trnInCnt,
      'refndAcctRegYn': refndAcctRegYn,
      'refndAcctRegDate': refndAcctRegDate,
      'eltnSecuredYn': eltnSecuredYn,
      'execAmtChangYn': execAmtChangYn,
      'estmRegYn': estmRegYn,
      'rgstrRegYn': rgstrRegYn,
      'payRegYn': payRegYn,
      'estmCnfmYn': estmCnfmYn,
      'lndAmtPayYn': lndAmtPayYn,
      'revisionCheckYn': revisionCheckYn,
      'estbsCntrFnYn': estbsCntrFnYn,
      'slCntrctEane': slCntrctEane,
      'slCntrctFlnm': slCntrctFlnm,
      'mvhhdSbmtYn': mvhhdSbmtYn,
      'rrcpSbmtYn': rrcpSbmtYn,
      'rtalSbmtYn': rtalSbmtYn,
      'cndtCntrYn': cndtCntrYn,
      'lwyrDiffBankCd8': lwyrDiffBankCd8,
      'lwyrDiffBankCd10': lwyrDiffBankCd10,
    };
  }

  factory CntrChngResData.fromMap(Map<String, dynamic> map) {
    return CntrChngResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      kndCd: map['kndCd'] != null ? map['kndCd'] as String : null,
      lndKndCd: map['lndKndCd'] != null ? map['lndKndCd'] as String : null,
      rgstrGbCd: map['rgstrGbCd'] != null ? map['rgstrGbCd'] as String : null,
      statCd: map['statCd'] != null ? map['statCd'] as String : null,
      lndStatCd: map['lndStatCd'] != null ? map['lndStatCd'] as String : null,
      execPlnAmt: map['execPlnAmt'] != null ? map['execPlnAmt'] as int : null,
      execAmt: map['execAmt'] != null ? map['execAmt'] as int : null,
      execPlnDt: map['execPlnDt'] != null ? map['execPlnDt'] as String : null,
      execDt: map['execDt'] != null ? map['execDt'] as String : null,
      slPrc: map['slPrc'] != null ? map['slPrc'] as int : null,
      bnkBrnchCd: map['bnkBrnchCd'] != null ? map['bnkBrnchCd'] as String : null,
      bizNo: map['bizNo'] != null ? map['bizNo'] as String : null,
      trnInCnt: map['trnInCnt'] != null ? map['trnInCnt'] as int : null,
      refndAcctRegYn: map['refndAcctRegYn'] != null ? map['refndAcctRegYn'] as String : null,
      refndAcctRegDate: map['refndAcctRegDate'] != null ? map['refndAcctRegDate'] as String : null,
      eltnSecuredYn: map['eltnSecuredYn'] != null ? map['eltnSecuredYn'] as String : null,
      execAmtChangYn: map['execAmtChangYn'] != null ? map['execAmtChangYn'] as String : null,
      estmRegYn: map['estmRegYn'] != null ? map['estmRegYn'] as String : null,
      rgstrRegYn: map['rgstrRegYn'] != null ? map['rgstrRegYn'] as String : null,
      payRegYn: map['payRegYn'] != null ? map['payRegYn'] as String : null,
      estmCnfmYn: map['estmCnfmYn'] != null ? map['estmCnfmYn'] as String : null,
      lndAmtPayYn: map['lndAmtPayYn'] != null ? map['lndAmtPayYn'] as String : null,
      revisionCheckYn: map['revisionCheckYn'] != null ? map['revisionCheckYn'] as String : null,
      estbsCntrFnYn: map['estbsCntrFnYn'] != null ? map['estbsCntrFnYn'] as String : null,
      slCntrctEane: map['slCntrctEane'] != null ? map['slCntrctEane'] as String : null,
      slCntrctFlnm: map['slCntrctFlnm'] != null ? map['slCntrctFlnm'] as String : null,
      mvhhdSbmtYn: map['mvhhdSbmtYn'] != null ? map['mvhhdSbmtYn'] as String : null,
      rrcpSbmtYn: map['rrcpSbmtYn'] != null ? map['rrcpSbmtYn'] as String : null,
      rtalSbmtYn: map['rtalSbmtYn'] != null ? map['rtalSbmtYn'] as String : null,
      cndtCntrYn: map['cndtCntrYn'] != null ? map['cndtCntrYn'] as String : null,
      lwyrDiffBankCd8: map['lwyrDiffBankCd8'] != null ? map['lwyrDiffBankCd8'] as String : null,
      lwyrDiffBankCd10: map['lwyrDiffBankCd10'] != null ? map['lwyrDiffBankCd10'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory CntrChngResData.fromJson(String source) => CntrChngResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'CntrChngResData(loanNo: $loanNo, kndCd: $kndCd, lndKndCd: $lndKndCd, rgstrGbCd: $rgstrGbCd, statCd: $statCd, lndStatCd: $lndStatCd, execPlnAmt: $execPlnAmt, execAmt: $execAmt, execPlnDt: $execPlnDt, execDt: $execDt, slPrc: $slPrc, bnkBrnchCd: $bnkBrnchCd, bizNo: $bizNo, trnInCnt: $trnInCnt, refndAcctRegYn: $refndAcctRegYn, refndAcctRegDate: $refndAcctRegDate, eltnSecuredYn: $eltnSecuredYn, execAmtChangYn: $execAmtChangYn, estmRegYn: $estmRegYn, rgstrRegYn: $rgstrRegYn, payRegYn: $payRegYn, estmCnfmYn: $estmCnfmYn, lndAmtPayYn: $lndAmtPayYn, revisionCheckYn: $revisionCheckYn, estbsCntrFnYn: $estbsCntrFnYn, slCntrctEane: $slCntrctEane, slCntrctFlnm: $slCntrctFlnm, mvhhdSbmtYn: $mvhhdSbmtYn, rrcpSbmtYn: $rrcpSbmtYn, rtalSbmtYn: $rtalSbmtYn, cndtCntrYn: $cndtCntrYn, lwyrDiffBankCd8: $lwyrDiffBankCd8, lwyrDiffBankCd10: $lwyrDiffBankCd10)';
  }

  @override
  bool operator ==(covariant CntrChngResData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.kndCd == kndCd &&
          other.lndKndCd == lndKndCd &&
          other.rgstrGbCd == rgstrGbCd &&
          other.statCd == statCd &&
          other.lndStatCd == lndStatCd &&
          other.execPlnAmt == execPlnAmt &&
          other.execAmt == execAmt &&
          other.execPlnDt == execPlnDt &&
          other.execDt == execDt &&
          other.slPrc == slPrc &&
          other.bnkBrnchCd == bnkBrnchCd &&
          other.bizNo == bizNo &&
          other.trnInCnt == trnInCnt &&
          other.refndAcctRegYn == refndAcctRegYn &&
          other.refndAcctRegDate == refndAcctRegDate &&
          other.eltnSecuredYn == eltnSecuredYn &&
          other.execAmtChangYn == execAmtChangYn &&
          other.estmRegYn == estmRegYn &&
          other.rgstrRegYn == rgstrRegYn &&
          other.payRegYn == payRegYn &&
          other.estmCnfmYn == estmCnfmYn &&
          other.lndAmtPayYn == lndAmtPayYn &&
          other.revisionCheckYn == revisionCheckYn &&
          other.estbsCntrFnYn == estbsCntrFnYn &&
          other.slCntrctEane == slCntrctEane &&
          other.slCntrctFlnm == slCntrctFlnm &&
          other.mvhhdSbmtYn == mvhhdSbmtYn &&
          other.rrcpSbmtYn == rrcpSbmtYn &&
          other.rtalSbmtYn == rtalSbmtYn &&
          other.cndtCntrYn == cndtCntrYn &&
          other.lwyrDiffBankCd8 == lwyrDiffBankCd8 &&
          other.lwyrDiffBankCd10 == lwyrDiffBankCd10;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    kndCd.hashCode ^
    lndKndCd.hashCode ^
    rgstrGbCd.hashCode ^
    statCd.hashCode ^
    lndStatCd.hashCode ^
    execPlnAmt.hashCode ^
    execAmt.hashCode ^
    execPlnDt.hashCode ^
    execDt.hashCode ^
    slPrc.hashCode ^
    bnkBrnchCd.hashCode ^
    bizNo.hashCode ^
    trnInCnt.hashCode ^
    refndAcctRegYn.hashCode ^
    refndAcctRegDate.hashCode ^
    eltnSecuredYn.hashCode ^
    execAmtChangYn.hashCode ^
    estmRegYn.hashCode ^
    rgstrRegYn.hashCode ^
    payRegYn.hashCode ^
    estmCnfmYn.hashCode ^
    lndAmtPayYn.hashCode ^
    revisionCheckYn.hashCode ^
    estbsCntrFnYn.hashCode ^
    slCntrctEane.hashCode ^
    slCntrctFlnm.hashCode ^
    mvhhdSbmtYn.hashCode ^
    rrcpSbmtYn.hashCode ^
    rtalSbmtYn.hashCode ^
    cndtCntrYn.hashCode ^
    lwyrDiffBankCd8.hashCode ^
    lwyrDiffBankCd10.hashCode;
  }
}
