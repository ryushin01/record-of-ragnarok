// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class LoginRes {
  String? adminNm;
  String? permCd;
  String? permNm;
  String? lognId;
  String? pwd;
  String? cphnNum;
  String? email;
  int? lognFailCnt;
  String? statCd;
  String? statNm;
  String? accessToken;
  String? refreshToken;
  LoginRes({
    this.adminNm,
    this.permCd,
    this.permNm,
    this.lognId,
    this.pwd,
    this.cphnNum,
    this.email,
    this.lognFailCnt,
    this.statCd,
    this.statNm,
    this.accessToken,
    this.refreshToken,
  });

  LoginRes copyWith({
    String? adminNm,
    String? permCd,
    String? permNm,
    String? lognId,
    String? pwd,
    String? cphnNum,
    String? email,
    int? lognFailCnt,
    String? statCd,
    String? statNm,
    String? accessToken,
    String? refreshToken,
  }) {
    return LoginRes(
      adminNm: adminNm ?? this.adminNm,
      permCd: permCd ?? this.permCd,
      permNm: permNm ?? this.permNm,
      lognId: lognId ?? this.lognId,
      pwd: pwd ?? this.pwd,
      cphnNum: cphnNum ?? this.cphnNum,
      email: email ?? this.email,
      lognFailCnt: lognFailCnt ?? this.lognFailCnt,
      statCd: statCd ?? this.statCd,
      statNm: statNm ?? this.statNm,
      accessToken: accessToken ?? this.accessToken,
      refreshToken: refreshToken ?? this.refreshToken,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'adminNm': adminNm,
      'permCd': permCd,
      'permNm': permNm,
      'lognId': lognId,
      'pwd': pwd,
      'cphnNum': cphnNum,
      'email': email,
      'lognFailCnt': lognFailCnt,
      'statCd': statCd,
      'statNm': statNm,
      'accessToken': accessToken,
      'refreshToken': refreshToken,
    };
  }

  factory LoginRes.fromMap(Map<String, dynamic> map) {
    return LoginRes(
      adminNm: map['adminNm'] != null ? map['adminNm'] as String : null,
      permCd: map['permCd'] != null ? map['permCd'] as String : null,
      permNm: map['permNm'] != null ? map['permNm'] as String : null,
      lognId: map['lognId'] != null ? map['lognId'] as String : null,
      pwd: map['pwd'] != null ? map['pwd'] as String : null,
      cphnNum: map['cphnNum'] != null ? map['cphnNum'] as String : null,
      email: map['email'] != null ? map['email'] as String : null,
      lognFailCnt: map['lognFailCnt'] != null ? map['lognFailCnt'] as int : null,
      statCd: map['statCd'] != null ? map['statCd'] as String : null,
      statNm: map['statNm'] != null ? map['statNm'] as String : null,
      accessToken: map['accessToken'] != null ? map['accessToken'] as String : null,
      refreshToken: map['refreshToken'] != null ? map['refreshToken'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory LoginRes.fromJson(String source) => LoginRes.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'LoginRes(adminNm: $adminNm, permCd: $permCd, permNm: $permNm, lognId: $lognId, pwd: $pwd, cphnNum: $cphnNum, email: $email, lognFailCnt: $lognFailCnt, statCd: $statCd, statNm: $statNm, accessToken: $accessToken, refreshToken: $refreshToken)';
  }

  @override
  bool operator ==(covariant LoginRes other) {
    if (identical(this, other)) return true;

    return other.adminNm == adminNm &&
        other.permCd == permCd &&
        other.permNm == permNm &&
        other.lognId == lognId &&
        other.pwd == pwd &&
        other.cphnNum == cphnNum &&
        other.email == email &&
        other.lognFailCnt == lognFailCnt &&
        other.statCd == statCd &&
        other.statNm == statNm &&
        other.accessToken == accessToken &&
        other.refreshToken == refreshToken;
  }

  @override
  int get hashCode {
    return adminNm.hashCode ^
    permCd.hashCode ^
    permNm.hashCode ^
    lognId.hashCode ^
    pwd.hashCode ^
    cphnNum.hashCode ^
    email.hashCode ^
    lognFailCnt.hashCode ^
    statCd.hashCode ^
    statNm.hashCode ^
    accessToken.hashCode ^
    refreshToken.hashCode;
  }
}
