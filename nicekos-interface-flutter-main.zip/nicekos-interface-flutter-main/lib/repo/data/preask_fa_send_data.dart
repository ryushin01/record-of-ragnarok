// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class TrnsSendReqData {
  String? loanNo;
  String? newLoanNo;
  int? tgLen;
  String? tgDsc;
  String? bnkTgNo;
  String? faTgNo;
  String? kosTgSndNo;
  String? tgSndDtm;
  String? tgRcvDtm;
  String? resCd;
  String? rsrvItmH;
  String? lndDsc;
  String? lndKndCd;
  String? fndUseCd;
  String? bnkLndProdtCd;
  String? bnkLndProdtNm;
  String? stndAplYn;
  String? mvLwyrCnfmYn;
  String? rgstrUnqNo1;
  String? rgstrUnqNo2;
  String? rgstrUnqNo3;
  String? rgstrUnqNo4;
  String? rgstrUnqNo5;
  String? rlesDsc;
  String? trgtRlesDsc;
  String? trgtRlesAddr;
  String? bfAskDt;
  String? lndPlnDt;
  String? slPrc;
  String? scrtevlAmt;
  String? isrnEntrAmt;
  String? lndAmt;
  int? bnkfxcltRgstrRnk;
  String? dbrtNm;
  String? dbtrBirthDt;
  String? dbtrAddr;
  String? dbtrPhno;
  String? dbtrHpno;
  String? pwpsNm;
  String? pwpsBirthDt;
  String? pwpsAddr;
  String? pwpsPhno;
  String? pwpsHpno;
  String? rmkFct;
  String? lndHndgSlfDsc;
  String? bnkBrnchNm;
  String? bnkDrctrNm;
  String? bnkBrnchPhno;
  String? bnkDrctrHp;
  String? bnkBrnchFax;
  String? bnkBrnchAddr;
  String? slmnCmpyNm;
  String? slmnNm;
  String? slmnPhno;
  String? rfrLnAprvNo;
  String? rgstrMtdDsc;
  String? odprtRpyEane;
  String? eltnEstbsLwyrNm;
  String? eltnEstbsLwyrBizNo;
  String? slCntrctEane;
  String? slCntrctFlnm;
  String? afrgstrScrtYn;
  String? bnkBrnchCd;
  String? rsrvItmB;
  String? regDtm;
  String? trgtRlesAddr2;
  String? addrSrchYn;
  String? cnvntLwyrYn;
  String? lnAprvNo2;
  TrnsSendReqData({
    this.loanNo,
    this.newLoanNo,
    this.tgLen,
    this.tgDsc,
    this.bnkTgNo,
    this.faTgNo,
    this.kosTgSndNo,
    this.tgSndDtm,
    this.tgRcvDtm,
    this.resCd,
    this.rsrvItmH,
    this.lndDsc,
    this.lndKndCd,
    this.fndUseCd,
    this.bnkLndProdtCd,
    this.bnkLndProdtNm,
    this.stndAplYn,
    this.mvLwyrCnfmYn,
    this.rgstrUnqNo1,
    this.rgstrUnqNo2,
    this.rgstrUnqNo3,
    this.rgstrUnqNo4,
    this.rgstrUnqNo5,
    this.rlesDsc,
    this.trgtRlesDsc,
    this.trgtRlesAddr,
    this.bfAskDt,
    this.lndPlnDt,
    this.slPrc,
    this.scrtevlAmt,
    this.isrnEntrAmt,
    this.lndAmt,
    this.bnkfxcltRgstrRnk,
    this.dbrtNm,
    this.dbtrBirthDt,
    this.dbtrAddr,
    this.dbtrPhno,
    this.dbtrHpno,
    this.pwpsNm,
    this.pwpsBirthDt,
    this.pwpsAddr,
    this.pwpsPhno,
    this.pwpsHpno,
    this.rmkFct,
    this.lndHndgSlfDsc,
    this.bnkBrnchNm,
    this.bnkDrctrNm,
    this.bnkBrnchPhno,
    this.bnkDrctrHp,
    this.bnkBrnchFax,
    this.bnkBrnchAddr,
    this.slmnCmpyNm,
    this.slmnNm,
    this.slmnPhno,
    this.rfrLnAprvNo,
    this.rgstrMtdDsc,
    this.odprtRpyEane,
    this.eltnEstbsLwyrNm,
    this.eltnEstbsLwyrBizNo,
    this.slCntrctEane,
    this.slCntrctFlnm,
    this.afrgstrScrtYn,
    this.bnkBrnchCd,
    this.rsrvItmB,
    this.regDtm,
    this.trgtRlesAddr2,
    this.addrSrchYn,
    this.cnvntLwyrYn,
    this.lnAprvNo2,
  });

  TrnsSendReqData copyWith({
    String? loanNo,
    String? newLoanNo,
    int? tgLen,
    String? tgDsc,
    String? bnkTgNo,
    String? faTgNo,
    String? kosTgSndNo,
    String? tgSndDtm,
    String? tgRcvDtm,
    String? resCd,
    String? rsrvItmH,
    String? lndDsc,
    String? lndKndCd,
    String? fndUseCd,
    String? bnkLndProdtCd,
    String? bnkLndProdtNm,
    String? stndAplYn,
    String? mvLwyrCnfmYn,
    String? rgstrUnqNo1,
    String? rgstrUnqNo2,
    String? rgstrUnqNo3,
    String? rgstrUnqNo4,
    String? rgstrUnqNo5,
    String? rlesDsc,
    String? trgtRlesDsc,
    String? trgtRlesAddr,
    String? bfAskDt,
    String? lndPlnDt,
    String? slPrc,
    String? scrtevlAmt,
    String? isrnEntrAmt,
    String? lndAmt,
    int? bnkfxcltRgstrRnk,
    String? dbrtNm,
    String? dbtrBirthDt,
    String? dbtrAddr,
    String? dbtrPhno,
    String? dbtrHpno,
    String? pwpsNm,
    String? pwpsBirthDt,
    String? pwpsAddr,
    String? pwpsPhno,
    String? pwpsHpno,
    String? rmkFct,
    String? lndHndgSlfDsc,
    String? bnkBrnchNm,
    String? bnkDrctrNm,
    String? bnkBrnchPhno,
    String? bnkDrctrHp,
    String? bnkBrnchFax,
    String? bnkBrnchAddr,
    String? slmnCmpyNm,
    String? slmnNm,
    String? slmnPhno,
    String? rfrLnAprvNo,
    String? rgstrMtdDsc,
    String? odprtRpyEane,
    String? eltnEstbsLwyrNm,
    String? eltnEstbsLwyrBizNo,
    String? slCntrctEane,
    String? slCntrctFlnm,
    String? afrgstrScrtYn,
    String? bnkBrnchCd,
    String? rsrvItmB,
    String? regDtm,
    String? trgtRlesAddr2,
    String? addrSrchYn,
    String? cnvntLwyrYn,
    String? lnAprvNo2,
  }) {
    return TrnsSendReqData(
      loanNo: loanNo ?? this.loanNo,
      newLoanNo: newLoanNo ?? this.newLoanNo,
      tgLen: tgLen ?? this.tgLen,
      tgDsc: tgDsc ?? this.tgDsc,
      bnkTgNo: bnkTgNo ?? this.bnkTgNo,
      faTgNo: faTgNo ?? this.faTgNo,
      kosTgSndNo: kosTgSndNo ?? this.kosTgSndNo,
      tgSndDtm: tgSndDtm ?? this.tgSndDtm,
      tgRcvDtm: tgRcvDtm ?? this.tgRcvDtm,
      resCd: resCd ?? this.resCd,
      rsrvItmH: rsrvItmH ?? this.rsrvItmH,
      lndDsc: lndDsc ?? this.lndDsc,
      lndKndCd: lndKndCd ?? this.lndKndCd,
      fndUseCd: fndUseCd ?? this.fndUseCd,
      bnkLndProdtCd: bnkLndProdtCd ?? this.bnkLndProdtCd,
      bnkLndProdtNm: bnkLndProdtNm ?? this.bnkLndProdtNm,
      stndAplYn: stndAplYn ?? this.stndAplYn,
      mvLwyrCnfmYn: mvLwyrCnfmYn ?? this.mvLwyrCnfmYn,
      rgstrUnqNo1: rgstrUnqNo1 ?? this.rgstrUnqNo1,
      rgstrUnqNo2: rgstrUnqNo2 ?? this.rgstrUnqNo2,
      rgstrUnqNo3: rgstrUnqNo3 ?? this.rgstrUnqNo3,
      rgstrUnqNo4: rgstrUnqNo4 ?? this.rgstrUnqNo4,
      rgstrUnqNo5: rgstrUnqNo5 ?? this.rgstrUnqNo5,
      rlesDsc: rlesDsc ?? this.rlesDsc,
      trgtRlesDsc: trgtRlesDsc ?? this.trgtRlesDsc,
      trgtRlesAddr: trgtRlesAddr ?? this.trgtRlesAddr,
      bfAskDt: bfAskDt ?? this.bfAskDt,
      lndPlnDt: lndPlnDt ?? this.lndPlnDt,
      slPrc: slPrc ?? this.slPrc,
      scrtevlAmt: scrtevlAmt ?? this.scrtevlAmt,
      isrnEntrAmt: isrnEntrAmt ?? this.isrnEntrAmt,
      lndAmt: lndAmt ?? this.lndAmt,
      bnkfxcltRgstrRnk: bnkfxcltRgstrRnk ?? this.bnkfxcltRgstrRnk,
      dbrtNm: dbrtNm ?? this.dbrtNm,
      dbtrBirthDt: dbtrBirthDt ?? this.dbtrBirthDt,
      dbtrAddr: dbtrAddr ?? this.dbtrAddr,
      dbtrPhno: dbtrPhno ?? this.dbtrPhno,
      dbtrHpno: dbtrHpno ?? this.dbtrHpno,
      pwpsNm: pwpsNm ?? this.pwpsNm,
      pwpsBirthDt: pwpsBirthDt ?? this.pwpsBirthDt,
      pwpsAddr: pwpsAddr ?? this.pwpsAddr,
      pwpsPhno: pwpsPhno ?? this.pwpsPhno,
      pwpsHpno: pwpsHpno ?? this.pwpsHpno,
      rmkFct: rmkFct ?? this.rmkFct,
      lndHndgSlfDsc: lndHndgSlfDsc ?? this.lndHndgSlfDsc,
      bnkBrnchNm: bnkBrnchNm ?? this.bnkBrnchNm,
      bnkDrctrNm: bnkDrctrNm ?? this.bnkDrctrNm,
      bnkBrnchPhno: bnkBrnchPhno ?? this.bnkBrnchPhno,
      bnkDrctrHp: bnkDrctrHp ?? this.bnkDrctrHp,
      bnkBrnchFax: bnkBrnchFax ?? this.bnkBrnchFax,
      bnkBrnchAddr: bnkBrnchAddr ?? this.bnkBrnchAddr,
      slmnCmpyNm: slmnCmpyNm ?? this.slmnCmpyNm,
      slmnNm: slmnNm ?? this.slmnNm,
      slmnPhno: slmnPhno ?? this.slmnPhno,
      rfrLnAprvNo: rfrLnAprvNo ?? this.rfrLnAprvNo,
      rgstrMtdDsc: rgstrMtdDsc ?? this.rgstrMtdDsc,
      odprtRpyEane: odprtRpyEane ?? this.odprtRpyEane,
      eltnEstbsLwyrNm: eltnEstbsLwyrNm ?? this.eltnEstbsLwyrNm,
      eltnEstbsLwyrBizNo: eltnEstbsLwyrBizNo ?? this.eltnEstbsLwyrBizNo,
      slCntrctEane: slCntrctEane ?? this.slCntrctEane,
      slCntrctFlnm: slCntrctFlnm ?? this.slCntrctFlnm,
      afrgstrScrtYn: afrgstrScrtYn ?? this.afrgstrScrtYn,
      bnkBrnchCd: bnkBrnchCd ?? this.bnkBrnchCd,
      rsrvItmB: rsrvItmB ?? this.rsrvItmB,
      regDtm: regDtm ?? this.regDtm,
      trgtRlesAddr2: trgtRlesAddr2 ?? this.trgtRlesAddr2,
      addrSrchYn: addrSrchYn ?? this.addrSrchYn,
      cnvntLwyrYn: cnvntLwyrYn ?? this.cnvntLwyrYn,
      lnAprvNo2: lnAprvNo2 ?? this.lnAprvNo2,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'newLoanNo': newLoanNo,
      'tgLen': tgLen,
      'tgDsc': tgDsc,
      'bnkTgNo': bnkTgNo,
      'faTgNo': faTgNo,
      'kosTgSndNo': kosTgSndNo,
      'tgSndDtm': tgSndDtm,
      'tgRcvDtm': tgRcvDtm,
      'resCd': resCd,
      'rsrvItmH': rsrvItmH,
      'lndDsc': lndDsc,
      'lndKndCd': lndKndCd,
      'fndUseCd': fndUseCd,
      'bnkLndProdtCd': bnkLndProdtCd,
      'bnkLndProdtNm': bnkLndProdtNm,
      'stndAplYn': stndAplYn,
      'mvLwyrCnfmYn': mvLwyrCnfmYn,
      'rgstrUnqNo1': rgstrUnqNo1,
      'rgstrUnqNo2': rgstrUnqNo2,
      'rgstrUnqNo3': rgstrUnqNo3,
      'rgstrUnqNo4': rgstrUnqNo4,
      'rgstrUnqNo5': rgstrUnqNo5,
      'rlesDsc': rlesDsc,
      'trgtRlesDsc': trgtRlesDsc,
      'trgtRlesAddr': trgtRlesAddr,
      'bfAskDt': bfAskDt,
      'lndPlnDt': lndPlnDt,
      'slPrc': slPrc,
      'scrtevlAmt': scrtevlAmt,
      'isrnEntrAmt': isrnEntrAmt,
      'lndAmt': lndAmt,
      'bnkfxcltRgstrRnk': bnkfxcltRgstrRnk,
      'dbrtNm': dbrtNm,
      'dbtrBirthDt': dbtrBirthDt,
      'dbtrAddr': dbtrAddr,
      'dbtrPhno': dbtrPhno,
      'dbtrHpno': dbtrHpno,
      'pwpsNm': pwpsNm,
      'pwpsBirthDt': pwpsBirthDt,
      'pwpsAddr': pwpsAddr,
      'pwpsPhno': pwpsPhno,
      'pwpsHpno': pwpsHpno,
      'rmkFct': rmkFct,
      'lndHndgSlfDsc': lndHndgSlfDsc,
      'bnkBrnchNm': bnkBrnchNm,
      'bnkDrctrNm': bnkDrctrNm,
      'bnkBrnchPhno': bnkBrnchPhno,
      'bnkDrctrHp': bnkDrctrHp,
      'bnkBrnchFax': bnkBrnchFax,
      'bnkBrnchAddr': bnkBrnchAddr,
      'slmnCmpyNm': slmnCmpyNm,
      'slmnNm': slmnNm,
      'slmnPhno': slmnPhno,
      'rfrLnAprvNo': rfrLnAprvNo,
      'rgstrMtdDsc': rgstrMtdDsc,
      'odprtRpyEane': odprtRpyEane,
      'eltnEstbsLwyrNm': eltnEstbsLwyrNm,
      'eltnEstbsLwyrBizNo': eltnEstbsLwyrBizNo,
      'slCntrctEane': slCntrctEane,
      'slCntrctFlnm': slCntrctFlnm,
      'afrgstrScrtYn': afrgstrScrtYn,
      'bnkBrnchCd': bnkBrnchCd,
      'rsrvItmB': rsrvItmB,
      'regDtm': regDtm,
      'trgtRlesAddr2': trgtRlesAddr2,
      'addrSrchYn': addrSrchYn,
      'cnvntLwyrYn': cnvntLwyrYn,
      'lnAprvNo2': lnAprvNo2,
    };
  }

  factory TrnsSendReqData.fromMap(Map<String, dynamic> map) {
    return TrnsSendReqData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      newLoanNo: map['newLoanNo'] != null ? map['newLoanNo'] as String : null,
      tgLen: map['tgLen'] != null ? map['tgLen'] as int : null,
      tgDsc: map['tgDsc'] != null ? map['tgDsc'] as String : null,
      bnkTgNo: map['bnkTgNo'] != null ? map['bnkTgNo'] as String : null,
      faTgNo: map['faTgNo'] != null ? map['faTgNo'] as String : null,
      kosTgSndNo: map['kosTgSndNo'] != null ? map['kosTgSndNo'] as String : null,
      tgSndDtm: map['tgSndDtm'] != null ? map['tgSndDtm'] as String : null,
      tgRcvDtm: map['tgRcvDtm'] != null ? map['tgRcvDtm'] as String : null,
      resCd: map['resCd'] != null ? map['resCd'] as String : null,
      rsrvItmH: map['rsrvItmH'] != null ? map['rsrvItmH'] as String : null,
      lndDsc: map['lndDsc'] != null ? map['lndDsc'] as String : null,
      lndKndCd: map['lndKndCd'] != null ? map['lndKndCd'] as String : null,
      fndUseCd: map['fndUseCd'] != null ? map['fndUseCd'] as String : null,
      bnkLndProdtCd: map['bnkLndProdtCd'] != null ? map['bnkLndProdtCd'] as String : null,
      bnkLndProdtNm: map['bnkLndProdtNm'] != null ? map['bnkLndProdtNm'] as String : null,
      stndAplYn: map['stndAplYn'] != null ? map['stndAplYn'] as String : null,
      mvLwyrCnfmYn: map['mvLwyrCnfmYn'] != null ? map['mvLwyrCnfmYn'] as String : null,
      rgstrUnqNo1: map['rgstrUnqNo1'] != null ? map['rgstrUnqNo1'] as String : null,
      rgstrUnqNo2: map['rgstrUnqNo2'] != null ? map['rgstrUnqNo2'] as String : null,
      rgstrUnqNo3: map['rgstrUnqNo3'] != null ? map['rgstrUnqNo3'] as String : null,
      rgstrUnqNo4: map['rgstrUnqNo4'] != null ? map['rgstrUnqNo4'] as String : null,
      rgstrUnqNo5: map['rgstrUnqNo5'] != null ? map['rgstrUnqNo5'] as String : null,
      rlesDsc: map['rlesDsc'] != null ? map['rlesDsc'] as String : null,
      trgtRlesDsc: map['trgtRlesDsc'] != null ? map['trgtRlesDsc'] as String : null,
      trgtRlesAddr: map['trgtRlesAddr'] != null ? map['trgtRlesAddr'] as String : null,
      bfAskDt: map['bfAskDt'] != null ? map['bfAskDt'] as String : null,
      lndPlnDt: map['lndPlnDt'] != null ? map['lndPlnDt'] as String : null,
      slPrc: map['slPrc'] != null ? map['slPrc'] as String : null,
      scrtevlAmt: map['scrtevlAmt'] != null ? map['scrtevlAmt'] as String : null,
      isrnEntrAmt: map['isrnEntrAmt'] != null ? map['isrnEntrAmt'] as String : null,
      lndAmt: map['lndAmt'] != null ? map['lndAmt'] as String : null,
      bnkfxcltRgstrRnk: map['bnkfxcltRgstrRnk'] != null ? map['bnkfxcltRgstrRnk'] as int : null,
      dbrtNm: map['dbrtNm'] != null ? map['dbrtNm'] as String : null,
      dbtrBirthDt: map['dbtrBirthDt'] != null ? map['dbtrBirthDt'] as String : null,
      dbtrAddr: map['dbtrAddr'] != null ? map['dbtrAddr'] as String : null,
      dbtrPhno: map['dbtrPhno'] != null ? map['dbtrPhno'] as String : null,
      dbtrHpno: map['dbtrHpno'] != null ? map['dbtrHpno'] as String : null,
      pwpsNm: map['pwpsNm'] != null ? map['pwpsNm'] as String : null,
      pwpsBirthDt: map['pwpsBirthDt'] != null ? map['pwpsBirthDt'] as String : null,
      pwpsAddr: map['pwpsAddr'] != null ? map['pwpsAddr'] as String : null,
      pwpsPhno: map['pwpsPhno'] != null ? map['pwpsPhno'] as String : null,
      pwpsHpno: map['pwpsHpno'] != null ? map['pwpsHpno'] as String : null,
      rmkFct: map['rmkFct'] != null ? map['rmkFct'] as String : null,
      lndHndgSlfDsc: map['lndHndgSlfDsc'] != null ? map['lndHndgSlfDsc'] as String : null,
      bnkBrnchNm: map['bnkBrnchNm'] != null ? map['bnkBrnchNm'] as String : null,
      bnkDrctrNm: map['bnkDrctrNm'] != null ? map['bnkDrctrNm'] as String : null,
      bnkBrnchPhno: map['bnkBrnchPhno'] != null ? map['bnkBrnchPhno'] as String : null,
      bnkDrctrHp: map['bnkDrctrHp'] != null ? map['bnkDrctrHp'] as String : null,
      bnkBrnchFax: map['bnkBrnchFax'] != null ? map['bnkBrnchFax'] as String : null,
      bnkBrnchAddr: map['bnkBrnchAddr'] != null ? map['bnkBrnchAddr'] as String : null,
      slmnCmpyNm: map['slmnCmpyNm'] != null ? map['slmnCmpyNm'] as String : null,
      slmnNm: map['slmnNm'] != null ? map['slmnNm'] as String : null,
      slmnPhno: map['slmnPhno'] != null ? map['slmnPhno'] as String : null,
      rfrLnAprvNo: map['rfrLnAprvNo'] != null ? map['rfrLnAprvNo'] as String : null,
      rgstrMtdDsc: map['rgstrMtdDsc'] != null ? map['rgstrMtdDsc'] as String : null,
      odprtRpyEane: map['odprtRpyEane'] != null ? map['odprtRpyEane'] as String : null,
      eltnEstbsLwyrNm: map['eltnEstbsLwyrNm'] != null ? map['eltnEstbsLwyrNm'] as String : null,
      eltnEstbsLwyrBizNo: map['eltnEstbsLwyrBizNo'] != null ? map['eltnEstbsLwyrBizNo'] as String : null,
      slCntrctEane: map['slCntrctEane'] != null ? map['slCntrctEane'] as String : null,
      slCntrctFlnm: map['slCntrctFlnm'] != null ? map['slCntrctFlnm'] as String : null,
      afrgstrScrtYn: map['afrgstrScrtYn'] != null ? map['afrgstrScrtYn'] as String : null,
      bnkBrnchCd: map['bnkBrnchCd'] != null ? map['bnkBrnchCd'] as String : null,
      rsrvItmB: map['rsrvItmB'] != null ? map['rsrvItmB'] as String : null,
      regDtm: map['regDtm'] != null ? map['regDtm'] as String : null,
      trgtRlesAddr2: map['trgtRlesAddr2'] != null ? map['trgtRlesAddr2'] as String : null,
      addrSrchYn: map['addrSrchYn'] != null ? map['addrSrchYn'] as String : null,
      cnvntLwyrYn: map['cnvntLwyrYn'] != null ? map['cnvntLwyrYn'] as String : null,
      lnAprvNo2: map['lnAprvNo2'] != null ? map['lnAprvNo2'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnsSendReqData.fromJson(String source) => TrnsSendReqData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TrnsSendReqData(loanNo: $loanNo, newLoanNo: $newLoanNo, tgLen: $tgLen, tgDsc: $tgDsc, bnkTgNo: $bnkTgNo, faTgNo: $faTgNo, kosTgSndNo: $kosTgSndNo, tgSndDtm: $tgSndDtm, tgRcvDtm: $tgRcvDtm, resCd: $resCd, rsrvItmH: $rsrvItmH, lndDsc: $lndDsc, lndKndCd: $lndKndCd, fndUseCd: $fndUseCd, bnkLndProdtCd: $bnkLndProdtCd, bnkLndProdtNm: $bnkLndProdtNm, stndAplYn: $stndAplYn, mvLwyrCnfmYn: $mvLwyrCnfmYn, rgstrUnqNo1: $rgstrUnqNo1, rgstrUnqNo2: $rgstrUnqNo2, rgstrUnqNo3: $rgstrUnqNo3, rgstrUnqNo4: $rgstrUnqNo4, rgstrUnqNo5: $rgstrUnqNo5, rlesDsc: $rlesDsc, trgtRlesDsc: $trgtRlesDsc, trgtRlesAddr: $trgtRlesAddr, bfAskDt: $bfAskDt, lndPlnDt: $lndPlnDt, slPrc: $slPrc, scrtevlAmt: $scrtevlAmt, isrnEntrAmt: $isrnEntrAmt, lndAmt: $lndAmt, bnkfxcltRgstrRnk: $bnkfxcltRgstrRnk, dbrtNm: $dbrtNm, dbtrBirthDt: $dbtrBirthDt, dbtrAddr: $dbtrAddr, dbtrPhno: $dbtrPhno, dbtrHpno: $dbtrHpno, pwpsNm: $pwpsNm, pwpsBirthDt: $pwpsBirthDt, pwpsAddr: $pwpsAddr, pwpsPhno: $pwpsPhno, pwpsHpno: $pwpsHpno, rmkFct: $rmkFct, lndHndgSlfDsc: $lndHndgSlfDsc, bnkBrnchNm: $bnkBrnchNm, bnkDrctrNm: $bnkDrctrNm, bnkBrnchPhno: $bnkBrnchPhno, bnkDrctrHp: $bnkDrctrHp, bnkBrnchFax: $bnkBrnchFax, bnkBrnchAddr: $bnkBrnchAddr, slmnCmpyNm: $slmnCmpyNm, slmnNm: $slmnNm, slmnPhno: $slmnPhno, rfrLnAprvNo: $rfrLnAprvNo, rgstrMtdDsc: $rgstrMtdDsc, odprtRpyEane: $odprtRpyEane, eltnEstbsLwyrNm: $eltnEstbsLwyrNm, eltnEstbsLwyrBizNo: $eltnEstbsLwyrBizNo, slCntrctEane: $slCntrctEane, slCntrctFlnm: $slCntrctFlnm, afrgstrScrtYn: $afrgstrScrtYn, bnkBrnchCd: $bnkBrnchCd, rsrvItmB: $rsrvItmB, regDtm: $regDtm, trgtRlesAddr2: $trgtRlesAddr2, addrSrchYn: $addrSrchYn, cnvntLwyrYn: $cnvntLwyrYn, lnAprvNo2: $lnAprvNo2)';
  }

  @override
  bool operator ==(covariant TrnsSendReqData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.newLoanNo == newLoanNo &&
          other.tgLen == tgLen &&
          other.tgDsc == tgDsc &&
          other.bnkTgNo == bnkTgNo &&
          other.faTgNo == faTgNo &&
          other.kosTgSndNo == kosTgSndNo &&
          other.tgSndDtm == tgSndDtm &&
          other.tgRcvDtm == tgRcvDtm &&
          other.resCd == resCd &&
          other.rsrvItmH == rsrvItmH &&
          other.lndDsc == lndDsc &&
          other.lndKndCd == lndKndCd &&
          other.fndUseCd == fndUseCd &&
          other.bnkLndProdtCd == bnkLndProdtCd &&
          other.bnkLndProdtNm == bnkLndProdtNm &&
          other.stndAplYn == stndAplYn &&
          other.mvLwyrCnfmYn == mvLwyrCnfmYn &&
          other.rgstrUnqNo1 == rgstrUnqNo1 &&
          other.rgstrUnqNo2 == rgstrUnqNo2 &&
          other.rgstrUnqNo3 == rgstrUnqNo3 &&
          other.rgstrUnqNo4 == rgstrUnqNo4 &&
          other.rgstrUnqNo5 == rgstrUnqNo5 &&
          other.rlesDsc == rlesDsc &&
          other.trgtRlesDsc == trgtRlesDsc &&
          other.trgtRlesAddr == trgtRlesAddr &&
          other.bfAskDt == bfAskDt &&
          other.lndPlnDt == lndPlnDt &&
          other.slPrc == slPrc &&
          other.scrtevlAmt == scrtevlAmt &&
          other.isrnEntrAmt == isrnEntrAmt &&
          other.lndAmt == lndAmt &&
          other.bnkfxcltRgstrRnk == bnkfxcltRgstrRnk &&
          other.dbrtNm == dbrtNm &&
          other.dbtrBirthDt == dbtrBirthDt &&
          other.dbtrAddr == dbtrAddr &&
          other.dbtrPhno == dbtrPhno &&
          other.dbtrHpno == dbtrHpno &&
          other.pwpsNm == pwpsNm &&
          other.pwpsBirthDt == pwpsBirthDt &&
          other.pwpsAddr == pwpsAddr &&
          other.pwpsPhno == pwpsPhno &&
          other.pwpsHpno == pwpsHpno &&
          other.rmkFct == rmkFct &&
          other.lndHndgSlfDsc == lndHndgSlfDsc &&
          other.bnkBrnchNm == bnkBrnchNm &&
          other.bnkDrctrNm == bnkDrctrNm &&
          other.bnkBrnchPhno == bnkBrnchPhno &&
          other.bnkDrctrHp == bnkDrctrHp &&
          other.bnkBrnchFax == bnkBrnchFax &&
          other.bnkBrnchAddr == bnkBrnchAddr &&
          other.slmnCmpyNm == slmnCmpyNm &&
          other.slmnNm == slmnNm &&
          other.slmnPhno == slmnPhno &&
          other.rfrLnAprvNo == rfrLnAprvNo &&
          other.rgstrMtdDsc == rgstrMtdDsc &&
          other.odprtRpyEane == odprtRpyEane &&
          other.eltnEstbsLwyrNm == eltnEstbsLwyrNm &&
          other.eltnEstbsLwyrBizNo == eltnEstbsLwyrBizNo &&
          other.slCntrctEane == slCntrctEane &&
          other.slCntrctFlnm == slCntrctFlnm &&
          other.afrgstrScrtYn == afrgstrScrtYn &&
          other.bnkBrnchCd == bnkBrnchCd &&
          other.rsrvItmB == rsrvItmB &&
          other.regDtm == regDtm &&
          other.trgtRlesAddr2 == trgtRlesAddr2 &&
          other.addrSrchYn == addrSrchYn &&
          other.cnvntLwyrYn == cnvntLwyrYn &&
          other.lnAprvNo2 == lnAprvNo2;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    newLoanNo.hashCode ^
    tgLen.hashCode ^
    tgDsc.hashCode ^
    bnkTgNo.hashCode ^
    faTgNo.hashCode ^
    kosTgSndNo.hashCode ^
    tgSndDtm.hashCode ^
    tgRcvDtm.hashCode ^
    resCd.hashCode ^
    rsrvItmH.hashCode ^
    lndDsc.hashCode ^
    lndKndCd.hashCode ^
    fndUseCd.hashCode ^
    bnkLndProdtCd.hashCode ^
    bnkLndProdtNm.hashCode ^
    stndAplYn.hashCode ^
    mvLwyrCnfmYn.hashCode ^
    rgstrUnqNo1.hashCode ^
    rgstrUnqNo2.hashCode ^
    rgstrUnqNo3.hashCode ^
    rgstrUnqNo4.hashCode ^
    rgstrUnqNo5.hashCode ^
    rlesDsc.hashCode ^
    trgtRlesDsc.hashCode ^
    trgtRlesAddr.hashCode ^
    bfAskDt.hashCode ^
    lndPlnDt.hashCode ^
    slPrc.hashCode ^
    scrtevlAmt.hashCode ^
    isrnEntrAmt.hashCode ^
    lndAmt.hashCode ^
    bnkfxcltRgstrRnk.hashCode ^
    dbrtNm.hashCode ^
    dbtrBirthDt.hashCode ^
    dbtrAddr.hashCode ^
    dbtrPhno.hashCode ^
    dbtrHpno.hashCode ^
    pwpsNm.hashCode ^
    pwpsBirthDt.hashCode ^
    pwpsAddr.hashCode ^
    pwpsPhno.hashCode ^
    pwpsHpno.hashCode ^
    rmkFct.hashCode ^
    lndHndgSlfDsc.hashCode ^
    bnkBrnchNm.hashCode ^
    bnkDrctrNm.hashCode ^
    bnkBrnchPhno.hashCode ^
    bnkDrctrHp.hashCode ^
    bnkBrnchFax.hashCode ^
    bnkBrnchAddr.hashCode ^
    slmnCmpyNm.hashCode ^
    slmnNm.hashCode ^
    slmnPhno.hashCode ^
    rfrLnAprvNo.hashCode ^
    rgstrMtdDsc.hashCode ^
    odprtRpyEane.hashCode ^
    eltnEstbsLwyrNm.hashCode ^
    eltnEstbsLwyrBizNo.hashCode ^
    slCntrctEane.hashCode ^
    slCntrctFlnm.hashCode ^
    afrgstrScrtYn.hashCode ^
    bnkBrnchCd.hashCode ^
    rsrvItmB.hashCode ^
    regDtm.hashCode ^
    trgtRlesAddr2.hashCode ^
    addrSrchYn.hashCode ^
    cnvntLwyrYn.hashCode ^
    lnAprvNo2.hashCode;
  }
}

class TrnsSendResData {
  int? tgLen;
  String? tgDsc;
  String? bnkTgNo;
  String? faTgNo;
  String? kosTgSndNo;
  String? tgSndDtm;
  String? tgRcvDtm;
  String? resCd;
  String? rsrvItmH;
  String? lndDsc;
  String? lndKndCd;
  String? fndUseCd;
  String? bnkLndPrdtCd;
  String? bnkLndPrdtNm;
  String? stndAplYn;
  String? mvLwyrCnfmYn;
  String? rgstrUnqNo1;
  String? rgstrUnqNo2;
  String? rgstrUnqNo3;
  String? rgstrUnqNo4;
  String? rgstrUnqNo5;
  String? rlesDsc;
  String? trgtRlesDsc;
  String? trgtRlesAddr;
  String? bfAskDt;
  String? lndPlnDt;
  int? slPrc;
  String? scrtevlAmt;
  String? isrnEntrAmt;
  int? lndAmt;
  int? bnkfxcltRgstrRnk;
  String? dbrtNm;
  String? dbtrBirthDt;
  String? dbtrAddr;
  String? dbtrPhno;
  String? dbtrHpno;
  String? pwpsNm;
  String? pwpsBirthDt;
  String? pwpsAddr;
  String? pwpsPhno;
  String? pwpsHpno;
  String? rmkFct;
  String? lndHndgSlfDsc;
  String? bnkBrnchNm;
  String? bnkDrctrNm;
  String? bnkBrnchPhno;
  String? drctrHp;
  String? bnkBrnchFax;
  String? bnkBrnchAddr;
  String? slmnCmpyNM;
  String? slmnNm;
  String? slmnPhno;
  String? rfrLnAprvNo;
  String? rgstrMtdDsc;
  String? odprtRpyEane;
  String? eltnEstbsLwyrNm;
  String? eltnEstbsLwyrBizNo;
  String? slCntrctEane;
  String? slCntrctFlnm;
  String? afrgstrScrtYn;
  String? bnkBrnchCd;
  String? rsrvItmB;
  String? regDtm;
  String? trgtRlesAddr2;
  String? addrSrchYn;
  String? cnvntLwyrYn;
  String? lnAprvNo2;
  TrnsSendResData({
    this.tgLen,
    this.tgDsc,
    this.bnkTgNo,
    this.faTgNo,
    this.kosTgSndNo,
    this.tgSndDtm,
    this.tgRcvDtm,
    this.resCd,
    this.rsrvItmH,
    this.lndDsc,
    this.lndKndCd,
    this.fndUseCd,
    this.bnkLndPrdtCd,
    this.bnkLndPrdtNm,
    this.stndAplYn,
    this.mvLwyrCnfmYn,
    this.rgstrUnqNo1,
    this.rgstrUnqNo2,
    this.rgstrUnqNo3,
    this.rgstrUnqNo4,
    this.rgstrUnqNo5,
    this.rlesDsc,
    this.trgtRlesDsc,
    this.trgtRlesAddr,
    this.bfAskDt,
    this.lndPlnDt,
    this.slPrc,
    this.scrtevlAmt,
    this.isrnEntrAmt,
    this.lndAmt,
    this.bnkfxcltRgstrRnk,
    this.dbrtNm,
    this.dbtrBirthDt,
    this.dbtrAddr,
    this.dbtrPhno,
    this.dbtrHpno,
    this.pwpsNm,
    this.pwpsBirthDt,
    this.pwpsAddr,
    this.pwpsPhno,
    this.pwpsHpno,
    this.rmkFct,
    this.lndHndgSlfDsc,
    this.bnkBrnchNm,
    this.bnkDrctrNm,
    this.bnkBrnchPhno,
    this.drctrHp,
    this.bnkBrnchFax,
    this.bnkBrnchAddr,
    this.slmnCmpyNM,
    this.slmnNm,
    this.slmnPhno,
    this.rfrLnAprvNo,
    this.rgstrMtdDsc,
    this.odprtRpyEane,
    this.eltnEstbsLwyrNm,
    this.eltnEstbsLwyrBizNo,
    this.slCntrctEane,
    this.slCntrctFlnm,
    this.afrgstrScrtYn,
    this.bnkBrnchCd,
    this.rsrvItmB,
    this.regDtm,
    this.trgtRlesAddr2,
    this.addrSrchYn,
    this.cnvntLwyrYn,
    this.lnAprvNo2,
  });

  TrnsSendResData copyWith({
    int? tgLen,
    String? tgDsc,
    String? bnkTgNo,
    String? faTgNo,
    String? kosTgSndNo,
    String? tgSndDtm,
    String? tgRcvDtm,
    String? resCd,
    String? rsrvItmH,
    String? lndDsc,
    String? lndKndCd,
    String? fndUseCd,
    String? bnkLndPrdtCd,
    String? bnkLndPrdtNm,
    String? stndAplYn,
    String? mvLwyrCnfmYn,
    String? rgstrUnqNo1,
    String? rgstrUnqNo2,
    String? rgstrUnqNo3,
    String? rgstrUnqNo4,
    String? rgstrUnqNo5,
    String? rlesDsc,
    String? trgtRlesDsc,
    String? trgtRlesAddr,
    String? bfAskDt,
    String? lndPlnDt,
    int? slPrc,
    String? scrtevlAmt,
    String? isrnEntrAmt,
    int? lndAmt,
    int? bnkfxcltRgstrRnk,
    String? dbrtNm,
    String? dbtrBirthDt,
    String? dbtrAddr,
    String? dbtrPhno,
    String? dbtrHpno,
    String? pwpsNm,
    String? pwpsBirthDt,
    String? pwpsAddr,
    String? pwpsPhno,
    String? pwpsHpno,
    String? rmkFct,
    String? lndHndgSlfDsc,
    String? bnkBrnchNm,
    String? bnkDrctrNm,
    String? bnkBrnchPhno,
    String? drctrHp,
    String? bnkBrnchFax,
    String? bnkBrnchAddr,
    String? slmnCmpyNM,
    String? slmnNm,
    String? slmnPhno,
    String? rfrLnAprvNo,
    String? rgstrMtdDsc,
    String? odprtRpyEane,
    String? eltnEstbsLwyrNm,
    String? eltnEstbsLwyrBizNo,
    String? slCntrctEane,
    String? slCntrctFlnm,
    String? afrgstrScrtYn,
    String? bnkBrnchCd,
    String? rsrvItmB,
    String? regDtm,
    String? trgtRlesAddr2,
    String? addrSrchYn,
    String? cnvntLwyrYn,
    String? lnAprvNo2,
  }) {
    return TrnsSendResData(
      tgLen: tgLen ?? this.tgLen,
      tgDsc: tgDsc ?? this.tgDsc,
      bnkTgNo: bnkTgNo ?? this.bnkTgNo,
      faTgNo: faTgNo ?? this.faTgNo,
      kosTgSndNo: kosTgSndNo ?? this.kosTgSndNo,
      tgSndDtm: tgSndDtm ?? this.tgSndDtm,
      tgRcvDtm: tgRcvDtm ?? this.tgRcvDtm,
      resCd: resCd ?? this.resCd,
      rsrvItmH: rsrvItmH ?? this.rsrvItmH,
      lndDsc: lndDsc ?? this.lndDsc,
      lndKndCd: lndKndCd ?? this.lndKndCd,
      fndUseCd: fndUseCd ?? this.fndUseCd,
      bnkLndPrdtCd: bnkLndPrdtCd ?? this.bnkLndPrdtCd,
      bnkLndPrdtNm: bnkLndPrdtNm ?? this.bnkLndPrdtNm,
      stndAplYn: stndAplYn ?? this.stndAplYn,
      mvLwyrCnfmYn: mvLwyrCnfmYn ?? this.mvLwyrCnfmYn,
      rgstrUnqNo1: rgstrUnqNo1 ?? this.rgstrUnqNo1,
      rgstrUnqNo2: rgstrUnqNo2 ?? this.rgstrUnqNo2,
      rgstrUnqNo3: rgstrUnqNo3 ?? this.rgstrUnqNo3,
      rgstrUnqNo4: rgstrUnqNo4 ?? this.rgstrUnqNo4,
      rgstrUnqNo5: rgstrUnqNo5 ?? this.rgstrUnqNo5,
      rlesDsc: rlesDsc ?? this.rlesDsc,
      trgtRlesDsc: trgtRlesDsc ?? this.trgtRlesDsc,
      trgtRlesAddr: trgtRlesAddr ?? this.trgtRlesAddr,
      bfAskDt: bfAskDt ?? this.bfAskDt,
      lndPlnDt: lndPlnDt ?? this.lndPlnDt,
      slPrc: slPrc ?? this.slPrc,
      scrtevlAmt: scrtevlAmt ?? this.scrtevlAmt,
      isrnEntrAmt: isrnEntrAmt ?? this.isrnEntrAmt,
      lndAmt: lndAmt ?? this.lndAmt,
      bnkfxcltRgstrRnk: bnkfxcltRgstrRnk ?? this.bnkfxcltRgstrRnk,
      dbrtNm: dbrtNm ?? this.dbrtNm,
      dbtrBirthDt: dbtrBirthDt ?? this.dbtrBirthDt,
      dbtrAddr: dbtrAddr ?? this.dbtrAddr,
      dbtrPhno: dbtrPhno ?? this.dbtrPhno,
      dbtrHpno: dbtrHpno ?? this.dbtrHpno,
      pwpsNm: pwpsNm ?? this.pwpsNm,
      pwpsBirthDt: pwpsBirthDt ?? this.pwpsBirthDt,
      pwpsAddr: pwpsAddr ?? this.pwpsAddr,
      pwpsPhno: pwpsPhno ?? this.pwpsPhno,
      pwpsHpno: pwpsHpno ?? this.pwpsHpno,
      rmkFct: rmkFct ?? this.rmkFct,
      lndHndgSlfDsc: lndHndgSlfDsc ?? this.lndHndgSlfDsc,
      bnkBrnchNm: bnkBrnchNm ?? this.bnkBrnchNm,
      bnkDrctrNm: bnkDrctrNm ?? this.bnkDrctrNm,
      bnkBrnchPhno: bnkBrnchPhno ?? this.bnkBrnchPhno,
      drctrHp: drctrHp ?? this.drctrHp,
      bnkBrnchFax: bnkBrnchFax ?? this.bnkBrnchFax,
      bnkBrnchAddr: bnkBrnchAddr ?? this.bnkBrnchAddr,
      slmnCmpyNM: slmnCmpyNM ?? this.slmnCmpyNM,
      slmnNm: slmnNm ?? this.slmnNm,
      slmnPhno: slmnPhno ?? this.slmnPhno,
      rfrLnAprvNo: rfrLnAprvNo ?? this.rfrLnAprvNo,
      rgstrMtdDsc: rgstrMtdDsc ?? this.rgstrMtdDsc,
      odprtRpyEane: odprtRpyEane ?? this.odprtRpyEane,
      eltnEstbsLwyrNm: eltnEstbsLwyrNm ?? this.eltnEstbsLwyrNm,
      eltnEstbsLwyrBizNo: eltnEstbsLwyrBizNo ?? this.eltnEstbsLwyrBizNo,
      slCntrctEane: slCntrctEane ?? this.slCntrctEane,
      slCntrctFlnm: slCntrctFlnm ?? this.slCntrctFlnm,
      afrgstrScrtYn: afrgstrScrtYn ?? this.afrgstrScrtYn,
      bnkBrnchCd: bnkBrnchCd ?? this.bnkBrnchCd,
      rsrvItmB: rsrvItmB ?? this.rsrvItmB,
      regDtm: regDtm ?? this.regDtm,
      trgtRlesAddr2: trgtRlesAddr2 ?? this.trgtRlesAddr2,
      addrSrchYn: addrSrchYn ?? this.addrSrchYn,
      cnvntLwyrYn: cnvntLwyrYn ?? this.cnvntLwyrYn,
      lnAprvNo2: lnAprvNo2 ?? this.lnAprvNo2,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'tgLen': tgLen,
      'tgDsc': tgDsc,
      'bnkTgNo': bnkTgNo,
      'faTgNo': faTgNo,
      'kosTgSndNo': kosTgSndNo,
      'tgSndDtm': tgSndDtm,
      'tgRcvDtm': tgRcvDtm,
      'resCd': resCd,
      'rsrvItmH': rsrvItmH,
      'lndDsc': lndDsc,
      'lndKndCd': lndKndCd,
      'fndUseCd': fndUseCd,
      'bnkLndPrdtCd': bnkLndPrdtCd,
      'bnkLndPrdtNm': bnkLndPrdtNm,
      'stndAplYn': stndAplYn,
      'mvLwyrCnfmYn': mvLwyrCnfmYn,
      'rgstrUnqNo1': rgstrUnqNo1,
      'rgstrUnqNo2': rgstrUnqNo2,
      'rgstrUnqNo3': rgstrUnqNo3,
      'rgstrUnqNo4': rgstrUnqNo4,
      'rgstrUnqNo5': rgstrUnqNo5,
      'rlesDsc': rlesDsc,
      'trgtRlesDsc': trgtRlesDsc,
      'trgtRlesAddr': trgtRlesAddr,
      'bfAskDt': bfAskDt,
      'lndPlnDt': lndPlnDt,
      'slPrc': slPrc,
      'scrtevlAmt': scrtevlAmt,
      'isrnEntrAmt': isrnEntrAmt,
      'lndAmt': lndAmt,
      'bnkfxcltRgstrRnk': bnkfxcltRgstrRnk,
      'dbrtNm': dbrtNm,
      'dbtrBirthDt': dbtrBirthDt,
      'dbtrAddr': dbtrAddr,
      'dbtrPhno': dbtrPhno,
      'dbtrHpno': dbtrHpno,
      'pwpsNm': pwpsNm,
      'pwpsBirthDt': pwpsBirthDt,
      'pwpsAddr': pwpsAddr,
      'pwpsPhno': pwpsPhno,
      'pwpsHpno': pwpsHpno,
      'rmkFct': rmkFct,
      'lndHndgSlfDsc': lndHndgSlfDsc,
      'bnkBrnchNm': bnkBrnchNm,
      'bnkDrctrNm': bnkDrctrNm,
      'bnkBrnchPhno': bnkBrnchPhno,
      'drctrHp': drctrHp,
      'bnkBrnchFax': bnkBrnchFax,
      'bnkBrnchAddr': bnkBrnchAddr,
      'slmnCmpyNM': slmnCmpyNM,
      'slmnNm': slmnNm,
      'slmnPhno': slmnPhno,
      'rfrLnAprvNo': rfrLnAprvNo,
      'rgstrMtdDsc': rgstrMtdDsc,
      'odprtRpyEane': odprtRpyEane,
      'eltnEstbsLwyrNm': eltnEstbsLwyrNm,
      'eltnEstbsLwyrBizNo': eltnEstbsLwyrBizNo,
      'slCntrctEane': slCntrctEane,
      'slCntrctFlnm': slCntrctFlnm,
      'afrgstrScrtYn': afrgstrScrtYn,
      'bnkBrnchCd': bnkBrnchCd,
      'rsrvItmB': rsrvItmB,
      'regDtm': regDtm,
      'trgtRlesAddr2': trgtRlesAddr2,
      'addrSrchYn': addrSrchYn,
      'cnvntLwyrYn': cnvntLwyrYn,
      'lnAprvNo2': lnAprvNo2,
    };
  }

  factory TrnsSendResData.fromMap(Map<String, dynamic> map) {
    return TrnsSendResData(
      tgLen: map['tgLen'] != null ? map['tgLen'] as int : null,
      tgDsc: map['tgDsc'] != null ? map['tgDsc'] as String : null,
      bnkTgNo: map['bnkTgNo'] != null ? map['bnkTgNo'] as String : null,
      faTgNo: map['faTgNo'] != null ? map['faTgNo'] as String : null,
      kosTgSndNo: map['kosTgSndNo'] != null ? map['kosTgSndNo'] as String : null,
      tgSndDtm: map['tgSndDtm'] != null ? map['tgSndDtm'] as String : null,
      tgRcvDtm: map['tgRcvDtm'] != null ? map['tgRcvDtm'] as String : null,
      resCd: map['resCd'] != null ? map['resCd'] as String : null,
      rsrvItmH: map['rsrvItmH'] != null ? map['rsrvItmH'] as String : null,
      lndDsc: map['lndDsc'] != null ? map['lndDsc'] as String : null,
      lndKndCd: map['lndKndCd'] != null ? map['lndKndCd'] as String : null,
      fndUseCd: map['fndUseCd'] != null ? map['fndUseCd'] as String : null,
      bnkLndPrdtCd: map['bnkLndPrdtCd'] != null ? map['bnkLndPrdtCd'] as String : null,
      bnkLndPrdtNm: map['bnkLndPrdtNm'] != null ? map['bnkLndPrdtNm'] as String : null,
      stndAplYn: map['stndAplYn'] != null ? map['stndAplYn'] as String : null,
      mvLwyrCnfmYn: map['mvLwyrCnfmYn'] != null ? map['mvLwyrCnfmYn'] as String : null,
      rgstrUnqNo1: map['rgstrUnqNo1'] != null ? map['rgstrUnqNo1'] as String : null,
      rgstrUnqNo2: map['rgstrUnqNo2'] != null ? map['rgstrUnqNo2'] as String : null,
      rgstrUnqNo3: map['rgstrUnqNo3'] != null ? map['rgstrUnqNo3'] as String : null,
      rgstrUnqNo4: map['rgstrUnqNo4'] != null ? map['rgstrUnqNo4'] as String : null,
      rgstrUnqNo5: map['rgstrUnqNo5'] != null ? map['rgstrUnqNo5'] as String : null,
      rlesDsc: map['rlesDsc'] != null ? map['rlesDsc'] as String : null,
      trgtRlesDsc: map['trgtRlesDsc'] != null ? map['trgtRlesDsc'] as String : null,
      trgtRlesAddr: map['trgtRlesAddr'] != null ? map['trgtRlesAddr'] as String : null,
      bfAskDt: map['bfAskDt'] != null ? map['bfAskDt'] as String : null,
      lndPlnDt: map['lndPlnDt'] != null ? map['lndPlnDt'] as String : null,
      slPrc: map['slPrc'] != null ? map['slPrc'] as int : null,
      scrtevlAmt: map['scrtevlAmt'] != null ? map['scrtevlAmt'] as String : null,
      isrnEntrAmt: map['isrnEntrAmt'] != null ? map['isrnEntrAmt'] as String : null,
      lndAmt: map['lndAmt'] != null ? map['lndAmt'] as int : null,
      bnkfxcltRgstrRnk: map['bnkfxcltRgstrRnk'] != null ? map['bnkfxcltRgstrRnk'] as int : null,
      dbrtNm: map['dbrtNm'] != null ? map['dbrtNm'] as String : null,
      dbtrBirthDt: map['dbtrBirthDt'] != null ? map['dbtrBirthDt'] as String : null,
      dbtrAddr: map['dbtrAddr'] != null ? map['dbtrAddr'] as String : null,
      dbtrPhno: map['dbtrPhno'] != null ? map['dbtrPhno'] as String : null,
      dbtrHpno: map['dbtrHpno'] != null ? map['dbtrHpno'] as String : null,
      pwpsNm: map['pwpsNm'] != null ? map['pwpsNm'] as String : null,
      pwpsBirthDt: map['pwpsBirthDt'] != null ? map['pwpsBirthDt'] as String : null,
      pwpsAddr: map['pwpsAddr'] != null ? map['pwpsAddr'] as String : null,
      pwpsPhno: map['pwpsPhno'] != null ? map['pwpsPhno'] as String : null,
      pwpsHpno: map['pwpsHpno'] != null ? map['pwpsHpno'] as String : null,
      rmkFct: map['rmkFct'] != null ? map['rmkFct'] as String : null,
      lndHndgSlfDsc: map['lndHndgSlfDsc'] != null ? map['lndHndgSlfDsc'] as String : null,
      bnkBrnchNm: map['bnkBrnchNm'] != null ? map['bnkBrnchNm'] as String : null,
      bnkDrctrNm: map['bnkDrctrNm'] != null ? map['bnkDrctrNm'] as String : null,
      bnkBrnchPhno: map['bnkBrnchPhno'] != null ? map['bnkBrnchPhno'] as String : null,
      drctrHp: map['drctrHp'] != null ? map['drctrHp'] as String : null,
      bnkBrnchFax: map['bnkBrnchFax'] != null ? map['bnkBrnchFax'] as String : null,
      bnkBrnchAddr: map['bnkBrnchAddr'] != null ? map['bnkBrnchAddr'] as String : null,
      slmnCmpyNM: map['slmnCmpyNM'] != null ? map['slmnCmpyNM'] as String : null,
      slmnNm: map['slmnNm'] != null ? map['slmnNm'] as String : null,
      slmnPhno: map['slmnPhno'] != null ? map['slmnPhno'] as String : null,
      rfrLnAprvNo: map['rfrLnAprvNo'] != null ? map['rfrLnAprvNo'] as String : null,
      rgstrMtdDsc: map['rgstrMtdDsc'] != null ? map['rgstrMtdDsc'] as String : null,
      odprtRpyEane: map['odprtRpyEane'] != null ? map['odprtRpyEane'] as String : null,
      eltnEstbsLwyrNm: map['eltnEstbsLwyrNm'] != null ? map['eltnEstbsLwyrNm'] as String : null,
      eltnEstbsLwyrBizNo: map['eltnEstbsLwyrBizNo'] != null ? map['eltnEstbsLwyrBizNo'] as String : null,
      slCntrctEane: map['slCntrctEane'] != null ? map['slCntrctEane'] as String : null,
      slCntrctFlnm: map['slCntrctFlnm'] != null ? map['slCntrctFlnm'] as String : null,
      afrgstrScrtYn: map['afrgstrScrtYn'] != null ? map['afrgstrScrtYn'] as String : null,
      bnkBrnchCd: map['bnkBrnchCd'] != null ? map['bnkBrnchCd'] as String : null,
      rsrvItmB: map['rsrvItmB'] != null ? map['rsrvItmB'] as String : null,
      regDtm: map['regDtm'] != null ? map['regDtm'] as String : null,
      trgtRlesAddr2: map['trgtRlesAddr2'] != null ? map['trgtRlesAddr2'] as String : null,
      addrSrchYn: map['addrSrchYn'] != null ? map['addrSrchYn'] as String : null,
      cnvntLwyrYn: map['cnvntLwyrYn'] != null ? map['cnvntLwyrYn'] as String : null,
      lnAprvNo2: map['lnAprvNo2'] != null ? map['lnAprvNo2'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnsSendResData.fromJson(String source) => TrnsSendResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TrnsSendResData(tgLen: $tgLen, tgDsc: $tgDsc, bnkTgNo: $bnkTgNo, faTgNo: $faTgNo, kosTgSndNo: $kosTgSndNo, tgSndDtm: $tgSndDtm, tgRcvDtm: $tgRcvDtm, resCd: $resCd, rsrvItmH: $rsrvItmH, lndDsc: $lndDsc, lndKndCd: $lndKndCd, fndUseCd: $fndUseCd, bnkLndPrdtCd: $bnkLndPrdtCd, bnkLndPrdtNm: $bnkLndPrdtNm, stndAplYn: $stndAplYn, mvLwyrCnfmYn: $mvLwyrCnfmYn, rgstrUnqNo1: $rgstrUnqNo1, rgstrUnqNo2: $rgstrUnqNo2, rgstrUnqNo3: $rgstrUnqNo3, rgstrUnqNo4: $rgstrUnqNo4, rgstrUnqNo5: $rgstrUnqNo5, rlesDsc: $rlesDsc, trgtRlesDsc: $trgtRlesDsc, trgtRlesAddr: $trgtRlesAddr, bfAskDt: $bfAskDt, lndPlnDt: $lndPlnDt, slPrc: $slPrc, scrtevlAmt: $scrtevlAmt, isrnEntrAmt: $isrnEntrAmt, lndAmt: $lndAmt, bnkfxcltRgstrRnk: $bnkfxcltRgstrRnk, dbrtNm: $dbrtNm, dbtrBirthDt: $dbtrBirthDt, dbtrAddr: $dbtrAddr, dbtrPhno: $dbtrPhno, dbtrHpno: $dbtrHpno, pwpsNm: $pwpsNm, pwpsBirthDt: $pwpsBirthDt, pwpsAddr: $pwpsAddr, pwpsPhno: $pwpsPhno, pwpsHpno: $pwpsHpno, rmkFct: $rmkFct, lndHndgSlfDsc: $lndHndgSlfDsc, bnkBrnchNm: $bnkBrnchNm, bnkDrctrNm: $bnkDrctrNm, bnkBrnchPhno: $bnkBrnchPhno, drctrHp: $drctrHp, bnkBrnchFax: $bnkBrnchFax, bnkBrnchAddr: $bnkBrnchAddr, slmnCmpyNM: $slmnCmpyNM, slmnNm: $slmnNm, slmnPhno: $slmnPhno, rfrLnAprvNo: $rfrLnAprvNo, rgstrMtdDsc: $rgstrMtdDsc, odprtRpyEane: $odprtRpyEane, eltnEstbsLwyrNm: $eltnEstbsLwyrNm, eltnEstbsLwyrBizNo: $eltnEstbsLwyrBizNo, slCntrctEane: $slCntrctEane, slCntrctFlnm: $slCntrctFlnm, afrgstrScrtYn: $afrgstrScrtYn, bnkBrnchCd: $bnkBrnchCd, rsrvItmB: $rsrvItmB, regDtm: $regDtm, trgtRlesAddr2: $trgtRlesAddr2, addrSrchYn: $addrSrchYn, cnvntLwyrYn: $cnvntLwyrYn, lnAprvNo2: $lnAprvNo2)';
  }

  @override
  bool operator ==(covariant TrnsSendResData other) {
    if (identical(this, other)) return true;

    return
      other.tgLen == tgLen &&
          other.tgDsc == tgDsc &&
          other.bnkTgNo == bnkTgNo &&
          other.faTgNo == faTgNo &&
          other.kosTgSndNo == kosTgSndNo &&
          other.tgSndDtm == tgSndDtm &&
          other.tgRcvDtm == tgRcvDtm &&
          other.resCd == resCd &&
          other.rsrvItmH == rsrvItmH &&
          other.lndDsc == lndDsc &&
          other.lndKndCd == lndKndCd &&
          other.fndUseCd == fndUseCd &&
          other.bnkLndPrdtCd == bnkLndPrdtCd &&
          other.bnkLndPrdtNm == bnkLndPrdtNm &&
          other.stndAplYn == stndAplYn &&
          other.mvLwyrCnfmYn == mvLwyrCnfmYn &&
          other.rgstrUnqNo1 == rgstrUnqNo1 &&
          other.rgstrUnqNo2 == rgstrUnqNo2 &&
          other.rgstrUnqNo3 == rgstrUnqNo3 &&
          other.rgstrUnqNo4 == rgstrUnqNo4 &&
          other.rgstrUnqNo5 == rgstrUnqNo5 &&
          other.rlesDsc == rlesDsc &&
          other.trgtRlesDsc == trgtRlesDsc &&
          other.trgtRlesAddr == trgtRlesAddr &&
          other.bfAskDt == bfAskDt &&
          other.lndPlnDt == lndPlnDt &&
          other.slPrc == slPrc &&
          other.scrtevlAmt == scrtevlAmt &&
          other.isrnEntrAmt == isrnEntrAmt &&
          other.lndAmt == lndAmt &&
          other.bnkfxcltRgstrRnk == bnkfxcltRgstrRnk &&
          other.dbrtNm == dbrtNm &&
          other.dbtrBirthDt == dbtrBirthDt &&
          other.dbtrAddr == dbtrAddr &&
          other.dbtrPhno == dbtrPhno &&
          other.dbtrHpno == dbtrHpno &&
          other.pwpsNm == pwpsNm &&
          other.pwpsBirthDt == pwpsBirthDt &&
          other.pwpsAddr == pwpsAddr &&
          other.pwpsPhno == pwpsPhno &&
          other.pwpsHpno == pwpsHpno &&
          other.rmkFct == rmkFct &&
          other.lndHndgSlfDsc == lndHndgSlfDsc &&
          other.bnkBrnchNm == bnkBrnchNm &&
          other.bnkDrctrNm == bnkDrctrNm &&
          other.bnkBrnchPhno == bnkBrnchPhno &&
          other.drctrHp == drctrHp &&
          other.bnkBrnchFax == bnkBrnchFax &&
          other.bnkBrnchAddr == bnkBrnchAddr &&
          other.slmnCmpyNM == slmnCmpyNM &&
          other.slmnNm == slmnNm &&
          other.slmnPhno == slmnPhno &&
          other.rfrLnAprvNo == rfrLnAprvNo &&
          other.rgstrMtdDsc == rgstrMtdDsc &&
          other.odprtRpyEane == odprtRpyEane &&
          other.eltnEstbsLwyrNm == eltnEstbsLwyrNm &&
          other.eltnEstbsLwyrBizNo == eltnEstbsLwyrBizNo &&
          other.slCntrctEane == slCntrctEane &&
          other.slCntrctFlnm == slCntrctFlnm &&
          other.afrgstrScrtYn == afrgstrScrtYn &&
          other.bnkBrnchCd == bnkBrnchCd &&
          other.rsrvItmB == rsrvItmB &&
          other.regDtm == regDtm &&
          other.trgtRlesAddr2 == trgtRlesAddr2 &&
          other.addrSrchYn == addrSrchYn &&
          other.cnvntLwyrYn == cnvntLwyrYn &&
          other.lnAprvNo2 == lnAprvNo2;
  }

  @override
  int get hashCode {
    return tgLen.hashCode ^
    tgDsc.hashCode ^
    bnkTgNo.hashCode ^
    faTgNo.hashCode ^
    kosTgSndNo.hashCode ^
    tgSndDtm.hashCode ^
    tgRcvDtm.hashCode ^
    resCd.hashCode ^
    rsrvItmH.hashCode ^
    lndDsc.hashCode ^
    lndKndCd.hashCode ^
    fndUseCd.hashCode ^
    bnkLndPrdtCd.hashCode ^
    bnkLndPrdtNm.hashCode ^
    stndAplYn.hashCode ^
    mvLwyrCnfmYn.hashCode ^
    rgstrUnqNo1.hashCode ^
    rgstrUnqNo2.hashCode ^
    rgstrUnqNo3.hashCode ^
    rgstrUnqNo4.hashCode ^
    rgstrUnqNo5.hashCode ^
    rlesDsc.hashCode ^
    trgtRlesDsc.hashCode ^
    trgtRlesAddr.hashCode ^
    bfAskDt.hashCode ^
    lndPlnDt.hashCode ^
    slPrc.hashCode ^
    scrtevlAmt.hashCode ^
    isrnEntrAmt.hashCode ^
    lndAmt.hashCode ^
    bnkfxcltRgstrRnk.hashCode ^
    dbrtNm.hashCode ^
    dbtrBirthDt.hashCode ^
    dbtrAddr.hashCode ^
    dbtrPhno.hashCode ^
    dbtrHpno.hashCode ^
    pwpsNm.hashCode ^
    pwpsBirthDt.hashCode ^
    pwpsAddr.hashCode ^
    pwpsPhno.hashCode ^
    pwpsHpno.hashCode ^
    rmkFct.hashCode ^
    lndHndgSlfDsc.hashCode ^
    bnkBrnchNm.hashCode ^
    bnkDrctrNm.hashCode ^
    bnkBrnchPhno.hashCode ^
    drctrHp.hashCode ^
    bnkBrnchFax.hashCode ^
    bnkBrnchAddr.hashCode ^
    slmnCmpyNM.hashCode ^
    slmnNm.hashCode ^
    slmnPhno.hashCode ^
    rfrLnAprvNo.hashCode ^
    rgstrMtdDsc.hashCode ^
    odprtRpyEane.hashCode ^
    eltnEstbsLwyrNm.hashCode ^
    eltnEstbsLwyrBizNo.hashCode ^
    slCntrctEane.hashCode ^
    slCntrctFlnm.hashCode ^
    afrgstrScrtYn.hashCode ^
    bnkBrnchCd.hashCode ^
    rsrvItmB.hashCode ^
    regDtm.hashCode ^
    trgtRlesAddr2.hashCode ^
    addrSrchYn.hashCode ^
    cnvntLwyrYn.hashCode ^
    lnAprvNo2.hashCode;
  }
}

