import 'dart:convert';

class Trns6300DetailResData {
  String? loanNo;
  int? tgLen;
  String? tgDsc;
  int? bnkTgNo;
  int? faTgNo;
  int? kosTgSndNo;
  String? tgSndDtm;
  String? tgRcvDtm;
  String? resCd;
  String? rsrvItmH;
  String? bnkTtlReqNo;
  String? lndPrgsStc;
  String? prgsDt;
  String? sbmtDocLst;
  int? mvhrHshldrRno;
  String? mvhrTrgtThngAddr;
  String? mvhrHshldrNmMvinDt;
  String? mvhrdtm;
  String? rsrvItmB;
  String? regDtm;
  String? lnAprvNo2;

  Trns6300DetailResData({
    this.loanNo,
    this.tgLen,
    this.tgDsc,
    this.bnkTgNo,
    this.faTgNo,
    this.kosTgSndNo,
    this.tgSndDtm,
    this.tgRcvDtm,
    this.resCd,
    this.rsrvItmH,
    this.bnkTtlReqNo,
    this.lndPrgsStc,
    this.prgsDt,
    this.sbmtDocLst,
    this.mvhrHshldrRno,
    this.mvhrTrgtThngAddr,
    this.mvhrHshldrNmMvinDt,
    this.mvhrdtm,
    this.rsrvItmB,
    this.regDtm,
    this.lnAprvNo2,
  });

  Trns6300DetailResData copyWith({
    String? loanNo,
    int? tgLen,
    String? tgDsc,
    int? bnkTgNo,
    int? faTgNo,
    int? kosTgSndNo,
    String? tgSndDtm,
    String? tgRcvDtm,
    String? resCd,
    String? rsrvItmH,
    String? bnkTtlReqNo,
    String? lndPrgsStc,
    String? prgsDt,
    String? sbmtDocLst,
    int? mvhrHshldrRno,
    String? mvhrTrgtThngAddr,
    String? mvhrHshldrNmMvinDt,
    String? mvhrdtm,
    String? rsrvItmB,
    String? regDtm,
    String? lnAprvNo2,
  }) {
    return Trns6300DetailResData(
      loanNo: loanNo ?? this.loanNo,
      tgLen: tgLen ?? this.tgLen,
      tgDsc: tgDsc ?? this.tgDsc,
      bnkTgNo: bnkTgNo ?? this.bnkTgNo,
      faTgNo: faTgNo ?? this.faTgNo,
      kosTgSndNo: kosTgSndNo ?? this.kosTgSndNo,
      tgSndDtm: tgSndDtm ?? this.tgSndDtm,
      tgRcvDtm: tgRcvDtm ?? this.tgRcvDtm,
      resCd: resCd ?? this.resCd,
      rsrvItmH: rsrvItmH ?? this.rsrvItmH,
      bnkTtlReqNo: bnkTtlReqNo ?? this.bnkTtlReqNo,
      lndPrgsStc: lndPrgsStc ?? this.lndPrgsStc,
      prgsDt: prgsDt ?? this.prgsDt,
      sbmtDocLst: sbmtDocLst ?? this.sbmtDocLst,
      mvhrHshldrRno: mvhrHshldrRno ?? this.mvhrHshldrRno,
      mvhrTrgtThngAddr: mvhrTrgtThngAddr ?? this.mvhrTrgtThngAddr,
      mvhrHshldrNmMvinDt: mvhrHshldrNmMvinDt ?? this.mvhrHshldrNmMvinDt,
      mvhrdtm: mvhrdtm ?? this.mvhrdtm,
      rsrvItmB: rsrvItmB ?? this.rsrvItmB,
      regDtm: regDtm ?? this.regDtm,
      lnAprvNo2: lnAprvNo2 ?? this.lnAprvNo2,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'tgLen': tgLen,
      'tgDsc': tgDsc,
      'bnkTgNo': bnkTgNo,
      'faTgNo': faTgNo,
      'kosTgSndNo': kosTgSndNo,
      'tgSndDtm': tgSndDtm,
      'tgRcvDtm': tgRcvDtm,
      'resCd': resCd,
      'rsrvItmH': rsrvItmH,
      'bnkTtlReqNo': bnkTtlReqNo,
      'lndPrgsStc': lndPrgsStc,
      'prgsDt': prgsDt,
      'sbmtDocLst': sbmtDocLst,
      'mvhrHshldrRno': mvhrHshldrRno,
      'mvhrTrgtThngAddr': mvhrTrgtThngAddr,
      'mvhrHshldrNmMvinDt': mvhrHshldrNmMvinDt,
      'mvhrdtm': mvhrdtm,
      'rsrvItmB': rsrvItmB,
      'regDtm': regDtm,
      'lnAprvNo2': lnAprvNo2,
    };
  }

  factory Trns6300DetailResData.fromMap(Map<String, dynamic> map) {
    return Trns6300DetailResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      tgLen: map['tgLen'] != null ? map['tgLen'] as int : null,
      tgDsc: map['tgDsc'] != null ? map['tgDsc'] as String : null,
      bnkTgNo: map['bnkTgNo'] != null ? map['bnkTgNo'] as int : null,
      faTgNo: map['faTgNo'] != null ? map['faTgNo'] as int : null,
      kosTgSndNo: map['kosTgSndNo'] != null ? map['kosTgSndNo'] as int : null,
      tgSndDtm: map['tgSndDtm'] != null ? map['tgSndDtm'] as String : null,
      tgRcvDtm: map['tgRcvDtm'] != null ? map['tgRcvDtm'] as String : null,
      resCd: map['resCd'] != null ? map['resCd'] as String : null,
      rsrvItmH: map['rsrvItmH'] != null ? map['rsrvItmH'] as String : null,
      bnkTtlReqNo: map['bnkTtlReqNo'] != null ? map['bnkTtlReqNo'] as String : null,
      lndPrgsStc: map['lndPrgsStc'] != null ? map['lndPrgsStc'] as String : null,
      prgsDt: map['prgsDt'] != null ? map['prgsDt'] as String : null,
      sbmtDocLst: map['sbmtDocLst'] != null ? map['sbmtDocLst'] as String : null,
      mvhrHshldrRno: map['mvhrHshldrRno'] != null ? map['mvhrHshldrRno'] as int : null,
      mvhrTrgtThngAddr: map['mvhrTrgtThngAddr'] != null ? map['mvhrTrgtThngAddr'] as String : null,
      mvhrHshldrNmMvinDt: map['mvhrHshldrNmMvinDt'] != null ? map['mvhrHshldrNmMvinDt'] as String : null,
      mvhrdtm: map['mvhrdtm'] != null ? map['mvhrdtm'] as String : null,
      rsrvItmB: map['rsrvItmB'] != null ? map['rsrvItmB'] as String : null,
      regDtm: map['regDtm'] != null ? map['regDtm'] as String : null,
      lnAprvNo2: map['lnAprvNo2'] != null ? map['lnAprvNo2'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());
  factory Trns6300DetailResData.fromJson(String source) => Trns6300DetailResData.fromMap(json.decode(source) as Map<String, dynamic>);
}