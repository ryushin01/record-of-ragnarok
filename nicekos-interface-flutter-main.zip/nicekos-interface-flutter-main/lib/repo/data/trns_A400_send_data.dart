// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class TrnsA400SendReqData {
  String? loanNo;
  String? trLn;
  String? trCd;
  String? trTpCd;
  String? loNo;
  String? payType;
  String? payBankCd;
  String? payAmt;
  String? transResultCd;
  String? filler;
  TrnsA400SendReqData({
    this.loanNo,
    this.trLn,
    this.trCd,
    this.trTpCd,
    this.loNo,
    this.payType,
    this.payBankCd,
    this.payAmt,
    this.transResultCd,
    this.filler,
  });

  TrnsA400SendReqData copyWith({
    String? loanNo,
    String? trLn,
    String? trCd,
    String? trTpCd,
    String? loNo,
    String? payType,
    String? payBankCd,
    String? payAmt,
    String? transResultCd,
    String? filler,
  }) {
    return TrnsA400SendReqData(
      loanNo: loanNo ?? this.loanNo,
      trLn: trLn ?? this.trLn,
      trCd: trCd ?? this.trCd,
      trTpCd: trTpCd ?? this.trTpCd,
      loNo: loNo ?? this.loNo,
      payType: payType ?? this.payType,
      payBankCd: payBankCd ?? this.payBankCd,
      payAmt: payAmt ?? this.payAmt,
      transResultCd: transResultCd ?? this.transResultCd,
      filler: filler ?? this.filler,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'trLn': trLn,
      'trCd': trCd,
      'trTpCd': trTpCd,
      'loNo': loNo,
      'payType': payType,
      'payBankCd': payBankCd,
      'payAmt': payAmt,
      'transResultCd': transResultCd,
      'filler': filler,
    };
  }

  factory TrnsA400SendReqData.fromMap(Map<String, dynamic> map) {
    return TrnsA400SendReqData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      trLn: map['trLn'] != null ? map['trLn'] as String : null,
      trCd: map['trCd'] != null ? map['trCd'] as String : null,
      trTpCd: map['trTpCd'] != null ? map['trTpCd'] as String : null,
      loNo: map['loNo'] != null ? map['loNo'] as String : null,
      payType: map['payType'] != null ? map['payType'] as String : null,
      payBankCd: map['payBankCd'] != null ? map['payBankCd'] as String : null,
      payAmt: map['payAmt'] != null ? map['payAmt'] as String : null,
      transResultCd: map['transResultCd'] != null ? map['transResultCd'] as String : null,
      filler: map['filler'] != null ? map['filler'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnsA400SendReqData.fromJson(String source) => TrnsA400SendReqData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TrnsA400SendReqData(loanNo: $loanNo, trLn: $trLn, trCd: $trCd, trTpCd: $trTpCd, loNo: $loNo, payType: $payType, payBankCd: $payBankCd, payAmt: $payAmt, transResultCd: $transResultCd, filler: $filler)';
  }

  @override
  bool operator ==(covariant TrnsA400SendReqData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.trLn == trLn &&
          other.trCd == trCd &&
          other.trTpCd == trTpCd &&
          other.loNo == loNo &&
          other.payType == payType &&
          other.payBankCd == payBankCd &&
          other.payAmt == payAmt &&
          other.transResultCd == transResultCd &&
          other.filler == filler;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    trLn.hashCode ^
    trCd.hashCode ^
    trTpCd.hashCode ^
    loNo.hashCode ^
    payType.hashCode ^
    payBankCd.hashCode ^
    payAmt.hashCode ^
    transResultCd.hashCode ^
    filler.hashCode;
  }
}


class TrnsA400SendResData {
  String? loanNo;
  String? trLn;
  String? trCd;
  String? trTpCd;
  String? loNo;
  String? payType;
  String? payBankCd;
  String? payAmt;
  String? transResultCd;
  String? filler;
  TrnsA400SendResData({
    this.loanNo,
    this.trLn,
    this.trCd,
    this.trTpCd,
    this.loNo,
    this.payType,
    this.payBankCd,
    this.payAmt,
    this.transResultCd,
    this.filler,
  });

  TrnsA400SendResData copyWith({
    String? loanNo,
    String? trLn,
    String? trCd,
    String? trTpCd,
    String? loNo,
    String? payType,
    String? payBankCd,
    String? payAmt,
    String? transResultCd,
    String? filler,
  }) {
    return TrnsA400SendResData(
      loanNo: loanNo ?? this.loanNo,
      trLn: trLn ?? this.trLn,
      trCd: trCd ?? this.trCd,
      trTpCd: trTpCd ?? this.trTpCd,
      loNo: loNo ?? this.loNo,
      payType: payType ?? this.payType,
      payBankCd: payBankCd ?? this.payBankCd,
      payAmt: payAmt ?? this.payAmt,
      transResultCd: transResultCd ?? this.transResultCd,
      filler: filler ?? this.filler,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'trLn': trLn,
      'trCd': trCd,
      'trTpCd': trTpCd,
      'loNo': loNo,
      'payType': payType,
      'payBankCd': payBankCd,
      'payAmt': payAmt,
      'transResultCd': transResultCd,
      'filler': filler,
    };
  }

  factory TrnsA400SendResData.fromMap(Map<String, dynamic> map) {
    return TrnsA400SendResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      trLn: map['trLn'] != null ? map['trLn'] as String : null,
      trCd: map['trCd'] != null ? map['trCd'] as String : null,
      trTpCd: map['trTpCd'] != null ? map['trTpCd'] as String : null,
      loNo: map['loNo'] != null ? map['loNo'] as String : null,
      payType: map['payType'] != null ? map['payType'] as String : null,
      payBankCd: map['payBankCd'] != null ? map['payBankCd'] as String : null,
      payAmt: map['payAmt'] != null ? map['payAmt'] as String : null,
      transResultCd: map['transResultCd'] != null ? map['transResultCd'] as String : null,
      filler: map['filler'] != null ? map['filler'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnsA400SendResData.fromJson(String source) => TrnsA400SendResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TrnsA400SendResData(loanNo: $loanNo, trLn: $trLn, trCd: $trCd, trTpCd: $trTpCd, loNo: $loNo, payType: $payType, payBankCd: $payBankCd, payAmt: $payAmt, transResultCd: $transResultCd, filler: $filler)';
  }

  @override
  bool operator ==(covariant TrnsA400SendResData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.trLn == trLn &&
          other.trCd == trCd &&
          other.trTpCd == trTpCd &&
          other.loNo == loNo &&
          other.payType == payType &&
          other.payBankCd == payBankCd &&
          other.payAmt == payAmt &&
          other.transResultCd == transResultCd &&
          other.filler == filler;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    trLn.hashCode ^
    trCd.hashCode ^
    trTpCd.hashCode ^
    loNo.hashCode ^
    payType.hashCode ^
    payBankCd.hashCode ^
    payAmt.hashCode ^
    transResultCd.hashCode ^
    filler.hashCode;
  }
}
