// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class CntrDetailResData {
  String? loanNo;
  String? bizNo;
  String? isrnGbCd;
  String? bnkBrnchCd;
  String? bnkGbCd;
  String? bnkBrnchNm;
  String? bnkDrctrNm;
  String? bnkBrnchPhno;
  String? lndKndCd;
  String? statCd;
  String? lndStatCd;
  String? rgstrGbCd;
  String? lndPrdtNm;
  String? dbtrNm;
  String? dbtrBirthDt;
  String? dbtrAddr;
  String? dbtrHpno;
  String? pwpsNm;
  String? pwpsBirthDt;
  String? pwpsHpno;
  int? execPlnAmt;
  String? execPlnDt;
  int? execAmt;
  String? execDt;
  int? slPrc;
  int? isrnEntrAmt;
  String? lwyrDiffBankCd1;
  String? lwyrDiffBankCd2;
  String? lwyrDiffBankCd3;
  String? lwyrDiffBankCd4;
  String? lwyrDiffBankCd5;
  String? lwyrDiffBankCd6;
  String? lwyrDiffBankCd7;
  String? lwyrDiffBankCd8;
  String? lwyrDiffBankCd9;
  String? lwyrDiffBankCd10;
  String? ersuClsMsg;
  String? ebtsLwyrBizno;
  String? regoNm;
  String? rgstrAcptDtm;
  String? imgKey;
  String? kndCd;
  String? lndThngAddr;
  String? ccrstAcptNum;
  String? clsctSctrtBprRegYn;
  String? ccrstBprRegYn;
  String? blncFpymnRcpt;
  String? regifBprRegYn;
  String? elregBizNo;
  String? rdnmInclAddr;
  String? rdnmStndAddr;
  String? grpNo;
  String? rmk;
  String? insDvsn;
  int? trnInCnt;
  String? refndAcctRegYn;
  String? refndAcctRegDate;
  String? eltnSecuredYn;
  String? execAmtChangYn;
  String? estmRegYn;
  String? rgstrRegYn;
  String? payRegYn;
  String? estmCnfmYn;
  String? lndAmtPayYn;
  String? revisionCheckYn;
  String? estbsCntrFnYn;
  String? slCntrctEane;
  String? slCntrctFlnm;
  String? mvhhdSbmtYn;
  String? rrcpSbmtYn;
  String? rtalSbmtYn;
  String? cndtCntrYn;
  String? rgstrAcptSbmtYn;
  String? cnvntLwyrYn;
  String? rschWkDdlnReqDt;
  String? sscptAskDt;
  String? rrcpCnfmReqYn;
  String? mvhhdCnfmReqYn;
  String? rvsnCntrctChrgTrgtYn;
  String? stndAplYn;
  String? befDbsmtCnclCd;
  String? elregYn;
  String? bnkTtlReqNo;
  String? fndUseCd;
  String? offRgstrYn;
  String? a300Send;
  CntrDetailResData({
    this.loanNo,
    this.bizNo,
    this.isrnGbCd,
    this.bnkBrnchCd,
    this.bnkGbCd,
    this.bnkBrnchNm,
    this.bnkDrctrNm,
    this.bnkBrnchPhno,
    this.lndKndCd,
    this.statCd,
    this.lndStatCd,
    this.rgstrGbCd,
    this.lndPrdtNm,
    this.dbtrNm,
    this.dbtrBirthDt,
    this.dbtrAddr,
    this.dbtrHpno,
    this.pwpsNm,
    this.pwpsBirthDt,
    this.pwpsHpno,
    this.execPlnAmt,
    this.execPlnDt,
    this.execAmt,
    this.execDt,
    this.slPrc,
    this.isrnEntrAmt,
    this.lwyrDiffBankCd1,
    this.lwyrDiffBankCd2,
    this.lwyrDiffBankCd3,
    this.lwyrDiffBankCd4,
    this.lwyrDiffBankCd5,
    this.lwyrDiffBankCd6,
    this.lwyrDiffBankCd7,
    this.lwyrDiffBankCd8,
    this.lwyrDiffBankCd9,
    this.lwyrDiffBankCd10,
    this.ersuClsMsg,
    this.ebtsLwyrBizno,
    this.regoNm,
    this.rgstrAcptDtm,
    this.imgKey,
    this.kndCd,
    this.lndThngAddr,
    this.ccrstAcptNum,
    this.clsctSctrtBprRegYn,
    this.ccrstBprRegYn,
    this.blncFpymnRcpt,
    this.regifBprRegYn,
    this.elregBizNo,
    this.rdnmInclAddr,
    this.rdnmStndAddr,
    this.grpNo,
    this.rmk,
    this.insDvsn,
    this.trnInCnt,
    this.refndAcctRegYn,
    this.refndAcctRegDate,
    this.eltnSecuredYn,
    this.execAmtChangYn,
    this.estmRegYn,
    this.rgstrRegYn,
    this.payRegYn,
    this.estmCnfmYn,
    this.lndAmtPayYn,
    this.revisionCheckYn,
    this.estbsCntrFnYn,
    this.slCntrctEane,
    this.slCntrctFlnm,
    this.mvhhdSbmtYn,
    this.rrcpSbmtYn,
    this.rtalSbmtYn,
    this.cndtCntrYn,
    this.rgstrAcptSbmtYn,
    this.cnvntLwyrYn,
    this.rschWkDdlnReqDt,
    this.sscptAskDt,
    this.rrcpCnfmReqYn,
    this.mvhhdCnfmReqYn,
    this.rvsnCntrctChrgTrgtYn,
    this.stndAplYn,
    this.befDbsmtCnclCd,
    this.elregYn,
    this.bnkTtlReqNo,
    this.fndUseCd,
    this.offRgstrYn,
    this.a300Send,
  });

  CntrDetailResData copyWith({
    String? loanNo,
    String? bizNo,
    String? isrnGbCd,
    String? bnkBrnchCd,
    String? bnkGbCd,
    String? bnkBrnchNm,
    String? bnkDrctrNm,
    String? bnkBrnchPhno,
    String? lndKndCd,
    String? statCd,
    String? lndStatCd,
    String? rgstrGbCd,
    String? lndPrdtNm,
    String? dbtrNm,
    String? dbtrBirthDt,
    String? dbtrAddr,
    String? dbtrHpno,
    String? pwpsNm,
    String? pwpsBirthDt,
    String? pwpsHpno,
    int? execPlnAmt,
    String? execPlnDt,
    int? execAmt,
    String? execDt,
    int? slPrc,
    int? isrnEntrAmt,
    String? lwyrDiffBankCd1,
    String? lwyrDiffBankCd2,
    String? lwyrDiffBankCd3,
    String? lwyrDiffBankCd4,
    String? lwyrDiffBankCd5,
    String? lwyrDiffBankCd6,
    String? lwyrDiffBankCd7,
    String? lwyrDiffBankCd8,
    String? lwyrDiffBankCd9,
    String? lwyrDiffBankCd10,
    String? ersuClsMsg,
    String? ebtsLwyrBizno,
    String? regoNm,
    String? rgstrAcptDtm,
    String? imgKey,
    String? kndCd,
    String? lndThngAddr,
    String? ccrstAcptNum,
    String? clsctSctrtBprRegYn,
    String? ccrstBprRegYn,
    String? blncFpymnRcpt,
    String? regifBprRegYn,
    String? elregBizNo,
    String? rdnmInclAddr,
    String? rdnmStndAddr,
    String? grpNo,
    String? rmk,
    String? insDvsn,
    int? trnInCnt,
    String? refndAcctRegYn,
    String? refndAcctRegDate,
    String? eltnSecuredYn,
    String? execAmtChangYn,
    String? estmRegYn,
    String? rgstrRegYn,
    String? payRegYn,
    String? estmCnfmYn,
    String? lndAmtPayYn,
    String? revisionCheckYn,
    String? estbsCntrFnYn,
    String? slCntrctEane,
    String? slCntrctFlnm,
    String? mvhhdSbmtYn,
    String? rrcpSbmtYn,
    String? rtalSbmtYn,
    String? cndtCntrYn,
    String? rgstrAcptSbmtYn,
    String? cnvntLwyrYn,
    String? rschWkDdlnReqDt,
    String? sscptAskDt,
    String? rrcpCnfmReqYn,
    String? mvhhdCnfmReqYn,
    String? rvsnCntrctChrgTrgtYn,
    String? stndAplYn,
    String? befDbsmtCnclCd,
    String? elregYn,
    String? bnkTtlReqNo,
    String? fndUseCd,
    String? offRgstrYn,
    String? a300Send,
  }) {
    return CntrDetailResData(
      loanNo: loanNo ?? this.loanNo,
      bizNo: bizNo ?? this.bizNo,
      isrnGbCd: isrnGbCd ?? this.isrnGbCd,
      bnkBrnchCd: bnkBrnchCd ?? this.bnkBrnchCd,
      bnkGbCd: bnkGbCd ?? this.bnkGbCd,
      bnkBrnchNm: bnkBrnchNm ?? this.bnkBrnchNm,
      bnkDrctrNm: bnkDrctrNm ?? this.bnkDrctrNm,
      bnkBrnchPhno: bnkBrnchPhno ?? this.bnkBrnchPhno,
      lndKndCd: lndKndCd ?? this.lndKndCd,
      statCd: statCd ?? this.statCd,
      lndStatCd: lndStatCd ?? this.lndStatCd,
      rgstrGbCd: rgstrGbCd ?? this.rgstrGbCd,
      lndPrdtNm: lndPrdtNm ?? this.lndPrdtNm,
      dbtrNm: dbtrNm ?? this.dbtrNm,
      dbtrBirthDt: dbtrBirthDt ?? this.dbtrBirthDt,
      dbtrAddr: dbtrAddr ?? this.dbtrAddr,
      dbtrHpno: dbtrHpno ?? this.dbtrHpno,
      pwpsNm: pwpsNm ?? this.pwpsNm,
      pwpsBirthDt: pwpsBirthDt ?? this.pwpsBirthDt,
      pwpsHpno: pwpsHpno ?? this.pwpsHpno,
      execPlnAmt: execPlnAmt ?? this.execPlnAmt,
      execPlnDt: execPlnDt ?? this.execPlnDt,
      execAmt: execAmt ?? this.execAmt,
      execDt: execDt ?? this.execDt,
      slPrc: slPrc ?? this.slPrc,
      isrnEntrAmt: isrnEntrAmt ?? this.isrnEntrAmt,
      lwyrDiffBankCd1: lwyrDiffBankCd1 ?? this.lwyrDiffBankCd1,
      lwyrDiffBankCd2: lwyrDiffBankCd2 ?? this.lwyrDiffBankCd2,
      lwyrDiffBankCd3: lwyrDiffBankCd3 ?? this.lwyrDiffBankCd3,
      lwyrDiffBankCd4: lwyrDiffBankCd4 ?? this.lwyrDiffBankCd4,
      lwyrDiffBankCd5: lwyrDiffBankCd5 ?? this.lwyrDiffBankCd5,
      lwyrDiffBankCd6: lwyrDiffBankCd6 ?? this.lwyrDiffBankCd6,
      lwyrDiffBankCd7: lwyrDiffBankCd7 ?? this.lwyrDiffBankCd7,
      lwyrDiffBankCd8: lwyrDiffBankCd8 ?? this.lwyrDiffBankCd8,
      lwyrDiffBankCd9: lwyrDiffBankCd9 ?? this.lwyrDiffBankCd9,
      lwyrDiffBankCd10: lwyrDiffBankCd10 ?? this.lwyrDiffBankCd10,
      ersuClsMsg: ersuClsMsg ?? this.ersuClsMsg,
      ebtsLwyrBizno: ebtsLwyrBizno ?? this.ebtsLwyrBizno,
      regoNm: regoNm ?? this.regoNm,
      rgstrAcptDtm: rgstrAcptDtm ?? this.rgstrAcptDtm,
      imgKey: imgKey ?? this.imgKey,
      kndCd: kndCd ?? this.kndCd,
      lndThngAddr: lndThngAddr ?? this.lndThngAddr,
      ccrstAcptNum: ccrstAcptNum ?? this.ccrstAcptNum,
      clsctSctrtBprRegYn: clsctSctrtBprRegYn ?? this.clsctSctrtBprRegYn,
      ccrstBprRegYn: ccrstBprRegYn ?? this.ccrstBprRegYn,
      blncFpymnRcpt: blncFpymnRcpt ?? this.blncFpymnRcpt,
      regifBprRegYn: regifBprRegYn ?? this.regifBprRegYn,
      elregBizNo: elregBizNo ?? this.elregBizNo,
      rdnmInclAddr: rdnmInclAddr ?? this.rdnmInclAddr,
      rdnmStndAddr: rdnmStndAddr ?? this.rdnmStndAddr,
      grpNo: grpNo ?? this.grpNo,
      rmk: rmk ?? this.rmk,
      insDvsn: insDvsn ?? this.insDvsn,
      trnInCnt: trnInCnt ?? this.trnInCnt,
      refndAcctRegYn: refndAcctRegYn ?? this.refndAcctRegYn,
      refndAcctRegDate: refndAcctRegDate ?? this.refndAcctRegDate,
      eltnSecuredYn: eltnSecuredYn ?? this.eltnSecuredYn,
      execAmtChangYn: execAmtChangYn ?? this.execAmtChangYn,
      estmRegYn: estmRegYn ?? this.estmRegYn,
      rgstrRegYn: rgstrRegYn ?? this.rgstrRegYn,
      payRegYn: payRegYn ?? this.payRegYn,
      estmCnfmYn: estmCnfmYn ?? this.estmCnfmYn,
      lndAmtPayYn: lndAmtPayYn ?? this.lndAmtPayYn,
      revisionCheckYn: revisionCheckYn ?? this.revisionCheckYn,
      estbsCntrFnYn: estbsCntrFnYn ?? this.estbsCntrFnYn,
      slCntrctEane: slCntrctEane ?? this.slCntrctEane,
      slCntrctFlnm: slCntrctFlnm ?? this.slCntrctFlnm,
      mvhhdSbmtYn: mvhhdSbmtYn ?? this.mvhhdSbmtYn,
      rrcpSbmtYn: rrcpSbmtYn ?? this.rrcpSbmtYn,
      rtalSbmtYn: rtalSbmtYn ?? this.rtalSbmtYn,
      cndtCntrYn: cndtCntrYn ?? this.cndtCntrYn,
      rgstrAcptSbmtYn: rgstrAcptSbmtYn ?? this.rgstrAcptSbmtYn,
      cnvntLwyrYn: cnvntLwyrYn ?? this.cnvntLwyrYn,
      rschWkDdlnReqDt: rschWkDdlnReqDt ?? this.rschWkDdlnReqDt,
      sscptAskDt: sscptAskDt ?? this.sscptAskDt,
      rrcpCnfmReqYn: rrcpCnfmReqYn ?? this.rrcpCnfmReqYn,
      mvhhdCnfmReqYn: mvhhdCnfmReqYn ?? this.mvhhdCnfmReqYn,
      rvsnCntrctChrgTrgtYn: rvsnCntrctChrgTrgtYn ?? this.rvsnCntrctChrgTrgtYn,
      stndAplYn: stndAplYn ?? this.stndAplYn,
      befDbsmtCnclCd: befDbsmtCnclCd ?? this.befDbsmtCnclCd,
      elregYn: elregYn ?? this.elregYn,
      bnkTtlReqNo: bnkTtlReqNo ?? this.bnkTtlReqNo,
      fndUseCd: fndUseCd ?? this.fndUseCd,
      offRgstrYn: offRgstrYn ?? this.offRgstrYn,
      a300Send: a300Send ?? this.a300Send,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'bizNo': bizNo,
      'isrnGbCd': isrnGbCd,
      'bnkBrnchCd': bnkBrnchCd,
      'bnkGbCd': bnkGbCd,
      'bnkBrnchNm': bnkBrnchNm,
      'bnkDrctrNm': bnkDrctrNm,
      'bnkBrnchPhno': bnkBrnchPhno,
      'lndKndCd': lndKndCd,
      'statCd': statCd,
      'lndStatCd': lndStatCd,
      'rgstrGbCd': rgstrGbCd,
      'lndPrdtNm': lndPrdtNm,
      'dbtrNm': dbtrNm,
      'dbtrBirthDt': dbtrBirthDt,
      'dbtrAddr': dbtrAddr,
      'dbtrHpno': dbtrHpno,
      'pwpsNm': pwpsNm,
      'pwpsBirthDt': pwpsBirthDt,
      'pwpsHpno': pwpsHpno,
      'execPlnAmt': execPlnAmt,
      'execPlnDt': execPlnDt,
      'execAmt': execAmt,
      'execDt': execDt,
      'slPrc': slPrc,
      'isrnEntrAmt': isrnEntrAmt,
      'lwyrDiffBankCd1': lwyrDiffBankCd1,
      'lwyrDiffBankCd2': lwyrDiffBankCd2,
      'lwyrDiffBankCd3': lwyrDiffBankCd3,
      'lwyrDiffBankCd4': lwyrDiffBankCd4,
      'lwyrDiffBankCd5': lwyrDiffBankCd5,
      'lwyrDiffBankCd6': lwyrDiffBankCd6,
      'lwyrDiffBankCd7': lwyrDiffBankCd7,
      'lwyrDiffBankCd8': lwyrDiffBankCd8,
      'lwyrDiffBankCd9': lwyrDiffBankCd9,
      'lwyrDiffBankCd10': lwyrDiffBankCd10,
      'ersuClsMsg': ersuClsMsg,
      'ebtsLwyrBizno': ebtsLwyrBizno,
      'regoNm': regoNm,
      'rgstrAcptDtm': rgstrAcptDtm,
      'imgKey': imgKey,
      'kndCd': kndCd,
      'lndThngAddr': lndThngAddr,
      'ccrstAcptNum': ccrstAcptNum,
      'clsctSctrtBprRegYn': clsctSctrtBprRegYn,
      'ccrstBprRegYn': ccrstBprRegYn,
      'blncFpymnRcpt': blncFpymnRcpt,
      'regifBprRegYn': regifBprRegYn,
      'elregBizNo': elregBizNo,
      'rdnmInclAddr': rdnmInclAddr,
      'rdnmStndAddr': rdnmStndAddr,
      'grpNo': grpNo,
      'rmk': rmk,
      'insDvsn': insDvsn,
      'trnInCnt': trnInCnt,
      'refndAcctRegYn': refndAcctRegYn,
      'refndAcctRegDate': refndAcctRegDate,
      'eltnSecuredYn': eltnSecuredYn,
      'execAmtChangYn': execAmtChangYn,
      'estmRegYn': estmRegYn,
      'rgstrRegYn': rgstrRegYn,
      'payRegYn': payRegYn,
      'estmCnfmYn': estmCnfmYn,
      'lndAmtPayYn': lndAmtPayYn,
      'revisionCheckYn': revisionCheckYn,
      'estbsCntrFnYn': estbsCntrFnYn,
      'slCntrctEane': slCntrctEane,
      'slCntrctFlnm': slCntrctFlnm,
      'mvhhdSbmtYn': mvhhdSbmtYn,
      'rrcpSbmtYn': rrcpSbmtYn,
      'rtalSbmtYn': rtalSbmtYn,
      'cndtCntrYn': cndtCntrYn,
      'rgstrAcptSbmtYn': rgstrAcptSbmtYn,
      'cnvntLwyrYn': cnvntLwyrYn,
      'rschWkDdlnReqDt': rschWkDdlnReqDt,
      'sscptAskDt': sscptAskDt,
      'rrcpCnfmReqYn': rrcpCnfmReqYn,
      'mvhhdCnfmReqYn': mvhhdCnfmReqYn,
      'rvsnCntrctChrgTrgtYn': rvsnCntrctChrgTrgtYn,
      'stndAplYn': stndAplYn,
      'befDbsmtCnclCd': befDbsmtCnclCd,
      'elregYn': elregYn,
      'bnkTtlReqNo': bnkTtlReqNo,
      'fndUseCd': fndUseCd,
      'offRgstrYn': offRgstrYn,
      'a300Send': a300Send,
    };
  }

  factory CntrDetailResData.fromMap(Map<String, dynamic> map) {
    return CntrDetailResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      bizNo: map['bizNo'] != null ? map['bizNo'] as String : null,
      isrnGbCd: map['isrnGbCd'] != null ? map['isrnGbCd'] as String : null,
      bnkBrnchCd: map['bnkBrnchCd'] != null ? map['bnkBrnchCd'] as String : null,
      bnkGbCd: map['bnkGbCd'] != null ? map['bnkGbCd'] as String : null,
      bnkBrnchNm: map['bnkBrnchNm'] != null ? map['bnkBrnchNm'] as String : null,
      bnkDrctrNm: map['bnkDrctrNm'] != null ? map['bnkDrctrNm'] as String : null,
      bnkBrnchPhno: map['bnkBrnchPhno'] != null ? map['bnkBrnchPhno'] as String : null,
      lndKndCd: map['lndKndCd'] != null ? map['lndKndCd'] as String : null,
      statCd: map['statCd'] != null ? map['statCd'] as String : null,
      lndStatCd: map['lndStatCd'] != null ? map['lndStatCd'] as String : null,
      rgstrGbCd: map['rgstrGbCd'] != null ? map['rgstrGbCd'] as String : null,
      lndPrdtNm: map['lndPrdtNm'] != null ? map['lndPrdtNm'] as String : null,
      dbtrNm: map['dbtrNm'] != null ? map['dbtrNm'] as String : null,
      dbtrBirthDt: map['dbtrBirthDt'] != null ? map['dbtrBirthDt'] as String : null,
      dbtrAddr: map['dbtrAddr'] != null ? map['dbtrAddr'] as String : null,
      dbtrHpno: map['dbtrHpno'] != null ? map['dbtrHpno'] as String : null,
      pwpsNm: map['pwpsNm'] != null ? map['pwpsNm'] as String : null,
      pwpsBirthDt: map['pwpsBirthDt'] != null ? map['pwpsBirthDt'] as String : null,
      pwpsHpno: map['pwpsHpno'] != null ? map['pwpsHpno'] as String : null,
      execPlnAmt: map['execPlnAmt'] != null ? map['execPlnAmt'] as int : null,
      execPlnDt: map['execPlnDt'] != null ? map['execPlnDt'] as String : null,
      execAmt: map['execAmt'] != null ? map['execAmt'] as int : null,
      execDt: map['execDt'] != null ? map['execDt'] as String : null,
      slPrc: map['slPrc'] != null ? map['slPrc'] as int : null,
      isrnEntrAmt: map['isrnEntrAmt'] != null ? map['isrnEntrAmt'] as int : null,
      lwyrDiffBankCd1: map['lwyrDiffBankCd1'] != null ? map['lwyrDiffBankCd1'] as String : null,
      lwyrDiffBankCd2: map['lwyrDiffBankCd2'] != null ? map['lwyrDiffBankCd2'] as String : null,
      lwyrDiffBankCd3: map['lwyrDiffBankCd3'] != null ? map['lwyrDiffBankCd3'] as String : null,
      lwyrDiffBankCd4: map['lwyrDiffBankCd4'] != null ? map['lwyrDiffBankCd4'] as String : null,
      lwyrDiffBankCd5: map['lwyrDiffBankCd5'] != null ? map['lwyrDiffBankCd5'] as String : null,
      lwyrDiffBankCd6: map['lwyrDiffBankCd6'] != null ? map['lwyrDiffBankCd6'] as String : null,
      lwyrDiffBankCd7: map['lwyrDiffBankCd7'] != null ? map['lwyrDiffBankCd7'] as String : null,
      lwyrDiffBankCd8: map['lwyrDiffBankCd8'] != null ? map['lwyrDiffBankCd8'] as String : null,
      lwyrDiffBankCd9: map['lwyrDiffBankCd9'] != null ? map['lwyrDiffBankCd9'] as String : null,
      lwyrDiffBankCd10: map['lwyrDiffBankCd10'] != null ? map['lwyrDiffBankCd10'] as String : null,
      ersuClsMsg: map['ersuClsMsg'] != null ? map['ersuClsMsg'] as String : null,
      ebtsLwyrBizno: map['ebtsLwyrBizno'] != null ? map['ebtsLwyrBizno'] as String : null,
      regoNm: map['regoNm'] != null ? map['regoNm'] as String : null,
      rgstrAcptDtm: map['rgstrAcptDtm'] != null ? map['rgstrAcptDtm'] as String : null,
      imgKey: map['imgKey'] != null ? map['imgKey'] as String : null,
      kndCd: map['kndCd'] != null ? map['kndCd'] as String : null,
      lndThngAddr: map['lndThngAddr'] != null ? map['lndThngAddr'] as String : null,
      ccrstAcptNum: map['ccrstAcptNum'] != null ? map['ccrstAcptNum'] as String : null,
      clsctSctrtBprRegYn: map['clsctSctrtBprRegYn'] != null ? map['clsctSctrtBprRegYn'] as String : null,
      ccrstBprRegYn: map['ccrstBprRegYn'] != null ? map['ccrstBprRegYn'] as String : null,
      blncFpymnRcpt: map['blncFpymnRcpt'] != null ? map['blncFpymnRcpt'] as String : null,
      regifBprRegYn: map['regifBprRegYn'] != null ? map['regifBprRegYn'] as String : null,
      elregBizNo: map['elregBizNo'] != null ? map['elregBizNo'] as String : null,
      rdnmInclAddr: map['rdnmInclAddr'] != null ? map['rdnmInclAddr'] as String : null,
      rdnmStndAddr: map['rdnmStndAddr'] != null ? map['rdnmStndAddr'] as String : null,
      grpNo: map['grpNo'] != null ? map['grpNo'] as String : null,
      rmk: map['rmk'] != null ? map['rmk'] as String : null,
      insDvsn: map['insDvsn'] != null ? map['insDvsn'] as String : null,
      trnInCnt: map['trnInCnt'] != null ? map['trnInCnt'] as int : null,
      refndAcctRegYn: map['refndAcctRegYn'] != null ? map['refndAcctRegYn'] as String : null,
      refndAcctRegDate: map['refndAcctRegDate'] != null ? map['refndAcctRegDate'] as String : null,
      eltnSecuredYn: map['eltnSecuredYn'] != null ? map['eltnSecuredYn'] as String : null,
      execAmtChangYn: map['execAmtChangYn'] != null ? map['execAmtChangYn'] as String : null,
      estmRegYn: map['estmRegYn'] != null ? map['estmRegYn'] as String : null,
      rgstrRegYn: map['rgstrRegYn'] != null ? map['rgstrRegYn'] as String : null,
      payRegYn: map['payRegYn'] != null ? map['payRegYn'] as String : null,
      estmCnfmYn: map['estmCnfmYn'] != null ? map['estmCnfmYn'] as String : null,
      lndAmtPayYn: map['lndAmtPayYn'] != null ? map['lndAmtPayYn'] as String : null,
      revisionCheckYn: map['revisionCheckYn'] != null ? map['revisionCheckYn'] as String : null,
      estbsCntrFnYn: map['estbsCntrFnYn'] != null ? map['estbsCntrFnYn'] as String : null,
      slCntrctEane: map['slCntrctEane'] != null ? map['slCntrctEane'] as String : null,
      slCntrctFlnm: map['slCntrctFlnm'] != null ? map['slCntrctFlnm'] as String : null,
      mvhhdSbmtYn: map['mvhhdSbmtYn'] != null ? map['mvhhdSbmtYn'] as String : null,
      rrcpSbmtYn: map['rrcpSbmtYn'] != null ? map['rrcpSbmtYn'] as String : null,
      rtalSbmtYn: map['rtalSbmtYn'] != null ? map['rtalSbmtYn'] as String : null,
      cndtCntrYn: map['cndtCntrYn'] != null ? map['cndtCntrYn'] as String : null,
      rgstrAcptSbmtYn: map['rgstrAcptSbmtYn'] != null ? map['rgstrAcptSbmtYn'] as String : null,
      cnvntLwyrYn: map['cnvntLwyrYn'] != null ? map['cnvntLwyrYn'] as String : null,
      rschWkDdlnReqDt: map['rschWkDdlnReqDt'] != null ? map['rschWkDdlnReqDt'] as String : null,
      sscptAskDt: map['sscptAskDt'] != null ? map['sscptAskDt'] as String : null,
      rrcpCnfmReqYn: map['rrcpCnfmReqYn'] != null ? map['rrcpCnfmReqYn'] as String : null,
      mvhhdCnfmReqYn: map['mvhhdCnfmReqYn'] != null ? map['mvhhdCnfmReqYn'] as String : null,
      rvsnCntrctChrgTrgtYn: map['rvsnCntrctChrgTrgtYn'] != null ? map['rvsnCntrctChrgTrgtYn'] as String : null,
      stndAplYn: map['stndAplYn'] != null ? map['stndAplYn'] as String : null,
      befDbsmtCnclCd: map['befDbsmtCnclCd'] != null ? map['befDbsmtCnclCd'] as String : null,
      elregYn: map['elregYn'] != null ? map['elregYn'] as String : null,
      bnkTtlReqNo: map['bnkTtlReqNo'] != null ? map['bnkTtlReqNo'] as String : null,
      fndUseCd: map['fndUseCd'] != null ? map['fndUseCd'] as String : null,
      offRgstrYn: map['offRgstrYn'] != null ? map['offRgstrYn'] as String : null,
      a300Send: map['a300Send'] != null ? map['a300Send'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory CntrDetailResData.fromJson(String source) => CntrDetailResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'CntrDetailResData(loanNo: $loanNo, bizNo: $bizNo, isrnGbCd: $isrnGbCd, bnkBrnchCd: $bnkBrnchCd, bnkGbCd: $bnkGbCd, bnkBrnchNm: $bnkBrnchNm, bnkDrctrNm: $bnkDrctrNm, bnkBrnchPhno: $bnkBrnchPhno, lndKndCd: $lndKndCd, statCd: $statCd, lndStatCd: $lndStatCd, rgstrGbCd: $rgstrGbCd, lndPrdtNm: $lndPrdtNm, dbtrNm: $dbtrNm, dbtrBirthDt: $dbtrBirthDt, dbtrAddr: $dbtrAddr, dbtrHpno: $dbtrHpno, pwpsNm: $pwpsNm, pwpsBirthDt: $pwpsBirthDt, pwpsHpno: $pwpsHpno, execPlnAmt: $execPlnAmt, execPlnDt: $execPlnDt, execAmt: $execAmt, execDt: $execDt, slPrc: $slPrc, isrnEntrAmt: $isrnEntrAmt, lwyrDiffBankCd1: $lwyrDiffBankCd1, lwyrDiffBankCd2: $lwyrDiffBankCd2, lwyrDiffBankCd3: $lwyrDiffBankCd3, lwyrDiffBankCd4: $lwyrDiffBankCd4, lwyrDiffBankCd5: $lwyrDiffBankCd5, lwyrDiffBankCd6: $lwyrDiffBankCd6, lwyrDiffBankCd7: $lwyrDiffBankCd7, lwyrDiffBankCd8: $lwyrDiffBankCd8, lwyrDiffBankCd9: $lwyrDiffBankCd9, lwyrDiffBankCd10: $lwyrDiffBankCd10, ersuClsMsg: $ersuClsMsg, ebtsLwyrBizno: $ebtsLwyrBizno, regoNm: $regoNm, rgstrAcptDtm: $rgstrAcptDtm, imgKey: $imgKey, kndCd: $kndCd, lndThngAddr: $lndThngAddr, ccrstAcptNum: $ccrstAcptNum, clsctSctrtBprRegYn: $clsctSctrtBprRegYn, ccrstBprRegYn: $ccrstBprRegYn, blncFpymnRcpt: $blncFpymnRcpt, regifBprRegYn: $regifBprRegYn, elregBizNo: $elregBizNo, rdnmInclAddr: $rdnmInclAddr, rdnmStndAddr: $rdnmStndAddr, grpNo: $grpNo, rmk: $rmk, insDvsn: $insDvsn, trnInCnt: $trnInCnt, refndAcctRegYn: $refndAcctRegYn, refndAcctRegDate: $refndAcctRegDate, eltnSecuredYn: $eltnSecuredYn, execAmtChangYn: $execAmtChangYn, estmRegYn: $estmRegYn, rgstrRegYn: $rgstrRegYn, payRegYn: $payRegYn, estmCnfmYn: $estmCnfmYn, lndAmtPayYn: $lndAmtPayYn, revisionCheckYn: $revisionCheckYn, estbsCntrFnYn: $estbsCntrFnYn, slCntrctEane: $slCntrctEane, slCntrctFlnm: $slCntrctFlnm, mvhhdSbmtYn: $mvhhdSbmtYn, rrcpSbmtYn: $rrcpSbmtYn, rtalSbmtYn: $rtalSbmtYn, cndtCntrYn: $cndtCntrYn, rgstrAcptSbmtYn: $rgstrAcptSbmtYn, cnvntLwyrYn: $cnvntLwyrYn, rschWkDdlnReqDt: $rschWkDdlnReqDt, sscptAskDt: $sscptAskDt, rrcpCnfmReqYn: $rrcpCnfmReqYn, mvhhdCnfmReqYn: $mvhhdCnfmReqYn, rvsnCntrctChrgTrgtYn: $rvsnCntrctChrgTrgtYn, stndAplYn: $stndAplYn, befDbsmtCnclCd: $befDbsmtCnclCd, elregYn: $elregYn, bnkTtlReqNo: $bnkTtlReqNo, fndUseCd: $fndUseCd, offRgstrYn: $offRgstrYn, a300Send: $a300Send)';
  }

  @override
  bool operator ==(covariant CntrDetailResData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.bizNo == bizNo &&
          other.isrnGbCd == isrnGbCd &&
          other.bnkBrnchCd == bnkBrnchCd &&
          other.bnkGbCd == bnkGbCd &&
          other.bnkBrnchNm == bnkBrnchNm &&
          other.bnkDrctrNm == bnkDrctrNm &&
          other.bnkBrnchPhno == bnkBrnchPhno &&
          other.lndKndCd == lndKndCd &&
          other.statCd == statCd &&
          other.lndStatCd == lndStatCd &&
          other.rgstrGbCd == rgstrGbCd &&
          other.lndPrdtNm == lndPrdtNm &&
          other.dbtrNm == dbtrNm &&
          other.dbtrBirthDt == dbtrBirthDt &&
          other.dbtrAddr == dbtrAddr &&
          other.dbtrHpno == dbtrHpno &&
          other.pwpsNm == pwpsNm &&
          other.pwpsBirthDt == pwpsBirthDt &&
          other.pwpsHpno == pwpsHpno &&
          other.execPlnAmt == execPlnAmt &&
          other.execPlnDt == execPlnDt &&
          other.execAmt == execAmt &&
          other.execDt == execDt &&
          other.slPrc == slPrc &&
          other.isrnEntrAmt == isrnEntrAmt &&
          other.lwyrDiffBankCd1 == lwyrDiffBankCd1 &&
          other.lwyrDiffBankCd2 == lwyrDiffBankCd2 &&
          other.lwyrDiffBankCd3 == lwyrDiffBankCd3 &&
          other.lwyrDiffBankCd4 == lwyrDiffBankCd4 &&
          other.lwyrDiffBankCd5 == lwyrDiffBankCd5 &&
          other.lwyrDiffBankCd6 == lwyrDiffBankCd6 &&
          other.lwyrDiffBankCd7 == lwyrDiffBankCd7 &&
          other.lwyrDiffBankCd8 == lwyrDiffBankCd8 &&
          other.lwyrDiffBankCd9 == lwyrDiffBankCd9 &&
          other.lwyrDiffBankCd10 == lwyrDiffBankCd10 &&
          other.ersuClsMsg == ersuClsMsg &&
          other.ebtsLwyrBizno == ebtsLwyrBizno &&
          other.regoNm == regoNm &&
          other.rgstrAcptDtm == rgstrAcptDtm &&
          other.imgKey == imgKey &&
          other.kndCd == kndCd &&
          other.lndThngAddr == lndThngAddr &&
          other.ccrstAcptNum == ccrstAcptNum &&
          other.clsctSctrtBprRegYn == clsctSctrtBprRegYn &&
          other.ccrstBprRegYn == ccrstBprRegYn &&
          other.blncFpymnRcpt == blncFpymnRcpt &&
          other.regifBprRegYn == regifBprRegYn &&
          other.elregBizNo == elregBizNo &&
          other.rdnmInclAddr == rdnmInclAddr &&
          other.rdnmStndAddr == rdnmStndAddr &&
          other.grpNo == grpNo &&
          other.rmk == rmk &&
          other.insDvsn == insDvsn &&
          other.trnInCnt == trnInCnt &&
          other.refndAcctRegYn == refndAcctRegYn &&
          other.refndAcctRegDate == refndAcctRegDate &&
          other.eltnSecuredYn == eltnSecuredYn &&
          other.execAmtChangYn == execAmtChangYn &&
          other.estmRegYn == estmRegYn &&
          other.rgstrRegYn == rgstrRegYn &&
          other.payRegYn == payRegYn &&
          other.estmCnfmYn == estmCnfmYn &&
          other.lndAmtPayYn == lndAmtPayYn &&
          other.revisionCheckYn == revisionCheckYn &&
          other.estbsCntrFnYn == estbsCntrFnYn &&
          other.slCntrctEane == slCntrctEane &&
          other.slCntrctFlnm == slCntrctFlnm &&
          other.mvhhdSbmtYn == mvhhdSbmtYn &&
          other.rrcpSbmtYn == rrcpSbmtYn &&
          other.rtalSbmtYn == rtalSbmtYn &&
          other.cndtCntrYn == cndtCntrYn &&
          other.rgstrAcptSbmtYn == rgstrAcptSbmtYn &&
          other.cnvntLwyrYn == cnvntLwyrYn &&
          other.rschWkDdlnReqDt == rschWkDdlnReqDt &&
          other.sscptAskDt == sscptAskDt &&
          other.rrcpCnfmReqYn == rrcpCnfmReqYn &&
          other.mvhhdCnfmReqYn == mvhhdCnfmReqYn &&
          other.rvsnCntrctChrgTrgtYn == rvsnCntrctChrgTrgtYn &&
          other.stndAplYn == stndAplYn &&
          other.befDbsmtCnclCd == befDbsmtCnclCd &&
          other.elregYn == elregYn &&
          other.bnkTtlReqNo == bnkTtlReqNo &&
          other.fndUseCd == fndUseCd &&
          other.offRgstrYn == offRgstrYn &&
          other.a300Send == a300Send;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    bizNo.hashCode ^
    isrnGbCd.hashCode ^
    bnkBrnchCd.hashCode ^
    bnkGbCd.hashCode ^
    bnkBrnchNm.hashCode ^
    bnkDrctrNm.hashCode ^
    bnkBrnchPhno.hashCode ^
    lndKndCd.hashCode ^
    statCd.hashCode ^
    lndStatCd.hashCode ^
    rgstrGbCd.hashCode ^
    lndPrdtNm.hashCode ^
    dbtrNm.hashCode ^
    dbtrBirthDt.hashCode ^
    dbtrAddr.hashCode ^
    dbtrHpno.hashCode ^
    pwpsNm.hashCode ^
    pwpsBirthDt.hashCode ^
    pwpsHpno.hashCode ^
    execPlnAmt.hashCode ^
    execPlnDt.hashCode ^
    execAmt.hashCode ^
    execDt.hashCode ^
    slPrc.hashCode ^
    isrnEntrAmt.hashCode ^
    lwyrDiffBankCd1.hashCode ^
    lwyrDiffBankCd2.hashCode ^
    lwyrDiffBankCd3.hashCode ^
    lwyrDiffBankCd4.hashCode ^
    lwyrDiffBankCd5.hashCode ^
    lwyrDiffBankCd6.hashCode ^
    lwyrDiffBankCd7.hashCode ^
    lwyrDiffBankCd8.hashCode ^
    lwyrDiffBankCd9.hashCode ^
    lwyrDiffBankCd10.hashCode ^
    ersuClsMsg.hashCode ^
    ebtsLwyrBizno.hashCode ^
    regoNm.hashCode ^
    rgstrAcptDtm.hashCode ^
    imgKey.hashCode ^
    kndCd.hashCode ^
    lndThngAddr.hashCode ^
    ccrstAcptNum.hashCode ^
    clsctSctrtBprRegYn.hashCode ^
    ccrstBprRegYn.hashCode ^
    blncFpymnRcpt.hashCode ^
    regifBprRegYn.hashCode ^
    elregBizNo.hashCode ^
    rdnmInclAddr.hashCode ^
    rdnmStndAddr.hashCode ^
    grpNo.hashCode ^
    rmk.hashCode ^
    insDvsn.hashCode ^
    trnInCnt.hashCode ^
    refndAcctRegYn.hashCode ^
    refndAcctRegDate.hashCode ^
    eltnSecuredYn.hashCode ^
    execAmtChangYn.hashCode ^
    estmRegYn.hashCode ^
    rgstrRegYn.hashCode ^
    payRegYn.hashCode ^
    estmCnfmYn.hashCode ^
    lndAmtPayYn.hashCode ^
    revisionCheckYn.hashCode ^
    estbsCntrFnYn.hashCode ^
    slCntrctEane.hashCode ^
    slCntrctFlnm.hashCode ^
    mvhhdSbmtYn.hashCode ^
    rrcpSbmtYn.hashCode ^
    rtalSbmtYn.hashCode ^
    cndtCntrYn.hashCode ^
    rgstrAcptSbmtYn.hashCode ^
    cnvntLwyrYn.hashCode ^
    rschWkDdlnReqDt.hashCode ^
    sscptAskDt.hashCode ^
    rrcpCnfmReqYn.hashCode ^
    mvhhdCnfmReqYn.hashCode ^
    rvsnCntrctChrgTrgtYn.hashCode ^
    stndAplYn.hashCode ^
    befDbsmtCnclCd.hashCode ^
    elregYn.hashCode ^
    bnkTtlReqNo.hashCode ^
    fndUseCd.hashCode ^
    offRgstrYn.hashCode ^
    a300Send.hashCode;
  }
}
