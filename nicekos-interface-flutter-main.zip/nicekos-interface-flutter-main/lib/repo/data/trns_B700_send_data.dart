// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class TrnsB700SendReqData {
  String? loanNo;
  String? trLn;
  String? trCd;
  String? trTpCd;
  String? loNo;
  String? imgTp;
  String? imgCheckYn;
  String? imgKey;
  String? imgPageCnt;
  String? seqNo;
  String? imgFileName;
  String? resultCd;
  String? filler;
  TrnsB700SendReqData({
    this.loanNo,
    this.trLn,
    this.trCd,
    this.trTpCd,
    this.loNo,
    this.imgTp,
    this.imgCheckYn,
    this.imgKey,
    this.imgPageCnt,
    this.seqNo,
    this.imgFileName,
    this.resultCd,
    this.filler,
  });

  TrnsB700SendReqData copyWith({
    String? loanNo,
    String? trLn,
    String? trCd,
    String? trTpCd,
    String? loNo,
    String? imgTp,
    String? imgCheckYn,
    String? imgKey,
    String? imgPageCnt,
    String? seqNo,
    String? imgFileName,
    String? resultCd,
    String? filler,
  }) {
    return TrnsB700SendReqData(
      loanNo: loanNo ?? this.loanNo,
      trLn: trLn ?? this.trLn,
      trCd: trCd ?? this.trCd,
      trTpCd: trTpCd ?? this.trTpCd,
      loNo: loNo ?? this.loNo,
      imgTp: imgTp ?? this.imgTp,
      imgCheckYn: imgCheckYn ?? this.imgCheckYn,
      imgKey: imgKey ?? this.imgKey,
      imgPageCnt: imgPageCnt ?? this.imgPageCnt,
      seqNo: seqNo ?? this.seqNo,
      imgFileName: imgFileName ?? this.imgFileName,
      resultCd: resultCd ?? this.resultCd,
      filler: filler ?? this.filler,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'trLn': trLn,
      'trCd': trCd,
      'trTpCd': trTpCd,
      'loNo': loNo,
      'imgTp': imgTp,
      'imgCheckYn': imgCheckYn,
      'imgKey': imgKey,
      'imgPageCnt': imgPageCnt,
      'seqNo': seqNo,
      'imgFileName': imgFileName,
      'resultCd': resultCd,
      'filler': filler,
    };
  }

  factory TrnsB700SendReqData.fromMap(Map<String, dynamic> map) {
    return TrnsB700SendReqData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      trLn: map['trLn'] != null ? map['trLn'] as String : null,
      trCd: map['trCd'] != null ? map['trCd'] as String : null,
      trTpCd: map['trTpCd'] != null ? map['trTpCd'] as String : null,
      loNo: map['loNo'] != null ? map['loNo'] as String : null,
      imgTp: map['imgTp'] != null ? map['imgTp'] as String : null,
      imgCheckYn: map['imgCheckYn'] != null ? map['imgCheckYn'] as String : null,
      imgKey: map['imgKey'] != null ? map['imgKey'] as String : null,
      imgPageCnt: map['imgPageCnt'] != null ? map['imgPageCnt'] as String : null,
      seqNo: map['seqNo'] != null ? map['seqNo'] as String : null,
      imgFileName: map['imgFileName'] != null ? map['imgFileName'] as String : null,
      resultCd: map['resultCd'] != null ? map['resultCd'] as String : null,
      filler: map['filler'] != null ? map['filler'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnsB700SendReqData.fromJson(String source) => TrnsB700SendReqData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TrnsB700SendReqData(loanNo: $loanNo, trLn: $trLn, trCd: $trCd, trTpCd: $trTpCd, loNo: $loNo, imgTp: $imgTp, imgCheckYn: $imgCheckYn, imgKey: $imgKey, imgPageCnt: $imgPageCnt, seqNo: $seqNo, imgFileName: $imgFileName, resultCd: $resultCd, filler: $filler)';
  }

  @override
  bool operator ==(covariant TrnsB700SendReqData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.trLn == trLn &&
          other.trCd == trCd &&
          other.trTpCd == trTpCd &&
          other.loNo == loNo &&
          other.imgTp == imgTp &&
          other.imgCheckYn == imgCheckYn &&
          other.imgKey == imgKey &&
          other.imgPageCnt == imgPageCnt &&
          other.seqNo == seqNo &&
          other.imgFileName == imgFileName &&
          other.resultCd == resultCd &&
          other.filler == filler;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    trLn.hashCode ^
    trCd.hashCode ^
    trTpCd.hashCode ^
    loNo.hashCode ^
    imgTp.hashCode ^
    imgCheckYn.hashCode ^
    imgKey.hashCode ^
    imgPageCnt.hashCode ^
    seqNo.hashCode ^
    imgFileName.hashCode ^
    resultCd.hashCode ^
    filler.hashCode;
  }
}

class TrnsB700SendResData {
  String? loanNo;
  String? trLn;
  String? trCd;
  String? trTpCd;
  String? loNo;
  String? imgTp;
  String? imgCheckYn;
  String? imgKey;
  String? imgPageCnt;
  String? seqNo;
  String? imgFileName;
  String? resultCd;
  String? filler;
  TrnsB700SendResData({
    this.loanNo,
    this.trLn,
    this.trCd,
    this.trTpCd,
    this.loNo,
    this.imgTp,
    this.imgCheckYn,
    this.imgKey,
    this.imgPageCnt,
    this.seqNo,
    this.imgFileName,
    this.resultCd,
    this.filler,
  });

  TrnsB700SendResData copyWith({
    String? loanNo,
    String? trLn,
    String? trCd,
    String? trTpCd,
    String? loNo,
    String? imgTp,
    String? imgCheckYn,
    String? imgKey,
    String? imgPageCnt,
    String? seqNo,
    String? imgFileName,
    String? resultCd,
    String? filler,
  }) {
    return TrnsB700SendResData(
      loanNo: loanNo ?? this.loanNo,
      trLn: trLn ?? this.trLn,
      trCd: trCd ?? this.trCd,
      trTpCd: trTpCd ?? this.trTpCd,
      loNo: loNo ?? this.loNo,
      imgTp: imgTp ?? this.imgTp,
      imgCheckYn: imgCheckYn ?? this.imgCheckYn,
      imgKey: imgKey ?? this.imgKey,
      imgPageCnt: imgPageCnt ?? this.imgPageCnt,
      seqNo: seqNo ?? this.seqNo,
      imgFileName: imgFileName ?? this.imgFileName,
      resultCd: resultCd ?? this.resultCd,
      filler: filler ?? this.filler,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'loanNo': loanNo,
      'trLn': trLn,
      'trCd': trCd,
      'trTpCd': trTpCd,
      'loNo': loNo,
      'imgTp': imgTp,
      'imgCheckYn': imgCheckYn,
      'imgKey': imgKey,
      'imgPageCnt': imgPageCnt,
      'seqNo': seqNo,
      'imgFileName': imgFileName,
      'resultCd': resultCd,
      'filler': filler,
    };
  }

  factory TrnsB700SendResData.fromMap(Map<String, dynamic> map) {
    return TrnsB700SendResData(
      loanNo: map['loanNo'] != null ? map['loanNo'] as String : null,
      trLn: map['trLn'] != null ? map['trLn'] as String : null,
      trCd: map['trCd'] != null ? map['trCd'] as String : null,
      trTpCd: map['trTpCd'] != null ? map['trTpCd'] as String : null,
      loNo: map['loNo'] != null ? map['loNo'] as String : null,
      imgTp: map['imgTp'] != null ? map['imgTp'] as String : null,
      imgCheckYn: map['imgCheckYn'] != null ? map['imgCheckYn'] as String : null,
      imgKey: map['imgKey'] != null ? map['imgKey'] as String : null,
      imgPageCnt: map['imgPageCnt'] != null ? map['imgPageCnt'] as String : null,
      seqNo: map['seqNo'] != null ? map['seqNo'] as String : null,
      imgFileName: map['imgFileName'] != null ? map['imgFileName'] as String : null,
      resultCd: map['resultCd'] != null ? map['resultCd'] as String : null,
      filler: map['filler'] != null ? map['filler'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TrnsB700SendResData.fromJson(String source) => TrnsB700SendResData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TrnsB700SendResData(loanNo: $loanNo, trLn: $trLn, trCd: $trCd, trTpCd: $trTpCd, loNo: $loNo, imgTp: $imgTp, imgCheckYn: $imgCheckYn, imgKey: $imgKey, imgPageCnt: $imgPageCnt, seqNo: $seqNo, imgFileName: $imgFileName, resultCd: $resultCd, filler: $filler)';
  }

  @override
  bool operator ==(covariant TrnsB700SendResData other) {
    if (identical(this, other)) return true;

    return
      other.loanNo == loanNo &&
          other.trLn == trLn &&
          other.trCd == trCd &&
          other.trTpCd == trTpCd &&
          other.loNo == loNo &&
          other.imgTp == imgTp &&
          other.imgCheckYn == imgCheckYn &&
          other.imgKey == imgKey &&
          other.imgPageCnt == imgPageCnt &&
          other.seqNo == seqNo &&
          other.imgFileName == imgFileName &&
          other.resultCd == resultCd &&
          other.filler == filler;
  }

  @override
  int get hashCode {
    return loanNo.hashCode ^
    trLn.hashCode ^
    trCd.hashCode ^
    trTpCd.hashCode ^
    loNo.hashCode ^
    imgTp.hashCode ^
    imgCheckYn.hashCode ^
    imgKey.hashCode ^
    imgPageCnt.hashCode ^
    seqNo.hashCode ^
    imgFileName.hashCode ^
    resultCd.hashCode ^
    filler.hashCode;
  }
}

