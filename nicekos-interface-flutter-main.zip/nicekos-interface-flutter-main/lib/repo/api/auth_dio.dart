// auth_dio.dart

import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:dio/src/response.dart' as R;
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';

import 'package:pretty_dio_logger/pretty_dio_logger.dart';
import 'dart:developer' as d;

import '../../app/auth/auth_cntr.dart';
import '../../config/url_config.dart';
import '../../utils/log_utils.dart';
import '../response/res_data.dart';


// Access-Control-Allow-Credentials: true, Access-Control-Allow-Headers: Origin,
// abstract class AuthDio
abstract class AuthDio {
  AuthDio._();

  static Dio run() {
    final dio = Dio(BaseOptions(
        headers: {
          'Content-Type': 'application/json',
          'accept': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Credentials': 'true',
          'Access-Control-Allow-Headers': 'Origin'
        },
        connectTimeout: const Duration(seconds: 20),
        receiveTimeout: const Duration(seconds: 60)));

    dio.interceptors.clear();
    dio.interceptors.add(interceptorsWrapper(dio));
    dio.interceptors.add(PrettyDioLogger(
      requestHeader: true,
      requestBody: true,
      responseBody: true,
      responseHeader: true,
      error: true,
      compact: true,
      maxWidth: 120,
    ));

    return dio;
  }

  static Future<dynamic> getRefreshToken() async {
    //로그인 서비스 개발 완료 시 주석 해제
    // String? aToken = AuthCntr.to.resLoginData.value.accessToken;
    // String? rToken = AuthCntr.to.resLoginData.value.refreshToken;
    //토큰 하드코딩 (로그인 서비스 개발 완료시 삭제될 예정)
    // 박원준토큰
    // String? aToken =  'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJhZG1pbk5vIjoicGp3NTg0NUBiYW5rbGUuY28ua3IiLCJpc0FkbWluIjoiWSIsImV4cCI6MTg4Mzc5OTg4NX0.619bR1FBAxIGy9X48RPHnIIfYo5HX9sNcyd6Z5kASIUofj__QtYo7BrRpjhPl7-7krkWOcsc41vaJSbJeXBimw';
    // String? rToken =
    'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJhZG1pbk5vIjoiYmFua2xlIiwiaXNBZG1pbiI6IlkiLCJleHAiOjE3MzcxODQwNTF9.J51ibKjmitYh1nxWnbkKyVJNL8l3_MCr35H1RO7k_l4d1qaOAdZKD2Gw0oTXRppVfDmKAC7ZJOs8xZ68Nxd7Ug';
    // 홍다인 토큰
    String? aToken =
        'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJhZG1pbk5vIjoiaGRpMDEwNEBiYW5rbGUuY28ua3IiLCJBRE1JTl9ST0xFIjoiMDEiLCJpc0FkbWluIjoiWSIsImV4cCI6MTg4NTUyNTQ4Nn0.vIH0iRxclqBqb_2mDoKitQOVO3ypDfaYHKnopPOLo8bz3GfTFtth09zUqOADQxxyAmFh-cLi4xEl3xS2LQhXQA';
    String? rToken =
        'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJhZG1pbk5vIjoiaGRpMDEwNEBiYW5rbGUuY28ua3IiLCJpc0FkbWluIjoiWSIsImV4cCI6MTg4Mzc5OTkwOX0.fPRHr_lNOzUevUV4SDRlZpXWM3wqe_NU3Det7DKQfA_fX83kgO1I4nllfB6d0Jcc3SSbK_KQreGs3HtPOU4_fw';
    final rDio = Dio();

    rDio.interceptors.clear();
    rDio.interceptors.add(refreshInterCepter());

    final refreshResponse = await rDio.request(
      '${UrlConfig.authURL}/auth/refreshtoken',
      data: {'accessToken': aToken ?? 'aa', 'refreshToken': rToken ?? 'bvb'},
      options: Options(method: 'POST'),
    );

    final rMap = json.decode(refreshResponse.toString());
    final naToken = rMap["accessToken"];
    final nrToken = rMap["refreshToken"];

    if (naToken == "") {
      return naToken;
    }

    d.log("[새로운 토큰 발급 완료]");
    d.log("newAccessToken : $naToken");

    AuthCntr.to.resLoginData.value.accessToken = naToken;
    AuthCntr.to.resLoginData.value.refreshToken = (nrToken);

    // AuthCntr.to.saveStorgeAll(TokenData(
    //     accessToken: naToken,
    //     refreshToken: nrToken,
    //     firebaseToken: "",
    //     userid: ""));

    return naToken;
  }

  static InterceptorsWrapper interceptorsWrapper(dio) {
    return InterceptorsWrapper(onRequest: (options, handler) async {
      try {
        //로그인 서비스 개발 완료 시 주석 해제
        // if (!StringUtils2.isEmpty(AuthCntr.to.resLoginData.value.accessToken)) {
        //   options.headers['Authorization'] =
        //       'Bearer ${AuthCntr.to.resLoginData.value.accessToken}';
        // }
        final storage = FlutterSecureStorage();
        String? aToken = await storage.read(key: 'accessToken') ?? '';

        String currentRoute = Get.currentRoute;
        // 현재 페이지 URI에 '/MeloAuth01Page'가 포함되어 있으면 제외
        bool isExcludedPath = currentRoute.contains('/MeloAuth01Page');
        String? isLogin = await storage.read(key: 'lognYn') ?? '';


        Lo.g('aToken ::::>>> $aToken');


        options.headers['Authorization'] = 'Bearer $aToken';

        return handler.next(options);
      } catch (e) {
        return handler.next(options);
      }
    }, onError: (error, handler) async {
      if (error.response?.statusCode == 401) {
        /**
         * RefreshToken 사용안함. 토큰 만료 또는 세션만료시 자동 로그아웃 처리로 변경
         */
        // final naToken = await getRefreshToken() ?? '';
        // if (naToken == "") {
        //   Get.snackbar("리플레쉬 토큰 오류!", "토큰이 재발급에 오류가 발생했습니다. 다시 로그인해주세요!");
        //   Get.offAllNamed('/MeloAuth01Page');
        //   return;
        // }
        // error.requestOptions.headers['Authorization'] = 'Bearer $naToken';
        // dynamic clonedRequest;
        // try {
        //   clonedRequest = await dio.request(error.requestOptions.path,
        //       options: Options(
        //           method: error.requestOptions.method,
        //           headers: error.requestOptions.headers),
        //       data: error.requestOptions.data,
        //       queryParameters: error.requestOptions.queryParameters);
        // } catch (e) {
        //   e.printError();
        // }
        // return handler.resolve(clonedRequest);

        final storage = FlutterSecureStorage();
        String? isChecked = await storage.read(key: 'isChecked') ?? '';
        String? isLogin = await storage.read(key: 'lognYn') ?? '';

        if (isChecked == 'true') {
          storage.delete(key: 'accessToken');
          storage.delete(key: 'refreshToken');
          storage.delete(key: 'lognYn');
        } else {
          storage.deleteAll();
        }
      }

      // pring("error:  $ error.response?.statusCode");
      return handler.reject(error);
      //return handler.resolve(error.response!);
    });
  }

  static InterceptorsWrapper refreshInterCepter() {
    return InterceptorsWrapper(onError: (error, handler) async {
      if (error.response?.statusCode != 200) {
        Get.snackbar("리플레쉬 토큰만료!", "토큰이 만료되었습니다. 다시 로그인해주세요!");
        Get.offAllNamed('/MeloAuth01Page');
      }
      return handler.next(error);
    });
  }

  static ResData dioResponse(R.Response response) {
    if (response.statusCode == 200) {
      try {
        return ResData.fromMap(response.data);
      } catch (e1) {
        return ResData.fromJson(response.data);
      }
    }
    // 200이 아니면
    try {
      return ResData.fromMap(jsonDecode(response.toString()));
    } catch (e1) {
      return ResData.fromJson(jsonEncode(response.toString()));
    }
  }

  static ResData dioException(DioException e) {
    String message = "모바일 네트워크 장애가 발생했습니다.  ${e.message}";
    debugPrint("========================================");
    debugPrint("###  DioException 2: ${e.response}");
    debugPrint("========================================");
    if (e.response != null) {
      try {
        message = ResData.fromMap(e.response!.data).msg!;
      } catch (e1) {
        message = ResData.fromJson(e.response!.data).msg!;
      }
    }

    return ResData(code: "99", msg: message);
  }
}
