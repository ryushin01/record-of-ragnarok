import 'package:dio/dio.dart';
import 'package:nicekos_interface_flutter/repo/response/res_data.dart';

import '../config/url_config.dart';
import '../utils/log_utils.dart';
import 'api/auth_dio.dart';

class PaymentRepo {

  Future<ResData> searchPaymentList(String loanNo) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/cntr/searchpaymentlist/$loanNo";
      var response = await AuthDio.run().post(url);
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }
}