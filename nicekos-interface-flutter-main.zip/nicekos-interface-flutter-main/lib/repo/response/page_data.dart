// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class PageData {
  int? currPageNum;
  int? totalPageNum;
  int? pageSize;
  int? totalElements;
  bool? last;
  PageData({
    this.currPageNum,
    this.totalPageNum,
    this.pageSize,
    this.totalElements,
    this.last,
  });

  PageData copyWith({
    int? currPageNum,
    int? totalPageNum,
    int? pageSize,
    int? totalElements,
    bool? last,
  }) {
    return PageData(
      currPageNum: currPageNum ?? this.currPageNum,
      totalPageNum: totalPageNum ?? this.totalPageNum,
      pageSize: pageSize ?? this.pageSize,
      totalElements: totalElements ?? this.totalElements,
      last: last ?? this.last,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'currPageNum': currPageNum,
      'totalPageNum': totalPageNum,
      'pageSize': pageSize,
      'totalElements': totalElements,
      'last': last,
    };
  }

  factory PageData.fromMap(Map<String, dynamic> map) {
    return PageData(
      currPageNum: map['currPageNum'] != null ? map['currPageNum'] as int : null,
      totalPageNum: map['totalPageNum'] != null ? map['totalPageNum'] as int : null,
      pageSize: map['pageSize'] != null ? map['pageSize'] as int : null,
      totalElements: map['totalElements'] != null ? map['totalElements'] as int : null,
      last: map['last'] != null ? map['last'] as bool : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory PageData.fromJson(String source) => PageData.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'PageData(currPageNum: $currPageNum, totalPageNum: $totalPageNum, pageSize: $pageSize, totalElements: $totalElements, last: $last)';
  }

  @override
  bool operator ==(covariant PageData other) {
    if (identical(this, other)) return true;

    return other.currPageNum == currPageNum &&
        other.totalPageNum == totalPageNum &&
        other.pageSize == pageSize &&
        other.totalElements == totalElements &&
        other.last == last;
  }

  @override
  int get hashCode {
    return currPageNum.hashCode ^ totalPageNum.hashCode ^ pageSize.hashCode ^ totalElements.hashCode ^ last.hashCode;
  }
}
