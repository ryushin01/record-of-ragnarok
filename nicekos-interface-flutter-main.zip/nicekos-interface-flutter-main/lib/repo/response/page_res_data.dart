import 'package:nicekos_interface_flutter/repo/response/page_data.dart';

class PageResData<T> {
  PageData? pageData;
  T? data;
}
