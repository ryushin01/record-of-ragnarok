import 'package:dio/dio.dart';
import 'package:nicekos_interface_flutter/repo/data/cntr_info_chng_data.dart';
import 'package:nicekos_interface_flutter/repo/response/res_data.dart';

import '../config/url_config.dart';
import '../utils/log_utils.dart';
import 'api/auth_dio.dart';

class CntrDetailRepo {

  Future<ResData> searchCntrDtl(String loanNo) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/cntr/searchcntrdetail/$loanNo";
      var response = await AuthDio.run().post(url);
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

  Future<ResData> modifyCntrInfo(CntrChngReqData reqData) async {
    try {
      // Rest api uri
      String url = "${UrlConfig.bankifURL}/cntr/modifycntrinfo";
      var response = await AuthDio.run().post(url, data: reqData.toJson());
      return AuthDio.dioResponse(response);
    } on DioException catch (e) {
      Lo.g("catch log");
      return AuthDio.dioException(e);
    }
  }

}