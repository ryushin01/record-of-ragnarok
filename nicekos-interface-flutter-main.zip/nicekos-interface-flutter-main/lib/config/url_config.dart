class UrlConfig {
  static String get bankifURL => "https://bankifdev.kosapp.co.kr/api";
  // static String get bankifURL => "http://localhost:8099/api";
  static String get authURL => "https://authdev.kosapp.co.kr/api";
}
