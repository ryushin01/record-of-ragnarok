import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:nicekos_interface_flutter/theme/theme.dart';

import 'colors.dart';
import 'text_style.dart';

class TextSyle {
  static TextStyle text(
      {TextStyle? textStyle,
      int fontWeight = 400,
      bool muted = false,
      bool xMuted = false,
      double? letterSpacing,
      Color? color,
      TextDecoration decoration = TextDecoration.none,
      double? height,
      double? wordSpacing,
      double? fontSize}) {
    return const TextStyle(
      color: gray100,
      fontSize: 12,
      fontFamily: 'Noto Sans KR',
      fontWeight: FontWeight.w500,
      //height: 0.12,
    );
  }

  static TextStyle title(
      {TextStyle? textStyle,
        int fontWeight = 400,
        bool muted = false,
        bool xMuted = false,
        double? letterSpacing,
        Color? color,
        TextDecoration decoration = TextDecoration.none,
        double? height,
        double? wordSpacing,
        double? fontSize}) {
    return const TextStyle(
      color: gray100,
      fontSize: 18,
      fontFamily: 'Noto Sans KR',
      fontWeight: FontWeight.w500,
      //height: 0.12,
    );
  }

  static TextStyle dialogText(
      {TextStyle? textStyle,
        int fontWeight = 400,
        bool muted = false,
        bool xMuted = false,
        double? letterSpacing,
        Color? color,
        TextDecoration decoration = TextDecoration.none,
        double? height,
        double? wordSpacing,
        double? fontSize}) {
    return const TextStyle(
      decoration: TextDecoration.underline,
      color: gray100,
      fontSize: 12,
      fontFamily: 'Noto Sans KR',
      fontWeight: FontWeight.w500,
      //height: 0.12,
    );
  }

  static TextStyle dataTable(
      {TextStyle? textStyle,
        int fontWeight = 400,
        bool muted = false,
        bool xMuted = false,
        double? letterSpacing,
        Color? color,
        TextDecoration decoration = TextDecoration.none,
        double? height,
        double? wordSpacing,
        double? fontSize}) {
    return const TextStyle(
      color: gray100,
      fontSize: 12,
      fontFamily: 'Noto Sans KR',
      fontWeight: FontWeight.w500,
      decoration: TextDecoration.underline
      //height: 0.2,
    );
  }

  static TextStyle inputFormText(
      {TextStyle? textStyle,
        int fontWeight = 400,
        bool muted = false,
        bool xMuted = false,
        double? letterSpacing,
        Color? color,
        TextDecoration decoration = TextDecoration.none,
        double? height,
        double? wordSpacing,
        double? fontSize}) {
    return const TextStyle(
      color: gray900,
      fontSize: 12,
      fontFamily: 'Noto Sans KR',
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle searchFormText(
      {TextStyle? textStyle,
        int fontWeight = 400,
        bool muted = false,
        bool xMuted = false,
        double? letterSpacing,
        Color? color,
        //TextDecoration decoration = TextDecoration.none,
        double? height,
        double? wordSpacing,
        double? fontSize}) {
    return const TextStyle(
      color: white,
      fontSize: 12,
      fontFamily: 'Noto Sans KR',
      fontWeight: FontWeight.w400,
    );
  }
}
