import 'dart:async';
import 'dart:ui';

import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/rendering.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:nicekos_interface_flutter/theme/colors.dart';

import '../repo/data/search_payment_list_data.dart';
import '../repo/data/trns_hist_data.dart';
import '../repo/response/res_stream.dart';
import '../theme/spacing.dart';
import '../theme/text_style.dart';
import '../widget/custom_button.dart';
import '../widget/error_page.dart';
import '../widget/if_divider.dart';
import '../widget/no_data_widget.dart';

abstract class IfUtils {
  IfUtils._();

  static void alert(String msg) {
    //  BotToast.showText(
    //     text: msg,
    //     contentColor: Colors.black.withOpacity(0.67),
    //     contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 25),
    //     textStyle: const TextStyle(fontSize: 14, color: Colors.white),
    //     duration: const Duration(seconds: 2),
    //     onlyOne: false);
    BotToast.showCustomText(
      duration: const Duration(milliseconds: 2500),
      // onlyOne: onlyOne,
      //  clickClose: clickClose,
      //  crossPage: crossPage,
      //  ignoreContentClick: ignoreContentClick,
      //   backgroundColor: Colors.black54,
      backButtonBehavior: BackButtonBehavior.none,
      animationDuration: const Duration(milliseconds: 300),
      animationReverseDuration: const Duration(milliseconds: 200),
      toastBuilder: (_) => Align(
        alignment: const Alignment(0, 0.47),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 5),
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: Colors.white,
            // color: Colors.black.withOpacity(0.2),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            msg,
            style: TextStyle(fontSize: 16, color: Colors.black),
          ),
        ),
      ),
    );
  }

  static void alertLong(String msg) {
    BotToast.showText(
        text: msg,
        contentColor: Colors.black.withOpacity(0.67),
        contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
        textStyle: const TextStyle(fontSize: 14, color: Colors.white),
        duration: const Duration(seconds: 5),
        onlyOne: false);
  }

  static void alertIcon(String msg, {String? icontype, Duration? duration}) {
    Color clr = const Color(0xFF4BCB1E);
    IconData icondata = Icons.check_rounded;
    if (icontype == 'E') {
      clr = const Color(0xFFE23E28);
      icondata = Icons.clear_rounded;
    } else if (icontype == 'W') {
      clr = const Color(0xFFFF9900);
      icondata = Icons.priority_high_rounded;
    }
    BotToast.showCustomText(
      duration: duration ?? const Duration(seconds: 2),
      // onlyOne: onlyOne,
      //  clickClose: clickClose,
      //  crossPage: crossPage,
      //  ignoreContentClick: ignoreContentClick,
      //   backgroundColor: Color(backgroundColor),
      backButtonBehavior: BackButtonBehavior.none,
      animationDuration: const Duration(milliseconds: 300),
      animationReverseDuration: const Duration(milliseconds: 200),
      toastBuilder: (_) => Align(
        alignment: const Alignment(0, 0.47),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 22,
                height: 22,
                decoration: ShapeDecoration(
                  color: clr,
                  shape: const OvalBorder(),
                ),
                child: Center(
                  child: Icon(
                    icondata,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
              ),
              const Gap(5),
              Flexible(
                child: Text(
                  msg,
                  softWrap: true,
                  maxLines: 2,
                  style: const TextStyle(fontSize: 14, color: Colors.black),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static void showAlertDialog(String? title, String? subtitle, String? buttonText, BackButtonBehavior backButtonBehavior,
      {VoidCallback? confirm, VoidCallback? backgroundReturn}) {
    BotToast.showAnimationWidget(
        clickClose: false,
        allowClick: false,
        onlyOne: true,
        crossPage: true,
        backButtonBehavior: backButtonBehavior,
        wrapToastAnimation: (controller, cancel, child) => Stack(
              children: <Widget>[
                GestureDetector(
                  onTap: () {
                    cancel();
                    backgroundReturn?.call();
                  },
                  //The DecoratedBox here is very important,he will fill the entire parent component
                  child: AnimatedBuilder(
                    builder: (_, child) => Opacity(
                      opacity: controller.value,
                      child: child,
                    ),
                    animation: controller,
                    child: const DecoratedBox(
                      decoration: BoxDecoration(color: Colors.black26),
                      child: SizedBox.expand(),
                    ),
                  ),
                ),
                CustomOffsetAnimation(
                  controller: controller,
                  child: child,
                )
              ],
            ),
        toastBuilder: (cancelFunc) => AlertDialog(
              backgroundColor: Colors.white,
              surfaceTintColor: Colors.transparent,
              insetPadding: const EdgeInsets.symmetric(horizontal: 16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              title: SizedBox(
                width: 100,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title.toString(),
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (subtitle != null) ...[
                      const Gap(5),
                      Text(
                        subtitle.toString(),
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ]
                  ],
                ),
              ),
              actions: <Widget>[
                CustomButton(
                    text: '$buttonText',
                    type: 'L',
                    isEnable: true,
                    widthValue: 300,
                    heightValue: 46,
                    onPressed: () {
                      cancelFunc();
                      confirm?.call();
                    }),
              ],
            ),
        animationDuration: const Duration(milliseconds: 300));
  }

  static void showConfirmDialog(String title, String subtitle, BackButtonBehavior backButtonBehavior,
      {VoidCallback? cancel, VoidCallback? confirm, VoidCallback? backgroundReturn}) {
    BotToast.showAnimationWidget(
        clickClose: false,
        allowClick: false,
        onlyOne: true,
        crossPage: true,
        backButtonBehavior: backButtonBehavior,
        wrapToastAnimation: (controller, cancel, child) => Stack(
              children: <Widget>[
                GestureDetector(
                  onTap: () {
                    cancel();
                    backgroundReturn?.call();
                  },
                  //The DecoratedBox here is very important,he will fill the entire parent component
                  child: AnimatedBuilder(
                    builder: (_, child) => Opacity(
                      opacity: controller.value,
                      child: child,
                    ),
                    animation: controller,
                    child: const DecoratedBox(
                      decoration: BoxDecoration(color: Colors.black26),
                      child: SizedBox.expand(),
                    ),
                  ),
                ),
                CustomOffsetAnimation(
                  controller: controller,
                  child: child,
                )
              ],
            ),
        toastBuilder: (cancelFunc) => AlertDialog(
              backgroundColor: Colors.grey[800],
              surfaceTintColor: Colors.transparent,
              insetPadding: const EdgeInsets.symmetric(horizontal: 16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              title: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title.toString(),
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (subtitle != null) ...[
                    const Gap(10),
                    Text(
                      subtitle.toString(),
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ]
                ],
              ),
              actions: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                          elevation: 3,
                          padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 20),
                        ),
                        onPressed: () {
                          cancelFunc();
                          cancel?.call();
                        },
                        child: Text('취소')),
                    const Gap(20),
                    ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                          elevation: 3,
                          padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 20),
                        ),
                        onPressed: () {
                          cancelFunc();
                          confirm?.call();
                        },
                        child: Text('확인')),
                  ],
                ),
              ],
            ),
        animationDuration: const Duration(milliseconds: 300));
  }

  static Widget progressbar({double? size}) {
    return Center(
      child: LoadingAnimationWidget.threeRotatingDots(
        color: Colors.orange,
        size: size ?? 40,
      ),
    );
  }

  static void showAutomaticCloseDialog(
    String? title,
    String? subtitle,
    Duration? duration, {
    VoidCallback? close,
  }) {
    BotToast.showAnimationWidget(
      allowClick: false,
      clickClose: false,
      onlyOne: true,
      crossPage: true,
      wrapToastAnimation: (controller, cancel, child) => Stack(
        children: <Widget>[
          GestureDetector(
            //The DecoratedBox here is very important,he will fill the entire parent component
            child: AnimatedBuilder(
              builder: (_, child) => Opacity(
                opacity: controller.value,
                child: child,
              ),
              animation: controller,
              child: const DecoratedBox(
                decoration: BoxDecoration(color: Colors.black26),
                child: SizedBox.expand(),
              ),
            ),
          ),
          CustomOffsetAnimation(
            controller: controller,
            child: child,
          )
        ],
      ),
      toastBuilder: (cancelFunc) => AlertDialog(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 20),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: SizedBox(
          width: Get.width,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  title.toString(),
                  style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
              if (subtitle != null) ...[
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(
                    subtitle.toString(),
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ]
            ],
          ),
        ),
      ),
      animationDuration: const Duration(milliseconds: 300),
      duration: duration,
      onClose: () {
        close?.call();
        // Navigator.of(Get.context!).pop();
      },
    );
  }

  static Widget commonStreamList<T>(StreamController stream, Widget Function(List<T>) buildBody, Function()? onRetryPressed) {
    return StreamBuilder<ResStream<List<T>>>(
      stream: stream.stream as Stream<ResStream<List<T>>>?,
      builder: (BuildContext context, AsyncSnapshot<ResStream<List<T>>> snapshot) {
        if (snapshot.hasData) {
          switch (snapshot.data?.status) {
            case Status.LOADING:
              return Center(
                  child: Padding(
                padding: const EdgeInsets.all(50.0),
                child: IfUtils.progressbar(),
              ));
            case Status.COMPLETED:
              var list = snapshot.data!.data;
              return list!.isEmpty ? const NoDataWidget() : buildBody(list);
            case Status.ERROR:
              return ErrorPage(
                errorMessage: snapshot.data!.message ?? '',
                onRetryPressed: onRetryPressed,
              );
            case null:
              return const SizedBox(
                width: 200,
                height: 300,
                child: Text("조회 중 오류가 발생했습니다."),
              );
          }
        }
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(48.0),
            child: Text(
              '조회 된 데이터가 없습니다.',
              style: TextSyle.text(),
            ),
            //child: Text("조회 된 데이터가 없습니다.",),
          ),
        );
      },
    );
  }

  static Widget commonStreamList2<T>(StreamController stream, Widget Function(List<T>) buildBody, Function()? onRetryPressed,) {
    return StreamBuilder<ResStream<List<T>>>(
      stream: stream.stream as Stream<ResStream<List<T>>>?,
      builder: (BuildContext context, AsyncSnapshot<ResStream<List<T>>> snapshot) {
        if (snapshot.hasData) {
          switch (snapshot.data?.status) {
            case Status.LOADING:
              return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(50.0),
                    child: IfUtils.progressbar(),
                  ));
            case Status.COMPLETED:
              var list = snapshot.data!.data;
              // 데이터가 없을 경우, 화면을 유지하고 대신 빈 상태를 표시
              return buildBody(list ?? []);
            case Status.ERROR:
              return ErrorPage(
                errorMessage: snapshot.data!.message ?? '',
                onRetryPressed: onRetryPressed,
              );
            case null:
              return const SizedBox(
                width: 200,
                height: 300,
                child: Text("조회 중 오류가 발생했습니다."),
              );
          }
        }
        // 데이터를 가져오지 못한 경우에도 기존 화면을 유지
        return buildBody([]);
      },
    );
  }

  static Widget commonStreamList3<T>(StreamController stream, Widget Function
      (List<T>) buildBody, Function()? onRetryPressed,) {
    return StreamBuilder<ResStream<List<T>>>(
      stream: stream.stream as Stream<ResStream<List<T>>>?,
      builder: (BuildContext context, AsyncSnapshot<ResStream<List<T>>> snapshot) {
        if (snapshot.hasData) {
          switch (snapshot.data?.status) {
            case Status.LOADING:
              return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(50.0),
                    child: IfUtils.progressbar(),
                  ));
            case Status.COMPLETED:
              var list = snapshot.data!.data;
              // 데이터가 없을 경우, 화면을 유지하고 대신 빈 상태를 표시
              return buildBody(list ?? []);
            case Status.ERROR:
              return ErrorPage(
                errorMessage: snapshot.data!.message ?? '',
                onRetryPressed: onRetryPressed,
              );
            case null:
              return const SizedBox(
                width: 200,
                height: 300,
                child: Text("조회 중 오류가 발생했습니다."),
              );
          }
        }
        // 데이터를 가져오지 못한 경우에도 기존 화면을 유지
        return buildBody([]);
      },
    );
  }

  static Widget commonStreamBody<T>(StreamController stream, Widget Function(T) buildBody, Function()? onRetryPressed) {
    return StreamBuilder<ResStream<T>>(
      stream: stream.stream as Stream<ResStream<T>>?,
      builder: (BuildContext context, AsyncSnapshot<ResStream<T>> snapshot) {
        if (snapshot.hasData) {
          switch (snapshot.data?.status) {
            case Status.LOADING:
              return Center(
                  child: Padding(
                padding: const EdgeInsets.all(50.0),
                child: IfUtils.progressbar(),
              ));
            case Status.COMPLETED:
              var result = snapshot.data!.data;
              return result == null ? const NoDataWidget() : buildBody(result);
            case Status.ERROR:
              return ErrorPage(
                errorMessage: snapshot.data!.message ?? '',
                onRetryPressed: onRetryPressed,
              );
            case null:
              return const SizedBox(
                width: 200,
                height: 300,
                child: Text("조회 중 오류가 발생했습니다."),
              );
          }
        }
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(48.0),
            child: Text(
              '조회 된 데이터가 없습니다.',
              style: TextSyle.text(),
            ),
            //child: Text("조회 된 데이터가 없습니다.",),
          ),
        );
      },
    );
  }
  static Widget buildCategory(String text) {
    return Container(
      alignment: Alignment.centerLeft,
      child: Text(
        text,
        style: const TextStyle(
          color: white,
          fontSize: 14,
          fontFamily: 'Noto Sans KR',
          fontWeight: FontWeight.w500,
          height: 0.10,
        ),
      ),
    );
  }
}

class CustomOffsetAnimation extends StatefulWidget {
  final AnimationController controller;
  final Widget child;

  const CustomOffsetAnimation({super.key, required this.controller, required this.child});

  @override
  // ignore: library_private_types_in_public_api
  _CustomOffsetAnimationState createState() => _CustomOffsetAnimationState();
}

class _CustomOffsetAnimationState extends State<CustomOffsetAnimation> {
  late Tween<Offset> tweenOffset;
  late Tween<double> tweenScale;

  late Animation<double> animation;

  @override
  void initState() {
    tweenOffset = Tween<Offset>(
      begin: const Offset(0.0, 0.8),
      end: Offset.zero,
    );
    tweenScale = Tween<double>(begin: 0.3, end: 1.0);
    animation = CurvedAnimation(parent: widget.controller, curve: Curves.decelerate);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (BuildContext context, Widget? child) {
        return FractionalTranslation(
            translation: tweenOffset.evaluate(animation),
            child: ClipRect(
              child: Transform.scale(
                scale: tweenScale.evaluate(animation),
                child: Opacity(
                  opacity: animation.value,
                  child: child,
                ),
              ),
            ));
      },
      child: widget.child,
    );
  }


}

class PaginationControls extends StatelessWidget {
  final int currentPage;
  final int totalPages;
  final ValueChanged<int> onPageChanged;

  PaginationControls({
    required this.currentPage,
    required this.totalPages,
    required this.onPageChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            icon: Icon(Icons.chevron_left),
            onPressed: currentPage > 0
                ? () {
              onPageChanged(currentPage - 1);
            }
                : null,
          ),
          // 페이지 번호 버튼들
          for (int i = 0; i < totalPages; i++)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 1.0),
              child: TextButton(
                onPressed: () {
                  onPageChanged(i);
                },
                child: Text(
                  '${i + 1}', // 페이지 번호는 1부터 시작하므로 i + 1
                  style: TextStyle(
                    fontWeight: currentPage == i ? FontWeight.bold : FontWeight.normal,
                    color: currentPage == i ? Colors.black : Colors.grey,
                  ),
                ),
              ),
            ),
          IconButton(
            icon: Icon(Icons.chevron_right),
            onPressed: currentPage < totalPages - 1
                ? () {
              onPageChanged(currentPage + 1);
            }
                : null,
          ),
        ],
      ),
    );
  }
}

// 다수 데이터 리스트 출력
class PaginationControls2 extends StatelessWidget {
  final int currentPage;
  final int totalPages;
  final ValueChanged<int> onPageChanged;

  PaginationControls2({
    required this.currentPage,
    required this.totalPages,
    required this.onPageChanged,
  });

  @override
  Widget build(BuildContext context) {
    // 표시할 페이지 그룹의 시작 인덱스 계산
    int startPage = (currentPage ~/ 10) * 10;
    int endPage = (startPage + 10 > totalPages) ? totalPages : startPage + 10;

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            icon: Icon(Icons.chevron_left),
            onPressed: currentPage > 0
                ? () {
              int previousGroupStart = ((currentPage ~/ 10) * 10) - 10;
              if (previousGroupStart < 0) {
                previousGroupStart = 0;
              }
              onPageChanged(previousGroupStart);
            }
                : null,
          ),
          for (int i = startPage; i < endPage; i++)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 1.0),
              child: TextButton(
                onPressed: () {
                  onPageChanged(i);
                },
                child: Text(
                  '${i + 1}',
                  style: TextStyle(
                    fontWeight: currentPage == i ? FontWeight.bold : FontWeight.normal,
                    color: currentPage == i ? Colors.black : Colors.grey,
                  ),
                ),
              ),
            ),
          IconButton(
            icon: Icon(Icons.chevron_right),
            onPressed: currentPage < totalPages - 1
                ? () {
              int nextPage = ((currentPage ~/ 10) + 1) * 10;
              if (nextPage < totalPages) {
                onPageChanged(nextPage);
              } else {
                onPageChanged(totalPages - 1);
              }
            }
                : null,
          ),
          if (endPage < totalPages)
            IconButton(
              icon: Icon(Icons.more_horiz),
              onPressed: () {
                onPageChanged(totalPages - 1); // 마지막 페이지로 이동
              },
            ),
        ],
      ),
    );
  }
}

// 공통 팝업창
class ShowWebDialog extends StatelessWidget {
  final String title; // 제목 텍스트
  final double width;
  final String saveButtonText; // '수정' 버튼 텍스트
  final String closeButtonText; // '삭제' 버튼 텍스트
  final VoidCallback? onSave; // '수정' 버튼 클릭 시 실행될 함수
  final VoidCallback? onClose; // '삭제' 버튼 클릭 시 실행될 함수
  final bool showButtons; // 버튼 표시 여부
  final Widget content; // 본문에 들어갈 위젯
  final String buttonAlignment; // start, end, center
  final double borderRadius;

  ShowWebDialog({
    required this.title,
    required this.width,
    this.saveButtonText = '저장', // 기본값 '저장'
    this.closeButtonText = '수정', // 기본값 '수정'
    this.onSave,
    this.onClose,
    this.showButtons = true, // 기본값 true
    required this.content,
    this.buttonAlignment = 'center',
    this.borderRadius = 0,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(borderRadius), // 모서리 둥글기 제거
      ),
      surfaceTintColor: Colors.white,
      child: SizedBox(
        width: width,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 고정된 상단 Container + 닫기 버튼
            Stack(
              children: [
                Container(
                  width: width,
                  decoration: BoxDecoration(
                    color: Colors.black, // 배경색 검정으로 설정
                    borderRadius:  BorderRadius.only(
                      topLeft: Radius.circular(borderRadius),  // 좌상단 반경
                      topRight: Radius.circular(borderRadius), // 우상단 반경
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Text(
                      title, // 제목 텍스트
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontFamily: 'Noto Sans KR',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  right: 0,
                  top: 0,
                  child: IconButton(
                    icon: const Icon(Icons.close, color: Colors.white),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
              ],
            ),
            // 스크롤 가능한 본문 내용
            Flexible(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      content, // 본문 내용
                      if (showButtons) // 버튼 표시 여부에 따라 표시
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Row(
                            mainAxisAlignment: buttonAlignment == 'end'
                                ? MainAxisAlignment.end
                                : buttonAlignment == 'start'
                                ? MainAxisAlignment.start
                                : MainAxisAlignment.center,
                            children: [
                              ElevatedButton(
                                onPressed: onSave ?? () {},
                                style: ElevatedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 10),
                                  backgroundColor: Colors.black,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: Text(
                                  saveButtonText, // '수정' 버튼 텍스트
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontFamily: 'Noto Sans',
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              OutlinedButton(
                                onPressed: onClose ??
                                        () {
                                      Navigator.pop(context);
                                    },
                                style: OutlinedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 3, vertical: 8),
                                  side: const BorderSide(color: Colors.black),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: Text(
                                  closeButtonText, // '삭제' 버튼 텍스트
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontFamily: 'Noto Sans',
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// 공통 모달창
class ShowWebModal extends StatelessWidget {
  final String title; // 제목 텍스트
  final double width;
  final String closeButtonText; // '확인' 버튼 텍스트
  final VoidCallback? onClose; // '확인' 버튼 클릭 시 실행될 함수
  final bool showButtons; // 버튼 표시 여부
  final Widget content; // 본문에 들어갈 위젯
  final String buttonAlignment; // start , end , center

  ShowWebModal({
    required this.title,
    required this.width,
    this.closeButtonText = '확인', // 기본값 '확인'
    this.onClose,
    this.showButtons = true, // 기본값 true
    required this.content,
    this.buttonAlignment = 'center'
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        // borderRadius: BorderRadius.zero, // 모서리 둥글기 제거
        borderRadius: BorderRadius.circular(10),
      ),
      surfaceTintColor: Colors.white,
      backgroundColor: Color(0xFFFFFFFF),
      child: SizedBox(
        width: width,
        child: Stack(
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Text(
                      title, // 제목 텍스트
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontFamily: 'Noto Sans KR',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                SingleChildScrollView(
                  child: Column(
                    children: [
                      content,
                      if (showButtons) // showButtons가 true일 때만 버튼 표시
                        Container(
                          width: Get.width*0.6,
                          padding: const EdgeInsets.all(10),
                          child: ElevatedButton(
                            onPressed: onClose ?? () {Navigator.pop(context);},
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                              backgroundColor: Color(0xFFebebeb),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                            child: Text(
                              closeButtonText, // '확인' 버튼 텍스트
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                                fontFamily: 'Noto Sans',
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),

              ],
            ),
            Positioned(
              right: 0,
              top: 0,
              child: IconButton(
                icon: const Icon(Icons.close, color: Colors.black),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ShowWebModal2 extends StatelessWidget {
  final String title; // 제목 텍스트
  final double width;
  final String closeButtonText; // '확인' 버튼 텍스트
  final VoidCallback? onClose; // '확인' 버튼 클릭 시 실행될 함수
  final bool showButtons; // 버튼 표시 여부
  final Widget content; // 본문에 들어갈 위젯
  final String buttonAlignment; // start , end , center

  ShowWebModal2({
    required this.title,
    required this.width,
    this.closeButtonText = '확인', // 기본값 '확인'
    this.onClose,
    this.showButtons = true, // 기본값 true
    required this.content,
    this.buttonAlignment = 'center'
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Color(0xFF808080), // 다이얼로그 외부 영역 색상
      child: Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        surfaceTintColor: Colors.white,
        backgroundColor: Color(0xFFFFFFFF),
        child: SizedBox(
          width: width,
          child: Stack(
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width,
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Text(
                        title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontFamily: 'Noto Sans KR',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        content,
                        if (showButtons)
                          Container(
                            width: Get.width * 0.6,
                            padding: const EdgeInsets.all(10),
                            child: ElevatedButton(
                              onPressed: onClose ?? () {Navigator.pop(context);},
                              style: ElevatedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                                backgroundColor: Color(0xFFebebeb),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(5),
                                ),
                              ),
                              child: Text(
                                closeButtonText,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 12,
                                  fontFamily: 'Noto Sans',
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ShowWebModalClr extends StatelessWidget {
  final String title; // 제목 텍스트
  final double width;
  final String closeButtonText; // '확인' 버튼 텍스트
  final VoidCallback? onClose; // '확인' 버튼 클릭 시 실행될 함수
  final bool showButtons; // 버튼 표시 여부
  final Widget content; // 본문에 들어갈 위젯
  final String buttonAlignment; // start , end , center

  ShowWebModalClr({
    required this.title,
    required this.width,
    this.closeButtonText = '확인', // 기본값 '확인'
    this.onClose,
    this.showButtons = true, // 기본값 true
    required this.content,
    this.buttonAlignment = 'center'
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.transparent, // 외부 영역을 투명하게 설정
      child: Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        surfaceTintColor: Colors.white,
        backgroundColor: Color(0xFFFFFFFF),
        child: SizedBox(
          width: width,
          child: Stack(
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width,
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Text(
                        title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontFamily: 'Noto Sans KR',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        content,
                        if (showButtons)
                          Container(
                            width: Get.width * 0.6,
                            padding: const EdgeInsets.all(10),
                            child: ElevatedButton(
                              onPressed: onClose ?? () {Navigator.pop(context);},
                              style: ElevatedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                                backgroundColor: Color(0xFFebebeb),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(5),
                                ),
                              ),
                              child: Text(
                                closeButtonText,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 12,
                                  fontFamily: 'Noto Sans',
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
