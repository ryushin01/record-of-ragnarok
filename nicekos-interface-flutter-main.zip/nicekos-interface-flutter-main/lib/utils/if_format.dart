import 'package:intl/intl.dart';

class IfFormat {
  static String getStrNumerFormat(dynamic number) {
    var numFormat = NumberFormat("###,###,###,### 원");
    if (number != null) {
      return numFormat.format(number);
    } else {
      return '-';
    }
  }

  static String getDateFormat(var date) {
    if (date != null && date.length == 8) {
      return '${date.substring(0, 4)}-${date.substring(4, 6)}-${date.substring(
          6, 8)}';
    }
    return '-';
  }

  static String getStrPhnNumFormat(var phnNum) {
    if (phnNum != null) {
      return phnNum.replaceAllMapped(
          RegExp(r'(\d{2,3})(\d{3,4})(\d{4})'), (m) => '${m[1]}-${m[2]}-${m[3]}');
    } else {
      return '-';
    }
  }

  static String getStrBizNoFormat(var bizNo) {
    if (bizNo != null) {
      return bizNo.replaceAllMapped(
          RegExp(r'(\d{3})(\d{2})(\d{5})'), (m) => '${m[1]}-${m[2]}-${m[3]}');
    } else {
      return '-';
    }
  }
}