import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nicekos_interface_flutter/app/busi/ctrl/Init_binding.dart';
import 'package:nicekos_interface_flutter/theme/theme.dart';
import 'package:nicekos_interface_flutter/utils/navigation_service.dart';

import 'app/busi/home.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    final botToastBuilder = BotToastInit();
    return GetMaterialApp(
      title: 'Test Console',
      debugShowCheckedModeBanner: false,
      theme: AppTheme(),
      initialBinding: InitBinding(),
      initialRoute: '/Home',
      getPages: [
        GetPage(name: '/Home', page: () => const Home(),
        ),
      ],
      builder: (_, child) {
        NavigationService.registerContext(_);
        //BotToastInit();
        return botToastBuilder(
            context,
            Directionality(
                textDirection: TextDirection.ltr,
                child: child ?? Container()));
      },
    );
  }
}



