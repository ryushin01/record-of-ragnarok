package com.example.nicekos_interface_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
