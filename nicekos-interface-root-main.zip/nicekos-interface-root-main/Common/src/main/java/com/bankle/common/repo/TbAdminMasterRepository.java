package com.bankle.common.repo;

import com.bankle.common.entity.TbAdminMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TbAdminMasterRepository extends JpaRepository<TbAdminMaster, String> {

    Optional<TbAdminMaster> findByLognId(String lognId);
    Optional<TbAdminMaster> findByLognIdAndStatCd(String lognId, String statCd);
}