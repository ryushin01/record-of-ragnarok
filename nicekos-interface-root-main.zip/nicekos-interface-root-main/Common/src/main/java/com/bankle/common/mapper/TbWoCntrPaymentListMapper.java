package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoCntrPaymentListDto;
import com.bankle.common.entity.TbWoCntrPaymentList;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbWoCntrPaymentListMapper extends DefaultMapper<TbWoCntrPaymentListDto, TbWoCntrPaymentList> {
    TbWoCntrPaymentListMapper INSTANCE = Mappers.getMapper(TbWoCntrPaymentListMapper.class);
}