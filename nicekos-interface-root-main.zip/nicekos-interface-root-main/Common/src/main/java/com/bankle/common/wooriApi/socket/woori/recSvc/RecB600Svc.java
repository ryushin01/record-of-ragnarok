package com.bankle.common.wooriApi.socket.woori.recSvc;

import com.bankle.common.dto.TbWoTrnRsltDto;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.entity.TbWoTrnRslt;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.mapper.TbWoTrnRsltMapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.repo.TbWoTrnRsltRepository;
import com.bankle.common.wooriApi.socket.woori.commonSvc.WooriCmnSvc;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.WooriCmnSvo;
import com.bankle.common.wooriApi.socket.woori.recSvc.vo.RecB600Svo;
import com.bankle.common.wooriApi.socket.woori.socketData.B6X0;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Optional;


@Slf4j
@Service
@RequiredArgsConstructor
public class RecB600Svc {
    private final WooriCmnSvc wooriCmnSvc;

    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;
    private final TbWoTrnRsltRepository tbWoTrnRsltRepository;

    private final String TR_CD = "B610";

    @Transactional(rollbackFor = {Exception.class})
    public void receive(RecB600Svo.receiveVo receiveVo) throws Exception {

        wooriCmnSvc.wooriReceive(WooriCmnSvo.receiveVo.builder()
                .trSeq(receiveVo.getTrSeq())
                .trnKnd(TR_CD)
                .trnName(receiveVo.getTrnName())
                .reqData(receiveVo.getReqData())
                .reqDataLog(receiveVo.getReqDataLog())
                .approvalNum(receiveVo.getApprovalNum())
                .membNo(receiveVo.getLoNo())
                .reptMembNo(receiveVo.getLoNo())
                .loanNo(receiveVo.getLoanNo())
                .loNo(receiveVo.getLoNo())
                .tgDsc(receiveVo.getTgDsc())
                .build());

        var cntrEntity = tbWoCntrMasterRepository
                .findByLoanNo(receiveVo.getLoanNo()).orElseGet(TbWoCntrMaster::new);
        var cntrDto = TbWoCntrMasterMapper.INSTANCE.toDto(cntrEntity);
        log.debug("TbWoCntrMasterDto ->>" + cntrDto.toString());

        String resCd = "999";
        log.debug("===============================================================");
        log.debug("FIND RESCD !!!");
        log.debug("===============================================================");
        log.debug("receiveVo.getLoanNo() : {}", receiveVo.getLoanNo());
        log.debug("receiveVo.getTrnKnd() : {}", receiveVo.getTrnKnd());
        Optional<TbWoTrnRslt> fndResCd = tbWoTrnRsltRepository.findByIdLoanNoAndIdTgDsc(receiveVo.getLoanNo(), receiveVo.getTrnKnd());
        if (fndResCd.isPresent()) {
            TbWoTrnRsltDto rsltDto = TbWoTrnRsltMapper.INSTANCE.toDto(fndResCd.get());
            resCd = rsltDto.getResCd();
        } else {
            resCd = "000";
        }
        log.debug("resCd : {}", resCd);

        B6X0 data = receiveVo.getB6X0();
        log.debug("B6X0 Data Pring===>{}",data.print());
        data.setTR_CD(TR_CD);
        data.setRES_CD(resCd);
        if (!StringUtils.hasText(data.getLO_NO().trim())) {
            data.setLO_NO("0000000000000");
        }
        log.debug("resCd ->>" + resCd);
        wooriCmnSvc.wooriSendResponse(WooriCmnSvo.sendVo.builder()
                .seq(receiveVo.getTrSeq())
                .trTp(TR_CD)
                .resData(data.dataToString())
                .resDataLog(data.print())
                .resCode(resCd)
                .build());
    }
}
