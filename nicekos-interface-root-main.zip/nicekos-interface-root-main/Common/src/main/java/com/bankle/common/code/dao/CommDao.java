package com.bankle.common.code.dao;

import com.bankle.common.code.vo.CommSvo;
import com.bankle.common.entity.TbCommCode;
import com.bankle.common.search.SrchCommCode;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

import static com.bankle.common.entity.QTbCommCode.tbCommCode;

@Slf4j
@Repository
@RequiredArgsConstructor
public class CommDao {
    private final JPAQueryFactory jpaQueryFactory;

    
    public List<TbCommCode> selCommCodeLst(CommSvo.SearchInSvo searchInSvo) throws Exception {

        return jpaQueryFactory
                .selectFrom(tbCommCode)
                .where(SrchCommCode.likeGrpCd(searchInSvo.getGrpCd())
                        , SrchCommCode.likeCode(searchInSvo.getCode())
                        , SrchCommCode.likeCodeNm(searchInSvo.getCodeNm())
                        , SrchCommCode.likeGrpNm(searchInSvo.getGrpNm())
                        , SrchCommCode.likeGrpDesc(searchInSvo.getGrpDesc())
                        , SrchCommCode.eqNum(searchInSvo.getNum())
                        , SrchCommCode.likeEtc1(searchInSvo.getEtc1())
                        , SrchCommCode.likeEtc2(searchInSvo.getEtc2())
                        , SrchCommCode.likeEtc3(searchInSvo.getEtc3())
                        , SrchCommCode.likeUseYn(searchInSvo.getUseYn())
                )
                .orderBy(tbCommCode.num.asc())
                .fetch();
    }

    public long updCommCode(CommSvo.ModifyInSvo modifyInSvo) throws Exception {
        return jpaQueryFactory
                .update(tbCommCode)
                .set(tbCommCode.chgDtm, LocalDateTime.now())
                .set(tbCommCode.chgMembNo, "000000000000") // 추후 세션에서 값을 가져오도록 처리하여야 한다.
                .set(tbCommCode.grpDesc, StringUtils.hasText(modifyInSvo.getModifyGrpDesc()) ? modifyInSvo.getModifyGrpDesc() : modifyInSvo.getGrpDesc())
                .set(tbCommCode.codeNm, StringUtils.hasText(modifyInSvo.getModifyCodeNm()) ? modifyInSvo.getModifyCodeNm() : modifyInSvo.getCodeNm())
                .set(tbCommCode.grpNm, StringUtils.hasText(modifyInSvo.getModifyGrpNm()) ? modifyInSvo.getModifyGrpNm() : modifyInSvo.getGrpNm())
                .set(tbCommCode.etc1, StringUtils.hasText(modifyInSvo.getModifyEtc1()) ? modifyInSvo.getModifyEtc1() : modifyInSvo.getEtc1())
                .set(tbCommCode.etc2, StringUtils.hasText(modifyInSvo.getModifyEtc2()) ? modifyInSvo.getModifyEtc2() : modifyInSvo.getEtc2())
                .set(tbCommCode.etc3, StringUtils.hasText(modifyInSvo.getModifyEtc3()) ? modifyInSvo.getModifyEtc3() : modifyInSvo.getEtc3())
                .set(tbCommCode.useYn, StringUtils.hasText(modifyInSvo.getModifyUseYn()) ? modifyInSvo.getModifyUseYn() : modifyInSvo.getUseYn())
                .where(SrchCommCode.eqGrpCd(modifyInSvo.getGrpCd())
                        , SrchCommCode.eqCode(modifyInSvo.getCode())
                )
                .execute();
    }

    public long delCommCode(CommSvo.RemoveInSvo removeInSvo) throws Exception {
        return jpaQueryFactory
                .update(tbCommCode)
                .set(tbCommCode.chgDtm, LocalDateTime.now())
                .set(tbCommCode.chgMembNo, "000000000000") // 추후 세션에서 값을 가져오도록 처리하여야 한다.
                .set(tbCommCode.grpDesc, removeInSvo.getGrpDesc())
                .set(tbCommCode.codeNm, removeInSvo.getCodeNm())
                .set(tbCommCode.grpNm, removeInSvo.getGrpNm())
                .set(tbCommCode.etc1, removeInSvo.getEtc1())
                .set(tbCommCode.etc2, removeInSvo.getEtc2())
                .set(tbCommCode.etc3, removeInSvo.getEtc3())
                .set(tbCommCode.useYn, removeInSvo.getUseYn())
                .where(SrchCommCode.eqGrpCd(removeInSvo.getGrpCd())
                        , SrchCommCode.eqCode(removeInSvo.getCode())
                )
                .execute();
    }



    public List<TbCommCode> searchCommCodeMultiList(List<String> multiGrpCd) {
        return jpaQueryFactory
                .selectFrom(tbCommCode)
                .where(tbCommCode.grpCd.in(multiGrpCd))
                .fetch();
    }
}
