package com.bankle.common.mapper;

import com.bankle.common.dto.TbCustMasterDto;
import com.bankle.common.entity.TbCustMaster;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbCustMasterMapper extends DefaultMapper<TbCustMasterDto, TbCustMaster>{

    TbCustMasterMapper INSTANCE = Mappers.getMapper(TbCustMasterMapper.class);
}