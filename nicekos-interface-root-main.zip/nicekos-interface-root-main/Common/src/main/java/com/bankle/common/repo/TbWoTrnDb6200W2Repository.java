package com.bankle.common.repo;

import com.bankle.common.entity.TbWoTrnDb6200W2;
import com.bankle.common.entity.TbWoTrnDb6200W2Id;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TbWoTrnDb6200W2Repository extends JpaRepository<TbWoTrnDb6200W2, TbWoTrnDb6200W2Id> {
}