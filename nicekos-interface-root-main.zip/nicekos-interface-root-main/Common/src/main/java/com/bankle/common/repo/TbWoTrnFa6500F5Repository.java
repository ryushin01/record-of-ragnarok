package com.bankle.common.repo;

import com.bankle.common.entity.TbWoTrnFa6500F5;
import com.bankle.common.entity.TbWoTrnFa6500F5Id;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TbWoTrnFa6500F5Repository extends JpaRepository<TbWoTrnFa6500F5, TbWoTrnFa6500F5Id> {

    List<TbWoTrnFa6500F5> findByIdLoanNoOrderByIdChgDtm(String loanNo);

    Optional<TbWoTrnFa6500F5> findByIdLoanNo(String loanNo);

}