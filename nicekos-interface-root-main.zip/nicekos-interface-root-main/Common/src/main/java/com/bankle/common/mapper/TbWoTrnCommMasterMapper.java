package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoTrnCommMasterDto;
import com.bankle.common.entity.TbWoTrnCommMaster;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TbWoTrnCommMasterMapper extends DefaultMapper<TbWoTrnCommMasterDto, TbWoTrnCommMaster> {
    TbWoTrnCommMasterMapper INSTANCE = Mappers.getMapper(TbWoTrnCommMasterMapper.class);
}