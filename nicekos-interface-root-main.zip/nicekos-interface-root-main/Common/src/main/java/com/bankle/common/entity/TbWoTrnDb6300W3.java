package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_TRN_DB_6300_W3")
public class TbWoTrnDb6300W3 {
    @EmbeddedId
    private TbWoTrnDb6300W3Id id;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "TG_LEN", nullable = false, precision = 8)
    private BigDecimal tgLen;

    @Size(max = 5)
    @Column(name = "TG_DSC", length = 5)
    private String tgDsc;

    @Size(max = 3)
    @Column(name = "RES_CD", length = 3)
    private String resCd;

    @Size(max = 5)
    @Column(name = "LND_AGNC_CD", length = 5)
    private String lndAgncCd;

    @Size(max = 14)
    @Column(name = "BNK_TG_TRNS_DTM", length = 14)
    private String bnkTgTrnsDtm;

    @Size(max = 14)
    @Column(name = "DB_TG_TRNS_DTM", length = 14)
    private String dbTgTrnsDtm;

    @Size(max = 8)
    @Column(name = "BNK_TG_NO", length = 8)
    private String bnkTgNo;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "DB_TG_NO", nullable = false, precision = 8)
    private BigDecimal dbTgNo;

    @Size(max = 39)
    @Column(name = "RSRV_ITM_H", length = 39)
    private String rsrvItmH;

    @Size(max = 20)
    @Column(name = "BNK_ASK_NO", length = 20)
    private String bnkAskNo;

    @Size(max = 20)
    @Column(name = "DB_MNG_NO", length = 20)
    private String dbMngNo;

    @Column(name = "KOS_TG_TRNS_DTM")
    private LocalDateTime kosTgTrnsDtm;

    @Size(max = 14)
    @Column(name = "KOS_TG_NO", length = 14)
    private String kosTgNo;

    @Size(max = 1)
    @Column(name = "NTTN_YN", length = 1)
    private String nttnYn;

    @Size(max = 8)
    @Column(name = "END_NOTI_DT", length = 8)
    private String endNotiDt;

    @Size(max = 6)
    @Column(name = "END_NOTI_TM", length = 6)
    private String endNotiTm;

    @Size(max = 40)
    @Column(name = "BNK_DRCTR_NM", length = 40)
    private String bnkDrctrNm;

    @Size(max = 20)
    @Column(name = "BNK_DRCTR_PHNO", length = 20)
    private String bnkDrctrPhno;

    @Size(max = 743)
    @Column(name = "RSRV_ITM_B", length = 743)
    private String rsrvItmB;

    @Column(name = "REG_DTM")
    private LocalDateTime regDtm;

}