package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnStndMaster}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnStndMasterDto implements Serializable {
    @Size(max = 14)
    String seq;
    @NotNull
    @Size(max = 50)
    String trnName;
    @NotNull
    @Size(max = 14)
    String trnKnd;
    @NotNull
    @Size(max = 3000)
    String reqData;
    @Size(max = 4000)
    String reqDataLog;
    @NotNull
    @Size(max = 1)
    String reqYn;
    @Size(max = 3000)
    String resData;
    @Size(max = 4000)
    String resDataLog;
    @NotNull
    @Size(max = 1)
    String resYn;
    @Size(max = 4)
    String resCode;
    @Size(max = 11)
    String approvalNum;
    @Size(max = 13)
    String membNo;
    @Size(max = 13)
    String reptMembNo;
    @Size(max = 3)
    String bankCode;
    @Size(max = 4)
    String bankResCode;
    @Size(max = 1000)
    String gubun;
    LocalDateTime reqDttm;
    LocalDateTime resDttm;
    @Size(max = 27)
    String imgKey;
    @Size(max = 1000)
    String userAgent;
    @NotNull
    LocalDateTime chgDtm;
    @NotNull
    @Size(max = 13)
    String chgMembNo;
    @NotNull
    LocalDateTime crtDtm;
    @NotNull
    @Size(max = 13)
    String crtMembNo;
    @Size(max = 10)
    String tgDsc;
    @Size(max = 1)
    String trnsStc;
    @Size(max = 500)
    String flPth;
    Integer resendCt;
    @Size(max = 11)
    String grpApprovalNum;
}