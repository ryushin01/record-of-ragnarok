package com.bankle.common.entity;

import com.bankle.common.entity.base.BaseTimeEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_ADMIN_MASTER", schema = "nicekos")
public class TbAdminMaster extends BaseTimeEntity {
    @Id
    @Size(max = 12)
    @Column(name = "MEMB_NO", nullable = false, length = 12)
    private String membNo;

    @Size(max = 40)
    @Column(name = "LOGN_ID", length = 40)
    private String lognId;

    @Size(max = 150)
    @NotNull
    @Column(name = "ADMIN_NM", nullable = false, length = 150)
    private String adminNm;

    @Size(max = 2)
    @NotNull
    @Column(name = "PERM_CD", nullable = false, length = 2)
    private String permCd;

    @Size(max = 100)
    @NotNull
    @Column(name = "PWD", nullable = false, length = 100)
    private String pwd;

    @Size(max = 150)
    @Column(name = "CPHN_NUM", length = 150)
    private String cphnNum;

    @Size(max = 2)
    @Column(name = "DEPT_CD", length = 2)
    private String deptCd;

    @Size(max = 2)
    @Column(name = "PSTN_CD", length = 2)
    private String pstnCd;

    @Size(max = 2)
    @NotNull
    @Column(name = "STAT_CD", nullable = false, length = 2)
    private String statCd;

    @NotNull
    @Column(name = "LOGN_FAIL_CNT", nullable = false)
    private Integer lognFailCnt;

    @Size(max = 6)
    @Column(name = "VERIFY_CD", length = 6)
    private String verifyCd;

    @Column(name = "VERIFY_EXPIRE_DTM")
    private LocalDateTime verifyExpireDtm;
}