package com.bankle.common.wooriApi.socket.ins.socketData;

import java.io.InputStream;

public class T6300W3 extends GetSetData {

    byte[] TG_LEN = new byte[8];
    byte[] TG_DSC = new byte[5];
    byte[] RES_CD = new byte[3];
    byte[] LND_AGNC_CD = new byte[5];
    byte[] BNK_TG_TRNS_DTM = new byte[14];
    byte[] DB_TG_TRNS_DTM = new byte[14];
    byte[] BNK_TG_NO = new byte[8];
    byte[] DB_TG_NO = new byte[8];
    byte[] RSRV_ITM_H = new byte[39];
    byte[] BNK_ASK_NO = new byte[20];
    byte[] LN_APRV_NO = new byte[14];
    byte[] DB_MNG_NO = new byte[20];
    byte[] KOS_TG_TRNS_DTM = new byte[14];
    byte[] KOS_TG_NO = new byte[14];
    byte[] NTTN_YN = new byte[1];
    byte[] END_NOTI_DT = new byte[8];
    byte[] END_NOTI_TM = new byte[6];
    byte[] BNK_DRCTR_NM = new byte[40];
    byte[] BNK_DRCTR_PHNO = new byte[20];
    byte[] RSRV_ITM_B = new byte[743];

    public T6300W3() {
        setData(this.TG_LEN, "");
        setData(this.TG_DSC, "");
        setData(this.RES_CD, "");
        setData(this.LND_AGNC_CD, "");
        setData(this.BNK_TG_TRNS_DTM, "");
        setData(this.DB_TG_TRNS_DTM, "");
        setData(this.BNK_TG_NO, "");
        setData(this.DB_TG_NO, "");
        setData(this.RSRV_ITM_H, "");
        setData(this.BNK_ASK_NO, "");
        setData(this.LN_APRV_NO, "");
        setData(this.DB_MNG_NO, "");
        setData(this.KOS_TG_TRNS_DTM, "");
        setData(this.KOS_TG_NO, "");
        setData(this.NTTN_YN, "");
        setData(this.END_NOTI_DT, "");
        setData(this.END_NOTI_TM, "");
        setData(this.BNK_DRCTR_NM, "");
        setData(this.BNK_DRCTR_PHNO, "");
        setData(this.RSRV_ITM_B, "");
    }

    public String getTG_LEN() {
        return getData(TG_LEN);
    }

    public String getTG_DSC() {
        return getData(TG_DSC);
    }

    public String getRES_CD() {
        return getData(RES_CD);
    }

    public String getLND_AGNC_CD() {
        return getData(LND_AGNC_CD);
    }

    public String getBNK_TG_TRNS_DTM() {
        return getData(BNK_TG_TRNS_DTM);
    }

    public String getDB_TG_TRNS_DTM() {
        return getData(DB_TG_TRNS_DTM);
    }

    public String getBNK_TG_NO() {
        return getData(BNK_TG_NO);
    }

    public String getDB_TG_NO() {
        return getData(DB_TG_NO);
    }

    public String getRSRV_ITM_H() {
        return getData(RSRV_ITM_H);
    }

    public String getBNK_ASK_NO() {
        return getData(BNK_ASK_NO);
    }

    public String getLN_APRV_NO() {
        return getData(LN_APRV_NO);
    }

    public String getDB_MNG_NO() {
        return getData(DB_MNG_NO);
    }

    public String getKOS_TG_TRNS_DTM() {
        return getData(KOS_TG_TRNS_DTM);
    }

    public String getKOS_TG_NO() {
        return getData(KOS_TG_NO);
    }

    public String getNTTN_YN() {
        return getData(NTTN_YN);
    }

    public String getEND_NOTI_DT() {
        return getData(END_NOTI_DT);
    }

    public String getEND_NOTI_TM() {
        return getData(END_NOTI_TM);
    }

    public String getBNK_DRCTR_NM() {
        return getData(BNK_DRCTR_NM);
    }

    public String getBNK_DRCTR_PHNO() {
        return getData(BNK_DRCTR_PHNO);
    }

    public String getRSRV_ITM_B() {
        return getData(RSRV_ITM_B);
    }

    public void setTG_LEN(String TG_LEN) {
        setData(this.TG_LEN, TG_LEN,"N");
    }

    public void setTG_DSC(String TG_DSC) {
        setData(this.TG_DSC, TG_DSC,"S");
    }

    public void setRES_CD(String RES_CD) {
        setData(this.RES_CD, RES_CD,"S");
    }

    public void setLND_AGNC_CD(String LND_AGNC_CD) {
        setData(this.LND_AGNC_CD, LND_AGNC_CD,"S");
    }

    public void setBNK_TG_TRNS_DTM(String BNK_TG_TRNS_DTM) {
        setData(this.BNK_TG_TRNS_DTM, BNK_TG_TRNS_DTM,"S");
    }

    public void setDB_TG_TRNS_DTM(String DB_TG_TRNS_DTM) {
        setData(this.DB_TG_TRNS_DTM, DB_TG_TRNS_DTM,"S");
    }

    public void setBNK_TG_NO(String BNK_TG_NO) {
        setData(this.BNK_TG_NO, BNK_TG_NO,"S");
    }

    public void setDB_TG_NO(String DB_TG_NO) {
        setData(this.DB_TG_NO, DB_TG_NO,"N");
    }

    public void setRSRV_ITM_H(String RSRV_ITM_H) {
        setData(this.RSRV_ITM_H, RSRV_ITM_H,"K");
    }

    public void setBNK_ASK_NO(String BNK_ASK_NO) {
        setData(this.BNK_ASK_NO, BNK_ASK_NO,"S");
    }

    public void setLN_APRV_NO(String LN_APRV_NO) {
        setData(this.LN_APRV_NO, LN_APRV_NO,"S");
    }

    public void setDB_MNG_NO(String DB_MNG_NO) {
        setData(this.DB_MNG_NO, DB_MNG_NO,"S");
    }

    public void setKOS_TG_TRNS_DTM(String KOS_TG_TRNS_DTM) {
        setData(this.KOS_TG_TRNS_DTM, KOS_TG_TRNS_DTM,"S");
    }

    public void setKOS_TG_NO(String KOS_TG_NO) {
        setData(this.KOS_TG_NO, KOS_TG_NO,"S");
    }

    public void setNTTN_YN(String NTTN_YN) {
        setData(this.NTTN_YN, NTTN_YN,"S");
    }

    public void setEND_NOTI_DT(String END_NOTI_DT) {
        setData(this.END_NOTI_DT, END_NOTI_DT,"S");
    }

    public void setEND_NOTI_TM(String END_NOTI_TM) {
        setData(this.END_NOTI_TM, END_NOTI_TM,"S");
    }

    public void setBNK_DRCTR_NM(String BNK_DRCTR_NM) {
        setData(this.BNK_DRCTR_NM, BNK_DRCTR_NM,"K");
    }

    public void setBNK_DRCTR_PHNO(String BNK_DRCTR_PHNO) {
        setData(this.BNK_DRCTR_PHNO, BNK_DRCTR_PHNO,"S");
    }

    public void setRSRV_ITM_B(String RSRV_ITM_B) {
        setData(this.RSRV_ITM_B, RSRV_ITM_B,"K");
    }

    public String dataToString() {
        return getData(TG_LEN) + getData(TG_DSC) + getData(RES_CD) + getData(LND_AGNC_CD) + getData(BNK_TG_TRNS_DTM) +
                getData(DB_TG_TRNS_DTM) + getData(BNK_TG_NO) + getData(DB_TG_NO) + getData(RSRV_ITM_H) + getData(BNK_ASK_NO) + getData(LN_APRV_NO) +
                getData(DB_MNG_NO) + getData(KOS_TG_TRNS_DTM) + getData(KOS_TG_NO) + getData(NTTN_YN) + getData(END_NOTI_DT) + getData(END_NOTI_TM) +
                getData(BNK_DRCTR_NM) + getData(BNK_DRCTR_PHNO) + getData(RSRV_ITM_B);
    }

    public String print() {
        StringBuffer sb = new StringBuffer();
        sb.append("TG_LEN            	: " + "\tSize " + TG_LEN.length + " : " + getData(TG_LEN) + "\n");
        sb.append("TG_DSC               : " + "\tSize " + TG_DSC.length + " : " + getData(TG_DSC) + "\n");
        sb.append("RES_CD               : " + "\tSize " + RES_CD.length + " : " + getData(RES_CD) + "\n");
        sb.append("LND_AGNC_CD          : " + "\tSize " + LND_AGNC_CD.length + " : " + getData(LND_AGNC_CD) + "\n");
        sb.append("BNK_TG_TRNS_DTM      : " + "\tSize " + BNK_TG_TRNS_DTM.length + " : " + getData(BNK_TG_TRNS_DTM) + "\n");
        sb.append("DB_TG_TRNS_DTM       : " + "\tSize " + DB_TG_TRNS_DTM.length + " : " + getData(DB_TG_TRNS_DTM) + "\n");
        sb.append("BNK_TG_NO            : " + "\tSize " + BNK_TG_NO.length + " : " + getData(BNK_TG_NO) + "\n");
        sb.append("DB_TG_NO             : " + "\tSize " + DB_TG_NO.length + " : " + getData(DB_TG_NO) + "\n");
        sb.append("RSRV_ITM_H           : " + "\tSize " + RSRV_ITM_H.length + " : " + getData(RSRV_ITM_H) + "\n");
        sb.append("BNK_ASK_NO           : " + "\tSize " + BNK_ASK_NO.length + " : " + getData(BNK_ASK_NO) + "\n");
        sb.append("LN_APRV_NO           : " + "\tSize " + LN_APRV_NO.length + " : " + getData(LN_APRV_NO) + "\n");
        sb.append("DB_MNG_NO            : " + "\tSize " + DB_MNG_NO.length + " : " + getData(DB_MNG_NO) + "\n");
        sb.append("KOS_TG_TRNS_DTM      : " + "\tSize " + KOS_TG_TRNS_DTM.length + " : " + getData(KOS_TG_TRNS_DTM) + "\n");
        sb.append("KOS_TG_NO            : " + "\tSize " + KOS_TG_NO.length + " : " + getData(KOS_TG_NO) + "\n");
        sb.append("NTTN_YN              : " + "\tSize " + NTTN_YN.length + " : " + getData(NTTN_YN) + "\n");
        sb.append("END_NOTI_DT          : " + "\tSize " + END_NOTI_DT.length + " : " + getData(END_NOTI_DT) + "\n");
        sb.append("END_NOTI_TM          : " + "\tSize " + END_NOTI_TM.length + " : " + getData(END_NOTI_TM) + "\n");
        sb.append("BNK_DRCTR_NM         : " + "\tSize " + BNK_DRCTR_NM.length + " : " + getData(BNK_DRCTR_NM) + "\n");
        sb.append("BNK_DRCTR_PHNO       : " + "\tSize " + BNK_DRCTR_PHNO.length + " : " + getData(BNK_DRCTR_PHNO) + "\n");
        sb.append("RSRV_ITM_B           : " + "\tSize " + RSRV_ITM_B.length + " : " + getData(RSRV_ITM_B) + "\n");
        return sb.toString();
    }

    public void readDataExternal(InputStream stream) {
        try {
            stream.read(TG_LEN, 0, TG_LEN.length);
            stream.read(TG_DSC, 0, TG_DSC.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(LND_AGNC_CD, 0, LND_AGNC_CD.length);
            stream.read(BNK_TG_TRNS_DTM, 0, BNK_TG_TRNS_DTM.length);
            stream.read(DB_TG_TRNS_DTM, 0, DB_TG_TRNS_DTM.length);
            stream.read(BNK_TG_NO, 0, BNK_TG_NO.length);
            stream.read(DB_TG_NO, 0, DB_TG_NO.length);
            stream.read(RSRV_ITM_H, 0, RSRV_ITM_H.length);
            stream.read(BNK_ASK_NO, 0, BNK_ASK_NO.length);
            stream.read(LN_APRV_NO, 0, LN_APRV_NO.length);
            stream.read(DB_MNG_NO, 0, DB_MNG_NO.length);
            stream.read(KOS_TG_TRNS_DTM, 0, KOS_TG_TRNS_DTM.length);
            stream.read(KOS_TG_NO, 0, KOS_TG_NO.length);
            stream.read(NTTN_YN, 0, NTTN_YN.length);
            stream.read(END_NOTI_DT, 0, END_NOTI_DT.length);
            stream.read(END_NOTI_TM, 0, END_NOTI_TM.length);
            stream.read(BNK_DRCTR_NM, 0, BNK_DRCTR_NM.length);
            stream.read(BNK_DRCTR_PHNO, 0, BNK_DRCTR_PHNO.length);
            stream.read(RSRV_ITM_B, 0, RSRV_ITM_B.length);
        } catch (Exception Ex) {
            Ex.printStackTrace();
        }
    }
}
