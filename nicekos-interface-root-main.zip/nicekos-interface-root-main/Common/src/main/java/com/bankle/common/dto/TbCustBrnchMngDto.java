package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Value;

import java.io.Serializable;

/**
 * DTO for {@link com.bankle.common.entity.TbCustBrnchMng}
 */
@Value
public class TbCustBrnchMngDto implements Serializable {
    Long id;
    @NotNull
    @Size(max = 10)
    String bizNo;
    @Size(max = 20)
    String brnchCd;
    @NotNull
    @Size(max = 500)
    String brnchNm;
}