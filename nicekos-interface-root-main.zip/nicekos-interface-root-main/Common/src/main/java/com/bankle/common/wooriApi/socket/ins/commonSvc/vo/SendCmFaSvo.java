package com.bankle.common.wooriApi.socket.ins.commonSvc.vo;

import lombok.*;

public class SendCmFaSvo {

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class SendCmFaInvo {

        private String loanNo;

        private String bnkTtlReqNo;

        private String lndKndCd;

        private String fndUseCd;

        private String lndPmntCnfmSlfCd;

        private String rcptInfoCnfmSlfCd;

        private String thdyRgstrAcptNoInptYn;

        private String regrApplNo1;

        private String regrApplNo2;

        private String regrApplNo3;

        private String cancNo1;

        private String cancNo2;

        private String cancNo3;

        private String cancNo4;

        private String srchrNm;

        private String rrcpCnfmYn;

        private String mvhrCnfmReqYn;

        private String divNum;

        private String mvhrHshldrRno;

        private String lnAprvNo;

        private String lndPrgsStc;

        private String prgsDt;
    }
}
