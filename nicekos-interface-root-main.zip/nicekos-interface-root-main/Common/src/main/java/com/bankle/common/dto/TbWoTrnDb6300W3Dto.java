package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnDb6300W3}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnDb6300W3Dto implements Serializable {
    TbWoTrnDb6300W3IdDto id;
    @NotNull
    BigDecimal tgLen;
    @Size(max = 5)
    String tgDsc;
    @Size(max = 3)
    String resCd;
    @Size(max = 5)
    String lndAgncCd;
    @Size(max = 14)
    String bnkTgTrnsDtm;
    @Size(max = 14)
    String dbTgTrnsDtm;
    @Size(max = 8)
    String bnkTgNo;
    @NotNull
    BigDecimal dbTgNo;
    @Size(max = 39)
    String rsrvItmH;
    @Size(max = 20)
    String bnkAskNo;
    @Size(max = 20)
    String dbMngNo;
    LocalDateTime kosTgTrnsDtm;
    @Size(max = 14)
    String kosTgNo;
    @Size(max = 1)
    String nttnYn;
    @Size(max = 8)
    String endNotiDt;
    @Size(max = 6)
    String endNotiTm;
    @Size(max = 40)
    String bnkDrctrNm;
    @Size(max = 20)
    String bnkDrctrPhno;
    @Size(max = 743)
    String rsrvItmB;
    LocalDateTime regDtm;
}