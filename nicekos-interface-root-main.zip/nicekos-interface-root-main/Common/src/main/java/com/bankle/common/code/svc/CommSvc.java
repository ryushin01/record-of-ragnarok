package com.bankle.common.code.svc;

import com.bankle.common.code.dao.CommDao;
import com.bankle.common.code.vo.CommCvo;
import com.bankle.common.code.vo.CommSvo;
import com.bankle.common.dto.TbCommCodeDto;
import com.bankle.common.entity.TbCommCode;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbCommCodeMapper;
import com.bankle.common.repo.TbCommCodeRepository;
import com.bankle.common.repo.TbSystHolidayRepository;
import com.bankle.common.utils.CustomeModelMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CommSvc {
    private final TbCommCodeMapper tbCommCodeMapper;

    private final CommDao commDao;
    private final TbCommCodeRepository tbCommCodeRepo;
    private final CustomeModelMapper cModelMapper;
    private final TbSystHolidayRepository tbSystHolidayRepository;



    public List<CommCvo.SearchCommCodeResCvo> fndCommCode(CommSvo.SearchInSvo searchInSvo) throws Exception {

        var model = commDao.selCommCodeLst(searchInSvo);

        if (model.stream().count() < 1) {
            return new ArrayList<>();
        }

        List<CommCvo.SearchCommCodeResCvo> resVo = TbCommCodeMapper.INSTANCE.toDtoList(model)
                .stream().map(dto -> cModelMapper.mapping(dto, CommSvo.SearchOutVo.class)).collect(Collectors.toList())
                .stream().map(svo -> cModelMapper.mapping(svo, CommCvo.SearchCommCodeResCvo.class)).collect(Collectors.toList());

        // 은행코드의 첫번째 은행을 가져 올 경우에는 우리은행을 맨위로 올려야 한다.
        // 이외에는 기존에 나가던대로 유지.
        if ("BANK_GB".equals(searchInSvo.getGrpCd()) && "0".equals(searchInSvo.getEtc1())) {
            resVo.sort(Comparator.comparing(CommCvo.SearchCommCodeResCvo::getEtc3));
        }
        return resVo;
    }

    @Transactional(rollbackFor = {DataAccessException.class, NullPointerException.class})
    public long crtCommCode(List<CommSvo.SaveInSvo> saveInSvoLst) throws Exception {
        var modelLst = new ArrayList<TbCommCode>();
        saveInSvoLst.stream()
                .map((element) -> cModelMapper.mapping(element, TbCommCodeDto.class))
                .toList()
                .forEach(
                        tbCommCodeDto -> {
                            tbCommCodeRepo.save(TbCommCodeMapper.INSTANCE.toEntity(tbCommCodeDto));
                        }
                );
        return 1L;
    }

    @Transactional(rollbackFor = Exception.class)
    public long edtCommCode(CommSvo.ModifyInSvo modifyInSvo) throws Exception {
        var ret = 99L;
        var pk = new TbCommCode.PK();
        try {
            pk.setCode(modifyInSvo.getCode());
            pk.setGrpCd(modifyInSvo.getGrpCd());
            var commCode = tbCommCodeRepo.findById(pk);
            if (commCode.isPresent()) {
                ret = commDao.updCommCode(
                        cModelMapper.mapping(TbCommCodeMapper.INSTANCE.toDto(commCode.get())
                                , CommSvo.ModifyInSvo.class));
            }
        } catch (Exception e) {
            e.fillInStackTrace();
            ret = 99L;
        }
        return 0L;
    }

    @Transactional(rollbackFor = Exception.class)
    public long delCommCode(CommSvo.RemoveInSvo removeInSvo) throws Exception {
        var ret = 99L;
        var pk = new TbCommCode.PK();
        try {
            pk.setCode(removeInSvo.getCode());
            pk.setGrpCd(removeInSvo.getGrpCd());
            var commCode = tbCommCodeRepo.findById(pk);
            if (commCode.isPresent()) {
                ret = commDao.delCommCode(
                        cModelMapper.mapping(TbCommCodeMapper.INSTANCE.toDto(commCode.get())
                                , CommSvo.RemoveInSvo.class));
            }
            return ret;
        } catch (Exception e) {
            e.fillInStackTrace();
            return 0L;
        }
    }


    public Map<String, Map<String, String>> searchCommCodeMultiList(List<String> multiGrpCd) throws Exception {
        try {
            var modelList = commDao.searchCommCodeMultiList(multiGrpCd);
            if (modelList == null) {
                return new HashMap<>();
            }
            var svo = modelList
                    .stream().map(TbCommCodeMapper.INSTANCE::toDto).toList()
                    .stream().map(e -> cModelMapper.mapping(e, CommSvo.SearchOutVo.class)).toList();
            var cvo = new ArrayList<>(svo.stream().map(e -> cModelMapper.mapping(e, CommCvo.SearchCommCodeResCvo.class)).toList());
            cvo.sort(Comparator.comparing(CommCvo.SearchCommCodeResCvo::getGrpCd).thenComparing(CommCvo.SearchCommCodeResCvo::getNum));
            return cvo.stream().collect(Collectors.groupingBy(CommCvo.SearchCommCodeResCvo::getGrpCd,
                    Collectors.toMap(CommCvo.SearchCommCodeResCvo::getCode, CommCvo.SearchCommCodeResCvo::getCodeNm)));
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

    public List<CommSvo.SearchOutVo> searchCommCodeList(String reqGbCd){
        try {
            var commCode = tbCommCodeRepo.findByGrpCdAndUseYn(reqGbCd, "Y");
            if (commCode.stream().count() < 1)
                return new ArrayList<>();

            return commCode.stream().map(TbCommCodeMapper.INSTANCE::toDto).toList()
                    .stream().map(dto -> cModelMapper.mapping(dto, CommSvo.SearchOutVo.class)).toList();
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

    public Map<String, String> searchCommCodeMap(String grpCd) {
        try {
            var commCode = tbCommCodeRepo.findByGrpCd(grpCd);
            if (commCode.stream().count() < 1)
                return new HashMap<>();

            return commCode.stream().map(TbCommCodeMapper.INSTANCE::toDto).toList()
                    .stream().map(dto -> cModelMapper.mapping(dto, CommSvo.SearchOutVo.class)).toList()
                    .stream().map(svo -> cModelMapper.mapping(svo, CommCvo.SearchCommCodeReqCvo.class)).toList()
                    .stream().collect(Collectors.toMap(CommCvo.SearchCommCodeReqCvo::getCode, CommCvo.SearchCommCodeReqCvo::getCodeNm));
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

    public String searchCommCodeOneGet(String grpCd, String code) {
        try {
            var commCode = tbCommCodeRepo.findByGrpCd(grpCd);
            if (commCode.stream().count() < 1)
                return "";

            var commCodeMap = commCode.stream().map(TbCommCodeMapper.INSTANCE::toDto).toList()
                    .stream().map(dto -> cModelMapper.mapping(dto, CommSvo.SearchOutVo.class)).toList()
                    .stream().map(svo -> cModelMapper.mapping(svo, CommCvo.SearchCommCodeReqCvo.class)).toList()
                    .stream().collect(Collectors.toMap(CommCvo.SearchCommCodeReqCvo::getCode, CommCvo.SearchCommCodeReqCvo::getCodeNm));

            var codeNm = commCodeMap.get(code);

            return StringUtils.hasText(codeNm) ? codeNm : "";
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

}
