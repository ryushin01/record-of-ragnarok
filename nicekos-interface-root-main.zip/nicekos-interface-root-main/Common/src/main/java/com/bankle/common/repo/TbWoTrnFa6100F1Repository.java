package com.bankle.common.repo;

import com.bankle.common.entity.TbWoTrnFa6100F1;
import com.bankle.common.entity.TbWoTrnFa6100F1Id;
import com.bankle.common.entity.TbWoTrnFa6500F5;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TbWoTrnFa6100F1Repository extends JpaRepository<TbWoTrnFa6100F1, TbWoTrnFa6100F1Id> {
    List<TbWoTrnFa6100F1> findByIdLoanNoOrderByIdChgDtm(String loanNo);
    Optional<TbWoTrnFa6100F1> findTop1ById_LoanNo(String loanNo);
}