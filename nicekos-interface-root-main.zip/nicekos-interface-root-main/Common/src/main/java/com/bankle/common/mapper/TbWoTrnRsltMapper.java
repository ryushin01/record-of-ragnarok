package com.bankle.common.mapper;

import com.bankle.common.dto.TbWoTrnRsltDto;
import com.bankle.common.entity.TbWoTrnRslt;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbWoTrnRsltMapper extends DefaultMapper<TbWoTrnRsltDto, TbWoTrnRslt> {
    TbWoTrnRsltMapper INSTANCE = Mappers.getMapper(TbWoTrnRsltMapper.class);
}