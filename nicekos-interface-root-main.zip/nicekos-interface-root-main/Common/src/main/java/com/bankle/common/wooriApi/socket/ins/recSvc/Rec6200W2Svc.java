package com.bankle.common.wooriApi.socket.ins.recSvc;


import com.bankle.common.dto.TbWoTrnDb6200W2Dto;
import com.bankle.common.dto.TbWoTrnDb6200W2IdDto;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.mapper.TbWoTrnDb6200W2Mapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.repo.TbWoTrnDb6200W2Repository;
import com.bankle.common.wooriApi.socket.ins.commonSvc.InsCmnSvc;
import com.bankle.common.wooriApi.socket.ins.commonSvc.vo.InsCmnSvo;
import com.bankle.common.wooriApi.socket.ins.recSvc.vo.Rec6200W2Svo;
import com.bankle.common.wooriApi.socket.ins.socketData.T6200W2;
import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Slf4j
@Component
@RequiredArgsConstructor
public class Rec6200W2Svc {

    private final String BNK_CD = "020";
    private final String TR_DSC = "100";
    private final String REQ_TG_FN_YN = "Y";
    private final String RES_TG_FN_YN = "N";
    private final String COMM_TG_DSC = "W2000";
    private final String TG_DSC = "6210";

    private final InsCmnSvc insCmnSvc;
    private final TbWoTrnDb6200W2Repository tbWoTrnDb6200W2Repository;
    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;
    private final EntityManager entityManager;

    @Transactional
    public void receive(Rec6200W2Svo.recInVo rec6200W2InVo) {
        try {


            log.debug("Rec6200W2Svo.rec6200W2InVo > " + rec6200W2InVo);
            log.debug("KOS_TG_SND_NO >>" + rec6200W2InVo.getT6200W2().getKOS_TG_NO());
            T6200W2 t6200W2 = rec6200W2InVo.getT6200W2();
            //------------------------------------------------------------------
            // 보험사 공통전문 수신 => TB_WO_TRN_COMM_MASTER
            //------------------------------------------------------------------
            String seq = t6200W2.getKOS_TG_NO().trim();
            InsCmnSvo.insCmnInVo insCmnInVo = new InsCmnSvo.insCmnInVo();
            insCmnInVo.setTgSqn(seq);
            insCmnInVo.setLoanNo(t6200W2.getLN_APRV_NO().trim());
            insCmnInVo.setTgDsc(COMM_TG_DSC);
            insCmnInVo.setTrDsc(TR_DSC);
            insCmnInVo.setBnkCd(BNK_CD);
            insCmnInVo.setReqDtm(LocalDateTime.now());
            insCmnInVo.setReqTgCnts(t6200W2.dataToString());
            insCmnInVo.setReqTgLog(t6200W2.print());
            insCmnInVo.setReqTgFnYn(REQ_TG_FN_YN);
            insCmnInVo.setResTgFnYn(RES_TG_FN_YN);
            insCmnSvc.insReceive(insCmnInVo);
            entityManager.flush();

            log.debug("보험사 공통전문 수신 => TbWoTrnDb6200W2Dto");
            log.debug("t6200W2.getTG_LEN() >>" + t6200W2.getTG_LEN().trim());
            log.debug("t6200W2.getDB_TG_NO() >>" + t6200W2.getDB_TG_NO().trim());
            String loanNo = rec6200W2InVo.getT6200W2().getLN_APRV_NO().substring(0, 11);
            var idBuilder = TbWoTrnDb6200W2IdDto.builder();
            idBuilder.loanNo(loanNo);
            idBuilder.chgDtm(LocalDateTime.now());
            TbWoTrnDb6200W2IdDto idDto = idBuilder.build();
            var mainBuilder = TbWoTrnDb6200W2Dto.builder();
            mainBuilder.id(idDto);
            mainBuilder.tgLen(StringUtils.hasText(t6200W2.getTG_LEN().trim()) ? new BigDecimal(t6200W2.getTG_LEN().trim()) : BigDecimal.valueOf(0));
            mainBuilder.tgDsc(t6200W2.getTG_DSC().trim());
            mainBuilder.lndAgncCd(t6200W2.getLND_AGNC_CD().trim());
            mainBuilder.bnkTgTrnsDtm(t6200W2.getBNK_TG_TRNS_DTM());
            mainBuilder.dbTgTrnsDtm(t6200W2.getDB_TG_TRNS_DTM());
            mainBuilder.bnkTgNo(t6200W2.getBNK_TG_NO().trim());
            mainBuilder.dbTgNo(StringUtils.hasText(t6200W2.getDB_TG_NO().trim()) ? new BigDecimal(t6200W2.getDB_TG_NO().trim()) : BigDecimal.valueOf(0));
            mainBuilder.rsrvItmH(t6200W2.getRSRV_ITM_H().trim());
            mainBuilder.bnkAskNo(t6200W2.getBNK_ASK_NO().trim());
            mainBuilder.dbMngNo(t6200W2.getDB_MNG_NO().trim());
            mainBuilder.kosMngNo(t6200W2.getKOS_MNG_NO().trim());
            mainBuilder.kosTgTrnsDtm(t6200W2.getKOS_TG_TRNS_DTM().trim());
            mainBuilder.kosTgNo(t6200W2.getKOS_TG_NO().trim());
            mainBuilder.lndKcd(t6200W2.getLND_KCD().trim());
            mainBuilder.fndYn(t6200W2.getFND_YN().trim());
            mainBuilder.cnfmtnDsc(t6200W2.getCNFMTN_DSC().trim());
            mainBuilder.srvDsc(t6200W2.getSRV_DSC().trim());
            mainBuilder.ojtAns(t6200W2.getOJT_ANS().trim());
            mainBuilder.sjtAns1(t6200W2.getSJT_ANS_1().trim());
            mainBuilder.sjtAns2(t6200W2.getSJT_ANS_2().trim());
            mainBuilder.sjtAns3(t6200W2.getSJT_ANS_3().trim());
            mainBuilder.sjtAns4(t6200W2.getSJT_ANS_4().trim());
            mainBuilder.sjtAns5(t6200W2.getSJT_ANS_5().trim());
            mainBuilder.slfCtfcAgnc(t6200W2.getSLF_CTFC_AGNC().trim());
            mainBuilder.slfCtfcTm(t6200W2.getSLF_CTFC_TM().trim());
            mainBuilder.resYn("Y");
            mainBuilder.optmYn("Y");
            mainBuilder.cnfmRsltBnkTrnsYn(t6200W2.getCNFM_RSLT_BNK_TRNS_YN().trim());
            mainBuilder.bnkResDtm(t6200W2.getBNK_RES_DTM().trim());
            mainBuilder.lndAmtJstPmntYn(t6200W2.getLND_AMT_JST_PMNT_YN().trim());
            mainBuilder.rcptJstChrgyn(t6200W2.getRCPT_JST_CHRGYN().trim());
            mainBuilder.rgstracptThdyYn(t6200W2.getRGSTRACPT_THDY_YN().trim());
            mainBuilder.rgstrErsrAcptNo(t6200W2.getRGSTR_ERSR_ACPT_NO().trim());
            mainBuilder.fxcltEstbsYn(t6200W2.getFXCLT_ESTBS_YN().trim());
            mainBuilder.fxcltEstbsRnkJstYn(t6200W2.getFXCLT_ESTBS_RNK_JST_YN().trim());
            mainBuilder.fxcltEstbsAmtJstYn(t6200W2.getFXCLT_ESTBS_AMT_JST_YN().trim());
            mainBuilder.acptnoJstYn(t6200W2.getACPTNO_JST_YN().trim());
            mainBuilder.odprtJstYn(t6200W2.getODPRT_JST_YN().trim());
            mainBuilder.rschDtm(t6200W2.getRSCH_DTM().trim());
            mainBuilder.srchrNm(t6200W2.getSRCHR_NM().trim());
            mainBuilder.srchrPhno(t6200W2.getSRCHR_PHNO().trim());
            mainBuilder.stndRmk(t6200W2.getSTND_RMK().trim());
            mainBuilder.lssrMvinhshldYn(t6200W2.getLSSR_MVINHSHLD_YN().trim());
            mainBuilder.lssrLssrHvttyn(t6200W2.getLSSR_LSSR_HVTTYN().trim());
            mainBuilder.lssrNm(t6200W2.getLSSR_NM().trim());
            mainBuilder.lssrRltsp(t6200W2.getLSSR_RLTSP().trim());
            mainBuilder.lssrMvinDt(t6200W2.getLSSR_MVIN_DT().trim());
            mainBuilder.lshdrMvinHshldEane(t6200W2.getLSHDR_MVIN_HSHLD_EANE().trim());
            mainBuilder.lshdrHvttYn(t6200W2.getLSHDR_HVTT_YN().trim());
            mainBuilder.lshdrNm(t6200W2.getLSHDR_NM().trim());
            mainBuilder.lshdrRltsp(t6200W2.getLSHDR_RLTSP().trim());
            mainBuilder.lshdrMvinDt(t6200W2.getLSHDR_MVIN_DT().trim());
            mainBuilder.dbtrSlfMvinYn(t6200W2.getDBTR_SLF_MVIN_YN().trim());
            mainBuilder.mvinAddrOptmYn(t6200W2.getMVIN_ADDR_OPTM_YN().trim());
            mainBuilder.mvinDtOptmYn(t6200W2.getMVIN_DT_OPTM_YN().trim());
            mainBuilder.spusMvinyn(t6200W2.getSPUS_MVINYN().trim());
            mainBuilder.dbtrOtsdMvinOptmYn(t6200W2.getDBTR_OTSD_MVIN_OPTM_YN().trim());
            mainBuilder.ttlStrdDtm(t6200W2.getTTL_STRD_DTM().trim());
            mainBuilder.ttlRschDt(t6200W2.getTTL_RSCH_DT().trim());
            mainBuilder.ttlSrchrNm(t6200W2.getTTL_SRCHR_NM().trim());
            mainBuilder.ttlDrwupDt(t6200W2.getTTL_DRWUP_DT().trim());
            mainBuilder.ttlRmk(t6200W2.getTTL_RMK().trim());
            mainBuilder.isrnScrtNo(t6200W2.getISRN_SCRT_NO().trim());
            mainBuilder.isrnEntrAmt(t6200W2.getISRN_ENTR_AMT().trim());
            mainBuilder.rthisrnPrmm(t6200W2.getRTHISRN_PRMM().trim());
            mainBuilder.unuslFctExstYn(t6200W2.getUNUSL_FCT_EXST_YN().trim());
            mainBuilder.unuslThngYn(t6200W2.getUNUSL_THNG_YN().trim());
            mainBuilder.cndtlExecYn(t6200W2.getCNDTL_EXEC_YN().trim());
            mainBuilder.rthRschFnYn(t6200W2.getRTH_RSCH_FN_YN().trim());
            mainBuilder.rsrvItmB(t6200W2.getRSRV_ITM_B().trim());
            mainBuilder.regDtm(LocalDateTime.now());
            mainBuilder.lnAprvNo2(t6200W2.getLN_APRV_NO().trim());
            TbWoTrnDb6200W2Dto mainDto = mainBuilder.build();
            log.debug("TbWoTrnDb6200W2Dto mainDto >>" + mainDto.toString());
            tbWoTrnDb6200W2Repository.save(TbWoTrnDb6200W2Mapper.INSTANCE.toEntity(mainDto));
            entityManager.flush();

            var cntrEntity = tbWoCntrMasterRepository
                    .findByLoanNo(rec6200W2InVo.getLoanNo()).orElseGet(TbWoCntrMaster::new);
            var cntrDto = TbWoCntrMasterMapper.INSTANCE.toDto(cntrEntity);
            log.debug("TbWoCntrMasterDto ->>" + cntrDto.toString());

            String resCd = "999";
            if (StringUtils.hasText(cntrDto.getLoanNo())) {
                resCd = "000";
            }

            log.debug("보험사 공통전문 수신 resCd ->>" + resCd);
            t6200W2.setRES_CD(resCd);
            t6200W2.setTG_DSC(TG_DSC);
            insCmnSvc.insSendResponse(InsCmnSvo.insCmnInVo.builder()
                    .tgSqn(rec6200W2InVo.getTgSqn())
                    .tgDsc(COMM_TG_DSC)
                    .resTgCnts(t6200W2.dataToString())
                    .resTgLog(t6200W2.print())
                    .resCd(resCd)
                    //.resTgFnYn("Y")
                    .build());
        } catch (Exception e) {
            e.printStackTrace();
            log.debug(
                    "Exception!!!!!!!: method::{} \n\n Exception [Err_Location] ::{}"
                    , Thread.currentThread().getStackTrace()[1].getMethodName() // 현재 실행되고있는 메서드 명
                    , e.getStackTrace()[0] // Exception 메세지
            );
            log.debug(e.getMessage());
        }
    }

}
