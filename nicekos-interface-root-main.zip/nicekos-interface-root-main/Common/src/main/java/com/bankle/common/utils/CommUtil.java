package com.bankle.common.utils;


import com.bankle.common.config.CommonConfig;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.util.StringUtils;

import java.net.InetAddress;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * 공통 유틸 클래스
 * @author SYS
 */
public class CommUtil {

	/**
	 * 난수 생성
	 * @author SYS
	 * @param digits
	 * @return
	 */
	public static int getRandomNumber(int digits) {
		Random random = new Random(System.currentTimeMillis());
		int range = (int)Math.pow(10, digits);
		int trim = (int)Math.pow(10, digits - 1);
		int rslt = random.nextInt(range) + trim;
		if (rslt > range) {
			rslt = rslt - trim;
		}
		return rslt;
	}

	/**
	 * 코드 생성
	 * @author SYS
	 * @param digits
	 * @return
	 */
	public static String getRandomCode(int digits) {
		int leftLimit = 48;
		int rightLimit = 122;
		Random random = new Random();
		return random.ints(leftLimit, rightLimit + 1)
			.filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
			.limit(digits)
			.collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
			.toString();
	}

	/**
	 * 코드 생성
	 * @author SYS
	 * @param digits
	 * @return
	 */
	public static String getRandomCodeUpperCase(int digits) {
		int leftLimit = 48;
		int rightLimit = 90;
		Random random = new Random();
		return random.ints(leftLimit, rightLimit + 1)
			.filter(i -> (i <= 57 || i >= 65) && i <= 90)
			.limit(digits)
			.collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
			.toString();
	}

	public static int err(){
		int i = 10;
		int j = 0;
		int k = CalcDivide(i, j);
		return k;
	}
	static int CalcDivide(int i, int j)  {
		return  i / j;
	}

	public static boolean isEmpty(String value) {
		return (value == null || value.length() == 0);
	}

	public static String rpad(String value, int len, String pad) {
		if(CommUtil.isEmpty(value)) {
			return value;
		}
		int lenStr = value.length();
		int lenPad = pad.length();
		if (lenStr < len && lenPad > 0) {
			StringBuffer sb = new StringBuffer(value);
			int i = lenStr + lenPad -1;
			for (; i < len; i += lenPad) {
				sb.append(pad);
			}
			return sb.toString();

		} else {
			return value;
		}
	}

	public static String getTime(String pattern) {
		SimpleDateFormat fmt = new SimpleDateFormat(pattern);
		String time = fmt.format(new Date(System.currentTimeMillis()));
		return time;
	}

	public static String getAmountComma(String value) {
		DecimalFormat df = new DecimalFormat("#,###");
		return df.format(Double.parseDouble(value));
	}

	public static String nvl(String value) {
		return nvl(value);
	}

	public static String mapToString(Map<String, Object> map, String keyName) {
		String rtnValue = "";
		try {
			rtnValue = nvl(map.get(keyName).toString());
		} catch (Exception Ex) { rtnValue = ""; }

		rtnValue = ("false".equals(rtnValue)) ? "" : rtnValue;

		return rtnValue;
	}

	public static boolean isNotEmpty(String value) {
		return !isEmpty(value);
	}


	public static String isPresent(String target, String source) {
		return target.equals(source) ? source : target;
	}

	public static <T> Map<Integer, List<T>> streamPaging(List<T> list, int pageSize) {
		return (Map<Integer, List<T>>) IntStream.iterate(0, i -> i + pageSize)
				.limit((list.size() + pageSize - 1) / pageSize)
				.boxed()
				.collect(Collectors.toMap(i -> i / pageSize, i -> list.subList(i, Math.min(i + pageSize, list.size()))));
	}

	public static String cvtFilePath(String target){
		return target.replace("/data/files/", CommonConfig.IMG_SCH_PATH);
	}

	/**
	 * 클라이언트 ip 가져오기
	 *
	 * @param : HttpServletRequest
	 * @return : ip
	 */
	public static String getIP(HttpServletRequest request) throws Exception {

		String ip = null;
		// HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
		ip = request.getHeader("X-Forwarded-For");

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("X-Real-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("X-RealIP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("REMOTE_ADDR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		//IP 주소가 로컬 루프백 주소(localhost)인 경우
		if ("0:0:0:0:0:0:0:1,127.0.0.1,211.264.251.51".contains(ip)) {
			InetAddress address = InetAddress.getLocalHost();
			ip = address.getHostName() + "/" + address.getHostAddress();
		}
		return ip;
	}

	public static String safeLpad(String[] array, int index, int length, String pad) {
		return StringUtil.lpad(
				(array != null && array.length > index && StringUtils.hasText(array[index]))
						? array[index]
						: "0",
				length,
				pad
		);
	}

}