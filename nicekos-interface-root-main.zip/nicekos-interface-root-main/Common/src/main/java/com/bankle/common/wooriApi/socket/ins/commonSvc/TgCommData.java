package com.bankle.common.wooriApi.socket.ins.commonSvc;
import com.bankle.common.utils.MapUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class TgCommData {

    private Log logger = LogFactory.getLog(TgCommData.class);

    protected Map<String, Object> map = new HashMap<String, Object>();

    public TgCommData(){
    }

    public TgCommData(Map<? extends String, ? extends Object> m){
        map.putAll(m);
    }

    public Object get(String key){
        return map.get(key);
    }

    public void put(String key, Object value){
        map.put(key, value);
    }

    public Object remove(String key){
        return map.remove(key);
    }

    public boolean containsKey(String key){
        return map.containsKey(key);
    }

    public boolean containsValue(Object value){
        return map.containsValue(value);
    }

    public void clear(){
        map.clear();
    }

    public Set<Map.Entry<String, Object>> entrySet(){
        return map.entrySet();
    }

    public Set<String> keySet(){
        return map.keySet();
    }

    public boolean isEmpty(){
        return map.isEmpty();
    }

    public void putAll(Map<? extends String, ?extends Object> m){
        map.putAll(m);
    }

    public Map<String,Object> getMap(){
        return map;
    }

    public String getString(String key) {
        return MapUtil.getString(map, key);
    }

    public int getInt(String key) {
        return MapUtil.getInt(map, key);
    }

    public double getDouble(String key) {
        return MapUtil.getDouble(map, key);
    }

    public BigDecimal getBigDecimal(String key) {
        return MapUtil.getBigDecimal(map, key);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        Iterator<Map.Entry<String, Object>> iter = map.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<String, Object> entry = iter.next();
            sb.append(entry.getKey());
            sb.append('=').append('"');
            sb.append(entry.getValue());
            sb.append('"');
            if (iter.hasNext()) {
                sb.append(',').append(' ');
            }
        }
        return sb.toString();

    }
}
