package com.bankle.app.biz.trn.ctrl;

import com.bankle.app.biz.cntr.vo.CntrMasterCvo;
import com.bankle.app.biz.trn.svc.TranHistSvc;
import com.bankle.app.biz.trn.vo.TranHistCvo;
import com.bankle.app.biz.trn.vo.TransCvo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


@Tag(name = "2. 전문 전송 내역", description = "전문 전송 내역 관리 API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class TranHistCtrl {

    private final TranHistSvc tranHistSvc;

    private final ModelMapper modelMapper;

    @Operation(summary = "여신번호로 전문 전송 내역 조회 ", description = "input : LoanNo(여신번호) example No : '22381866498'")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "여신번호로 전문 전송 내역 조회 성공", content = @Content(schema = @Schema(implementation = TranHistCvo.TranHistResCvo.class))),
    })
    @PostMapping("/trn/searchtrnhist/{loanNo}")
    public ResponseEntity<?> searchTrnHist(@Valid @PathVariable(name = "loanNo") String loanNo) throws Exception {
        try {
            var res = tranHistSvc.getByLoanNo(loanNo)
                    .stream()
                    .map(e -> modelMapper
                            .map(e, TranHistCvo.TranHistResCvo.class))
                    .toList();

            if(res.stream().count() > 0){
                return  ResData.SUCCESS(res,"성공");
            }
            return ResData.FAIL("전문 전송 내역이 존재하지 않습니다.");

        }catch (Exception e){
            throw new DefaultException(e.getMessage());
        }
    }
}
