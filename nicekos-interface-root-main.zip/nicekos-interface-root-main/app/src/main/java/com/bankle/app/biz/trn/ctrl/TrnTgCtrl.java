package com.bankle.app.biz.trn.ctrl;

import com.bankle.app.biz.trn.svc.TrnTgSvc;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;

@Slf4j
@RestController
@RequiredArgsConstructor
public class TrnTgCtrl {

    private final TrnTgSvc trnTgSvc;

    @PostMapping(value="/trn/savedbtg")
    public @ResponseBody Map<String, Object> saveDbTg(HttpServletRequest httpServletRequest) {

        log.debug("===============================================================");
        log.debug("DB Socket Receive !!!");
        log.debug("===============================================================");

        return trnTgSvc.setDataDb(httpServletRequest);
    }


    @PostMapping(value = "/trn/savefatg")
    public @ResponseBody Map<String, Object> saveFaTg(HttpServletRequest httpServletRequest) {

        log.debug("===============================================================");
        log.debug("FA Socket Receive !!!");
        log.debug("===============================================================");

        if(httpServletRequest.getContentLength() < 600 ){
            return trnTgSvc.setDataFaStd(httpServletRequest);
        } else {
            return trnTgSvc.setDataFaAsk(httpServletRequest);
        }
    }
}
