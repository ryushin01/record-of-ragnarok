package com.bankle.app.biz.trn.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class LoanExeCvo {

    @Getter
    @Setter
    @ToString
    public static class LoanExeReqCvo {

        private String loanNo;

        private String newLoanNo;

        private String trLn;

        private String trCd;

        private String trTpCd;

        private String loNo;

        private String trSq;

        private String reqDttm;

        private String resDttm;

        private String resCd;

        private String approvalNum;

        private String exeDtm;

        private String procDvsn;

        private String exeAmt;

        private String categoryCd;

        private String docTax;

        private String debtDcAmt;

        private String etcAmt;

        private String filler;
    }
}
