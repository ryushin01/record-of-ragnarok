package com.bankle.app.biz.trn.svc;


import com.bankle.app.biz.trn.vo.SendDbAskSvo;
import com.bankle.app.biz.trn.vo.SendFaAskSvo;
import com.bankle.common.dto.TbWoCntrMasterDto;
import com.bankle.common.dto.TbWoTrnDb6100W1Dto;
import com.bankle.common.dto.TbWoTrnFa6100F1Dto;
import com.bankle.common.entity.TbCustBrnchMng;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.mapper.TbWoTrnDb6100W1Mapper;
import com.bankle.common.mapper.TbWoTrnFa6100F1Mapper;
import com.bankle.common.repo.TbCustBrnchMngRepository;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.repo.TbWoTrnDb6100W1Repository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.DateUtil;
import com.bankle.common.utils.NumberUtil;
import com.bankle.common.wooriApi.socket.ins.sendSvc.Send6100W1Svc;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6100F1Svo;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6100W1Svo;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import jakarta.persistence.EntityManager;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

@Slf4j
@Service
@AllArgsConstructor
public class SendDbAskSvc {

    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;

    private final TbWoTrnDb6100W1Repository tbWoTrnDb6100W1Repository;

    private final EntityManager entityManager;

    private final CustomeModelMapper customeModelMapper;

    private final Send6100W1Svc send6100W1Svc;

    private final BizUtil bizUtil;

    private final TbCustBrnchMngRepository tbCustBrnchMngRepository;

    @Transactional
    public boolean save(@Valid SendDbAskSvo.SendDbAskInSvo inSvo) throws Exception {
        //------------------------------------------------------------------
        // 원장 생성
        //------------------------------------------------------------------
        String newLoanNo = inSvo.getNewLoanNo();
        String seq = bizUtil.getSeq(Sequence.TRANS);
        TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(inSvo.getLoanNo())
                .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));

        TbWoCntrMasterDto tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);
        tbWoCntrMasterDto.setLoanNo(newLoanNo);
        tbWoCntrMasterDto.setBizNo(inSvo.getLwfmBizno());
        tbWoCntrMasterDto.setLndKndCd(inSvo.getLndKndCd());
        tbWoCntrMasterDto.setFndUseCd(inSvo.getFndYn());
        tbWoCntrMasterDto.setLndPrdtNm(inSvo.getPrdtNm());
        tbWoCntrMasterDto.setStndAplYn(inSvo.getStndTrgtYn());
        tbWoCntrMasterDto.setMvhhdCnfmReqYn("");
        tbWoCntrMasterDto.setSlPrc(BigDecimal.valueOf(0));
        tbWoCntrMasterDto.setIsrnEntrAmt(inSvo.getIsrnEntrAmt());
        tbWoCntrMasterDto.setExecPlnAmt(inSvo.getLndAmt());
        tbWoCntrMasterDto.setExecPlnDt(inSvo.getLndPlnDt());
        tbWoCntrMasterDto.setExecDt(inSvo.getLndPlnDt());
        tbWoCntrMasterDto.setExecAmt(inSvo.getLndAmt());
        tbWoCntrMasterDto.setDbtrNm(inSvo.getDbtrNm());
        tbWoCntrMasterDto.setDbtrBirthDt(inSvo.getDbtrRrno());
        tbWoCntrMasterDto.setDbtrAddr(inSvo.getDbtrAddr());
        tbWoCntrMasterDto.setDbtrHpno(inSvo.getDbtrHpno());
        tbWoCntrMasterDto.setPwpsNm("");
        tbWoCntrMasterDto.setSlmnLndProc("");
        tbWoCntrMasterDto.setSrMembNo("");
        tbWoCntrMasterDto.setTrAmt(BigDecimal.valueOf(0));
        tbWoCntrMasterDto.setSellerNm1("");
        tbWoCntrMasterDto.setSellerBirthDt1("");
        tbWoCntrMasterDto.setSellerNm2("");
        tbWoCntrMasterDto.setOwnLoanMaxAmt(BigDecimal.valueOf(0));
        tbWoCntrMasterDto.setOwnLoanPlnAmt(BigDecimal.valueOf(0));
        tbWoCntrMasterDto.setOwnLoanBankNm1("");
        tbWoCntrMasterDto.setOwnLoanBankNm2("");
        tbWoCntrMasterDto.setOwnLoanBankNm3("");
        tbWoCntrMasterDto.setOwnLoanBankNm4("");
        tbWoCntrMasterDto.setOwnLoanBankNm5("");
        tbWoCntrMasterDto.setCnsgnNm("");
        tbWoCntrMasterDto.setTrstNm("");
        tbWoCntrMasterDto.setBnfrNm("");
        tbWoCntrMasterDto.setNowLshDrNm("");
        tbWoCntrMasterDto.setRsrvItmB("");
        tbWoCntrMasterDto.setOblMLnAprvNo("");
        tbWoCntrMasterDto.setOblTotCnt(0);
        tbWoCntrMasterDto.setOblGrpRnkNo(0);
        Optional<TbCustBrnchMng> fndByNm = tbCustBrnchMngRepository.findAllByBrnchNm(inSvo.getAskBrnchNm());
        if (fndByNm.isPresent()) {
            tbWoCntrMasterDto.setBnkBrnchCd(fndByNm.get().getBrnchCd());
        } else {
            tbWoCntrMasterDto.setBnkBrnchCd("999999");
        }
        tbWoCntrMasterDto.setBnkBrnchNm(inSvo.getAskBrnchNm());
        tbWoCntrMasterDto.setBnkDrctrNm(inSvo.getAskBrnchDrctrNm());
        tbWoCntrMasterDto.setBnkBrnchPhno(inSvo.getAskBrnchPhno());
        tbWoCntrMasterRepository.save(TbWoCntrMasterMapper.INSTANCE.toEntity(tbWoCntrMasterDto));
        entityManager.flush();

        //------------------------------------------------------------------
        // 전문 상세 생성
        //------------------------------------------------------------------
        inSvo.setKosTgNo(seq);
        inSvo.setLoanNo(newLoanNo);
        inSvo.setChgDtm(LocalDateTime.now());
        tbWoTrnDb6100W1Repository.save(
                TbWoTrnDb6100W1Mapper.INSTANCE
                        .toEntity(customeModelMapper
                                .mapping(inSvo, TbWoTrnDb6100W1Dto.class)));
        entityManager.flush();

        //------------------------------------------------------------------
        // 전문 전송
        //------------------------------------------------------------------
        Send6100W1Svo.sendInVo sendInVo = customeModelMapper.mapping(inSvo, Send6100W1Svo.sendInVo.class);
        CheckResponseSvo checkResponseSvo = send6100W1Svc.sendAndResponse(sendInVo);
        return "000".equals(checkResponseSvo.getRescode());
    }
}
