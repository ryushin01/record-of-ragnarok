package com.bankle.app.biz.trn.vo;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class SendFaPreAskSvo {

    @Getter
    @Setter
    @ToString
    public static class SendFaPreAskInSvo {

        private String loanNo;

        private String newLoanNo;

        private LocalDateTime chgDtm;

        private BigDecimal tgLen;

        private String tgDsc;

        private String bnkTgNo;

        private String faTgNo;

        private String kosTgSndNo;

        private LocalDateTime tgSndDtm;

        private LocalDateTime  tgRcvDtm;

        private String resCd;

        private String rsrvItmH;

        private String lndDsc;

        private String lndKndCd;

        private String fndUseCd;

        private String bnkLndProdtCd;

        private String bnkLndProdtNm;

        private String stndAplYn;

        private String mvLwyrCnfmYn;

        private String rgstrUnqNo1;

        private String rgstrUnqNo2;

        private String rgstrUnqNo3;

        private String rgstrUnqNo4;

        private String rgstrUnqNo5;

        private String rlesDsc;

        private String trgtRlesDsc;

        private String trgtRlesAddr;

        private String bfAskDt;

        private String lndPlnDt;

        private BigDecimal slPrc;

        private String scrtevlAmt;

        private String isrnEntrAmt;

        private BigDecimal lndAmt;

        private BigDecimal bnkfxcltRgstrRnk;

        private String dbrtNm;

        private String dbtrBirthDt;

        private String dbtrAddr;

        private String dbtrPhno;

        private String dbtrHpno;

        private String pwpsNm;

        private String pwpsBirthDt;

        private String pwpsAddr;

        private String pwpsPhno;

        private String pwpsHpno;

        private String rmkFc;

        private String lndHndgSlfDsc;

        private String bnkBrnchNm;

        private String bnkDrctrNm;

        private String bnkBrnchPhno;

        private String bnkDrctrHp;

        private String bnkBrnchFax;

        private String bnkBrnchAddr;

        private String slmnCmpyNM;

        private String slmnNm;

        private String slmnPhno;

        private String rfrLnAprvNo;

        private String rgstrMtdDsc;

        private String odprtRpyEane;

        private String eltnEstbsLwyrNm;

        private String eltnEstbsLwyrBizNo;

        private String slCntrctEane;

        private String slCntrctFlnm;

        private String afrgstrScrtYn;

        private String bnkBrnchCd;

        private String rsrvItmB;

        private LocalDateTime regDtm;

        private String trgtRlesAddr2;

        private String addrSrchYn;

        private String cnvntLwyrYn;

        private String lnAprvNo2;

    }
}
