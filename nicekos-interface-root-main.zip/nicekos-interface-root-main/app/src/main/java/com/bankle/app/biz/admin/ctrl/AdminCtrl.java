package com.bankle.app.biz.admin.ctrl;

import com.bankle.app.biz.admin.svc.AdminSvc;
import com.bankle.app.biz.admin.vo.AdminCvo;
import com.bankle.app.biz.admin.vo.AdminSvo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "01.Admin", description = "관리자 관리 API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class AdminCtrl {

    private final AdminSvc adminService;
    private final CustomeModelMapper modelMapper;

    /**
     * @package : com.withuslaw.Admin.biz.admin.ctrl
     * @name : Admin 로그인 Controller
     * @date : 2023-11-13 오전 11:12
     * @author : JS Hong
     * @version : 1.0.0
     **/

    @Operation(summary = "Admin 로그인 ", description = "example :\n\n id : a@bankle.co.kr\n\n pwd : bankle\n\n lognYn : 로그인 중 여부\n\n membNo : 관리자번호\n\n adminNm : 관리자명\n\n " +
            "permCd : 관리자권한코드\n\n permNm : 관리자권한명\n\n lognId : 아이디\n\n cphnNum : 전화번호\n\n lognFailCnt : 로그인실패횟수\n\n" +
            "statCd : 관리자상태코드 (00 : 초대중, 01 : 승인, 02 : 초대취소)\n\n statNm : 관리자상태명\n\n0. 로그인 성공시(성공 조건 statCd : 01, 옳바른 아이디 비번) : code >> '00' 이하 경우엔 '99'\n\n1. 이외에 유효성 검사 틀린 경우엔 전부 msg : 존재하지 않는 이메일입니다." +
            "\n\n그러나, 비밀번호가 5회 틀린 경우엔 잠기는 기능이 기획에 있었으므로,\n\n 1) 비밀번호가 잘못된 경우 : msg, 관리자명, 아이디, 로그인실패횟수 증가 출력\n\n2) 아이디가 잘못된 경우 : msq, 아이디 출력\n\n을 출력하게 해두었음")
    //0. 로그인 성공시(성공 조건 statCd : 01, 옳바른 아이디 비번) : code >> '00' 이하 경우엔 '99'\n\n 1. 비밀번호가 잘못된 경우 : msg, 관리자명, 아이디, 로그인실패횟수 증가 출력\n\n 2. 아이디가 잘못된 경우 : msq, 아이디 출력\n\n" +
    //            " 3. 다른 ip에서 접속한 경우 : msg, 관리자 정보 출력\n\n4. 승인이 되지않은(statCd : 00) 계정의 로그인인 경우 : msg, 관리자 정보 출력\n\n4. 초대취소된(statCd : 02) 계정의 로그인인 경우 : msg, 관리자 정보 출력
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "login & 조회 성공", content = @Content(schema = @Schema(implementation = AdminCvo.LoginAdminResCvo.class))),
    })
    @PostMapping(value = "/admin/login")
    public ResponseEntity<?> login(@RequestBody AdminCvo.LoginVo loginVo) throws Exception {
        try {

            String id = loginVo.getAdminId();
            String pwd = loginVo.getPwd();

            log.debug("관리자 로그인 Controller");
            AdminSvo.AdminLoginInSvo inSvo = new AdminSvo.AdminLoginInSvo();
            inSvo.setLognId(id);
            inSvo.setPwd(pwd);
            AdminSvo.AdminLoginOutSvo outSvo = adminService.adminLogin(inSvo);
            AdminCvo.LoginAdminResCvo resCvo = modelMapper.mapping(outSvo, AdminCvo.LoginAdminResCvo.class);
            if ("01".equals(outSvo.getResCd())) {
                return ResData.FAIL(resCvo, "잘못된 비밀번호 입니다.");
            } else if ("02".equals(outSvo.getResCd())) {
                return ResData.FAIL(resCvo, "잘못된 아이디 입니다.");
            } else if ("03".equals(outSvo.getResCd())) {
                return ResData.FAIL(resCvo, "다른 ip에서의 접속입니다.");
            } else if ("04".equals(outSvo.getResCd())) {
                return ResData.FAIL(resCvo, "초대중인 계정입니다.");
            } else if ("05".equals(outSvo.getResCd())) {
                return ResData.FAIL(resCvo, "초대취소된 처리된 계정입니다.");
            } else if ("06".equals(outSvo.getResCd())) {
                return ResData.FAIL(resCvo, "존재하지 않는 이메일입니다.");
            } else if ("07".equals(outSvo.getResCd())) {
                return ResData.SUCCESS(resCvo, "중복 로그인!");
            }
            return ResData.SUCCESS(resCvo, "관리자 로그인 성공");

        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }
}
