package com.bankle.app.biz.trn.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

public class TranHistSvo {

    @Getter
    @Setter
    @Builder
    public static class TranHistOutSvo {

        @Schema(description = "번호")
        private String seq;

        @Schema(description = "전문명")
        private String trnName;

        @Schema(description = "전문코드")
        private String trnKnd;

        @Schema(description = "응답여부")
        private String resYn;

        @Schema(description = "응답코드")
        private String resCd;

        @Schema(description = "요청 일시")
        private LocalDateTime reqDttm;

    }
}
