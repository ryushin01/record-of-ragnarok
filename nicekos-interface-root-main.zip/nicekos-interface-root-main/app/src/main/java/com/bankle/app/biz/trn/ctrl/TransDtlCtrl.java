package com.bankle.app.biz.trn.ctrl;

import com.bankle.app.biz.cntr.vo.CntrMasterCvo;
import com.bankle.app.biz.trn.svc.TransDtlSvc;
import com.bankle.app.biz.trn.vo.TransCvo;
import com.bankle.app.biz.trn.vo.TransSvo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@Tag(name = "1. 원장", description = "원장 관리 API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class TransDtlCtrl {

    private final TransDtlSvc transDtlSvc;

    private final CustomeModelMapper customeModelMapper;

    @Operation(summary = "여신번호로 전문 조회(전문 상세)", description = "input : LoanNo(여신번호) example No : '22381866498'")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "여신번호로 원장 조회 성공", content = @Content(schema = @Schema(implementation = CntrMasterCvo.FndByLoanNoResCvo.class))),
    })
    @PostMapping("/trn/searchtrnsdetail/{loanNo}")
    public ResponseEntity<?> searchCntrDetail(@Valid @PathVariable(name = "loanNo") String loanNo) throws Exception {
        try {
            return ResData.SUCCESS(transDtlSvc.getByLoanNo(loanNo)
                    .stream()
                    .map(e -> customeModelMapper.mapping(e, TransCvo.TransResCvo.class))
                    .toList(), "성공");
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "여신번호로 전문 조회(6100)", description = "input : LoanNo(여신번호) example No : '22381866498'")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "여신번호로 원장 조회 성공", content = @Content(schema = @Schema(implementation = CntrMasterCvo.FndByLoanNoResCvo.class))),
    })
    @PostMapping("/trn/searchtrns6100detail/{loanNo}")
    public ResponseEntity<?> searchTrns6100Detail(@Valid @PathVariable(name = "loanNo") String loanNo) throws Exception {
        try {
            log.debug("여기 들어옴");
            return ResData.SUCCESS(transDtlSvc.getByLoanNo6100(loanNo)
                    .stream()
                    .map(e -> customeModelMapper.mapping(e, TransCvo.trns6100ResCvo.class))
                    .toList(), "성공");
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "여신번호로 전문 조회(6300)", description = "input : LoanNo(여신번호) example No : '22381866498'")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "여신번호로 원장 조회 성공", content = @Content(schema = @Schema(implementation = TransCvo.Trns6300ResCvo.class))),
    })
    @PostMapping("/trn/searchtrns6300detail/{loanNo}")
    public ResponseEntity<?> searchTrns6300Detail(@Valid @PathVariable(name = "loanNo") String loanNo) throws Exception {
        try {
            log.debug("여기 들어옴");
            return ResData.SUCCESS(transDtlSvc.getByLoanNo6300(loanNo)
                    .stream()
                    .map(e -> customeModelMapper.mapping(e, TransCvo.Trns6300ResCvo.class))
                    .toList(), "성공");
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "여신번호로 전문 조회(db 6300)", description = "input : LoanNo(여신번호) example No : '22381866498'")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "여신번호로 원장 조회 성공", content = @Content(schema = @Schema(implementation = TransCvo.Trns6300DbResCvo.class))),
    })
    @PostMapping("/trn/searchtrnsdb6300detail/{loanNo}")
    public ResponseEntity<?> searchTrnsDb6300Detail(@Valid @PathVariable(name = "loanNo") String loanNo) throws Exception {
        try {
            log.debug("여기 들어옴");
            return ResData.SUCCESS(transDtlSvc.getByLoanNoDb6300(loanNo)
                    .stream()
                    .map(e -> customeModelMapper.mapping(e, TransCvo.Trns6300DbResCvo.class))
                    .toList(), "성공");
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "대출 실행 전문 조회(A700)", description = "대출 실행 전문 조회(A700) API")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "대출 실행 전문 조회(A700) 성공", content = @Content(schema = @Schema(implementation = TransCvo.Trns6300ResCvo.class))),
    })
    @PostMapping("/trn/searchloanexe/{loanNo}")
    public ResponseEntity<?> searchTransLoanExe(@Valid @PathVariable(name = "loanNo") String loanNo) throws Exception {
        try {
            return ResData.SUCCESS(customeModelMapper.mapping(
                    transDtlSvc.getLoanExeByLoanNo(loanNo), TransCvo.TrnsLoanExeResCvo.class), "성공");
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "지급 요청 결과통지 전문 조회(A400)", description = "지급 요청 결과통지 전문 조회(A400) API")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "지급 요청 결과통지 전문 조회(A400) 성공", content = @Content(schema = @Schema(implementation = TransCvo.TrnsPayRsltResCvo.class))),
    })
    @PostMapping("/trn/searchpayrslt/{loanNo}")
    public ResponseEntity<?> searchPayRslt(@Valid @PathVariable(name = "loanNo") String loanNo) throws Exception {
        try {
            return ResData.SUCCESS(customeModelMapper.mapping(
                    transDtlSvc.getPayRsltByLoanNo(loanNo), TransCvo.TrnsPayRsltResCvo.class), "성공");
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "DB 청약의뢰 전문 조회(W1000)", description = "DB 청약의뢰 전문 조회(W1000) API")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "DB 청약의뢰 전문 조회(W1000) 성공", content = @Content(schema = @Schema(implementation = TransCvo.TrnAskDbResCvo.class))),
    })
    @PostMapping("/trn/searchaskdb/{loanNo}")
    public ResponseEntity<?> searchTranAskDb(@Valid @PathVariable(name = "loanNo") String loanNo) throws Exception {
        try {
            return ResData.SUCCESS(transDtlSvc.getTrnAskDbByLoanNo(loanNo)
                    .stream()
                    .map(e -> customeModelMapper.mapping(e, TransCvo.TrnAskDbResCvo.class))
                    .toList(), "성공");
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "이미지 파일 서류전송 결과 통지 전문 조회(B700)", description = "이미지 파일 서류전송 결과 통지 전문 조회(B700) API")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "이미지 파일 서류전송 결과 통지 전문 조회(B700) 성공", content = @Content(schema = @Schema(implementation = TransCvo.TrnsImageSendRsltResCvo.class))),
    })
    @PostMapping("/trn/searchimagesendrslt/{loanNo}")
    public ResponseEntity<?> searchImageSendRslt(@Valid @PathVariable(name = "loanNo") String loanNo) throws Exception {
        try {
            return ResData.SUCCESS(customeModelMapper.mapping(
                    transDtlSvc.getImageSendRsltByLoanNo(loanNo), TransCvo.TrnsImageSendRsltResCvo.class), "성공");
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }
}

