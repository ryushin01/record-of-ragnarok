package com.bankle;

import com.bankle.app.config.AppConfigList;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication(
		scanBasePackages = {
				"com.bankle.common"
				, "com.bankle.app"
		}
)
@EnableJpaAuditing
@Import(AppConfigList.class)
public class AppApplication {
	public static void main(String[] args) {
		// System.setProperty("spring.config.name", "application-app-dev");
		System.out.println("AppApplication Hello world!");
		SpringApplication.run(AppApplication.class, args);
	}
}
