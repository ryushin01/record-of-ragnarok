package com.bankle.batch.execdtstat;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * 배치 - 대출실행일 진행상태 업데이트 배치
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.19
 */
@Tag(name = "배치 - 대출실행일 진행상태 업데이트 배치", description = "")
@RequiredArgsConstructor
@RestController
public class ExecDtStat {

    private final ExecDtStatService execDtStatService;

    @Operation(summary = "대출실행일 진행상태 변경 배치", description = """
            대출 실행일이 오늘인 배정 완료 의뢰건 상태코드를 업데이트 합니다.
            
            - 매일 오전 02:00과 03:00에 실행
            
            """)
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "성공")})
    @PatchMapping("/batch/executiondate-state")
    public void runSwagger() {
        this.execDtStat();
    }

    // 매일 오전 02:00과 03:00에 실행
    // 초 분 시 일 월 요일
    @Scheduled(cron = "0 0 2,3 * * *")
    public void execDtStat() {
        execDtStatService.execute();
    }
}
