package com.bankle.batch.hist;

import com.bankle.batch.hist.vo.BatchHistVo;
import com.bankle.common.dto.TbBatchHistDto;
import com.bankle.common.mapper.TbBatchHistMapper;
import com.bankle.common.repo.TbBatchHistRepository;
import com.bankle.common.utils.CustomeModelMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * 배치 공통 서비스
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.19
 */
@Service
@RequiredArgsConstructor
public class BatchHistService {

    private final TbBatchHistRepository tbBatchHistRepo;
    private final CustomeModelMapper customeModelMapper;

    public void crtBatchHist(BatchHistVo.BatchHistInsReq inVo) {
        tbBatchHistRepo.save(
                TbBatchHistMapper.INSTANCE.toEntity(
                        customeModelMapper.mapping(inVo, TbBatchHistDto.class)
                )
        );
    }

}
