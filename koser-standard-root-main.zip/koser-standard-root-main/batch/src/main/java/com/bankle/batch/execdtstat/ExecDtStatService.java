package com.bankle.batch.execdtstat;

import com.bankle.batch.hist.BatchHistService;
import com.bankle.batch.hist.vo.BatchHistVo;
import com.bankle.common.dto.TbRgstrStatHistDto;
import com.bankle.common.enums.Sequence;
import com.bankle.common.mapper.TbRgstrMasterMapper;
import com.bankle.common.mapper.TbRgstrStatHistMapper;
import com.bankle.common.repo.TbRgstrMasterRepository;
import com.bankle.common.repo.TbRgstrStatHistRepository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.DateUtil;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


import java.time.LocalDateTime;
import java.util.List;

/**
 * 배치 - 대출실행일 진행상태 업데이트 서비스
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.19
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ExecDtStatService {

    private static final String BATCH_ID = "EXECDT_STAT_01";

    private final BatchHistService batchHistService;
    private final CustomeModelMapper modelMapper;
    private final TbRgstrMasterRepository tbRgstrMasterRepository;
    private final TbRgstrStatHistRepository tbRgstrStatHistRepository;
    private final BizUtil bizUtil;


    @Transactional
    public void execute() {
        /**
         * 예제 주석 : 1. 배치 시작시에 대한 시간을 만들어 놓는다.
         */
        LocalDateTime stDtm = LocalDateTime.now();
        /**
         * 예제 주석 : 2. 배치 실행 메소드명을 가져온다. 아래의 내용을 복사하여 그대로 사용하여도 무방하다.
         */
        List<String> statCd = List.of("01", "02");
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        /**
         * 예제 주석 : 3. 배치를 시작하여 각 배치에 맞는 로직을 작성한다.
         */
        try {

        //오늘날짜(YYYYmmDD)를 가져온다.
        String toDay = DateUtil.getDateNowStr();

        //배정 완료(20)인 의뢰 건 중 대출 실행일이 오늘인 의뢰건 리스트를 가져온다.
        var rgstrMasterList = tbRgstrMasterRepository.findByExecDtAndStatCd(toDay , "20");

        if(CollectionUtils.isNotEmpty(rgstrMasterList)) {

           var rgstrDtoList =TbRgstrMasterMapper.INSTANCE.toDtoList(rgstrMasterList);

           rgstrDtoList.forEach(dto ->{
               // 상태코드를 대출실행(30)으로 변경한다.
               dto.setStatCd("30");

               //원장 업데이트
               tbRgstrMasterRepository.save(TbRgstrMasterMapper.INSTANCE.toEntity(dto));

               // 등기이력 상태 저장
               tbRgstrStatHistRepository.save(TbRgstrStatHistMapper.INSTANCE.toEntity(TbRgstrStatHistDto.builder()
                       .rqstNo(dto.getRqstNo())
                       .statCd(dto.getStatCd())
                       .build()));
           });
        }

            /**
             * 예제 주석 : 4. 배치 종료시에 대한 시간을 만들어 놓는다.
             */
            LocalDateTime endDtm = LocalDateTime.now();

            /**            예제 주석 : 5. 배치내역을 적재하도록 한다.
             *             적재시에 대한 내용은 아래와 같이 작성을 진행하도록 한다.
             *             batchId  -> 각 배치에 맞는 id를 만들어 작성을 진행한다.(업무단위로 나눈 약어를 기준으로 작성을 진행한다.)
             *             method   -> 각 배치가 실행되는 직접적인 메소드 명이다. 대다수는 execute로 추출이 되겠지만,
             *                         간혹 메소드가 복수로 만들어 질 경우에는 뒤에 숫자가 붙기 때문에 메소드명을 추출을 하여 해당하는 서비스를 추출 할 수 있도록 한다.
             *             errYn    -> catch문에서 에러가 발생할 경우 Y로 작성하며 Default는 N으로 작성한다.
             *             errMsg   -> 빈값이며 catch문에서 에러가 발생할 경우 Exception 의 메세지를 담아주도록 한다.
             *             stDtm    -> 위에서 선언한 시작 시간을 담아준다.
             *             endDtm   -> 위세서 선언한 종료 시간을 담아준다. catch문 안에서는 catch가 잡힌 마지막 시간인 LocalDateTime.now()로 작성을 해주면된다.
             */
            BatchHistVo.BatchHistInsReq histInSvo = BatchHistVo.BatchHistInsReq.builder()
                    .batchId(BATCH_ID).method(methodName).errYn("N").stDtm(stDtm).endDtm(endDtm)
                    .build();
            batchHistService.crtBatchHist(histInSvo);
        } catch (Exception e) {
            BatchHistVo.BatchHistInsReq histInSvo = BatchHistVo.BatchHistInsReq.builder()
                    .batchId(BATCH_ID).method(methodName).errYn("Y").errMsg(e.getMessage()).stDtm(stDtm).endDtm(LocalDateTime.now())
                    .build();

            batchHistService.crtBatchHist(histInSvo);
        }
    }
}
