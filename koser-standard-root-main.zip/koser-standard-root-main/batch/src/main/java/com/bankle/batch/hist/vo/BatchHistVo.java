package com.bankle.batch.hist.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
/**
 * @author 박원준
 * @version 1.0
 * @since 2025.03.19
 */
public class BatchHistVo {

    @Builder
    @Getter
    @Setter
    public static class BatchHistInsReq {
        private String batchId;
        private String method;
        private String errYn;
        private String errMsg;
        private LocalDateTime stDtm;
        private LocalDateTime endDtm;
    }
}
