package com.bankle.app.client.rqst.vo;

import com.bankle.common.annotation.DateFormatString;
import com.bankle.common.annotation.LocalDateTimeToString;
import com.bankle.common.annotation.NullToEmptyString;
import com.bankle.common.commSvc.vo.ImageVo;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 금융기관 - 의뢰목록 I/O
 *
 * @author 이은희
 * @version 1.0
 * @since 2025.03.13
 */
public class RqstVo {

    @Getter
    @Setter
    public static class RqstInfoRes {

        @Schema(description = "의뢰번호", example = "2025031200001")
        @NullToEmptyString
        private String rqstNo;

        @Schema(description = "법무대리인", example = "홍길동법무법인")
        @NullToEmptyString
        private String lgagMembNm;

        @Schema(description = "법무대리인 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String lgagMembHpno;

        @Schema(description = "시스템관리자", example = "김뱅클")
        @NullToEmptyString
        private String mngrMembNm;

        @Schema(description = "시스템관리자 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String mngrMembHpno;

        @Schema(description = "보안요청 사유", example = "")
        @NullToEmptyString
        private String procRsnCnts;

        @Schema(description = "진행 상태 코드"
                , example = "00 : 등기의뢰\n" +
                "10 : 보안필요\n" +
                "20 : 배정완료\n" +
                "30 : 대출실행\n" +
                "40 : 접수검토중\n" +
                "50 : 접수반려\n" +
                "60 : 접수완료\n" +
                "70 : 진행취소\n" +
                "80 : 진행보류")
        @NullToEmptyString
        private String statCd;

    }

    @Getter
    @Setter
    public static class RqstListReq {

        @Size(min = 2 , max = 2 , message = "tap 구분 값은 필수 값 입니다.")
        @Schema(description = "tap 선택", example = "00:미배정, 01:배정완료, 02:진행보류, 03: 진행취소")
        private String tabSelection;

        @Min(value = 1, message = "현재 페이지는 1 이상이어야 합니다.")
        @Schema( description = "현재 페이지" , example = "1")
        private int pageNum;

        @Min(value = 1, message = "페이지에 보여지는 데이터 수는 1 이상이어야 합니다.")
        @Schema( description = "페이지에 보여지는 데이터수" , example = "50")
        private int pageSize;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RqstListRes {
        @Schema(description = "전체 페이지 개수", example = "7")
        private int totalPages;

        @Schema(description = "전체 데이터 개수 (검색된 모든 데이터 항목 수)", example = "100")
        private long totalElements;

        @Schema(description = "전자등기 의뢰 목록")
        private List<RqstVo.RqstInfo> rqstList;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RqstInfo{

        @Schema( description = "의뢰번호" , example = "1234567890")
        @NullToEmptyString
        private String rqstNo;

        @Schema( description = "대출 실행일" , example = "2025-03-14")
        @DateFormatString
        private String execDt;

        @Schema( description = "의뢰일시" , example = "2023-12-19 16:24:04")
        @LocalDateTimeToString
        private LocalDateTime crtDtm;

        @Schema( description = "진행 상태 명" , example = "등기의뢰")
        @NullToEmptyString
        private String statNm;

        @Schema(description = "진행상태 코드\n " +
                "00 : 등기의뢰\n" +
                "10 : 보안필요\n" +
                "20 : 배정완료\n" +
                "30 : 대출실행\n" +
                "40 : 접수검토중\n" +
                "50 : 접수반려\n" +
                "60 : 접수완료\n" +
                "70 : 진행취소\n" +
                "80 : 진행보류"
                , example = "00")
        @NullToEmptyString
        private String statCd;

    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RqstCrtReq {
        @Schema(description = "의뢰번호", maxLength = 13, example = "20250312")
        @Size(min = 13 , max = 13 , message = "의뢰번호는 13자리를 입력하세요.")
        String rqstNo;

        @Schema(description = "대출실행일", maxLength = 8, example = "20250312")
        @Size(min = 8 , max = 8 , message = "대출실행 8자리를 입력하세요.")
        String execDt;

        @Schema(description = "이미지 리스트", example = "[]")
        List<ImageVo.ImageInfo> imageInfo;
    }

    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RqstCrtRes {
        @Schema(description = "의뢰번호", maxLength = 13, example = "2025010100001")
        String rqstNo;

        @Schema(description = "대출실행일", maxLength = 8, example = "20250312")
        @NullToEmptyString
        String execDt;
    }

}
