package com.bankle.app.client.board.ctrl;


import com.bankle.app.client.board.svc.ClientBoardSvc;
import com.bankle.app.client.board.vo.ClientBoardVo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * 금융기관 - 공지사항 컨트롤러
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.19
 */
@Tag(name = "금융기관 - 공지사항", description = "금융기관 - 공지사항")
@Slf4j
@RestController
@RequiredArgsConstructor
public class ClientBoardCtrl {

    private final ClientBoardSvc clientBoardSvc;

    @Operation(
            summary = "공지사항 목록 조회 API",
            description = """
        요청 데이터:
        - 현재 페이지 (pageNum)
        - 페이지에 보여지는 데이터수 (pageSize)  
        """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation =  ClientBoardVo.BoardListRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/client/board/list")
    public ResponseEntity<?> getBoardlist(@Valid ClientBoardVo.BoardListReq req) throws Exception {
            return ResData.SUCCESS(clientBoardSvc.boardList(req) , "공지 목록 조회 성공");
    }


}
