package com.bankle.app.client.home.vo;

import com.bankle.common.annotation.NullToEmptyString;
import com.bankle.common.annotation.YNToBoolean;
import com.bankle.common.vo.PageData;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

public class HomeVo {

    @Getter
    @Setter
    public static class HomeLiveRgstrInfoReq extends PageData.PageReqData {
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HomeStatisticsRes {

        @Schema(description = "오늘 실행 건수", example = "0")
        @NullToEmptyString
        @JsonProperty("cntExec")
        private String CntExec;

        @Schema(description = "진행중", example = "0")
        @NullToEmptyString
        @JsonProperty("cntProg")
        private String CntProg;

        @Schema(description = "접수완료", example = "0")
        @NullToEmptyString
        @JsonProperty("cntComplete")
        private String CntComplete;

    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HomeRgstrRes {

        @Schema(description = "실시간 등기 현황 리스트", example = "")
        private List<HomeRegistrationListRes> rgstrMasterList = new ArrayList<>();

    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HomeRegistrationListRes {

        @Schema(description = "의뢰 번호", example = "2025031300001")
        @NullToEmptyString
        private String rqstNo;

        @Schema(description = "채무자", example = "김채무")
        @NullToEmptyString
        private String dbtrNm;

        @Schema(description = "법무대리인", example = "홍길동")
        @NullToEmptyString
        private String lgagMembNm;

        @Schema(description = "진행상태명", example = "대출실행")
        @NullToEmptyString
        private String statCdNm;

        @Schema(description = "등기접수번호", example = "111111")
        @NullToEmptyString
        private String acptNo;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HomeBoardRes {

        @Schema(description = "공지사항 리스트", example = "")
        private List<HomeBoardListRes> homeBoardListRes = new ArrayList<>();

    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HomeBoardListRes {

        @Schema(description = "공지사항 제목", example = "[공지] 공지사항")
        @NullToEmptyString
        private String boardTitles;

        @Schema(description = "등록일", example = "YYYY-MM-DD")
        @NullToEmptyString
        private String crtDtm;

        @Schema(description = "긴급 여부", example = "false")
        @YNToBoolean
        private String emcyYn;
    }
}
