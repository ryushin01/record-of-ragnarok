package com.bankle.app.client.rqst.svc;

import com.bankle.app.client.rqst.vo.RqstVo;
import com.bankle.common.commSvc.CommonSvc;
import com.bankle.common.commSvc.FileSvc;
import com.bankle.common.config.CommCont;
import com.bankle.common.dto.TbRgstrMasterDto;
import com.bankle.common.dto.TbRgstrStatHistDto;
import com.bankle.common.entity.TbRgstrMaster;
import com.bankle.common.entity.TbRgstrStatHist;
import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.BadRequestException;
import com.bankle.common.mapper.TbRgstrMasterMapper;
import com.bankle.common.mapper.TbRgstrStatHistMapper;
import com.bankle.common.repo.TbRgstrMasterRepository;
import com.bankle.common.repo.TbRgstrStatHistRepository;
import com.bankle.common.userAuth.UserAuthSvc;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.StringUtil;
import com.bankle.common.vo.RgstrData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * 금융기관 - 의뢰목록 서비스
 *
 * @author 이은희
 * @version 1.0
 * @since 2025.03.13
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RqstSvc {

    private final BizUtil bizUtil;
    private final CustomeModelMapper modelMapper;
    private final FileSvc fileSvc;
    private final CommonSvc commonSvc;
    private final TbRgstrMasterRepository tbRgstrMasterRepository;
    private final TbRgstrStatHistRepository tbRgstrStatHistRepository;

    /**
     * 등기자료 팝업 정보 조회 (미배정, 보완필요)
     *
     * @param rqstNo 등기의뢰 번호
     * @return : 등기자료 정보
     */
    public RqstVo.RqstInfoRes getInfo(String rqstNo) throws Exception {
        String bizNo = UserAuthSvc.getBizNo();
        RgstrData rgstrData = commonSvc.getRgstrMasterInfo(rqstNo, bizNo);

        RqstVo.RqstInfoRes result = modelMapper.mapping(rgstrData, RqstVo.RqstInfoRes.class);

        //진행상태가 보완요청일 겨우 보완요청 사유 조회
        if(StringUtil.equals(rgstrData.getStatCd(), CommCont.RGSTR_STAT_SPLMT)) {
            TbRgstrStatHistDto rgstrStatHistDto =  tbRgstrStatHistRepository.findTop1ByRqstNoAndStatCdOrderBySeqDesc(rqstNo, CommCont.RGSTR_STAT_SPLMT)
                    .map(TbRgstrStatHistMapper.INSTANCE::toDto)
                    .orElseGet(TbRgstrStatHistDto::new);

            result.setProcRsnCnts(rgstrStatHistDto.getProcRsnCnts());
        }

        return result;
    }

    /**
     * 전자등기 의뢰목록 조회
     *
     * @param req 진행상태 Tab, 페이지번호
     * @return 진행 상태별 의뢰목록
     */
    @Transactional
    public RqstVo.RqstListRes getList(RqstVo.RqstListReq req) throws Exception {

        /*
            미배정(00): 배정되기 전 (등기의뢰, 보완필요 상태)
            배정완료(01): 배정된 후 (배정완료, 대출실행, 접수검토중, 접수반려, 접수완료)
            진행보류(02): 진행보류된 후 (진행보류)
            진행취소(03): 진행취소된 후 (진행취소)
        */
        List<String> statCds = switch (req.getTabSelection()) {
            case "00" -> Arrays.asList("00", "10"); //미배정
            case "01" -> Arrays.asList("20", "30", "40", "50", "60"); //미배정, 배정완료
            case "02" -> List.of("80"); //미배정 진행보류
            case "03" -> List.of("70"); // 미배정 진행취소
            default -> throw new BadRequestException("존재하지 않는 Tap 메뉴 입니다.");
        };

        //등기의뢰 등록 최신순으로 조회
        Sort sort = Sort.by(Sort.Direction.DESC, "crtDtm");
        Pageable pageable = PageRequest.of(req.getPageNum()-1, req.getPageSize() , sort);

        String bizNo = UserAuthSvc.getBizNo();

        //원장 페이징 조회
        Page<TbRgstrMaster> list = tbRgstrMasterRepository.findByBndBizNoAndStatCdIn(bizNo, statCds, pageable);

        RqstVo.RqstListRes result = RqstVo.RqstListRes.builder()
                .totalPages(list.getTotalPages())
                .totalElements(list.getTotalElements())
                .build();

        if(list.isEmpty()) {
            result.setRqstList(new ArrayList<>());
            return result;
        }

        List<TbRgstrMasterDto> dtoList = TbRgstrMasterMapper.INSTANCE.toDtoList(list.getContent());

        List<RqstVo.RqstInfo> rqstList = dtoList.stream()
                .map(dto -> modelMapper.mapping(dto, RqstVo.RqstInfo.class))
                .toList();

        result.setRqstList(rqstList);

        return result;

    }

    /**
     * 전자등기 의뢰 제출
     *
     * @param execDt 실행일
     * @param multipartFiles 이미지 파일
     * @return : 원장 정보
     */
    @Transactional(rollbackFor = Exception.class)
    public RqstVo.RqstCrtRes crtRqst(String execDt, List<MultipartFile> multipartFiles) throws Exception {

        // 첨부파일 코드(등기자료)
        String attcFilCd = "01";

        String statCd = "00";

        // =================================================================
        // 파일 업로드
        // =================================================================
        String fileSeq = fileSvc.crtImages(multipartFiles, attcFilCd, null);


        // =================================================================
        // 원장 생성
        // =================================================================
        String rqstNo = bizUtil.getSeq(Sequence.RQST_NO);

        tbRgstrMasterRepository.save(TbRgstrMasterMapper.INSTANCE.toEntity(TbRgstrMasterDto.builder()
                .rqstNo(rqstNo)
                .bndBizNo(UserAuthSvc.getBizNo())
                .statCd(statCd)
                .execDt(execDt)
                .rgstrDataFilSeq(fileSeq)
                .build()));

        //------------------------------------------------------------------
        // 등기 상태 이력 저장
        //------------------------------------------------------------------
        tbRgstrStatHistRepository.save(TbRgstrStatHistMapper.INSTANCE.toEntity(TbRgstrStatHistDto.builder()
                .rqstNo(rqstNo)
                .statCd(statCd)
                .build()));

        return new RqstVo.RqstCrtRes(rqstNo, execDt);
    }

    /**
     * 전자등기 수정
     *
     * @param reqVo 원장번호, 실행일
     * @param multipartFiles 이미지 파일
     * @return : 원장 정보
     */
    @Transactional(rollbackFor = Exception.class)
    public RqstVo.RqstCrtRes updateRqst(RqstVo.RqstCrtReq reqVo, List<MultipartFile> multipartFiles) throws Exception {

        // 첨부파일 코드(등기자료)
        String attcFilCd = "01";
        String statCd = "00";
        String rqstNo = reqVo.getRqstNo();
        String execDt = reqVo.getExecDt();

        Optional<TbRgstrMaster> tbRgstrMaster = tbRgstrMasterRepository.findByRqstNo(rqstNo);

        if (tbRgstrMaster.isEmpty()) {
            throw new BadRequestException("해당 의뢰번호에 대한 등기자료가 존재하지 않습니다.");
        }

        // =================================================================
        // 파일 업로드
        // =================================================================
        TbRgstrMasterDto tbRgstrMasterDto = TbRgstrMasterMapper.INSTANCE.toDto(tbRgstrMaster.get());

        String fileSeq = fileSvc.updImages(multipartFiles, attcFilCd, tbRgstrMasterDto.getRgstrDataFilSeq(), reqVo.getImageInfo());

        // =================================================================
        // 원장 수정
        // =================================================================
        tbRgstrMasterDto.setExecDt(execDt);
        tbRgstrMasterRepository.save(TbRgstrMasterMapper.INSTANCE.toEntity(tbRgstrMasterDto));

        //------------------------------------------------------------------
        // 등기 상태 이력 저장
        //------------------------------------------------------------------
        tbRgstrStatHistRepository.save(TbRgstrStatHistMapper.INSTANCE.toEntity(TbRgstrStatHistDto.builder()
                .rqstNo(rqstNo)
                .statCd(statCd)
                .build()));

        return new RqstVo.RqstCrtRes(rqstNo, execDt);
    }
}
