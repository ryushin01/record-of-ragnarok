package com.bankle.app.client.home.ctrl;

import com.bankle.app.client.home.svc.HomeSvc;
import com.bankle.app.client.home.vo.HomeVo;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author : lsh
 * @version : 1.
 * @package : com.bankle.app.biz.client.home
 * @class : HomeController.java
 * @data : 25. 1. 16.
 **/
@Tag(name = "금융기관 - 홈", description = "홈")
@Slf4j
@RestController
@RequiredArgsConstructor
public class HomeCtrl {

    private final HomeSvc homeSvc;

    @Operation(summary = "등기현황 건수 조회", description = """
            금융기관 전자등기 관리 시스템 홈 화면 상단
            
            [ REQUEST ]
            - 요청에 필요한 정보 없음
            
            [ RESPONSE ]
            
            code
            - 00 : 성공
            - 99 : 실패
            
            msg
            - code가 00 : 'return 성공'
            
            data
            - cntExec : 오늘 실행 건수
            - cntProg : 진행 중
            - cntComplete : 접수 완료
            """)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "등기 현황 건수 조회 성공", content = @Content(schema = @Schema(implementation = HomeVo.HomeStatisticsRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/client/home/statistics")
    public ResponseEntity<?> homeStatisticsCtrl() throws Exception{
        return ResData.SUCCESS(homeSvc.getLiveStatistics(), "return 성공");
    }

    @Operation(summary = "실시간 등기 현황", description = """
            목록 조회 : 금융기관 전자등기 관리 시스템 홈 화면 좌측 하단
            
            [ REQUEST ]
            - 요청에 필요한 정보 없음
            
            [ RESPONSE ]
            
            code
            - 00 : 성공
            - 99 : 실패
            
            msg
            - code가 00 : 'return 성공'
            
            data
            - rgstrMasterList : 실시간 등기 현황
              > rqstNo : 의뢰 번호\n
              > dbtrNm : 채무자\n
              > lgagMembNm : 법무대리인\n
              > statCdNm : 진행 상태\n
              > acptNo : 등기 접수 번호\n
            """)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "실시간 등기 현황 조회 성공", content = @Content(schema = @Schema(implementation = HomeVo.HomeRgstrRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/client/home/registration-list")
    public ResponseEntity<?> homeRegistrationListCtrl()  throws Exception{
        return ResData.SUCCESS(homeSvc.getLiveRgstrStatus(), "return 성공");
    }

    @Operation(summary = "공지사항", description = """
            목록 조회 : 금융기관 전자등기 관리 시스템 홈 화면 우측 하단
            
            [ REQUEST ]
            - 요청에 필요한 정보 없음
            
            [ RESPONSE ]
            
            code
            - 00 : 성공
            - 99 : 실패
            
            msg
            - code가 00 : 'return 성공'
            
            data
            - homeBoardResVo
              > boardTitles : 공지사항 제목\n
              > crtDtm : 등록일\n
              > emcyYn : 긴급 여부\n
            """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "공지사항 조회 성공", content = @Content(schema = @Schema(implementation = HomeVo.HomeBoardListRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/client/home/board-list")
    public ResponseEntity<?> homeBoardListCtrl()  throws Exception{
        return ResData.SUCCESS(homeSvc.getHomeBoard(), "return 성공");
    }

}
