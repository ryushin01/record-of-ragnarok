package com.bankle.app.client.rgstr.svc;

import com.bankle.app.client.rgstr.vo.RgstrVo;
import com.bankle.common.commSvc.CommonSvc;
import com.bankle.common.config.CommCont;
import com.bankle.common.dto.TbRgstrMasterDto;
import com.bankle.common.dto.TbRgstrStatHistDto;
import com.bankle.common.entity.TbRgstrMaster;
import com.bankle.common.entity.spce.TbRgstrMasterSpec;
import com.bankle.common.exception.BadRequestException;
import com.bankle.common.mapper.TbRgstrMasterMapper;
import com.bankle.common.mapper.TbRgstrStatHistMapper;
import com.bankle.common.repo.TbRgstrMasterRepository;
import com.bankle.common.repo.TbRgstrStatHistRepository;
import com.bankle.common.userAuth.UserAuthSvc;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.StringUtil;
import com.bankle.common.vo.RgstrData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 금융기관 - 현황조회 서비스
 *
 * @author 이은희
 * @version 1.0
 * @since 2025.03.13
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RgstrSvc {

    private final CustomeModelMapper modelMapper;
    private final CommonSvc commonSvc;
    private final TbRgstrMasterRepository tbRgstrMasterRepository;
    private final TbRgstrStatHistRepository tbRgstrStatHistRepository;


    /**
     * 등기자료 의뢰번호 검색
     *
     * @param rqstNo 의뢰번호
     * @return 의뢰번호 검색 유무
     */
    public Boolean getSearch(String rqstNo) throws Exception {

        String bizNo = UserAuthSvc.getBizNo();

        var result = tbRgstrMasterRepository.findByRqstNoAndBndBizNo(rqstNo, bizNo);

        return result.isPresent();
    }

    /**
     * 등기자료 정보 조회
     *
     * @param rqstno 등기의뢰 번호
     * @return : 등기자료 정보
     */
    public RgstrVo.RgstrInfoRes getInfo(String rqstno) throws Exception {

        String bizNo = UserAuthSvc.getBizNo();
        RgstrData rgstrData = commonSvc.getRgstrMasterInfo(rqstno, bizNo);

        return modelMapper.mapping(rgstrData, RgstrVo.RgstrInfoRes.class);
    }

    /**
     * 등기팝업증 정보 조회
     * @param rqstno 등기의뢰 번호
     * @return 등기팝업증 정보
     * @throws Exception 실행 오류
     */
    public RgstrVo.RgstrAcceptInfoRes getAcceptInfo(String rqstno) throws Exception {

        String bizNo = UserAuthSvc.getBizNo();
        RgstrData rgstrData = commonSvc.getRgstrMasterInfo(rqstno, bizNo);

        RgstrVo.RgstrAcceptInfoRes result = modelMapper.mapping(rgstrData, RgstrVo.RgstrAcceptInfoRes.class);

        //관할법원 및 등기소 정보 조회
        result.setJudtCourtNm(commonSvc.getCommCodeNm("JUDT_COURT_CD", rgstrData.getJudtCourtCd()));
        result.setRegrNm(commonSvc.getCommCodeNm("REGR_CD", rgstrData.getRegrCd()));

        return result;
    }

    /**
     * 금융기관- 전자등기 현황 리스트 조회
     * @param reqVo 검색조건
     * @return 전자등기 현황 리스트
     * @throws Exception 실행오류
     */
    public RgstrVo.RgstrListRes getList(RgstrVo.RgstrListReq reqVo) throws Exception {


        //------------------------------------------------------------------
        // 리스트 정렬 기준 세팅
        //------------------------------------------------------------------
        //등기의뢰 대출실행일 기준 최신순(대출실행일이 같으면 의리일시 기준 최신순)
        Sort sort = Sort.by(
                Sort.Order.desc("execDt"),
                Sort.Order.desc("crtDtm")
        );
        Pageable pageable = PageRequest.of(reqVo.getPageNum()-1, reqVo.getPageSize() , sort);

        //------------------------------------------------------------------
        // 검색조건 세팅
        //------------------------------------------------------------------
        Specification<TbRgstrMaster> spec = (root, query, criteriaBuilder) -> null;

        //금융기관 사업자번호
        String bizNo = UserAuthSvc.getBizNo();
        spec = spec.and(TbRgstrMasterSpec.equalsBndBizNo(bizNo));

        //검색기간
        if(StringUtil.equals(reqVo.getSearchType(), "EXEC")) {
            spec = spec.and(TbRgstrMasterSpec.greaterThanOrEqualToExecDt(reqVo.getFromDate()));
            spec = spec.and(TbRgstrMasterSpec.lessThanOrEqualToExecDt(reqVo.getToDate()));
        } else {
            spec = spec.and(TbRgstrMasterSpec.greaterThanOrEqualToCrtDtm(reqVo.getFromDate()));
            spec = spec.and(TbRgstrMasterSpec.lessThanCrtDtm(reqVo.getToDate()));
        }

        //의뢰번호 검색
        if(StringUtils.hasText(reqVo.getRqstNo())) {
            spec = spec.and(TbRgstrMasterSpec.likeRqstNo(reqVo.getRqstNo()));
        }

        //진행상태 검색
        if(StringUtils.hasText(reqVo.getStatCd())) {
            spec = spec.and(TbRgstrMasterSpec.equalsStatCd(reqVo.getStatCd()));
        }

        //접수번호 검색
        if(StringUtils.hasText(reqVo.getAcptNo())) {
            spec = spec.and(TbRgstrMasterSpec.likeAcptNo(reqVo.getAcptNo()));
        }

        //채무자 검색
        if(StringUtils.hasText(reqVo.getDbtrNm())) {
            spec = spec.and(TbRgstrMasterSpec.likeDbtrNm(reqVo.getDbtrNm()));
        }

        //------------------------------------------------------------------
        // 리스트 조회
        //------------------------------------------------------------------
        Page<TbRgstrMaster> list = tbRgstrMasterRepository.findAll(spec, pageable);

        RgstrVo.RgstrListRes result = RgstrVo.RgstrListRes.builder()
                .totalPages(list.getTotalPages())
                .totalElements(list.getTotalElements())
                .build();

        if(list.isEmpty()) {
            result.setRgstrList(new ArrayList<>());
            return result;
        }

        List<TbRgstrMasterDto> dtoList = TbRgstrMasterMapper.INSTANCE.toDtoList(list.getContent());

        List<RgstrVo.RgstrInfo> rqstList = dtoList.stream()
                .map(dto -> modelMapper.mapping(dto, RgstrVo.RgstrInfo.class))
                .toList();

        result.setRgstrList(rqstList);

        return result;
    }

    /**
     * 등기 원장 상태 진행보류 변경 및 등기 진행상태 이력 저장
     *
     * @param rqstNo 등기의뢰 번호
     * @throws Exception 실행 오류
     */
    @Transactional
    public void updateRgstrHold(String rqstNo) throws Exception {

        //1. 등기 원장 정보 조회 및 유효성 체크
        TbRgstrMasterDto rgstrMasterDto = commonSvc.getRgstrMastrDto(rqstNo);

        String bizNo = UserAuthSvc.getBizNo();
        if(!StringUtil.equals(rgstrMasterDto.getBndBizNo(), bizNo)) {
            throw new BadRequestException("등기자료의 채권자 정보가 일치하지 않습니다.");
        }

        if(StringUtil.equals(rgstrMasterDto.getStatCd(), CommCont.RGSTR_STAT_HOLD)) {
            throw new BadRequestException("등기자료가 이미 진행보류 상태 입니다.");
        }

        if(StringUtil.equals(rgstrMasterDto.getStatCd(), CommCont.RGSTR_STAT_CNCL)) {
            throw new BadRequestException("등기자료가 진행취소 되어 진행보류 불가합니다.");
        }

        //2. 진행상태를 진행보류로 변경
        rgstrMasterDto.setStatCd(CommCont.RGSTR_STAT_HOLD);

        //3. 등기 원장 테이블 저장
        tbRgstrMasterRepository.save(TbRgstrMasterMapper.INSTANCE.toEntity(rgstrMasterDto));

        //4. 등기 상태 이력 저장
        tbRgstrStatHistRepository.save(TbRgstrStatHistMapper.INSTANCE.toEntity(TbRgstrStatHistDto.builder()
                .rqstNo(rqstNo)
                .statCd(CommCont.RGSTR_STAT_HOLD)
                .build()));
    }

}
