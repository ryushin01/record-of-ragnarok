package com.bankle.app.client.rgstr.ctrl;

import com.bankle.app.client.rgstr.svc.RgstrSvc;
import com.bankle.app.client.rgstr.vo.RgstrVo;
import com.bankle.app.client.rqst.vo.RqstVo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

/**
 * 금융기관 - 현황조회 컨트롤러
 *
 * @author 이은희
 * @version 1.0
 * @since 2025.03.13
 */
@Tag(name = "금융기관 - 현황조회", description = "등기 현황 조회")
@Slf4j
@RestController
@RequiredArgsConstructor
public class RgstrCtrl {

    private final RgstrSvc rgstrSvc;

    @Operation(summary = "전자등기 현황 목록", description = "전자등기 현황 목록 조회")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RqstVo.RqstInfoRes.class)))
    })
    @GetMapping(value = "/client/registration/list")
    public ResponseEntity<?> getList(@Valid RgstrVo.RgstrListReq reqVo) throws Exception {

        RgstrVo.RgstrListRes resVo = rgstrSvc.getList(reqVo);
        return ResData.SUCCESS(resVo, "성공");

    }

    @Operation(summary = "등기자료 팝업 조회", description = "등기자료 팝업 조회")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RgstrVo.RgstrInfoRes.class)))
    })
    @GetMapping(value = "/client/registration/data")
    public ResponseEntity<?> getInfo(@RequestParam String rqstno) throws Exception {

        RgstrVo.RgstrInfoRes resVo = rgstrSvc.getInfo(rqstno);
        return ResData.SUCCESS(resVo, "성공");
    }

    @Operation(summary = "등기접수증 팝업 조회", description = "등기접수증 팝업 조회")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RgstrVo.RgstrInfoRes.class)))
    })
    @GetMapping(value = "/client/registration/accept")
    public ResponseEntity<?> getAcceptInfo(@RequestParam String rqstno) throws Exception {

        RgstrVo.RgstrAcceptInfoRes resVo = rgstrSvc.getAcceptInfo(rqstno);
        return ResData.SUCCESS(resVo, "성공");
    }
    @Operation(summary = "의뢰번호 검색", description = "의뢰번호 검색")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = Boolean.class)))
    })
    @GetMapping(value = "/client/registration/search")
    public ResponseEntity<?> getSearch(@RequestParam String rqstno) throws Exception {

        boolean result = rgstrSvc.getSearch(rqstno);
        return ResData.SUCCESS(result, "성공");
    }
    @Operation(summary = "등기 진행보류", description = "등기 상태를 진행보류로 변경")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RgstrVo.RgstrInfoRes.class)))
    })
    @PatchMapping(value = "/client/registration/hold")
    public ResponseEntity<?> updateRgstrHold(@RequestBody RgstrVo.RgstrHoldReq reqVo, Authentication authentication) throws Exception {

//        UserDetails getUserDetails = (UserDetails)authentication.getDetails();
//        String membNo = (String)authentication.getPrincipal();
//        log.debug("### membNo : {}", membNo );

        rgstrSvc.updateRgstrHold(reqVo.getRqstNo());

        return ResData.SUCCESS("00","진행보류 성공");
    }


}
