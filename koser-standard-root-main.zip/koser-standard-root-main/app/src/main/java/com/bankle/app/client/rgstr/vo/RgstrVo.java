package com.bankle.app.client.rgstr.vo;

import com.bankle.app.client.rqst.vo.RqstVo;
import com.bankle.common.annotation.DateFormatString;
import com.bankle.common.annotation.LocalDateTimeToString;
import com.bankle.common.annotation.NullToEmptyString;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 금융기관 - 현황조회 I/O
 *
 * @author 이은희
 * @version 1.0
 * @since 2025.03.13
 */
public class RgstrVo {

    @Getter
    @Setter
    public static class RgstrInfoRes {

        @Schema(description = "지번", example = "서울시")
        @NullToEmptyString
        private String lotnumAddr;

        @Schema(description = "도로명", example = "서울시")
        @NullToEmptyString
        private String rdnmAddr;

        @Schema(description = "상세주소(동)", example = "101")
        @NullToEmptyString
        private String bldg;

        @Schema(description = "상세주소(호)", example = "11")
        @NullToEmptyString
        private String unit;

        @Schema(description = "의뢰번호", example = "2025031200001")
        private String rqstNo;

        @Schema(description = "채무자명", example = "홍길동")
        @NullToEmptyString
        private String dbtrNm;

        @Schema(description = "설정약정일", example = "20250312")
        @DateFormatString
        private String seDt;

        @Schema(description = "대출실행일", example = "20250312")
        @DateFormatString
        private String execDt;

        @Schema(description = "채권최고액", example = "0")
        private BigDecimal bndMaxAmt = BigDecimal.valueOf(0);

        @Schema(description = "법무대리인", example = "홍길동법무법인")
        @NullToEmptyString
        private String lgagMembNm;

        @Schema(description = "법무대리인 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String lgagMembHpno;

        @Schema(description = "시스템관리자", example = "김뱅클")
        @NullToEmptyString
        private String mngrMembNm;

        @Schema(description = "시스템관리자 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String mngrMembHpno;

        @Schema(description = "진행상태 코드\n " +
                "00 : 등기의뢰\n" +
                "10 : 보안필요\n" +
                "20 : 배정완료\n" +
                "30 : 대출실행\n" +
                "40 : 접수검토중\n" +
                "50 : 접수반려\n" +
                "60 : 접수완료\n" +
                "70 : 진행취소\n" +
                "80 : 진행보류"
                , example = "00")
        @NullToEmptyString
        private String statCd;

    }

    @Getter
    @Setter
    public static class RgstrAcceptInfoRes {

        @Schema(description = "지번", example = "서울시")
        @NullToEmptyString
        private String lotnumAddr;

        @Schema(description = "도로명", example = "서울시")
        @NullToEmptyString
        private String rdnmAddr;

        @Schema(description = "상세주소(동)", example = "101")
        @NullToEmptyString
        private String bldg;

        @Schema(description = "상세주소(호)", example = "11")
        @NullToEmptyString
        private String unit;

        @Schema(description = "의뢰번호", example = "2025031200001")
        private String rqstNo;

        @Schema(description = "채무자명", example = "홍길동")
        @NullToEmptyString
        private String dbtrNm;

        @Schema(description = "대출실행일", example = "20250312")
        @DateFormatString
        private String execDt;

        @Schema(description = "관할법원", example = "광주지방법원")
        @NullToEmptyString
        private String judtCourtNm;

        @Schema(description = "등기소", example = "무안등기소")
        @NullToEmptyString
        private String regrNm;

        @Schema(description = "접수번호", example = "45360")
        @NullToEmptyString
        private String acptNo;

        @Schema(description = "법무대리인", example = "홍길동법무법인")
        @NullToEmptyString
        private String lgagMembNm;

        @Schema(description = "법무대리인 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String lgagMembHpno;

        @Schema(description = "시스템관리자", example = "김뱅클")
        @NullToEmptyString
        private String mngrMembNm;

        @Schema(description = "시스템관리자 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String mngrMembHpno;

        @Schema(description = "진행상태 코드\n " +
                "00 : 등기의뢰\n" +
                "10 : 보안필요\n" +
                "20 : 배정완료\n" +
                "30 : 대출실행\n" +
                "40 : 접수검토중\n" +
                "50 : 접수반려\n" +
                "60 : 접수완료\n" +
                "70 : 진행취소\n" +
                "80 : 진행보류"
                , example = "00")
        @NullToEmptyString
        private String statCd;

    }

    @Getter
    @Setter
    public static class RgstrListReq {

        @Min(value = 1, message = "현재 페이지는 1 이상이어야 합니다.")
        @Schema( description = "현재 페이지" , example = "1")
        private int pageNum;

        @Min(value = 1, message = "페이지에 보여지는 데이터 수는 1 이상이어야 합니다.")
        @Schema( description = "페이지에 보여지는 데이터수" , example = "50")
        private int pageSize;

        @Schema(description = "의뢰번호", example = "2025031200001")
        private String rqstNo;

        @Schema(description = "진행상태 코드\n " +
                "00 : 등기의뢰\n" +
                "10 : 보안필요\n" +
                "20 : 배정완료\n" +
                "30 : 대출실행\n" +
                "40 : 접수검토중\n" +
                "50 : 접수반려\n" +
                "60 : 접수완료\n" +
                "70 : 진행취소\n" +
                "80 : 진행보류"
                , example = "00")
        private String statCd;

        @Schema(description = "접수번호", example = "45360")
        private String acptNo;

        @Schema(description = "검색일 구분(대출실행일:EXEC, 의뢰일:RQST)", example = "EXEC")
        @Size(min = 4 , max = 4 , message = "검색일 구분이 올바르지 않습니다.")
        private String searchType;

        @Schema(description = "검색 시작일", example = "20250312")
        @Size(max = 8 , message = "올바른 날짜 형식이 아닙니다.")
        private String fromDate;

        @Schema(description = "검색 종료일", example = "20250312")
        @Size(max = 8 , message = "올바른 날짜 형식이 아닙니다.")
        private String toDate;

        @Schema(description = "채무자명", example = "홍길동")
        private String dbtrNm;

    }
    @Getter
    @Setter
    @Builder
    public static class RgstrListRes {
        @Schema(description = "전체 페이지 개수", example = "7")
        private int totalPages;

        @Schema(description = "전체 데이터 개수 (검색된 모든 데이터 항목 수)", example = "100")
        private long totalElements;

        @Schema(description = "전자등기 현황 목록")
        private List<RgstrVo.RgstrInfo> rgstrList;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RgstrInfo{

        @Schema( description = "의뢰번호" , example = "1234567890")
        @NullToEmptyString
        private String rqstNo;

        @Schema( description = "의뢰일시" , example = "2023-12-19")
        @LocalDateTimeToString(pattern = "yyyy-MM-dd")
        private LocalDateTime crtDtm;

        @Schema( description = "대출 실행일" , example = "2025-03-14")
        @DateFormatString
        private String execDt;

        @Schema( description = "진행 상태 명" , example = "등기의뢰")
        @NullToEmptyString
        private String statNm;

        @Schema(description = "채무자명", example = "홍길동")
        @NullToEmptyString
        private String dbtrNm;

        @Schema(description = "접수번호", example = "123456,123456")
        @NullToEmptyString
        private String acptNo;

        @Schema(description = "진행상태 코드\n " +
                "00 : 등기의뢰\n" +
                "10 : 보안필요\n" +
                "20 : 배정완료\n" +
                "30 : 대출실행\n" +
                "40 : 접수검토중\n" +
                "50 : 접수반려\n" +
                "60 : 접수완료\n" +
                "70 : 진행취소\n" +
                "80 : 진행보류"
                , example = "00")
        @NullToEmptyString
        private String statCd;

    }

    @Getter
    @Setter
    public static class RgstrHoldReq {

        @Schema( description = "의뢰번호" , example = "1234567890")
        @Size(min = 13 , max = 13 , message = "의뢰번호 13자리를 입력하세요.")
        private String rqstNo;

    }
}
