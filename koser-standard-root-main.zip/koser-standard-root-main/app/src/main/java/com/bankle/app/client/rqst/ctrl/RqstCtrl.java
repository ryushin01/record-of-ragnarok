package com.bankle.app.client.rqst.ctrl;

import com.bankle.app.client.rqst.svc.RqstSvc;
import com.bankle.app.client.rqst.vo.RqstVo;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 금융기관 - 의뢰목록 컨트롤러
 *
 * @author 이은희
 * @version 1.0
 * @since 2025.03.13
 */
@Tag(name = "금융기관 - 의뢰목록", description = "등기 의뢰목록 조회")
@Slf4j
@RestController
@RequiredArgsConstructor
public class RqstCtrl {

    private final RqstSvc rqstSvc;

    @Operation(summary = "전자등기 의뢰목록", description = "전자등기 의뢰목록 조회")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RqstVo.RqstInfoRes.class)))
    })
    @GetMapping(value = "/client/request/list")
    public ResponseEntity<?> getList(@Valid RqstVo.RqstListReq reqVo) throws Exception {

        RqstVo.RqstListRes resVo = rqstSvc.getList(reqVo);
        return ResData.SUCCESS(resVo, "성공");

    }

    @Operation(summary = "등기자료 팝업 조회", description = "등기자료 팝업 조회")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RqstVo.RqstInfoRes.class)))
    })
    @GetMapping(value = "/client/request/info")
    public ResponseEntity<?> getInfo(@RequestParam String rqstno) throws Exception {

        RqstVo.RqstInfoRes resVo = rqstSvc.getInfo(rqstno);
        return ResData.SUCCESS(resVo, "성공");

    }

    @Operation(summary = "전자등기 의뢰", description = "전자등기 의뢰\n\n" +
            "execDt : 실행일자(20250301)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RqstVo.RqstCrtRes.class)))
    })
    @PostMapping(value = "/client/request", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.APPLICATION_JSON_VALUE}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> crtRqst(
            @RequestParam String execDt,
            @RequestPart(value = "multipartFiles") @Parameter(content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE)) List<MultipartFile> multipartFiles
    ) throws Exception {

        RqstVo.RqstCrtRes resVo = rqstSvc.crtRqst(execDt, multipartFiles);
        return ResData.SUCCESS(resVo, "성공");

    }

    @Operation(summary = "전자등기 수정",
            description = """
                등기접수 정보 등록

                imageInfo 예시
                등록 : []
                수정 : /files/images 파일 조회 응답값

                "imageInfo": [
                    {
                      "seq": "2025031200001",
                      "filIdx": 1,
                      "src": "/files/images/dcyt/2025031200001/1",
                      "attcFilNm": "스크린샷 2025-01-14 오후 4.05.12.png",
                      "filSize": 1000
                    },
                    {
                      "seq": "2025031200001",
                      "filIdx": 2,
                      "src": "/files/images/dcyt/2025031200001/2",
                      "attcFilNm": "스크린샷 2025-01-15 오전 10.33.56.png",
                      "filSize": 2000
                    }
                ]
            """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RqstVo.RqstCrtRes.class)))
    })
    @PatchMapping(value = "/client/request", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.APPLICATION_JSON_VALUE}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> updateRqst(
            @Valid @RequestPart() @Parameter(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE), required = true) RqstVo.RqstCrtReq rqstCrtReq,
            @RequestPart(value = "multipartFiles", required = false) @Parameter(content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE)) List<MultipartFile> multipartFiles
    ) throws Exception {

        RqstVo.RqstCrtRes resVo = rqstSvc.updateRqst(rqstCrtReq, multipartFiles);
        return ResData.SUCCESS(resVo, "성공");

    }


}
