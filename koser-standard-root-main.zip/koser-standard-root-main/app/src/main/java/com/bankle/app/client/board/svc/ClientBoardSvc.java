package com.bankle.app.client.board.svc;



import com.bankle.app.client.board.vo.ClientBoardVo;
import com.bankle.common.commSvc.CommonSvc;
import com.bankle.common.dto.TbBoardDto;
import com.bankle.common.entity.TbBoard;
import com.bankle.common.mapper.TbBoardMapper;
import com.bankle.common.repo.TbBoardRepository;

import com.bankle.common.utils.CustomeModelMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;


/**
 * 금융기관 - 공지 서비스
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.19
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ClientBoardSvc {

    private final TbBoardRepository tbBoardRepository;
    private final CustomeModelMapper modelMapper;
    private final CommonSvc commonSvc;
    private final CustomeModelMapper customeModelMapper;

    /**
     * 공지 리스트 조회
     *
     * @param : BoardVo.BoardListReq
     * @return : BoardVo.BoardListRes
     */
    @Transactional
    public ClientBoardVo.BoardListRes boardList(ClientBoardVo.BoardListReq req) throws Exception {

        Sort sort = Sort.by(
                Sort.Order.desc("emcyYn"),  // emcyYn이 "Y"인 데이터 우선 정렬
                Sort.Order.desc("chgDtm")   // 그 안에서 chgDtm 내림차순 정렬
        );
        Pageable pageable = PageRequest.of(req.getPageNum() - 1, req.getPageSize(), sort);

        //게시판 페이징 조회
        Page<TbBoard> allList = tbBoardRepository.findByDelYn("N", pageable);

        // 총 게시물 수
        long totalElements = allList.getTotalElements();
        //총 페이지 수
        int totalPages = allList.getTotalPages();

        ClientBoardVo.BoardListRes resVo = ClientBoardVo.BoardListRes.builder()
                .totalPages(totalPages)
                .totalElements(totalElements)
                .build();

        if (allList.getTotalElements() == 0) {
            return resVo;
        }

        List<ClientBoardVo.BoardInfo> boardInfoList = new ArrayList<>();
        var boardDtoList = TbBoardMapper.INSTANCE.toDtoList(allList.getContent());

        // 현재 페이지 번호
        int currentPage = req.getPageNum() - 1;
        // 페이지 크기
        int pageSize = req.getPageSize();

        for (int i = 0; i < boardDtoList.size(); i++) {
            TbBoardDto dto = boardDtoList.get(i);
            String writerNm = "";
            if (StringUtils.hasText(dto.getChgMembNo())) {
                var membInfo = commonSvc.getTbCustMasterDto(dto.getChgMembNo());
                writerNm = membInfo.getMembNm();
            }

            var info = modelMapper.mapping(dto, ClientBoardVo.BoardInfo.class);
            info.setWriterNm(writerNm);

            // 번호 설정: 총 개수 - (현재 페이지 * 페이지 크기) - 인덱스
            long num = totalElements - ((long) currentPage * pageSize) - i;
            info.setNum(num);  // 번호 설정

            if (StringUtils.hasText(dto.getBoardFilSeq())) {
                var fileDtos = commonSvc.getTbFileDtoList(dto.getBoardFilSeq());
                List<ClientBoardVo.fileInfo> imageInfos = fileDtos.stream().map(file -> customeModelMapper.mapping(file , ClientBoardVo.fileInfo.class))
                        .toList();
                info.setFileInfoList(imageInfos);
            }

            boardInfoList.add(info);
        }

        resVo.setBoardList(boardInfoList);
        return resVo;

    }




}
