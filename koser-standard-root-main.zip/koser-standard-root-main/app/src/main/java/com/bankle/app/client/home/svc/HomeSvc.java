package com.bankle.app.client.home.svc;

import com.bankle.app.client.home.vo.HomeVo;
import com.bankle.common.entity.TbBoard;
import com.bankle.common.entity.TbRgstrMaster;
import com.bankle.common.mapper.TbCommCodeMapper;
import com.bankle.common.mapper.TbCustMasterMapper;
import com.bankle.common.repo.TbBoardRepository;
import com.bankle.common.repo.TbCommCodeRepository;
import com.bankle.common.repo.TbCustMasterRepository;
import com.bankle.common.repo.TbRgstrMasterRepository;
import com.bankle.common.userAuth.UserAuthSvc;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.DateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 금융기관 - 홈
 *
 * @author 정가은
 * @version 1.0
 * @since 2025.03.13
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class HomeSvc {
    private final TbRgstrMasterRepository tbRgstrMasterRepository;
    private final TbCustMasterRepository tbCustMasterRepository;
    private final TbCommCodeRepository tbCommCodeRepository;
    private final TbBoardRepository tbBoardRepository;

    private final CustomeModelMapper modelMapper;

    /**
     * 금융기관 - 홈) 등기현황 건수 조회
     *
     * @return HomeStatisticsRes : 실행건수, 진행중, 접수완료 건수
     * @throws Exception
     */
    public HomeVo.HomeStatisticsRes getLiveStatistics() throws Exception {

        HomeVo.HomeStatisticsRes result = new HomeVo.HomeStatisticsRes();

        LocalDate today = LocalDate.now();
        String formatToday = today.format(DateTimeFormatter.ofPattern("yyyyMMdd")); // 오늘일자

        // 오늘 실행 건수 -> 진행취소, 진행보류 제외 대출 실행 당일인 건수 (대출실행 ~ 접수완료) , CODE : 30, 40, 50, 60
        long tbRgstrSum = tbRgstrMasterRepository.countByExecDtAndBndBizNoAndStatCdIn(formatToday, UserAuthSvc.getBizNo(), Arrays.asList("30", "40", "50", "60"));
        String cntTodayExecDt = tbRgstrSum > 0 ? String.valueOf(tbRgstrSum) : "0";
        result.setCntExec(cntTodayExecDt);

        // 진행중 -> 대출실행 후 접수완료 상태가 안된 건수 (대출실행, 접수검토중, 접수반려), CODE : 30, 40, 50
        long tbRgstrProg = tbRgstrMasterRepository.countByExecDtAndBndBizNoAndStatCdIn(formatToday, UserAuthSvc.getBizNo(), Arrays.asList("30", "40", "50"));
        String cntTodayProg = tbRgstrProg > 0 ? String.valueOf(tbRgstrProg) : "0";
        result.setCntProg(cntTodayProg);

        // 접수완료 -> 대출실행 후 접수완료 상태인 건수 (접수완료), CODE : 60
        long tbRgstrComplete = tbRgstrMasterRepository.countByExecDtAndBndBizNoAndStatCd(formatToday, UserAuthSvc.getBizNo(), "60");
        String cntTodayComplete = tbRgstrComplete > 0 ? String.valueOf(tbRgstrComplete) : "0";
        result.setCntComplete(cntTodayComplete);

        return result;

    }

    /**
     * 금융기관 - 홈) 실시간 등기 현황
     *
     * @return HomeStatisticsRes : 실시간 등기현황 리스트
     * @throws Exception
     */
    public HomeVo.HomeRgstrRes getLiveRgstrStatus() throws Exception {

        HomeVo.HomeRgstrRes result = new HomeVo.HomeRgstrRes();

        LocalDate today = LocalDate.now();
        String formatToday = today.format(DateTimeFormatter.ofPattern("yyyyMMdd")); // 오늘일자

        List<TbRgstrMaster> tbLiveRgstr = tbRgstrMasterRepository.findTop6ByExecDtAndBndBizNoOrderByStatCdAsc(formatToday, UserAuthSvc.getBizNo());
        List<HomeVo.HomeRegistrationListRes> rgstrMasterList = new ArrayList<>();

        for (TbRgstrMaster rgstr : tbLiveRgstr) {

            HomeVo.HomeRegistrationListRes rgstrMasterVo = modelMapper.mapping(rgstr, HomeVo.HomeRegistrationListRes.class);

            // 승인된 법무대리인 이름 출력
            var custMaster = tbCustMasterRepository.findByMembNoAndMembGbCdAndStatCd(rgstr.getLgagMembNo(), "10", "10");
            if (custMaster.isPresent()) {
                var custDto = TbCustMasterMapper.INSTANCE.toDto(custMaster.get());
                rgstrMasterVo.setLgagMembNm(custDto.getMembNm());
            }

            // 진행상태코드 공통코드에서 이름 조회
            var commCode = tbCommCodeRepository.findById_CodeAndId_GrpCd(rgstr.getStatCd(), "PROC_STAT_CD");
            if (commCode.isPresent()) {
                var commDto = TbCommCodeMapper.INSTANCE.toDto(commCode.get());
                rgstrMasterVo.setStatCdNm(commDto.getCodeNm().replaceAll("\\(.*?\\)", ""));
            }
            rgstrMasterList.add(rgstrMasterVo);
        }
        result.setRgstrMasterList(rgstrMasterList);

        return result;

    }

    /**
     * 금융기관 - 홈) 공지사항 조회
     *
     * @return HomeBoardRes : 공지사항 리스트
     * @throws Exception
     */
    public HomeVo.HomeBoardRes getHomeBoard() throws Exception {
        {
            // 긴급여부(EMCY_YN) 최상단. 삭제여부(DEL_YN) N
            Sort sort = Sort.by(Sort.Order.desc("emcyYn"), Sort.Order.desc("crtDtm"));
            List<TbBoard> tbBoards = tbBoardRepository.findTop6ByDelYn("N", sort);

            List<HomeVo.HomeBoardListRes> homeBoardListRes = tbBoards.stream()
                    .map(tbBoard -> HomeVo.HomeBoardListRes.builder()
                            .boardTitles(tbBoard.getBoardTitle())
                            .crtDtm(DateUtil.formatOfPattern(tbBoard.getCrtDtm(), "yyyy-MM-dd"))
                            .emcyYn(tbBoard.getEmcyYn())
                            .build())
                    .collect(Collectors.toList());

            return new HomeVo.HomeBoardRes(homeBoardListRes);
        }
    }
}
