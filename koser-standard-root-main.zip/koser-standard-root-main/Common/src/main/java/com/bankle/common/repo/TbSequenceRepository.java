package com.bankle.common.repo;


import com.bankle.common.entity.TbSequence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

/**
 *  Sequence 조회 레파지토리
 * @Package     : com.withuslaw.common.repo
 * @name        : TbWoSequenceRepository.java
 * @date        : 2023/09/25 5:53 PM
 * @author      : tigerBK
 * @version     : 1.0.0
**/
public interface TbSequenceRepository extends JpaRepository<TbSequence, java.sql.Date > {

    /**
     *
     * @name        : TbWoSequenceRepository.getSeq
     * @author      : tigerBK
     * @param       : SeqName 별
     * @return      : 20230921 + 000001 (6자리) ->  20230925000006 14자리
    **/
    @Procedure(value = "GetSequence")
    String getSeq(@Param("sequence_name") String seqName , @Param("sequence_length") int seqLength );


}
