package com.bankle.common.repo;

import com.bankle.common.entity.TbAdminRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TbAdminRequestRepository extends JpaRepository<TbAdminRequest, String> {
}