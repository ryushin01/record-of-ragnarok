package com.bankle.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CommonConfig {

    /**
     * Common 및 모든 프로젝트 Configuration 파일 사용방법입니다.
     * <p>
     * 해당 클래스의 기능은 application-{server}.yml 파일 내의 설정된 내용의 value를 가져오는 기능을 하고 있습니다.
     * 해당하는 값을 불러와서 사용하는 방법은 아래와 동일하다.
     * static으로 사용을 할 것 이기 때문에 경로를 언더스코어 & 대문자로 작성을 합니다.
     * 어노테이션 @Value로 선언하여 yml내에 지정한 경로로 작성을 해줍니다. 이떄는 ":"(콜론) 을 .으로 변경하여 붙여서 작성을 해줍니다.
     * 선언된 어노테이션 아래에 setter를 작성을 해줍니다.
     * 해당하는 property의 값을 쓸 곳에 가서 CommonConfig.SAMPLE 로 불러서 사용하시면 됩니다.
     * <p>
     * <ex>
     * <p>
     * application-common-dev.yml >>>>>>>>>>>> 파일 위치입니다.
     * <p>
     * private static String CUSTOM_PROPERTY_SAMPLE;
     *
     * @Value("${custom.property.sample}") public void setCUSTOM_PROPERTY_SAMPLE(String sample) {
     * CUSTOM_PROPERTY_SAMPLE = sample;
     * }
     * </ex>
     */

    public static boolean SAVE_TRANSFER_TO_DB = false;
    public static String PUSH_API_KEY;
    public static String SMS_SECRET_KEY;
    public static String CORP_NUM;
    public static String USER_ID;
    public static String LINK_ID;
    public static String SECRET_KEY;
    public static Boolean IS_TEST;
    public static Boolean IS_IP_RESTRICT_ON_OFF;
    public static String ENV;
    public static String BASE_URL_ADMIN;
    public static String BASE_URL_API;
    public static String BASE_URL_APP_WOORI;
    public static String BASE_URL_AUTH;
    public static String BASE_URL_BATCH;
    public static String BASE_URL_IMAGE;
    public static final String IMG_SCH_PATH = "/images/";
    public static String WEB_BASE_URL_APP_WOORI;
    // DirectSend(이메일)
    public static String DIRECTSEND_URL;
    public static String DIRECTSEND_ID;
    public static String DIRECTSEND_APIKEY;
    public static int    DIRECTSEND_RETURN_URL;
    public static int    DIRECTSEND_OPTION_RETURN_URL;

    //iros
    public static String IROS_APIKEY;
    public static String IROS_URL;
    public static String IROS_IP;
    public static String IROS_PAYNO;
    public static String IROS_PAYPW;

    public static String IROS_USERID1;
    public static String IROS_USERID2;
    public static String IROS_USERID3;
    public static String IROS_USERID4;

    public static String IROS_USERPW1;
    public static String IROS_USERPW2;
    public static String IROS_USERPW3;
    public static String IROS_USERPW4;

    public static final String AES256_KEY = "Rc4yOMej5z8ycllTGWrlmycos1o4Gcu9";


    @Value("${spring.config.activate.on-profile}")
    public void setENV(String env) { ENV = env; }

    @Value("${iros.apikey}")
    public void setIROS_APIKEY(String irosApikey) { IROS_APIKEY = irosApikey; }

    @Value("${iros.url}")
    public void setIROS_URL(String irosUrl) { IROS_URL = irosUrl; }

    @Value("${iros.ip}")
    public void seIROS_IP(String irosIp) { IROS_IP = irosIp; }

    @Value("${iros.payNo}")
    public void setIROS_PAYNO(String irosPayNo) { IROS_PAYNO = irosPayNo; }

    @Value("${iros.payPw}")
    public void setIROS_PAYPW(String irosPayPw) { IROS_PAYPW  = irosPayPw; }

    @Value("${iros.userId1}")
    public void setIROS_USERID1(String irosUserId1) { IROS_USERID1  = irosUserId1; }

    @Value("${iros.userId2}")
    public void setIROS_USERID2(String irosUserId2) { IROS_USERID2  = irosUserId2; }

    @Value("${iros.userId3}")
    public void setIROS_USERID3(String irosUserId3) { IROS_USERID3  = irosUserId3; }

    @Value("${iros.userId4}")
    public void setIROS_USERID4(String irosUserId4) { IROS_USERID4  = irosUserId4; }


    @Value("${iros.userPw1}")
    public void setIROS_USERPW1(String irosUserPw1) { IROS_USERPW1  = irosUserPw1; }

    @Value("${iros.userPw2}")
    public void setIROS_USERPW2(String irosUserPw2) { IROS_USERPW2  = irosUserPw2; }

    @Value("${iros.userPw3}")
    public void setIROS_USERPW3(String irosUserPw3) { IROS_USERPW3 = irosUserPw3; }

    @Value("${iros.userPw4}")
    public void setIROS_USERPW4(String irosUserPw4) { IROS_USERPW4  = irosUserPw4; }


}
