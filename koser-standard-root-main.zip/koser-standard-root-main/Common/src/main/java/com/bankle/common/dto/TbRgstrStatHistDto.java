package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbRgstrStatHist}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TbRgstrStatHistDto implements Serializable {
    LocalDateTime crtDtm;
    String crtMembNo;
    @Size(max = 13)
    String seq;
    @Size(max = 13)
    String rqstNo;
    @Size(max = 2)
    String statCd;

    String procRsnCnts;
}