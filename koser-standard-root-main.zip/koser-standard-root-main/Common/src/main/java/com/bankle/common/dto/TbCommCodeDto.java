package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbCommCode}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TbCommCodeDto implements Serializable {

    TbCommCodeIdDto id;

    @Size(max = 100)
    String codeNm;          // 코드명

    @Size(max = 100)
    String grpNm;           // 그룹명

    @Size(max = 500)
    String grpDesc;         // 그룹 상세내용

    Integer num;            // 순번

    @Size(max = 1000)
    String etc1;            // 비고1

    @Size(max = 1000)
    String etc2;            // 비고2

    @Size(max = 1000)
    String etc3;            // 비고3

    @Size(max = 1)
    String useYn;           // 사용 여부

    LocalDateTime crtDtm;   // 생성일시
    String crtMembNo;       // 생성회원번호
    LocalDateTime chgDtm;   // 수정일시
    String chgMembNo;       // 수정회원번호
}