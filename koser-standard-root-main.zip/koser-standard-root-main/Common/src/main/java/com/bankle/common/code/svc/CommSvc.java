package com.bankle.common.code.svc;

import com.bankle.common.code.dao.CommDao;
import com.bankle.common.code.vo.CommVo;
import com.bankle.common.dto.TbCommCodeDto;
import com.bankle.common.dto.TbCommCodeIdDto;
import com.bankle.common.entity.TbCommCode;
import com.bankle.common.mapper.TbCommCodeMapper;
import com.bankle.common.repo.TbCommCodeRepository;
import com.bankle.common.utils.CustomeModelMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CommSvc {
    private final CommDao commDao;
    private final TbCommCodeRepository tbCommCodeRepository;

    private final CustomeModelMapper cModelMapper;

    /**
     * 공통코드 조회
     *
     * @param : multiGrpCd
     */
    public Map<String, Map<String, String>> searchCommCodeMultiList(List<String> multiGrpCd) throws Exception{

        var modelList = commDao.searchCommCodeMultiList(multiGrpCd);
        if (modelList == null) {
            return new HashMap<>();
        }

        return modelList.stream()
                .map(TbCommCodeMapper.INSTANCE::toDto)
                .map(e -> cModelMapper.mapping(e, CommVo.CommResVo.class))
                .sorted(Comparator.comparing(CommVo.CommResVo::getGrpCd)
                        .thenComparing(CommVo.CommResVo::getNum))
                .collect(Collectors.groupingBy(CommVo.CommResVo::getGrpCd,
                        Collectors.toMap(CommVo.CommResVo::getCode, CommVo.CommResVo::getCodeNm)));

    }



    /**
     * 인터넷 등기소 제공 데이터로 등기소 정보 등록 서비스
     * @param : CommVo.SaveInternetRegoReq
     */
    public void saveInternetRego(CommVo.SaveInternetRegoReq req) throws Exception {
        try {

          // "["부터 "] "까지 제거
          // 등기소 주소
          String addr = req.getRegt_addr().replaceAll("\\[.*?\\] ", "");

          Optional<TbCommCode> commCode = tbCommCodeRepository.findById_CodeAndId_GrpCd(req.getRegt_no(),"REGR_CD");

           TbCommCodeDto dto = new TbCommCodeDto();
           if (commCode.isPresent()) {
               dto = TbCommCodeMapper.INSTANCE.toDto(commCode.get());
               dto.setCodeNm(req.getRegt_name());
               dto.setEtc1(addr);
               dto.setNum(req.getRnum());
           } else {
               dto = TbCommCodeDto.builder()
                       .id(TbCommCodeIdDto.builder().grpCd("REGR_CD").code(req.getRegt_no()).build())
                       .codeNm(req.getRegt_name())
                       .etc1(addr)
                       .grpNm("인터넷 등기소 구분 코드")
                       .grpDesc("인터넷 등기소 구분 코드")
                       .num(req.getRnum())
                       .useYn("Y")
                       .build();
            }

            tbCommCodeRepository.save(TbCommCodeMapper.INSTANCE.toEntity(dto));

        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(e.getMessage());
        }
    }


}
