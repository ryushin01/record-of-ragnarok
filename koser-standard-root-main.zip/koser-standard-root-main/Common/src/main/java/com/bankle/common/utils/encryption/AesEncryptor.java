package com.bankle.common.utils.encryption;

import com.bankle.common.config.CommonConfig;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;


/**
 * AesEncryptor
 * 실제 AES-256 암호화/복호화 로직을 수행하는 유틸리티 클래스.
 * @author bcla007
 * $version 1.0.0
 * @date 25. 4. 10.
 *
 **/
@Slf4j
public class AesEncryptor {

    // 암호화/복호화에 사용되는 키
    private static final String KEY = CommonConfig.AES256_KEY; // 32-byte key (256-bit)

    // 평문 문자열을 AES-256 CBC 모드로 암호화하고, Base64로 인코딩하여 반환.
    public static String encrypt(String plainText) {
        try {
            log.debug("plainText {}", plainText);
            IvParameterSpec ivSpec = new IvParameterSpec(CommonConfig.AES256_KEY.substring(0, 16).getBytes());
            SecretKeySpec keySpec = new SecretKeySpec(KEY.getBytes("UTF-8"), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding"); // AES-256 CBC 모드
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);

            byte[] encrypted = cipher.doFinal(plainText.getBytes("UTF-8"));
            log.debug("Base64.getEncoder().encodeToString(encrypted) = {}",
                    Base64.getEncoder().encodeToString(encrypted));
            return Base64.getEncoder().encodeToString(encrypted); // DB 저장 시 Base64 인코딩
        } catch (Exception e) {
            e.printStackTrace(); // 실제 운영에서는 로그로 대체
        }
        return null;
    }

    //Base64로 인코딩된 암호문을 디코딩하고 AES로 복호화하여 원문 반환.
    public static String decrypt(String encryptedText) {
        try {
            IvParameterSpec ivSpec = new IvParameterSpec(CommonConfig.AES256_KEY.substring(0, 16).getBytes());
            SecretKeySpec keySpec = new SecretKeySpec(KEY.getBytes(), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);

            byte[] decodedBytes = Base64.getDecoder().decode(encryptedText);
            byte[] decrypted = cipher.doFinal(decodedBytes);

            return new String(decrypted, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}