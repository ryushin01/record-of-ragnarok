package com.bankle.common.entity;

import com.bankle.common.entity.base.BaseTimeEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_ADMIN_REQUEST")
public class TbAdminRequest extends BaseTimeEntity {
    @Id
    @Size(max = 13)
    @Column(name = "SEQ", nullable = false, length = 13)
    private String seq;

    @Column(name = "REQ_DT")
    private LocalDateTime reqDt;

    @Size(max = 13)
    @Column(name = "RQST_NO", length = 13)
    private String rqstNo;

    @Size(max = 2)
    @Column(name = "REQ_GB_CD", length = 2)
    private String reqGbCd;

    @Size(max = 2)
    @Column(name = "PROC_GB_CD", length = 2)
    private String procGbCd;

    @Size(max = 1)
    @Column(name = "DEL_YN", length = 1)
    private String delYn;

    @Size(max = 3)
    @Column(name = "RTUN_CD", length = 3)
    private String rtunCd;

    @Lob
    @Column(name = "RTUN_MSG")
    private String rtunMsg;

}