package com.bankle.common.mapper;

import com.bankle.common.dto.TbBatchHistDto;
import com.bankle.common.entity.TbBatchHist;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbBatchHistMapper extends DefaultMapper<TbBatchHistDto, TbBatchHist> {
    TbBatchHistMapper INSTANCE = Mappers.getMapper(TbBatchHistMapper.class);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    TbBatchHist partialUpdate(TbBatchHistDto tbBatchHistDto, @MappingTarget TbBatchHist tbBatchHist);
}