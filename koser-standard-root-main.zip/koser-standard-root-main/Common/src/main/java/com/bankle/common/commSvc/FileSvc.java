package com.bankle.common.commSvc;

import com.bankle.common.commSvc.vo.ImageVo;
import com.bankle.common.config.CommonConfig;
import com.bankle.common.config.ImgConfig;
import com.bankle.common.dto.*;
import com.bankle.common.entity.TbFile;
import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.BadRequestException;
import com.bankle.common.mapper.TbFileMapper;
import com.bankle.common.repo.TbFileRepository;
import com.bankle.common.repo.TbOfficeMasterRepository;
import com.bankle.common.repo.TbRgstrMasterRepository;
import com.bankle.common.userAuth.UserAuthSvc;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.StringUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class FileSvc {

    private final BizUtil bizUtil;
    private final CommonSvc commonSvc;
    private final CustomeModelMapper modelMapper;
    private final TbFileRepository tbFileRepository;
    private final TbRgstrMasterRepository tbRgstrMasterRepository;
    private final TbOfficeMasterRepository tbOfficeMasterRepository;

    static String pathSplit = String.valueOf("local".equals(CommonConfig.ENV) ? '\\' : '/');

    /**
     * 등기자료 수정
     * @param multipartFiles 신규 업로드 파일
     * @param attcFilCd 첨부파일 종류
     * @param filSeq 기 등록한 파일 순번
     * @param imageInfos 기 등록한 파일 정보
     * @return
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    public String updImages(List<MultipartFile> multipartFiles, String attcFilCd, String filSeq, List<ImageVo.ImageInfo> imageInfos) throws Exception {

        // =================================================================
        // 신규 업로드 파일 및 기등록한 파일 정보 유무 체크
        // =================================================================
        if( (multipartFiles == null || multipartFiles.isEmpty()) && (imageInfos == null || imageInfos.isEmpty())) {
            if (!"04".equals(attcFilCd)) {
                throw new BadRequestException("파일을 업로드해 주세요.");
            }
        }

        // =================================================================
        // 파일정보가 없을 경우 삭제 (DelYn 수정)
        // =================================================================
        List<TbFileDto> tbFileDtos = commonSvc.getTbFileDtoList(filSeq).stream()
                .filter(dto -> imageInfos == null || imageInfos.isEmpty() ||    // imageInfos가 null이거나 빈 리스트면 모든 파일을 삭제 처리
                        imageInfos.stream().noneMatch(updFile ->                // imageInfos가 존재할 경우 체크
                                updFile.getSeq().equals(dto.getId().getSeq()) &&
                                        updFile.getFilIdx() == dto.getId().getFilIdx()))
                .peek(el -> el.setDelYn("Y"))
                .toList();

        if (!tbFileDtos.isEmpty()) {
            tbFileRepository.saveAll(TbFileMapper.INSTANCE.toEntityList(tbFileDtos));
        }

        // =================================================================
        // 신규 업로드한 multipartFiles이 있으면 파일 업로드 처리, 없으면 리턴
        // =================================================================
        return multipartFiles == null || multipartFiles.isEmpty() ? filSeq : crtImages(multipartFiles, attcFilCd, filSeq);
    }


    /**
     * 이미지 업로드 서비스
     *
     * <p>이미지 저장 프로세스 :
     * 1. 기존 파일 존재시 삭제 (수정)
     * 2. 파일 업로드
     *
     * @param multipartFiles 이미지 파일,
     * @param attcFilCd 첨부파일 코드(업무요청구분코드)
     * @param filSeq 파일 시퀀스(신규 등록일 경우 null)
     * @return 이미지 시퀀스 번호
     * @author sws
     */
    @Transactional(rollbackFor = Exception.class)
    public String crtImages(List<MultipartFile> multipartFiles, String attcFilCd, String filSeq) throws Exception {

        log.debug("multipartFiles >>>>>>>>>> {}", multipartFiles);

        // 허용할 확장자 목록
        final List<String> ALLOWED_EXTENSIONS = Arrays.asList("jpg", "jpeg", "png");
        final List<String> ALLOWED_EXTENSIONS_BOARD = Arrays.asList("pdf", "hwp", "hwpx", "docx", "xls", "xlsx");

        // 최대 업로드 가능 개수, 크기 설정
        final int MAX_FILES = 20;
        final int MAX_FILES_BOARD_AND_BIZDOC = 5;
        final long MAX_TOTAL_SIZE_MB = 20; // 20MB
        final long MAX_TOTAL_SIZE_BYTES = MAX_TOTAL_SIZE_MB * 1024 * 1024;

        // 파일 개수 및 확장자 제한 체크
        List<String> allowedExtensions = "04".equals(attcFilCd) ? ALLOWED_EXTENSIONS_BOARD : ALLOWED_EXTENSIONS;
        int maxFileCount = "03,04".contains(attcFilCd) ? MAX_FILES_BOARD_AND_BIZDOC : MAX_FILES;


        if (multipartFiles.size() > maxFileCount) {
            throw new BadRequestException("최대 " + maxFileCount + "개까지 업로드할 수 있습니다.");
        }

        // 전체 파일 크기 계산
        long totalSize = multipartFiles.stream().mapToLong(MultipartFile::getSize).sum();
        log.debug("totalSize -> {}", totalSize);
        log.debug("totalSize_MB -> {}", (double) totalSize / (1024 * 1024));
        if (totalSize > MAX_TOTAL_SIZE_BYTES) {
            throw new BadRequestException("업로드 가능한 전체 용량은 최대 "+ MAX_TOTAL_SIZE_MB +"MB 입니다.");
        }

        // =================================================================
        // 파일 업로드
        // =================================================================
        log.debug("CommonConfig.ENV ----->{}", CommonConfig.ENV);

        // 파일순번
        int fileIdx = 1;

        if (filSeq == null) { // 신규 등록
            filSeq = bizUtil.getSeq(Sequence.IMAGE);
        } else { // 이미지 추가
            // 기존 파일이 존재하는 경우, 마지막 인덱스 가져오기
            List<TbFile> tbFiles = tbFileRepository.findById_Seq(filSeq);
            if (!tbFiles.isEmpty()) {
                fileIdx = tbFiles.get(tbFiles.size() - 1).getId().getFilIdx() + 1;
            }
        }

        pathSplit = String.valueOf('/');

        // 첨부파일테이블 저장 데이터
        ImageVo.ImageDataReq crtDataReq = new ImageVo.ImageDataReq();

        // 반환을 할 파일 리스트
        List<TbFile> fileList = new ArrayList<>();

        // 이미지별 경로설정
        String dir = getloadDir(attcFilCd);

        // 파일 이름을 업로드 한 날짜로 바꾸어서 저장할 것이다
        String currentDate = new SimpleDateFormat("yyyyMMdd").format(new Date());

        // 프로젝트 폴더에 저장하기 위해 절대경로를 설정 (Window 의 Tomcat 은 Temp 파일을 이용한다)
        String path = new File(dir).getAbsolutePath() + pathSplit + currentDate;

        //테스트를 위한 하드코딩
//        path = "/Users/song" + path;

        log.debug("path : {}", path);
        File file = new File(path);
        if (!file.exists()) {
            file.mkdirs();
        }


        for (MultipartFile multipartFile : multipartFiles) {
            if (!multipartFile.isEmpty()) {
                String contentType = multipartFile.getContentType();
                String fileName = multipartFile.getOriginalFilename();

                log.debug(" contentType -->{}", contentType);
                log.debug(" fileName -->{}", fileName);

                if (!StringUtils.hasText(contentType) || (fileName == null || fileName.isBlank())) {
                    continue;
                }

                // 확장자 체크
                String extension = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
                if (!allowedExtensions.contains(extension)) {
                    throw new BadRequestException("허용되지 않은 파일 형식입니다: " + extension);
                }

                String newFileNm = Long.toString(System.nanoTime()) + '.' + extension;

                TbFileIdDto tbFileIdDto = new TbFileIdDto();
                tbFileIdDto.setSeq(filSeq);
                tbFileIdDto.setFilIdx(fileIdx);
                crtDataReq.setId(tbFileIdDto);

                crtDataReq.setAttcFilCd(attcFilCd);
                crtDataReq.setAttcFilNm(multipartFile.getOriginalFilename());
                crtDataReq.setChgAttcFilNm(newFileNm);
                crtDataReq.setFilSize(multipartFile.getSize());
                crtDataReq.setDelYn("N");

                file = new File(path + pathSplit + newFileNm);
                log.debug("path : {}", path + pathSplit + newFileNm);
                // 디버깅을 위해 생성되는 경로 및 파일 이름 출력
                log.debug("Actual Path: {}", file.getAbsolutePath());

                // 파일을 해당 경로로 복사 또는 이동
                multipartFile.transferTo(file);


                // 이미지 파일인 경우에만 리사이징
//                if (ALLOWED_EXTENSIONS.contains(extension)) {
//                    // 이미지 리사이징 후 원본 파일에 덮어쓰기
//                    crtResize(file, file, 1024);
//                }

                // 파일 경로 설정
                // [01 : 등기자료, 02 : 등기접수증, 03 : 사업자등록증, 04 : 공지사항 첨부파일, 05 : 회원등록 신청서, 06 : 프로필 이미지]
                if ("04,05".contains(attcFilCd)) {
                    // 암호화 없이 원본 파일 경로 설정
                    crtDataReq.setAttcFilLocNm(file.getAbsolutePath());
                } else {
                    // 업무 관련 파일 암호화
                    String encPath = crtEncode(path + pathSplit + newFileNm);
                    crtDataReq.setAttcFilLocNm(encPath);

                    // 원본 파일 삭제
                    if (file.exists()) {
                        file.delete();
                    }
                }

                var tbFileDto = modelMapper.mapping(crtDataReq, TbFileDto.class);
                var tbFile = TbFileMapper.INSTANCE.toEntity(tbFileDto);
                log.debug("tbWoCntrFile = {}", tbFile.toString());

                fileList.add(tbFile);

                // 파일 권한 설정(쓰기, 읽기)
                file.setWritable(true);
                file.setReadable(true);

                fileIdx++;

            }
        }

        log.debug("fileList.isEmpty() {} ", fileList.isEmpty());
        //첨부파일테이블 저장
        if (!fileList.isEmpty()) {
            log.debug("fileList {}", fileList);
            tbFileRepository.saveAll(fileList);
        }

        return filSeq;
    }

    /**
     * 이미지 조회
     *
     * @param imageReq 의뢰번호, 파일구분코드
     * @return 이미지 정보
     */
    @Transactional
    public ImageVo.ImageRes getImages(@Valid ImageVo.ImageInfoReq imageReq) throws Exception {

        String seq = imageReq.getSeq();
        String attcFilCd = imageReq.getAttcFilCd();

        ImageVo.ImageRes imageRes = new ImageVo.ImageRes();
        List<ImageVo.ImageInfo> imageInfoRes = new ArrayList<>();
        List<TbFileDto> fileDtos;

        // [01 : 등기자료, 02 : 등기접수증, 03 : 사업자등록증, 04 : 공지사항 첨부파일, 05 : 회원등록 신청서, 06 : 프로필 이미지]
        switch (attcFilCd) {
            case "01" -> { // seq : 의뢰번호
                // 의뢰번호로 원장 조회 후 파일 일련번호로 첨부파일 조회
                TbRgstrMasterDto rgstrDto = commonSvc.getRgstrMastrDto(seq);
                fileDtos = commonSvc.getTbFileDtoList(rgstrDto.getRgstrDataFilSeq());
                imageRes.setExecDt(rgstrDto.getExecDt());
            }
            case "02" -> { // seq : 의뢰번호
                // 의뢰번호로 원장 조회 후 파일 일련번호로 첨부파일 조회 (등기접수증 파일 일련번호 없을 경우 null 처리)
                TbRgstrMasterDto rgstrDto = commonSvc.getRgstrMastrDto(seq);
                fileDtos = StringUtils.hasText(rgstrDto.getRgstrAcptFilSeq())
                            ? commonSvc.getTbFileDtoList(rgstrDto.getRgstrAcptFilSeq())
                            : null;
                imageRes.setExecDt(rgstrDto.getExecDt());
            }
            case "03" -> { // seq : 사업자번호
                TbOfficeMasterDto tbOfficeMasterDto = commonSvc.getTbOfficeDto(seq);
                fileDtos = commonSvc.getTbFileDtoList(tbOfficeMasterDto.getBizFilSeq());
            }
            case "04" -> { // seq : 공지사항 시퀀스
                TbBoardDto tbBoardDto = commonSvc.getTbBoardDto(seq);
                fileDtos = commonSvc.getTbFileDtoList(tbBoardDto.getBoardFilSeq());
            }
            case "05" -> {
                // TODO: 회원등록 신청서 seq 고정
                fileDtos = commonSvc.getTbFileDtoList("999999999999");
            }
            case "06" -> { // seq : 사업자번호
                TbOfficeMasterDto tbOfficeMasterDto = commonSvc.getTbOfficeDto(seq);
                fileDtos = commonSvc.getTbFileDtoList(tbOfficeMasterDto.getProFilSeq());
            }
            default -> throw new BadRequestException("존재하지 않는 업무 구분 입니다.");
        }

        if (fileDtos != null && !fileDtos.isEmpty()) {
            for (TbFileDto tbFileDto : fileDtos) {
                ImageVo.ImageInfo imageInfo = new ImageVo.ImageInfo();
                imageInfo.setSeq(tbFileDto.getId().getSeq());
                imageInfo.setFilIdx(tbFileDto.getId().getFilIdx());
                imageInfo.setSrc(ImgConfig.IMAGE_URL_PREFIX + tbFileDto.getId().getSeq() + "/" + tbFileDto.getId().getFilIdx());
                imageInfo.setAttcFilNm(tbFileDto.getAttcFilNm());
                imageInfo.setFilSize(tbFileDto.getFilSize());
                imageInfoRes.add(imageInfo);
                imageRes.setImgData(imageInfoRes);
            }
        }

        imageRes.setRqstNo(seq);

        return imageRes;
    }

    /**
     * 이미지 파일 단건 조회 - 복호화
     *
     * @param seq 파일 시퀀스
     * @param filIdx 파일 인덱스
     * @return 이미지
     */
    public ResponseEntity<?> getDecryptedImage(String seq, String filIdx) throws Exception {

        log.debug("Decrypted Image Start");
        log.debug("=============================================================================");

        String bizNo = UserAuthSvc.getBizNo();

        List<TbFile> fileList = tbFileRepository.findById_Seq(seq);
        TbFileDto fileDto = fileList.stream()
                .findFirst()
                .map(TbFileMapper.INSTANCE::toDto)
                .orElseThrow(() -> new BadRequestException("파일이 존재하지 않습니다"));

        String attcFilCd = fileDto.getAttcFilCd();

        // bizNo가 null이면 관리자 - 검증 생략
        if (bizNo != null) {
            validateFileAccess(attcFilCd, seq, bizNo);
        }

        chkNumberic(seq, filIdx);

        byte[] keyData = ImgConfig.TIFF_SECRET_KEY.getBytes();
        SecretKey secretKey = new SecretKeySpec(keyData, "AES");
        FileEncrypterDecrypter fileEncrypterDecrypter = new FileEncrypterDecrypter(secretKey);

        // 파일 정보 조회
        TbFileDto tbFileDto = commonSvc.getTbFileDto(seq, filIdx);
        String attcFilLocNm = tbFileDto.getAttcFilLocNm();
        String attcFilNm = tbFileDto.getAttcFilNm();

        if (attcFilLocNm == null || attcFilLocNm.isBlank()) {
            throw new BadRequestException("파일 경로가 유효하지 않습니다.");
        }

        // 파일 확장자 체크
        int lastDotIndex = attcFilLocNm.lastIndexOf(".");
        if (lastDotIndex == -1) {
            throw new BadRequestException("파일 확장자가 없습니다.");
        }

        String ext = attcFilLocNm.substring(lastDotIndex + 1);
        log.debug("ext :{}", ext);

        byte[] fileByteArray;

        //확장자가 "enc" 이면 암호화된 파일이다.
        if ("enc".equals(ext)) {
            //복호화
            fileByteArray = fileEncrypterDecrypter.decrypt(attcFilLocNm);
        } else {
            fileByteArray = Files.readAllBytes(Paths.get(attcFilLocNm));
        }

        // 파일 존재 여부 확인
        if (fileByteArray == null || fileByteArray.length == 0) {
            throw new BadRequestException("파일을 찾을 수 없습니다.");
        }

        // Content-Type 설정
        String mediaType;
        if (attcFilNm.endsWith(".jpg") || attcFilNm.endsWith(".jpeg")) {
            mediaType = "image/jpeg";
        } else if (attcFilNm.endsWith(".png")) {
            mediaType = "image/png";
        } else {
            throw new BadRequestException("지원하지 않는 파일 형식입니다.");
        }

        return ResponseEntity.ok()
                .contentType(MediaType.valueOf(mediaType))
                .body(new InputStreamResource(new ByteArrayInputStream(fileByteArray)));
    }

    /**
     * 파일 다운로드
     *
     * @param seq 파일 시퀀스
     * @param filIdx 파일 인덱스
     * @return 다운로드
     */
    public ResponseEntity<?> downloadFile(String seq, String filIdx) throws Exception {

        log.debug("Download File Start");
        log.debug("=============================================================================");

        chkNumberic(seq, filIdx);

        // 파일 정보 조회
        TbFileDto tbFileDto = commonSvc.getTbFileDto(seq, filIdx);
        String filePath = tbFileDto.getAttcFilLocNm();
        String fileName = tbFileDto.getAttcFilNm();

        // 파일 로드
        File file = new File(filePath);
        if (!file.exists()) {
            throw new BadRequestException("파일이 존재하지 않습니다.");
        }

        // 파일 데이터 읽기
        byte[] fileData = Files.readAllBytes(file.toPath());
        if (fileData.length == 0) {
            throw new BadRequestException("파일이 비어 있습니다.");
        }

        ByteArrayResource resource = new ByteArrayResource(fileData);

        // 파일 인코딩
        String encodedFileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8);

        // 파일 다운로드 응답 생성
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + encodedFileName + "\"")
                .body(resource);
    }
    
    /**
     * 파일경로 반환 서비스
     *
     * @param attcFilCd 첨부파일 코드(업무요청구분코드)
     * @return 파일경로
     */
    public String getloadDir(String attcFilCd) {

        // 파일경로
        String dir;

        switch (attcFilCd) {
            // 등기자료
            case "01" -> dir = ImgConfig.IMG_PATH_BIZ_01;
            // 등기접수증
            case "02" -> dir = ImgConfig.IMG_PATH_BIZ_02;
            // 사업자등록증
            case "03" -> dir = ImgConfig.IMG_PATH_CUST_03;
            // 공지사항 첨부파일
            case "04" -> dir = ImgConfig.IMG_PATH_BOARD_04;
            // 회원등록 신청서
            case "05" -> dir = ImgConfig.IMG_PATH_CUST_05;
            // 프로필 이미지
            case "06" -> dir = ImgConfig.IMG_PATH_PROFILE_06;
            //경로 오류 저장경로
            default -> dir = ImgConfig.IMG_PATH_99;
        }

        return dir;
    }

    /**
     * 이미지 리사이징
     *
     * @param srcFile 원본이미지파일
     * @param tgtFile ReSizing 한 이미지를 저장할 파일
     * @param tgtSize 변경사이즈
     * @return boolean
     */
    public File crtResize(File srcFile, File tgtFile, int tgtSize) throws Exception {

        log.debug("ReSizing Start");
        log.debug("=============================================================================");
        log.debug("=============================================================================");

        String srcFileName = srcFile.getName();
        String tgtFileName = tgtFile.getName();
        String ext = tgtFileName.substring(tgtFileName.lastIndexOf(".")).replace(".", "");

        int srcWidth = 0;
        int srcHeight = 0;
        int resizeWidth = 0;
        int resizeHeight = 0;

        log.debug("srcFileName [{}]   tgtFileName []   ext [{}]", srcFileName, ext);

        Image srcImage = ImageIO.read(srcFile);
        srcWidth = srcImage.getWidth(null);
        srcHeight = srcImage.getHeight(null);

        if (srcWidth > srcHeight) {
            resizeWidth = tgtSize;
            resizeHeight = (tgtSize * srcHeight) / srcWidth;
        } else {
            resizeHeight = tgtSize;
            resizeWidth = (tgtSize * srcWidth) / srcHeight;
        }

        log.debug("WIDTH  (source >> target >> resize) : {}   >>   {}   >>   {}", srcWidth, tgtSize, resizeWidth);
        log.debug("HEIGHT (source >> target >> resize) : {}   >>   {}   >>   {}", srcHeight, tgtSize, resizeHeight);

        Image resizeImage = srcImage.getScaledInstance(resizeWidth, resizeHeight, Image.SCALE_SMOOTH);
//        BufferedImage newImage = new BufferedImage(resizeWidth, resizeHeight, BufferedImage.TYPE_INT_RGB);
        int imageType = "png".equalsIgnoreCase(ext) ? BufferedImage.TYPE_INT_ARGB : BufferedImage.TYPE_INT_RGB; // TYPE_INT_ARGB : 알파 채널 포함 (투명도)
        BufferedImage newImage = new BufferedImage(resizeWidth, resizeHeight, imageType);

        Graphics g = newImage.getGraphics();
        g.drawImage(resizeImage, 0, 0, null);
        g.dispose();
        ImageIO.write(newImage, ext, tgtFile);

        log.debug("=============================================================================");
        log.debug("=============================================================================");

        return tgtFile;
    }

    /**
     * 파일 암호화
     *
     * @param attcFilLocNm 저장된 절대 경로
     * @return 암호화 파일경로
     */
    public String crtEncode(String attcFilLocNm) throws Exception {
        String attcEncFilLocNm = attcFilLocNm + ".enc";
        log.debug("암호파일 경로 : {}", attcEncFilLocNm);
        log.debug("=====암호화 시작=======");
        byte[] keyData = ImgConfig.TIFF_SECRET_KEY.getBytes();
        SecretKey secretKey = new SecretKeySpec(keyData, "AES");
        FileEncrypterDecrypter fileEncrypterDecrypter = new FileEncrypterDecrypter(secretKey);
        fileEncrypterDecrypter.encrypt(attcFilLocNm, attcEncFilLocNm);
        log.debug("=====암호화 끝=======");

//암호화 후 원본 파일 삭제 주석
//		if (file.delete()) {
//			log.debug(file.getAbsolutePath() + "파일 삭제 성공");
//		} else {
//			log.debug(file.getAbsolutePath() + "파일 삭제 실패");
//		}
        return attcEncFilLocNm;
    }

    /**
     * 문자형 숫자 체크
     *
     * @param seq 파일 시퀀스
     * @param filIdx 파일 인덱스
     */
    public void chkNumberic(String seq, String filIdx) {
        if (StringUtil.isNumberic(seq) || StringUtil.isNumberic(filIdx)) {
            throw new BadRequestException("seq와 filIdx는 숫자로만 이루어져야 합니다.");
        }
    }

    /**
     * 파일 조회 접근 권한
     *
     * @param attcFilCd 첨부 파일 구분 코드
     * @param seq 파일 시퀀스
     * @param bizNo 금융기관 사업자번호
     */
    public void validateFileAccess(String attcFilCd, String seq, String bizNo) {
        log.debug("validateFileAccess.attcFilCd -------> {}", attcFilCd);
        log.debug("validateFileAccess.seq -------> {}", seq);
        log.debug("validateFileAccess.bizNo -------> {}", bizNo);

        // [01 : 등기자료, 02 : 등기접수증, 03 : 사업자등록증, 04 : 공지사항 첨부파일, 05 : 회원등록 신청서, 06 : 프로필 이미지]
        switch (attcFilCd) {
            case "01" -> {
                if (!tbRgstrMasterRepository.existsByRgstrDataFilSeqAndBndBizNo(seq, bizNo)) {
                    throw new BadRequestException("등기자료 파일이 존재하지 않습니다.");
                }
            }
            case "02" -> {
                if (!tbRgstrMasterRepository.existsByRgstrAcptFilSeqAndBndBizNo(seq, bizNo)) {
                    throw new BadRequestException("등기접수증 파일이 존재하지 않습니다.");
                }
            }
            case "03" -> {
                if (!tbOfficeMasterRepository.existsByBizFilSeqAndBizNo(seq, bizNo)) {
                    throw new BadRequestException("사업자등록증 파일이 존재하지 않습니다.");
                }
            }
            case "06" -> {
                if (!tbOfficeMasterRepository.existsByProFilSeqAndBizNo(seq, bizNo)) {
                    throw new BadRequestException("프로필 파일이 존재하지 않습니다.");
                }
            }
            default -> throw new BadRequestException("존재하지 않는 업무 구분 입니다.");
        }
    }

}
