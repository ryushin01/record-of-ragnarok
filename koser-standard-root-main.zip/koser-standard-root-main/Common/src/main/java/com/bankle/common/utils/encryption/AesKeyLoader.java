package com.bankle.common.utils.encryption;

import javax.crypto.SecretKey;
import java.io.FileInputStream;
import java.security.KeyStore;

/**
 * AesKeyLoader
 * JCEKS 형식의 KeyStore에서 SecretKey를 로드하는 역할.
 * @author bcla007
 * $version 1.0.0
 * @date 25. 4. 10.
 *
 **/

public class AesKeyLoader {

    //주어진 경로와 인증 정보로 KeyStore를 로딩하고 SecretKey 반환
    public static SecretKey loadKey(String keystorePath, String alias, String storePass, String keyPass) throws Exception {
        KeyStore keyStore = KeyStore.getInstance("JCEKS");
        try (FileInputStream fis = new FileInputStream(keystorePath)) {
            keyStore.load(fis, storePass.toCharArray());
        }
        return (SecretKey) keyStore.getKey(alias, keyPass.toCharArray());
    }
}