package com.bankle.common.entity;

import com.bankle.common.entity.base.BaseTimeEntityByCrtDtmAndMembNo;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "TB_RGSTR_STAT_HIST")
public class TbRgstrStatHist extends BaseTimeEntityByCrtDtmAndMembNo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SEQ", nullable = false)
    private Long seq;

    @Size(max = 13)
    @Column(name = "RQST_NO", length = 13, nullable = false)
    private String rqstNo;

    @Size(max = 2)
    @Column(name = "STAT_CD", length = 2, nullable = false)
    private String statCd;

    @Lob
    @Column(name = "PROC_RSN_CNTS")
    private String procRsnCnts;

}