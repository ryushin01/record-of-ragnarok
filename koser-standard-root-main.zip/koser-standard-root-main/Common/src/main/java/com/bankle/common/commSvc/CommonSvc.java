package com.bankle.common.commSvc;

import com.bankle.common.commSvc.vo.CommCodeVo;
import com.bankle.common.dto.*;
import com.bankle.common.entity.TbCustMaster;
import com.bankle.common.entity.TbFile;
import com.bankle.common.exception.BadRequestException;
import com.bankle.common.mapper.*;
import com.bankle.common.repo.*;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.RgstrData;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 공통 서비스
 *
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CommonSvc {
    private final TbCommCodeRepository tbCommCodeRepository;
    private final TbRgstrMasterRepository tbRgstrMasterRepository;
    private final TbCustMasterRepository tbCustMasterRepository;
    private final TbOfficeMasterRepository tbOfficeMasterRepository;
    private final TbRgstrStatHistRepository tbRgstrStatHistRepository;
    private final TbFileRepository tbFileRepository;
    private final CustomeModelMapper modelMapper;
    private final TbBoardRepository tbBoardRepository;

    /**
     * 공통코드 단건 조회
     * @param grpCd 그룹코드
     * @param code 코드
     * @return 코드명
     * @throws Exception
     */
    public String getCommCodeNm(String grpCd, String code) throws Exception {

        TbCommCodeDto dto =  tbCommCodeRepository.findById_CodeAndId_GrpCd(code,grpCd)
                .map(TbCommCodeMapper.INSTANCE::toDto)
                .orElseGet(TbCommCodeDto::new);

        return dto.getCodeNm() == null ? "" : dto.getCodeNm();
    }

    /**
     * 공통코드 다건 조회
     * @param grpCd 그룹코드
     * @return 코드명 리스트
     */
    public CommCodeVo.CommCodeListRes getCommCodeList(String grpCd) throws Exception {

        List<CommCodeVo.CommCodeInfo> commCodeInfos = tbCommCodeRepository.findById_GrpCd(grpCd)
                .stream()
                .map(code -> modelMapper.mapping(code, CommCodeVo.CommCodeInfo.class))
                .toList();

        if (commCodeInfos.isEmpty()) {
            throw new BadRequestException("유효 하지 않은 코드값 입니다.");
        }

        return CommCodeVo.CommCodeListRes.builder()
                .commCodeList(commCodeInfos)
                .build();
    }

    /**
     * 등기 원장 테이블 정보 단건 조회
     *
     * @param rqstNo 등기의뢰 번호
     * @return 등기 원장 테이블 데이터
     * @throws BadRequestException 의뢰번호가 없을 경우
     * @throws EntityNotFoundException 일치하는 등기 원장 정보가 없을 경우
     */
    public TbRgstrMasterDto getRgstrMastrDto(String rqstNo) throws Exception {

        if(!StringUtils.hasText(rqstNo)) throw new BadRequestException("의뢰번호가 없습니다.");

        return tbRgstrMasterRepository.findByRqstNo(rqstNo)
                .map(TbRgstrMasterMapper.INSTANCE::toDto)
                .orElseThrow(() -> new EntityNotFoundException("등기 의뢰번호 "+rqstNo));

    }

    /**
     * 등기 원장 테이블 정보 단건 조회
     *
     * @param rqstNo 등기의뢰 번호
     * @param bizNo 사업자 번호
     * @return 등기 원장 테이블 데이터
     * @throws BadRequestException 의뢰번호가 없을 경우
     * @throws EntityNotFoundException 일치하는 등기 원장 정보가 없을 경우
     */
    public TbRgstrMasterDto getRgstrMastrDto(String rqstNo, String bizNo) throws Exception {

        if(!StringUtils.hasText(rqstNo)) throw new BadRequestException("의뢰번호가 없습니다.");

        if(!StringUtils.hasText(bizNo)) throw new BadRequestException("금융기관 사업자번호가 없습니다.");

        return tbRgstrMasterRepository.findByRqstNoAndBndBizNo(rqstNo, bizNo)
                .map(TbRgstrMasterMapper.INSTANCE::toDto)
                .orElseThrow(() -> new EntityNotFoundException("등기 의뢰번호 ["+rqstNo+"] 사업자번호["+bizNo+"]"));

    }


    /**
     * 회원 마스터 테이블 정보 단건 조회
     *
     * @param membNo 회원번호
     * @return 회원 마스터 테이블 데이터
     * @throws BadRequestException 회원번호가 없을 경우
     */
    public TbCustMasterDto getTbCustMasterDto(String membNo) throws Exception {
        if(!StringUtils.hasText(membNo)) throw new BadRequestException("회원번호가 없습니다.");

        return tbCustMasterRepository.findByMembNo(membNo)
                .map(TbCustMasterMapper.INSTANCE::toDto)
                .orElseGet(TbCustMasterDto::new);
    }


    /**
     * 사무소 테이블 정보 단건 조회
     *
     * @param bizNo 사업자 번호
     * @return 사무소 테이블 데이터
     * @throws BadRequestException 사업자 번호가 없을 경우
     */
    public TbOfficeMasterDto getTbOfficeDto(String bizNo) throws Exception {
        if(!StringUtils.hasText(bizNo)) throw new BadRequestException("사무소 번호가 없습니다.");

        return tbOfficeMasterRepository.findByBizNo(bizNo)
                .map(TbOfficeMasterMapper.INSTANCE::toDto)
                .orElseGet(TbOfficeMasterDto::new);
    }

    /**
     * 등기데이터 정보 조회 (금융기관에서 조회 시 해당 금융기관 데이터만 조회 가능)
     *
     * @param rqstNo 등기 의뢰번호
     * @param bizNo 사업자번호
     * @return 등기 원장 정보 + 법무대리인 정보 + 시스템관리자 정보 + 의뢰자 정보
     * @throws EntityNotFoundException 일치하는 등기 원장 정보가 없을 경우
     */
    public RgstrData getRgstrMasterInfo(String rqstNo, String bizNo) throws Exception {

        TbRgstrMasterDto rgstrDto = getRgstrMastrDto(rqstNo, bizNo);

        return getRgstrMasterInfo(rgstrDto);
    }

    /**
     * 등기데이터 정보 조회 (관리자에서 조회 시 전제 데이터 조회 가능 )
     *
     * @param rqstNo 등기 의뢰번호
     * @return 등기 원장 정보 + 법무대리인 정보 + 시스템관리자 정보 + 의뢰자 정보
     * @throws EntityNotFoundException 일치하는 등기 원장 정보가 없을 경우
     */
    public RgstrData getRgstrMasterInfo(String rqstNo) throws Exception {
        TbRgstrMasterDto rgstrDto = getRgstrMastrDto(rqstNo);

        return getRgstrMasterInfo(rgstrDto);
    }

    /**
     * 등기데이터 정보 조회 (프론트 조회를 위해 법무대리인/관리자/의뢰자 정보 모두 포함 )
     *
     * @param rgstrDto 등기 원장 정보
     * @return 등기 원장 정보 + 법무대리인 정보 + 시스템관리자 정보 + 의뢰자 정보
     * @throws EntityNotFoundException 일치하는 등기 원장 정보가 없을 경우
     */
    public RgstrData getRgstrMasterInfo(TbRgstrMasterDto rgstrDto) throws Exception {

        RgstrData result = modelMapper.mapping(rgstrDto, RgstrData.class);

        //법무대리인 이름 및 연락처 조회
        String lgagMembNo = rgstrDto.getLgagMembNo();
        if (StringUtils.hasText(lgagMembNo)) {
            TbCustMasterDto lgagDto = getTbCustMasterDto(lgagMembNo);
            result.setLgagMembNm(lgagDto.getMembNm());
            result.setLgagMembHpno(lgagDto.getMembHpno());
        }

        //시스템 관리자 이름 및 연락처 조회
        String mngrMembNo = rgstrDto.getMngrMembNo();
        if(StringUtils.hasText(mngrMembNo)) {
            TbCustMasterDto mngrDto = getTbCustMasterDto(mngrMembNo);
            result.setMngrMembNm(mngrDto.getMembNm());
            result.setMngrMembHpno(mngrDto.getMembHpno());
        }

        //금융기관(채권자) 이름 및 연락처 조회
        String bndBizNo = rgstrDto.getBndBizNo();
        if (StringUtils.hasText(bndBizNo)) {
            TbOfficeMasterDto officeDto = getTbOfficeDto(bndBizNo);
            result.setBndMembNm(officeDto.getBizNm());

            TbCustMasterDto bndDto = tbCustMasterRepository.findTop1ByBizNoOrderByCrtDtmDesc(bndBizNo)
                    .map(TbCustMasterMapper.INSTANCE::toDto)
                    .orElseGet(TbCustMasterDto::new);

            result.setBndMembHpno(bndDto.getMembHpno());
        }
        return result;
    }

    /**
     * 등기자료 진행상태 별 처리사유 조회
     *
     * @param rqstNo 의뢰번호
     * @param statCd 상태코드
     * @return 진행상태 처리 사유
     * @throws Exception 실행 중 오류
     */
    public String getProcRsnCnts(String rqstNo, String statCd) throws Exception {
        TbRgstrStatHistDto dto = tbRgstrStatHistRepository.findTop1ByRqstNoAndStatCdOrderBySeqDesc(rqstNo, statCd)
                .map(TbRgstrStatHistMapper.INSTANCE::toDto)
                .orElseGet(TbRgstrStatHistDto::new);

        return dto.getProcRsnCnts();
    }


    /**
     * 첨부파일 테이블 다건조회
     *
     * @param seq 파일시퀀스
     * @return 첨부파일 정보 리스트
     * @throws BadRequestException 첨부파일 일련번호가 없을 경우
     */
    public List<TbFileDto> getTbFileDtoList(String seq) throws Exception {
        if (!StringUtils.hasText(seq)) {
            throw new BadRequestException("첨부파일 일련번호가 존재하지 않습니다.");
        }
        List<TbFile> tbFiles = tbFileRepository.findById_SeqAndDelYn(seq , "N");
        return TbFileMapper.INSTANCE.toDtoList(tbFiles);
    }


    /**
     * 첨부파일 테이블 단건조회
     *
     * @param seq 파일시퀀스
     * @param filIdx 파일인덱스
     * @return 첨부파일 정보
     * @throws BadRequestException 첨부파일 일련번호가 없을 경우
     */
    public TbFileDto getTbFileDto(String seq, String filIdx) throws Exception {
        if (!StringUtils.hasText(seq)) {
            throw new BadRequestException("첨부파일 일련번호가 존재하지 않습니다.");
        }
        if (!StringUtils.hasText(filIdx)) {
            throw new BadRequestException("첨부파일 인덱스가 존재하지 않습니다.");
        }
        return tbFileRepository.findById_SeqAndId_FilIdxAndDelYn(seq, Integer.valueOf(filIdx), "N")
                .map(TbFileMapper.INSTANCE::toDto)
                .orElseThrow(() -> new EntityNotFoundException("파일 시퀀스 ["+seq+"] 파일 인덱스 ["+filIdx+"]"));
    }


    /**
     * 공지 테이블 정보 단건 조회
     *
     * @param seq 공지 일련번호
     * @return 공지 테이블 테이블 데이터
     * @throws BadRequestException 공지 일련번호가 없을 경우
     */
    public TbBoardDto getTbBoardDto(String seq) throws Exception {
        if(!StringUtils.hasText(seq)) throw new BadRequestException("공지 일련번호가 없습니다.");

        return tbBoardRepository.findBySeqAndDelYn(seq , "N")
                .map(TbBoardMapper.INSTANCE::toDto)
                .orElseGet(TbBoardDto::new);
    }

    /**
     * 회원 마스터 테이블 회원 구분별 리스트 조회
     *
     * @param membGbCd 사용자 유형
     * @return 회원 마스터 테이블 회원 구분별 리스트
     * @throws BadRequestException 사용자 유형이 없을 경우
     */
    public CommCodeVo.CustListRes getCustList(@Valid String membGbCd) throws Exception {
        if(!StringUtils.hasText(membGbCd)) throw new BadRequestException("사용자 유형이 없습니다.");

        if (!"00,10,20".contains(membGbCd)) {
            throw new BadRequestException("유효하지 않은 사용자 유형입니다.");
        }

        List<TbCustMaster> tbCustMasters = tbCustMasterRepository.findByMembGbCdAndStatCd(membGbCd, "10");

        List<CommCodeVo.CustInfo> custInfoList = tbCustMasters.stream()
                .map(data -> modelMapper.mapping(data, CommCodeVo.CustInfo.class))
                .toList();

        return CommCodeVo.CustListRes.builder()
                .custList(custInfoList)
                .build();
    }
}
