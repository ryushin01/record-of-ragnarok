package com.bankle.common.utils.encryption;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import lombok.extern.slf4j.Slf4j;

/**
 * AesEncryptConverter
 * DB에 저장되는 문자열 데이터를 AES 암호화/복호화하는 기능을 제공 (양방향 암호화)
 * @author bcla007
 * $version 1.0.0
 * @date 25. 4. 10.
 *
 **/
@Slf4j
@Converter
public class AesEncryptConverter implements AttributeConverter<String, String> {

    //DB에 저장되기 전에 값을 AES 암호화.
    @Override
    public String convertToDatabaseColumn(String attribute) {
        try {
            if (attribute != null) {
                log.debug("AES encrypt attribute: {}", attribute);
                return AesEncryptor.encrypt(attribute);
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Encryption error", e);
        }
    }

    // DB에서 가져온 값을 AES 복호화하여 Entity에 적용.
    @Override
    public String convertToEntityAttribute(String dbData) {
        try {
            if (dbData != null) {
                return AesEncryptor.decrypt(dbData);
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Decryption error", e);
        }
    }
}
