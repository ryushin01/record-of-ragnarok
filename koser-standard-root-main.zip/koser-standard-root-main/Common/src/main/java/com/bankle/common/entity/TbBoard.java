package com.bankle.common.entity;

import com.bankle.common.entity.base.BaseTimeEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "TB_BOARD")
public class TbBoard extends BaseTimeEntity {
    @Id
    @Size(max = 13)
    @Column(name = "SEQ", nullable = false, length = 13)
    private String seq;

    @Size(max = 100)
    @Column(name = "BOARD_TITLE", length = 100)
    private String boardTitle;

    @Lob
    @Column(name = "BOARD_CONTENTS")
    private String boardContents;

    @Size(max = 1)
    @Column(name = "EMCY_YN", length = 1)
    private String emcyYn;

    @Column(name = "HITS")
    private Integer hits;

    @Size(max = 13)
    @Column(name = "BOARD_FIL_SEQ", length = 13)
    private String boardFilSeq;

    @Size(max = 1)
    @Column(name = "DEL_YN", length = 1)
    private String delYn;

}