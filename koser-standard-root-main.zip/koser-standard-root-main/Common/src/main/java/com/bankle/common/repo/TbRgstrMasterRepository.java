package com.bankle.common.repo;

import com.bankle.common.entity.TbRgstrMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TbRgstrMasterRepository extends JpaRepository<TbRgstrMaster, String> {
    List<TbRgstrMaster> findTop6ByExecDtAndBndBizNoOrderByStatCdAsc(String execDt, String bndBizNo);

    long countByExecDtAndBndBizNoAndStatCdIn(String execDt, String bndBizNo, List<String> statCdList);

    long countByExecDtAndBndBizNoAndStatCd(String execDt, String bndBizNo, String statCd);

    Optional<TbRgstrMaster> findByRqstNo(String rqstNO);

    Optional<TbRgstrMaster> findByRqstNoAndBndBizNo(String rqstNo, String bndBizNo);

    long countByStatCdIn(List<String> statCdList);

    Page<TbRgstrMaster> findByStatCdInAndRqstNoContaining(List<String> statCdList, String rqstNo, Pageable pageable);

    Page<TbRgstrMaster> findByBndBizNoAndStatCdIn(String bizNo, List<String> statCdList, Pageable pageable);
    Page<TbRgstrMaster> findByStatCdIn(List<String> statCdList, Pageable pageable);

    Page<TbRgstrMaster> findAll(Specification<TbRgstrMaster> spec, Pageable pageable);

    Optional<List<TbRgstrMaster>> findAll(Specification<TbRgstrMaster> spec);

    List<TbRgstrMaster> findByExecDtAndStatCd(String execDt, String statCd);

    boolean existsByRqstNo(String rqstNo);

    boolean existsByRgstrDataFilSeqAndBndBizNo(String rgstrDataFilSeq, String bndBizNo);

    boolean existsByRgstrAcptFilSeqAndBndBizNo(String rgstrAcptFilSeq, String bndBizNo);
}