package com.bankle.common.commSvc;

import com.bankle.common.config.CommonConfig;
import com.bankle.common.exception.*;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.httpapi.HttpApi;
import com.bankle.common.vo.IrosVo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClientRequestException;

import java.util.*;


/**
 * 공통 - 인터넷등기소 API
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.18
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class IrosSvc {

    private final CommonSvc commonSvc;
    private final CustomeModelMapper modelMapper;

    /**
     * 주소로 등기고유번호 검색 API
     * - 도로명 주소와 상세주소를 결합하여 간편검색 방식으로 등기고유번호를 조회합니다.
     *
     * @param req : 도로명 주소, 지번주소 코드, 동, 호
     * @return 결과코드:
     *         - 99 : API 오류 발생
     *         - 00 : 조회 성공
     *         - 01 : 고유번호가 한 개가 아닌 경우
     */
    @Transactional
    public IrosVo.GetUnqRgstrNoRes getUnqRgstrNo(IrosVo.GetUnqRgstrNoReq req) throws Exception {

        IrosVo.GetUnqRgstrNoRes res = new IrosVo.GetUnqRgstrNoRes();

        // 도로명 주소
        String addr = req.getRdnmAddr();

        // 주소 조합
        addr += switch (req.getLotnumAddrCd()) {
            case "01" -> " " + req.getBldg() + "동 " + req.getUnit() + "호";  // 동 + 호
            case "02" -> " " + req.getBldg() + "동";                         // 동
            case "03" -> " " + req.getUnit() + "호";                         // 호
            case "04" -> "";                         // 없음
            default -> throw new BadRequestException("존재하지 않는 지번주소 코드입니다.");
        };

        log.debug("검색 주소 : {} ", addr);

       //API 호출
       var apiRes = callIrosGetUnqRgstrNo(addr);

       if("Y".equals(apiRes.getOut().getErrYn())){
           res.setResCd("99");
           res.setMsg(apiRes.getOut().getErrMsg());
           return res;
       }

        // 등기고유번호 리스트 생성
        List<String> unqRgstrNoList = new ArrayList<>();
        apiRes.getOut().getOutC0000().getList().forEach(dataItem ->
                unqRgstrNoList.add(dataItem.getPropertyUniqueId())
        );

        // 등기고유번호 조회 결과 처리
        if (unqRgstrNoList.size() != 1) {
            // 고유번호가 한 개가 아닌 경우 조회 실패 처리
            res.setResCd("01");
            res.setMsg("조회된 고유번호가 한 개가 아닙니다.");
        } else {
            // 고유번호가 정확히 한 개인 경우 조회 성공 처리
            res.setResCd("00");
            res.setUnqRgstrNo(unqRgstrNoList.get(0));
            res.setMsg("등기고유번호 조회 성공");
        }

       return res;
    }

    /**
     * 등기고유번호로 주소 검색 API
     *     *
     * @param unqRgstrNo: 등기고유번호
     * @return 결과코드:
     *         - 99 : API 오류 발생
     *         - 00 : 조회 성공
     *         - 01 : 고유번호가 한 개가 아닌 경우
     */
    @Transactional
    public IrosVo.GetAddrRes getAddr(String unqRgstrNo) throws Exception {

        //API 호출
        var apiRes = callIrosGetAddr(unqRgstrNo);

        IrosVo.GetAddrRes res = new IrosVo.GetAddrRes();

        if("Y".equals(apiRes.getOut().getErrYn())){
            res.setResCd("99");
            res.setMsg(apiRes.getOut().getErrMsg());
            return res;
        }

        String addr = apiRes.getOut().getOutC0000().getList().get(0).getPropertyLocation();


        if (StringUtils.hasText(addr)) {
            // 주소조회
            res.setResCd("00");
            res.setRdnmAddr(addr);
            res.setMsg("주소 조회 성공");
        }else{
            // 고유번호가 한 개가 아닌 경우 조회 실패 처리
            res.setResCd("01");
            res.setMsg("주소 조회 실패");
        }

        return res;
    }


    /**
     * 접수번호 리스트 조회 API
     * - 입력된 접수번호가 실제로 존재하는지 조회하는 API입니다.
     *
     * @param req : 의뢰번호, 등기접수번호 리스트(콤마로 구분), 등기소코드
     * @return true  - 모든 접수번호 조회 성공
     *         false - 하나라도 조회 실패 시
     */
    @Transactional
    public boolean acptNoListValid(IrosVo.AcptNoListValidReq req) throws Exception {
        String[] acptNos = req.getAcptNos().split(",");
        var acptNoValidReq = modelMapper.mapping(req, IrosVo.AcptNoValidReq.class);

        // 모든 접수번호가 유효한지 검사
        return Arrays.stream(acptNos).allMatch(acptNo -> {
            acptNoValidReq.setAcptNo(acptNo);
            try {
                return acptNoValid(acptNoValidReq);
            } catch (Exception e) {
                return false;
            }
        });
    }


    /**
     * 접수번호 조회 API
     * - 입력된 접수번호가 실제로 존재하는지 조회하는 API입니다.
     *
     * @param req : 의뢰번호, 등기접수번호, 등기소코드
     * @return true  - 접수번호 조회 성공
     *         false - 접수번호 조회 실패
     */
    @Transactional
    public boolean acptNoValid(IrosVo.AcptNoValidReq req) throws Exception {

        var rgstrMaster = commonSvc.getRgstrMastrDto(req.getRqstNo());

        if (!StringUtils.hasText(rgstrMaster.getUnqRgstrNo())) {
            log.error("원장에 등기고유번호가 존재하지 않습니다.");
            return false;
        }

        var officeMaster = commonSvc.getTbOfficeDto(rgstrMaster.getBndBizNo());

        if (!StringUtils.hasText(officeMaster.getBizNm())) {
            log.error("채권자 사무소 정보에 상호 명이 존재하지 않습니다.");
            return false;
        }

        //접수번호 조회
        IrosVo.IrosC0003Res apiRes = callIrosGetRgstrReqInfo(IrosVo.SearchRgstrReqInfoReq.builder()
                .unqRgstrNo(rgstrMaster.getUnqRgstrNo()) //등기고유번호
                .ownerName(officeMaster.getBizNm()) // 채권자 상호명
                .nameTape("1") //1: 등기신청인 , 2:소유자
                .selRegt(req.getRegoCd())
                .inpRecevNo(req.getAcptNo())
                .build());

        if ("Y".equals(apiRes.getOut().getErrYn())) {
            log.error("IROS 에러발생 ===>>>>>>>>> {}", apiRes.getOut().getErrMsg());
            return false;
        }

        //조회된 접수번호 정보 리스트
        var ccrstlist = apiRes.getOut().getOutC0003().getList();

        if (ccrstlist != null && !ccrstlist.isEmpty()) {
            for (IrosVo.C0003DataItem data : ccrstlist) {
                // 접수번호가 같은지 확인
                if (!req.getAcptNo().equals(data.getReceiptNum())) {
                    log.error("접수번호 불일치: {} != {}", req.getAcptNo(), data.getReceiptNum());
                } else {
                    //일치하다면 true을 리턴
                    return true;
                }
            }
        }

        return false;
    }




    /**
     * IROS API 호출/응답 서비스
     * 주소로 등기고유번호 검색 API
     *
     * @param addr 주소 (검색할 주소 값)
     * @return IROS 코드 C0000의 응답데이터
     */
    @Transactional
    public IrosVo.IrosC0000Res callIrosGetUnqRgstrNo(String addr) throws Exception {

        IrosVo.SearchUnqRgstrNoReq reqData = IrosVo.SearchUnqRgstrNoReq.builder()
                .appCd(CommonConfig.IROS_USERID1)
                .orgCd("iros")
                .svcCd("C0000")
                .vAddrCls("3")
                .kindcls("전체")
                .adminRegn1("전체")
                .adminRegn3("")
                .clsFlag("현행")
                .simpleAddress(addr)
                .build();

        log.debug("reqData ===========> " + reqData.toString());

        var api = HttpApi.create(HttpMethod.POST, CommonConfig.IROS_URL)
                .header("Content-Type", "application/json")
                .header("api-cloud-key", CommonConfig.IROS_APIKEY)
                .inserter(BodyInserters.fromValue(
                        reqData
                ));

        try {
            var res = api.sync(IrosVo.IrosC0000Res.class);
            log.debug("res->{}", res.getBody());
            return res.getBody();


        } catch (WebClientRequestException e) {
            Throwable cause = e.getCause();

            if (cause instanceof java.net.ConnectException) {
                throw new ConnectionTimeoutException("연결 타임아웃", e);
            } else if (cause instanceof java.net.SocketTimeoutException) {
                throw new ResponseTimeoutException("응답 지연", e);
            } else if (cause instanceof java.util.concurrent.TimeoutException) {
                throw new RequestTimeoutException("응답 시간 초과", e);
            } else if (cause instanceof io.netty.handler.timeout.ReadTimeoutException) {
                throw new ReadTimeoutException("읽기 응답 타임아웃", e);
            }

            throw new NetworkException("네트워크 오류", e);
        } catch (Exception e) {
            log.error("IROS API 처리 중 알 수 없는 오류", e);
            throw new RuntimeException("IROS API 처리 중 오류 발생", e);
        }

    }


    /**
     * IROS API 호출/응답 서비스
     * 등기고유번호 주소 검색 API
     *
     * @param unqRgstrNo : 등기고유번호
     * @return IROS 코드 C0000의 응답데이터
     */
    @Transactional
    public IrosVo.IrosC0000Res callIrosGetAddr(String unqRgstrNo) throws Exception {

        IrosVo.SearchAddrInSvo reqData = IrosVo.SearchAddrInSvo.builder()
                .appCd(CommonConfig.IROS_USERID1)
                .orgCd("iros")
                .svcCd("C0000")
                .vAddrCls("9")
                .kindcls("전체")
                .adminRegn1("전체")
                .adminRegn3("")
                .clsFlag("현행")
                .unqRgstrNo(unqRgstrNo)
                .build();

        log.debug("reqData ===========> " + reqData.toString());

        var api = HttpApi.create(HttpMethod.POST, CommonConfig.IROS_URL)
                .header("Content-Type", "application/json")
                .header("api-cloud-key", CommonConfig.IROS_APIKEY)
                .inserter(BodyInserters.fromValue(
                        reqData
                ));
        try {
            var res = api.sync(IrosVo.IrosC0000Res.class);
            log.debug("res->{}", Objects.requireNonNull(res.getBody()));
            return res.getBody();

        } catch (WebClientRequestException e) {
            Throwable cause = e.getCause();

            if (cause instanceof java.net.ConnectException) {
                throw new ConnectionTimeoutException("연결 타임아웃", e);
            } else if (cause instanceof java.net.SocketTimeoutException) {
                throw new ResponseTimeoutException("응답 지연", e);
            } else if (cause instanceof java.util.concurrent.TimeoutException) {
                throw new RequestTimeoutException("응답 시간 초과", e);
            } else if (cause instanceof io.netty.handler.timeout.ReadTimeoutException) {
                throw new ReadTimeoutException("읽기 응답 타임아웃", e);
            }

            throw new NetworkException("네트워크 오류", e);
        } catch (Exception e) {
            log.error("IROS API 처리 중 알 수 없는 오류", e);
            throw new RuntimeException("IROS API 처리 중 오류 발생", e);
        }

    }


    /**
     * IROS API 호출/응답 서비스
     * 고유번호로 등기신청사건 조회 api
     *
     * @param : IrosSvo.InfoTechInSvo
     * @return IROS 코드 C0003의 응답데이터
     * @throws
     */
    @Transactional
    public IrosVo.IrosC0003Res callIrosGetRgstrReqInfo(IrosVo.SearchRgstrReqInfoReq req) throws Exception {

        IrosVo.SearchRgstrReq reqData = IrosVo.SearchRgstrReq.builder()
                .appCd(CommonConfig.IROS_USERID1)
                .orgCd("iros")
                .svcCd("C0003")
                .userId(CommonConfig.IROS_USERID1)
                .userPw(CommonConfig.IROS_USERPW1)
                .selRegt(StringUtils.hasText(req.getSelRegt()) ? req.getSelRegt() : "")
                .inpRecevNo(StringUtils.hasText(req.getInpRecevNo()) ? req.getInpRecevNo() : "")
                .rstNo(req.getUnqRgstrNo())
                .nameType(req.getNameTape())
                .ownerName(req.getOwnerName())
                .passYn("Y")
                .build();

        log.debug("reqData ===========> " + reqData.toString());

        var api = HttpApi.create(HttpMethod.POST, CommonConfig.IROS_URL)
                .header("Content-Type", "application/json")
                .header("api-cloud-key", CommonConfig.IROS_APIKEY)
                .inserter(BodyInserters.fromValue(
                        reqData
                ));
        try {
            var res = api.sync(IrosVo.IrosC0003Res.class);
            log.debug("res->{}", Objects.requireNonNull(res.getBody()));
            return res.getBody();

        } catch (WebClientRequestException e) {
            Throwable cause = e.getCause();

            if (cause instanceof java.net.ConnectException) {
                throw new ConnectionTimeoutException("연결 타임아웃", e);
            } else if (cause instanceof java.net.SocketTimeoutException) {
                throw new ResponseTimeoutException("응답 지연", e);
            } else if (cause instanceof java.util.concurrent.TimeoutException) {
                throw new RequestTimeoutException("응답 시간 초과", e);
            } else if (cause instanceof io.netty.handler.timeout.ReadTimeoutException) {
                throw new ReadTimeoutException("읽기 응답 타임아웃", e);
            }

            throw new NetworkException("네트워크 오류", e);
        } catch (Exception e) {
            log.error("IROS API 처리 중 알 수 없는 오류", e);
            throw new RuntimeException("IROS API 처리 중 오류 발생", e);
        }

    }


}
