package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbAdminRequest}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TbAdminRequestDto implements Serializable {
    LocalDateTime crtDtm;
    String crtMembNo;
    LocalDateTime chgDtm;
    String chgMembNo;
    @Size(max = 13)
    String seq;
    LocalDateTime reqDt;
    @Size(max = 13)
    String rqstNo;
    @Size(max = 2)
    String reqGbCd;
    @Size(max = 2)
    String procGbCd;
    @Size(max = 1)
    String delYn;
    @Size(max = 3)
    String rtunCd;
    String rtunMsg;
}