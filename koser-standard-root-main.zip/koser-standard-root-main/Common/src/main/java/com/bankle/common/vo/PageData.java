package com.bankle.common.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PageData {

    private PageReqData pageReqData;
    private PageResData pageResData;

    @Data
    public static class PageReqData {

        @Schema(description = "현재 페이지 번호")
        private int currentPage;

        @Schema(description = "페이지당 사이즈")
        private int pageSize;

    }

    @Data
    public static class PageResData {
        @Schema(description = "전체 조회 갯수")
        private int totalCount;
        @Schema(description = "현재 페이지 번호")
        private int currentPage;
    }
}


