package com.bankle.common.repo;

import com.bankle.common.entity.TbFile;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TbFileRepository extends JpaRepository<TbFile, String> {

    List<TbFile> findById_Seq(String seq);

    List<TbFile> findById_SeqAndDelYn(String seq, String delYn);

    Optional<TbFile> findById_SeqAndId_FilIdxAndDelYn(String seq, Integer integer, String n);
}