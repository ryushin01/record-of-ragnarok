package com.bankle.common.ctrl;

import com.bankle.common.commSvc.FileSvc;
import com.bankle.common.commSvc.vo.ImageVo;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * @package  : com.bankle.common.ctrl
 * @class    : FileAttachCtrl.java
 * @data     : 25. 1. 20.
 * @author   : sws
 * @version  : 1.
 **/
@Tag(name = "공통 - 파일 조회", description = "파일 조회")
@Slf4j
@RestController
@RequiredArgsConstructor
public class FileCtrl {

    private final FileSvc fileSvc;

    @Operation(
            summary = "파일 정보 다건 조회",
            description = """
                파일 정보 다건 조회 서비스
                - seq
                    의뢰번호(rqstNo) : 등기자료, 등기접수증
                    사업자등록번호(bizNo) : 사업자등록증
                    공지사항 일련번호(seq) : 공지사항
                    "9999999999999" : 회원등록 신청서
                    사업자등록번호(bizNo) : 프로필 이미지
                - attcFilCd
                    01: 등기자료
                    02: 등기접수증
                    03: 사업자등록증
                    04: 공지사항 첨부파일
                    05: 회원등록 신청서
                    06: 프로필 이미지
                    
                조회하는 seq값의 attcFilCd(첨부파일코드)를 맞춰 입력해주세요!
            """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "파일 조회 성공", content = @Content(schema = @Schema(implementation = ImageVo.ImageRes.class)))
    })
    @GetMapping(value = "/files/images")
    public ResponseEntity<?> getImagesInfo(@Valid ImageVo.ImageInfoReq imageReq) throws Exception {
        return ResData.SUCCESS(fileSvc.getImages(imageReq), "파일 다건 조회 성공");
    }

    @Operation(summary = "파일 단건 조회 - 복호화", description = "파일 조회 서비스\n\n")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "파일 조회 성공", content = @Content(schema = @Schema(implementation = ImageVo.ImageDcytRes.class)))
    })
    @GetMapping(value = "/files/images/dcyt/{seq}/{filidx}")
    public ResponseEntity<?> getDecryptedImage(@PathVariable("seq") String seq, @PathVariable("filidx") String filIdx) throws Exception {
        return fileSvc.getDecryptedImage(seq, filIdx);
    }

    @Operation(summary = "파일 다운로드", description = "파일 다운로드\n\n")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "파일 조회 성공", content = @Content())
    })
    @GetMapping(value = "/files/download/{seq}/{filidx}")
    public ResponseEntity<?> downloadFile(@PathVariable("seq") String seq, @PathVariable("filidx") String filIdx) throws Exception {
        return fileSvc.downloadFile(seq, filIdx);
    }

}
