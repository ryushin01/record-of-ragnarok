package com.bankle.common.utils.httpapi.vo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ErrorResVo {
	
	private String errCode;
	
	private String errMsg;
	
}
