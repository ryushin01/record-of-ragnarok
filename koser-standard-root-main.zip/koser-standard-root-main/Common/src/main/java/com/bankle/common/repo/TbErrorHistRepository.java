package com.bankle.common.repo;

import com.bankle.common.entity.TbErrorHist;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TbErrorHistRepository extends JpaRepository<TbErrorHist, Long> {
}