package com.bankle.common.mapper;

import com.bankle.common.dto.TbRgstrMasterDto;
import com.bankle.common.entity.TbRgstrMaster;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbRgstrMasterMapper extends DefaultMapper<TbRgstrMasterDto, TbRgstrMaster> {
    TbRgstrMasterMapper INSTANCE = Mappers.getMapper(TbRgstrMasterMapper.class);
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    TbRgstrMaster partialUpdate(TbRgstrMasterDto tbRgstrMasterDto, @MappingTarget TbRgstrMaster tbRgstrMaster);
}