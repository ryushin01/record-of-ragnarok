package com.bankle.common.entity;

import com.bankle.common.entity.base.BaseTimeEntityByCrtDtmAndMembNo;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;
import org.springframework.data.annotation.CreatedBy;

import java.time.Instant;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_ERROR_HIST")
public class TbErrorHist extends BaseTimeEntityByCrtDtmAndMembNo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SEQ", nullable = false)
    private Long seq;

    @Size(max = 300)
    @Column(name = "URL", length = 300)
    private String url;

    @Size(max = 10)
    @Column(name = "HTTP_METHOD", length = 10)
    private String httpMethod;

    @Column(name = "STAT_CD")
    private Integer statCd;

    @Size(max = 300)
    @Column(name = "CLASS_NM", length = 300)
    private String classNm;

    @Lob
    @Column(name = "PARAMETER")
    private String parameter;

    @Lob
    @Column(name = "MESSAGE")
    private String message;

    @Size(max = 300)
    @Column(name = "USER_AGENT", length = 300)
    private String userAgent;

    @Size(max = 100)
    @Column(name = "IP_ADDR", length = 100)
    private String ipAddr;

    @Size(max = 300)
    @Column(name = "REFERRER", length = 300)
    private String referrer;

}