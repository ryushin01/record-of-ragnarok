package com.bankle.common.mapper;

import com.bankle.common.dto.TbRgstrStatHistDto;
import com.bankle.common.entity.TbRgstrStatHist;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TbRgstrStatHistMapper extends DefaultMapper<TbRgstrStatHistDto, TbRgstrStatHist> {
    TbRgstrStatHistMapper INSTANCE = Mappers.getMapper(TbRgstrStatHistMapper.class);
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)TbRgstrStatHist partialUpdate(TbRgstrStatHistDto tbRgstrStatHistDto, @MappingTarget TbRgstrStatHist tbRgstrStatHist);
}