package com.bankle.common.code.dao;

import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import java.util.List;
import com.bankle.common.entity.TbCommCode;

import static com.bankle.common.entity.QTbCommCode.tbCommCode;

@Slf4j
@Repository
@RequiredArgsConstructor
public class CommDao {
    private final JPAQueryFactory jpaQueryFactory;

    public List<TbCommCode> searchCommCodeMultiList(List<String> multiGrpCd) {
        return jpaQueryFactory
                .selectFrom(tbCommCode)
                .where(tbCommCode.id.grpCd.in(multiGrpCd))
                .fetch();
    }
}
