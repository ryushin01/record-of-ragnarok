package com.bankle.common.entity;

import com.bankle.common.entity.base.BaseTimeEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_CUST_MASTER")
public class TbCustMaster extends BaseTimeEntity {
    @Id
    @Size(max = 11)
    @Column(name = "MEMB_NO", nullable = false, length = 11)
    private String membNo;

    @Size(max = 20)
    @Column(name = "MEMB_ID", length = 20)
    private String membId;

    @Size(max = 100)
    @Column(name = "MEMB_PWD", length = 100)
    private String membPwd;

    @Size(max = 10)
    @Column(name = "BIZ_NO" , length = 10)
    private String bizNo;

    @Size(max = 2)
    @Column(name = "STAT_CD", length = 2)
    private String statCd;

    @Size(max = 50)
    @Column(name = "MEMB_NM", length = 50)
    private String membNm;

    @Size(max = 2)
    @Column(name = "MEMB_GB_CD", length = 2)
    private String membGbCd;

    @Column(name = "JOIN_DTM")
    private LocalDateTime joinDtm;

    @Size(max = 13)
    @Column(name = "MEMB_HPNO", length = 13)
    private String membHpno;

}