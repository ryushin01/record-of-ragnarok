package com.bankle.common.vo;

import com.bankle.common.dto.TbRgstrMasterDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class RgstrData extends TbRgstrMasterDto {

    @Schema(description = "법무대리인")
    private String lgagMembNm;

    @Schema(description = "법무대리인 연락처")
    private String lgagMembHpno;

    @Schema(description = "시스템관리자")
    private String mngrMembNm;

    @Schema(description = "시스템관리자 연락처")
    private String mngrMembHpno;

    @Schema(description = "금융기관(채권자)")
    private String bndMembNm;

    @Schema(description = "금융기관(채권자) 연락처")
    private String bndMembHpno;

}
