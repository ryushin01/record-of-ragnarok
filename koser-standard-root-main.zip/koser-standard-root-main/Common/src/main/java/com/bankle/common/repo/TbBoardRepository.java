package com.bankle.common.repo;

import com.bankle.common.entity.TbBoard;
import com.bankle.common.entity.TbRgstrMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.Optional;

public interface TbBoardRepository extends JpaRepository<TbBoard, String> {
    List<TbBoard> findTop6ByDelYn(String DelYn, Sort sort);
    Page<TbBoard> findByDelYn(String delYn, Pageable pageable);
    Optional<TbBoard> findBySeqAndDelYn(String seq ,String delYn);
    List<TbBoard> findAllBySeqIn(List<String> seq);
}