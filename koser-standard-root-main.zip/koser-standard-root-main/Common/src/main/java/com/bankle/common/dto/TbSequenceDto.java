package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * DTO for {@link com.bankle.common.entity.TbSequence}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TbSequenceDto implements Serializable {
    LocalDate id;
    @NotNull
    @Size(max = 100)
    String seqName;
    @NotNull
    Integer seqNumber;
}