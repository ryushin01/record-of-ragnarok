package com.bankle.common.ctrl;

import com.bankle.common.code.svc.CommSvc;
import com.bankle.common.code.vo.CommVo;
import com.bankle.common.commSvc.CommonSvc;
import com.bankle.common.commSvc.vo.CommCodeVo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * 공통 - 공통코드 서비스
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.18
 */
@Tag(name = "공통 - 공통코드 서비스", description = "공통코드")
@Slf4j
@RestController
@RequiredArgsConstructor
public class CommCodeCtrl {

    private final CommSvc commSvc;
    private final CommonSvc commonSvc;
    private final CustomeModelMapper modelMapper;

    @Operation(
            summary = "인터넷 등기소 제공 데이터로 등기소 정보 등록 API",
            description = """
                   - 인터넷 등기소의 등기소 데이터를 공통코드에 저장하는 서비스 입니다.
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = boolean.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PostMapping(value = "/comm/code/saveinternetrego")
    public ResponseEntity<?> saveInternetRego(@Valid @RequestBody List<CommVo.SaveInternetRegoReq> list) {
        try {
            for(var req: list){
                commSvc.saveInternetRego(modelMapper.mapping(req, CommVo.SaveInternetRegoReq.class));
            }
            return ResData.SUCCESS( true, "등기소 등록 성공");
        } catch (Exception e) {
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(
            summary = "공통코드 단건 조회 API",
            description = """
                            - grpcd (그룹코드) : ex) JUDT_COURT_CD
                            - code (코드) : ex) 11
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/comm/code/{grpcd}/{code}")
    public ResponseEntity<?> getCommCodeNm(@Valid @PathVariable("grpcd") String grpcd, @PathVariable("code") String code) throws Exception {
        return ResData.SUCCESS(commonSvc.getCommCodeNm(grpcd, code), "공통코드 단건 조회 성공");
    }

    @Operation(
            summary = "공통코드 다건 조회 API",
            description = """
                            - grpcd (그룹코드) : ex) JUDT_COURT_CD (관할법원 코드)
                            - grpcd (그룹코드) : ex) LOTNUM_ADDR_GB_CD (지번주소구분 코드)
                            - grpcd (그룹코드) : ex) MEMB_GB_CD (회원정보 유형)
                            - grpcd (그룹코드) : ex) REALE_CD (부동산구분 코드)
                            - grpcd (그룹코드) : ex) SPPL_REQ_GB_CD (보완요청 사유)
                            - grpcd (그룹코드) : ex) PROC_CLS_GB_CD (진행취소 사유)
                            - grpcd (그룹코드) : ex) RTUN_GB_CD (반려 사유)
                            - grpcd (그룹코드) : ex) PROC_STAT_CD (진행 상태)
                            - grpcd (그룹코드) : ex) REGR_CD (등기소)
                            - grpcd (그룹코드) : ex) ATTC_FIL_CD (첨부파일 코드)
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = CommCodeVo.CommCodeListRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/comm/code/{grpcd}")
    public ResponseEntity<?> getCommCodeList(@Valid @PathVariable("grpcd") String grpcd) throws Exception {
        return ResData.SUCCESS(commonSvc.getCommCodeList(grpcd), "공통코드 다건 조회 성공");
    }

    @Operation(
            summary = "공통코드 회원 구분별 조회",
            description = """
                           - membGbCd (사용자 유형) : 00 (금융기관)
                           - membGbCd (사용자 유형) : 10 (법무대리인)
                           - membGbCd (사용자 유형) : 20 (관리자)
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = CommCodeVo.CustListRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/comm/code/members/{membgbcd}")
    public ResponseEntity<?> getCustList(@Valid @PathVariable("membgbcd") String membGbCd) throws Exception {
        return ResData.SUCCESS(commonSvc.getCustList(membGbCd), "공통코드 회원 조회 성공");
    }

}
