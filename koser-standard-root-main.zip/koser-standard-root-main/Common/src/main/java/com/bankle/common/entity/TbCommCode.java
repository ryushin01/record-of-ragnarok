package com.bankle.common.entity;

import com.bankle.common.entity.base.BaseTimeEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "TB_COMM_CODE")
public class TbCommCode extends BaseTimeEntity {

    @EmbeddedId
    private TbCommCodeId id;

    @Size(max = 100)
    @Column(name = "CODE_NM", length = 100)
    private String codeNm;

    @Size(max = 100)
    @Column(name = "GRP_NM", length = 100)
    private String grpNm;

    @Size(max = 500)
    @Column(name = "GRP_DESC", length = 500)
    private String grpDesc;

    @Column(name = "NUM")
    private Integer num;

    @Size(max = 1000)
    @Column(name = "ETC_1", length = 1000)
    private String etc1;

    @Size(max = 1000)
    @Column(name = "ETC_2", length = 1000)
    private String etc2;

    @Size(max = 1000)
    @Column(name = "ETC_3", length = 1000)
    private String etc3;

    @Size(max = 1)
    @Column(name = "USE_YN", length = 1)
    private String useYn;

}