package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbCustMaster}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TbCustMasterDto implements Serializable {
    LocalDateTime crtDtm;
    String crtMembNo;
    LocalDateTime chgDtm;
    String chgMembNo;
    @Size(max = 11)
    String membNo;
    @Size(max = 20)
    String membId;
    @Size(max = 100)
    String membPwd;
    @Size(max = 10)
    String bizNo;
    @Size(max = 2)
    String statCd;
    @Size(max = 50)
    String membNm;
    @Size(max = 2)
    String membGbCd;
    LocalDateTime joinDtm;
    @Size(max = 13)
    String membHpno;
}