package com.bankle.common.repo;

import com.bankle.common.entity.TbRgstrMaster;
import com.bankle.common.entity.TbRgstrStatHist;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TbRgstrStatHistRepository extends JpaRepository<TbRgstrStatHist, String> {

  Optional<TbRgstrStatHist> findTop1ByRqstNoAndStatCdOrderBySeqDesc(String rqstNo, String statCd);

  List<TbRgstrStatHist> findByRqstNoOrderBySeqDesc(String rqstNo);

  Optional<TbRgstrStatHist> findTop1ByRqstNoAndStatCdInOrderBySeqDesc(String rqstNo, List statCd);
}