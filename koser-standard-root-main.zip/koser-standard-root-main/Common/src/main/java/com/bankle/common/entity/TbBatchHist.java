package com.bankle.common.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_BATCH_HIST")
public class TbBatchHist {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SEQ", nullable = false)
    private Long seq;

    @Size(max = 100)
    @Column(name = "BATCH_ID", length = 100)
    private String batchId;

    @Size(max = 150)
    @Column(name = "METHOD", length = 150)
    private String method;

    @Size(max = 1)
    @Column(name = "ERR_YN", length = 1)
    private String errYn;

    @Lob
    @Column(name = "ERR_MSG")
    private String errMsg;

    @ColumnDefault("current_timestamp()")
    @Column(name = "ST_DTM")
    private LocalDateTime stDtm;

    @ColumnDefault("current_timestamp()")
    @Column(name = "END_DTM")
    private LocalDateTime endDtm;

}