package com.bankle.common.utils.httpapi;

import org.springframework.stereotype.Repository;

@Repository
public class HttpSave {

//    public static void saveLog(LogDto logDto) {
//        SqlSessionTemplate sql = AppCntxtPrvidr.getSqlSession();
//        sql.insert("HttpMapper.saveLog", logDto);
//    }

}

