package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.Hibernate;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class TbFileId implements Serializable {
    private static final long serialVersionUID = 8919379384227972701L;
    @Size(max = 13)
    @NotNull
    @Column(name = "SEQ", nullable = false, length = 13)
    private String seq;

    @NotNull
    @Column(name = "FIL_IDX", nullable = false)
    private Integer filIdx;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        TbFileId entity = (TbFileId) o;
        return Objects.equals(this.filIdx, entity.filIdx) &&
                Objects.equals(this.seq, entity.seq);
    }

    @Override
    public int hashCode() {
        return Objects.hash(filIdx, seq);
    }

}