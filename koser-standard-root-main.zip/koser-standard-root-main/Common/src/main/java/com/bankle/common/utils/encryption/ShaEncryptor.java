package com.bankle.common.utils.encryption;

import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * ShaEncryptor
 * SHA-256 해시 알고리즘을 수행하는 유틸리티 클래스.
 * @author bcla007
 * $version 1.0.0
 * @date 25. 4. 10.
 *
 **/
@Slf4j
public class ShaEncryptor {

    // 주어진 문자열을 SHA-256 알고리즘으로 해싱하여 16진수 문자열로 반환.
    public static String hash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            log.debug("bytesToHex(hashedBytes) {}", hashedBytes);
            return bytesToHex(hashedBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

    // 바이트 배열을 사람이 읽을 수 있는 16진수 문자열(hex string) 으로 변환.
    private static String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();

        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b); // byte to hex
            if (hex.length() == 1) hexString.append('0'); // padding
            hexString.append(hex);
        }

        return hexString.toString();
    }
}
