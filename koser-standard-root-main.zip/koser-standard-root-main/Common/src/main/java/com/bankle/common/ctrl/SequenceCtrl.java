package com.bankle.common.ctrl;


import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @package  : com.bankle.common.ctrl
 * @class    : SequenceCtrl.java
 * @data     : 25. 3. 217.
 * @author   : rojoon
 * @version  : 1.0
 **/
@Tag(name = "공통 - 시퀀스 관리", description = "시퀀스 관리")
@Slf4j
@RestController
@RequiredArgsConstructor
public class SequenceCtrl {

    private final BizUtil bizUtil;

    @Operation(
            summary = "시퀀스 조회 API",
            description = """
        시퀀스 코드:
        - BOARD: 게시판 시퀀스
        - IMAGE: 이미지 시퀀스
        - RQST_NO: 의뢰번호 시퀀스
        - RGSTR_STAT_HIST: 의뢰 상태 이력 시퀀스
        - MEMB_NO: 회원번호
    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "comm/sequence")
    public ResponseEntity<?> sequence(@Valid @RequestParam("sequence") Sequence sequence)  throws Exception {
            return ResData.SUCCESS(bizUtil.getSeq(sequence) , "시퀀스 조회 성공");
    }
}
