package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbRgstrMaster}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TbRgstrMasterDto implements Serializable {
    LocalDateTime crtDtm;
    String crtMembNo;
    LocalDateTime chgDtm;
    String chgMembNo;
    @Size(max = 13)
    String rqstNo;
    @Size(max = 10)
    String bndBizNo;
    @Size(max = 2)
    String statCd;
    @Size(max = 8)
    String execDt;
    @Size(max = 50)
    String dbtrNm;
    BigDecimal bndMaxAmt;
    @Size(max = 8)
    String seDt;
    @Size(max = 15)
    String unqRgstrNo;
    @Size(max = 2)
    String realeCd;
    @Size(max = 1000)
    String lotnumAddr;
    @Size(max = 1000)
    String rdnmAddr;
    @Size(max = 2)
    String lotnumAddrCd;
    @Size(max = 10)
    String bldg;
    @Size(max = 10)
    String unit;
    @Size(max = 11)
    String lgagMembNo;
    String lgagDlvrCnts;
    @Size(max = 13)
    String mngrMembNo;
    @Size(max = 2)
    String judtCourtCd;
    @Size(max = 2)
    String regrCd;
    @Size(max = 100)
    String acptNo;
    @Size(max = 1)
    String rgstrAcptYn;
    LocalDateTime acptRptDtm;
    String mngrDlvrCnts;
    @Size(max = 13)
    String rgstrDataFilSeq;
    @Size(max = 13)
    String rgstrAcptFilSeq;
    LocalDateTime mtchDtm;


    /**
     * 진행상태명 조회 (VO에서 사용)
     * @return 진행상태명
     */
    public String getStatNm() {
        String statCd = this.statCd == null ? "" : this.statCd;

        return switch(statCd) {
            case "00" -> "등기의뢰";
            case "10" -> "보완필요";
            case "20" -> "배정완료";
            case "30" -> "대출실행";
            case "40" -> "접수검토중";
            case "50" -> "접수반려";
            case "60" -> "접수완료";
            case "70" -> "진행취소";
            case "80" -> "진행보류";
            default ->  "";
        };
    }
}