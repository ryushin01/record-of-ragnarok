package com.bankle.common.utils.encryption;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import lombok.extern.slf4j.Slf4j;

/**
 * ShaEncryptConverter
 * DB에 저장되는 문자열을 SHA-256 해시값으로 변환하는 기능 제공 (단방향 암호화)
 * @author bcla007
 * $version 1.0.0
 * @date 25. 4. 10.
 *
 **/
@Slf4j
@Converter
public class ShaEncryptConverter implements AttributeConverter<String, String> {

    //Entity에서 받은 평문 문자열을 SHA-256으로 해시하여 DB에 저장.
    @Override
    public String convertToDatabaseColumn(String attribute) {
        try {
            if (attribute != null) {
                return ShaEncryptor.hash(attribute);  // 속성 값을 해시값으로 변환
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Hashing error", e);
        }
    }

    @Override
    public String convertToEntityAttribute(String dbData) {
        // 해시는 단방향이므로, 복호화가 불가능하고 dbData를 그대로 반환
        return dbData;
    }
}
