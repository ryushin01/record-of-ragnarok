package com.bankle.common.commSvc.vo;

import com.bankle.common.annotation.DateFormatString;
import com.bankle.common.annotation.NullToEmptyString;
import com.bankle.common.dto.TbFileIdDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

public class ImageVo {

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ImageDataReq {
        @Schema(description = "")
        TbFileIdDto id;

        @Schema(description = "첨부파일 코드 (업무 요청 구분코드)", maxLength = 2, example = "01")
        private String attcFilCd;

        @Schema(description = "첨부파일 위치명", maxLength = 100, example = "/files/01")
        private String attcFilLocNm;

        @Schema(description = "첨부파일 명", maxLength = 200, example = "test.png")
        private String attcFilNm;

        @Schema(description = "변경 첨부파일 명", maxLength = 100, example = "4252631438250.png")
        private String chgAttcFilNm;

        @Schema(description = "파일사이즈", maxLength = 250, example = "")
        private Long filSize;

        @Schema(description = "삭제여부", maxLength = 3, example = "N")
        private String delYn;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ImageInfoReq {
        @Schema(description = "시퀀스 번호", maxLength = 13, example = "2025040300001")
        String seq;

        @Schema(description = "파일 일련번호 구분", maxLength = 13, example = "01")
        String attcFilCd;
    }


    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ImageRes {
        @Schema(description = "이미지 데이터")
        List<ImageInfo> imgData = new ArrayList<>();

        @Schema(description = "의뢰번호", example = "2024031200001")
        @NullToEmptyString
        String rqstNo;

        @Schema(description = "대출실행일", example = "2025-03-12")
        @DateFormatString
        @NullToEmptyString
        String execDt;
    }

    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ImageInfo {

        @Schema(description = "개별 이미지 일력번호", example = "2025031300001")
        private String seq;

        @Schema(description = "개별 이미지 순번", example = "1")
        private int filIdx;

        @Schema(description = "개별 이미지 조회 uri경로", example = "/files/images/dcyt/{seq}/{filidx}")
        @NullToEmptyString
        private String src;

        @Schema(description = "첨부파일 명", example = "test.jpg")
        @NullToEmptyString
        private String attcFilNm;

        @Schema(description = "파일사이즈", example = "100")
        private Long filSize;
    }

    @Getter
    @Setter
    @ToString
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ImageDcytRes {
        @Schema(description = "이미지 데이터")
        private byte[] imageData;

        @Schema(description = "파일 MIME 타입", example = "image/jpeg")
        private String contentType;
    }

}
