package com.bankle.common.repo;

import com.bankle.common.entity.TbOfficeMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TbOfficeMasterRepository extends JpaRepository<TbOfficeMaster, String> {
    Optional<TbOfficeMaster> findByBizNo(String bizNo);
    List<TbOfficeMaster> findByBizGbCdAndStatCd(String bizGbCd, String statCd);
    boolean existsByBizFilSeqAndBizNo(String bizFilSeq, String bizNo);
    boolean existsByProFilSeqAndBizNo(String bizFilSeq, String bizNo);
}