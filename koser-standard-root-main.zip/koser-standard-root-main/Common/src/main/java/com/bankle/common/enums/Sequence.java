package com.bankle.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;


/**
 * @package      : com.withuslaw.common.enums.Sequence
 * @name         : Sequence.java
 * @date         : 2023-09-18 오후 5:02
 * @author       : Tiger bk
 * @version      : 1.0.0
 * @desc         : 20231001 + seqLength (6자리) -> 2023100100006 14자리
 **/


@Getter
@AllArgsConstructor
public enum Sequence {
    BOARD("BOARD", 13),
    IMAGE("IMAGE", 13),
    RQST_NO("RQST_NO", 13),
    RGSTR_STAT_HIST("RGSTR_STAT_HIST", 13),
    MEMB_NO("MEMB_NO" , 11)
    ;

    
    private final String seqNm;
    private final int seqLen;
    
    
    public static Sequence findBySeqName(String seqName) {
        for (Sequence sq : Sequence.values()) {
            if (sq.getSeqNm().equals(seqName)) {
                return sq;
            }
        }
        return null;
    }
}
