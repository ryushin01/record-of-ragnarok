package com.bankle.common.entity;

import com.bankle.common.entity.base.BaseTimeEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_RGSTR_MASTER")
public class TbRgstrMaster extends BaseTimeEntity {
    @Id
    @Size(max = 13)
    @Column(name = "RQST_NO", nullable = false, length = 13)
    private String rqstNo;

    @Size(max = 10)
    @Column(name = "BND_BIZ_NO", length = 10)
    private String bndBizNo;

    @Size(max = 2)
    @NotNull
    @Column(name = "STAT_CD", length = 2)
    private String statCd;

    @Size(max = 8)
    @NotNull
    @Column(name = "EXEC_DT", length = 8)
    private String execDt;

    @Size(max = 50)
    @Column(name = "DBTR_NM", length = 50)
    private String dbtrNm;

    @Column(name = "BND_MAX_AMT")
    private BigDecimal bndMaxAmt;

    @Size(max = 8)
    @Column(name = "SE_DT", length = 8)
    private String seDt;

    @Size(max = 15)
    @Column(name = "UNQ_RGSTR_NO", length = 15)
    private String unqRgstrNo;

    @Size(max = 2)
    @Column(name = "REALE_CD", length = 2)
    private String realeCd;

    @Size(max = 1000)
    @Column(name = "LOTNUM_ADDR", length = 1000)
    private String lotnumAddr;

    @Size(max = 1000)
    @Column(name = "RDNM_ADDR", length = 1000)
    private String rdnmAddr;

    @Size(max = 2)
    @Column(name = "LOTNUM_ADDR_CD", length = 2)
    private String lotnumAddrCd;

    @Size(max = 10)
    @Column(name = "BLDG", length = 10)
    private String bldg;

    @Size(max = 10)
    @Column(name = "UNIT", length = 10)
    private String unit;

    @Size(max = 11)
    @Column(name = "LGAG_MEMB_NO", length = 11)
    private String lgagMembNo;

    @Lob
    @Column(name = "LGAG_DLVR_CNTS")
    private String lgagDlvrCnts;

    @Size(max = 13)
    @Column(name = "MNGR_MEMB_NO", length = 13)
    private String mngrMembNo;

    @Size(max = 2)
    @Column(name = "JUDT_COURT_CD", length = 2)
    private String judtCourtCd;

    @Size(max = 4)
    @Column(name = "REGR_CD", length = 4)
    private String regrCd;

    @Size(max = 100)
    @Column(name = "ACPT_NO", length = 200)
    private String acptNo;

    @Size(max = 1)
    @Column(name = "RGSTR_ACPT_YN", length = 1)
    private String rgstrAcptYn;

    @ColumnDefault("current_timestamp()")
    @Column(name = "ACPT_RPT_DTM")
    private LocalDateTime acptRptDtm;

    @Lob
    @Column(name = "MNGR_DLVR_CNTS")
    private String mngrDlvrCnts;

    @Size(max = 13)
    @Column(name = "RGSTR_DATA_FIL_SEQ", length = 13)
    private String rgstrDataFilSeq;

    @Size(max = 13)
    @Column(name = "RGSTR_ACPT_FIL_SEQ", length = 13)
    private String rgstrAcptFilSeq;

    @ColumnDefault("current_timestamp()")
    @Column(name = "MTCH_DTM")
    private LocalDateTime mtchDtm;

}