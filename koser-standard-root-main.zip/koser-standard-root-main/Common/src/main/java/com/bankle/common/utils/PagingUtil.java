package com.bankle.common.utils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Paging 처리 util
 * list 객체와 pageSize입력시 각 페이징처리되도록 리턴
 *
 * @param list list 객체
 * @param pageSize 페이징 사이즈
 * @return Map<Integer, List<T>> 페이징 처리된 list 객체
 */
public class PagingUtil {

    public static <T> Map<Integer, List<T>> streamPaging(List<T> list, int pageSize) {
        return IntStream.iterate(0, i -> i + pageSize)
                .limit((list.size() + pageSize - 1) / pageSize)
                .boxed()
                .collect(Collectors.toMap(i -> i / pageSize, i -> list.subList(i, Math.min(i + pageSize, list.size()))));
    }
}
