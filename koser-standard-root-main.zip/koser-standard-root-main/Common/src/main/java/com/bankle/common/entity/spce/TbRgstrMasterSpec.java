package com.bankle.common.entity.spce;

import com.bankle.common.entity.TbRgstrMaster;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class TbRgstrMasterSpec {

    public static Specification<TbRgstrMaster> likeRqstNo(String rqstNo) {
        return (root, query, CriteriaBuilder) -> CriteriaBuilder.like(root.get("rqstNo"), "%" + rqstNo + "%");
    }

    public static Specification<TbRgstrMaster> equalsStatCd(String statCd) {
        return (root, query, CriteriaBuilder) -> CriteriaBuilder.equal(root.get("statCd"), statCd);
    }

    public static Specification<TbRgstrMaster> equalsBndBizNo(String bndBizNo) {
        return (root, query, CriteriaBuilder) -> CriteriaBuilder.equal(root.get("bndBizNo"), bndBizNo);
    }

    public static Specification<TbRgstrMaster> likeAcptNo(String acptNo) {
        return (root, query, CriteriaBuilder) -> CriteriaBuilder.like(root.get("acptNo"), "%" + acptNo + "%");
    }

    public static Specification<TbRgstrMaster> likeDbtrNm(String dbtrNm) {
        return (root, query, CriteriaBuilder) -> CriteriaBuilder.like(root.get("dbtrNm"), "%" + dbtrNm + "%");
    }

    public static Specification<TbRgstrMaster> greaterThanOrEqualToExecDt(String fromDate) {

        return StringUtils.hasText(fromDate)
                ? (root, query, CriteriaBuilder) -> CriteriaBuilder.greaterThanOrEqualTo(root.get("execDt"), fromDate)
                : null;
    }

    public static Specification<TbRgstrMaster> lessThanOrEqualToExecDt(String toDate) {
        return StringUtils.hasText(toDate)
                ? (root, query, CriteriaBuilder) -> CriteriaBuilder.lessThanOrEqualTo(root.get("execDt"), toDate)
                : null;
    }

    public static Specification<TbRgstrMaster> greaterThanOrEqualToCrtDtm(String fromDate) {
        if(StringUtils.hasText(fromDate)) {
            LocalDate date = LocalDate.parse(fromDate, DateTimeFormatter.ofPattern("yyyyMMdd"));
            return (root, query, criteriaBuilder) -> criteriaBuilder.greaterThanOrEqualTo(root.get("crtDtm"), date);
        } else {
            return null;
        }
    }

    public static Specification<TbRgstrMaster> lessThanCrtDtm(String toDate) {
        if(StringUtils.hasText(toDate)) {
            LocalDate date = LocalDate.parse(toDate, DateTimeFormatter.ofPattern("yyyyMMdd")).plusDays(1);
            return (root, query, criteriaBuilder) -> criteriaBuilder.lessThan(root.get("crtDtm"), date);
        } else {
            return null;
        }
    }

    public static Specification<TbRgstrMaster> greaterThanOrEqualToSeDt(String fromDate) {
        return StringUtils.hasText(fromDate)
                ? (root, query, CriteriaBuilder) -> CriteriaBuilder.greaterThanOrEqualTo(root.get("seDt"), fromDate)
                : null;
    }

    public static Specification<TbRgstrMaster> lessThanOrEqualToSeDt(String toDate) {
        return StringUtils.hasText(toDate)
                ? (root, query, CriteriaBuilder) -> CriteriaBuilder.lessThanOrEqualTo(root.get("seDt"), toDate)
                : null;
    }
}
