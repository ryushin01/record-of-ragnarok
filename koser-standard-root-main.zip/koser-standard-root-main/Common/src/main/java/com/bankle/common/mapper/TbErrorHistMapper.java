package com.bankle.common.mapper;

import com.bankle.common.entity.TbErrorHist;
import com.bankle.common.dto.TbErrorHistDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbErrorHistMapper extends DefaultMapper<TbErrorHistDto, TbErrorHist> {

    TbErrorHistMapper INSTANCE = Mappers.getMapper(TbErrorHistMapper.class);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    TbErrorHist partialUpdate(TbErrorHistDto tbErrorHistDto, @MappingTarget TbErrorHist tbErrorHist);
}