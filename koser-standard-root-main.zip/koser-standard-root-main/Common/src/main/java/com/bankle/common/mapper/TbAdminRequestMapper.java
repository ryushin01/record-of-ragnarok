package com.bankle.common.mapper;

import com.bankle.common.dto.TbAdminRequestDto;
import com.bankle.common.entity.TbAdminRequest;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbAdminRequestMapper extends DefaultMapper<TbAdminRequestDto, TbAdminRequest> {

    TbAdminRequestMapper INSTANCE = Mappers.getMapper(TbAdminRequestMapper.class);
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    TbAdminRequest partialUpdate(TbAdminRequestDto tbAdminRequestDto, @MappingTarget TbAdminRequest tbAdminRequest);
}