package com.bankle.common.repo;

import com.bankle.common.entity.TbCustMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TbCustMasterRepository extends JpaRepository<TbCustMaster, String> {

    Optional<TbCustMaster> findByMembNo(String membNo);
    Optional<TbCustMaster> findByMembNoAndMembGbCdAndStatCd(String membNo, String membGbCd, String statCd);
    Optional<TbCustMaster> findByMembIdAndStatCdAndMembGbCd(String membId, String statCd, String membGbCd);
    Optional<TbCustMaster> findByMembId(String membId);
    List<TbCustMaster> findByMembGbCdAndStatCd(String membGbCd, String statCd);
    Page<TbCustMaster> findByMembGbCdIn(List<String> membGbCd, Pageable pageable);
    Page<TbCustMaster> findByMembNm(String membNm, Pageable pageable);
    Page<TbCustMaster> findByMembGbCdInAndMembNm(List<String> membGbCd, String membNm, Pageable pageable);
    Optional<TbCustMaster> findTop1ByBizNoOrderByCrtDtmDesc(String bizNo);
    Page<TbCustMaster> findByMembGbCdAndStatCd(String membGbCd, String statCd , Pageable pageable);
    Page<TbCustMaster> findByMembGbCdAndStatCdAndMembNmContaining(String membGbCd, String statCd , String membNm , Pageable pageable);
}