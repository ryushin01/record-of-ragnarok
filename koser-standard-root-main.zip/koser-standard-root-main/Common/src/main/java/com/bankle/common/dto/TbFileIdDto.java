package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;

/**
 * DTO for {@link com.bankle.common.entity.TbFileId}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor(force = true)
@Builder
public class TbFileIdDto implements Serializable {
    @NotNull
    @Size(max = 13)
    String seq;
    @NotNull
    Integer filIdx;
}