package com.bankle.common.entity;

import com.bankle.common.entity.base.BaseTimeEntity;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "TB_FILE")
public class TbFile extends BaseTimeEntity {
    @EmbeddedId
    private TbFileId id;

    @Size(max = 2)
    @Column(name = "ATTC_FIL_CD", length = 2)
    private String attcFilCd;

    @Size(max = 100)
    @Column(name = "ATTC_FIL_LOC_NM", length = 100)
    private String attcFilLocNm;

    @Size(max = 200)
    @Column(name = "ATTC_FIL_NM", length = 200)
    private String attcFilNm;

    @Size(max = 100)
    @Column(name = "CHG_ATTC_FIL_NM", length = 100)
    private String chgAttcFilNm;

    @Column(name = "FIL_SIZE")
    private Long filSize;

    @Size(max = 1)
    @Column(name = "DEL_YN", length = 1)
    private String delYn;


}