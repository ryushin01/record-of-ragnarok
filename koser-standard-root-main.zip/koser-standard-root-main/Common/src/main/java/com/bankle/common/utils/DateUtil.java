package com.bankle.common.utils;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

public class DateUtil {

    public static final String FORMAT_yyyyMMddhhmmss = "yyyyMMddhhmmss";
    public static final String FORMAT_yyyyMMdd = "yyyyMMdd";
    public static final String FORMAT_yyyyMM = "yyyyMM";
    public static final String FORMAT_dd = "dd";
    public static final String FORMAT_hhmm = "hhmm";



    /**
     * 현재 일자
     *
     * @return
     */
    public static String getDayStrNow() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        DateFormat df = new SimpleDateFormat(FORMAT_dd);
        return df.format(cal.getTime());
    }

    /**
     * 현재일의 마지막 일자
     *
     * @return
     */
    public static String getLastDayStrNow() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        return String.valueOf(cal.getActualMaximum(Calendar.DAY_OF_MONTH));
    }

    /**
     * 오늘일자 - 년월일
     *
     * @return
     */
    public static String getDateNowStr() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        DateFormat df = new SimpleDateFormat(FORMAT_yyyyMMdd);
        return df.format(cal.getTime());
    }

    /**
     * 오늘일자(포맷지원)
     *
     * @param format
     * @return
     */
    public static String getDateNowStr(String format) {
        LocalDate today = LocalDate.now();
        return today.format(DateTimeFormatter.ofPattern(format));
//        Calendar cal = Calendar.getInstance();
//        cal.setTime(new Date());
//        DateFormat df = new SimpleDateFormat(
//                (format != null && (!FORMAT_yyyyMMdd.equals(format) || !FORMAT_yyyyMM.equals(format))) ? FORMAT_yyyyMMdd
//                        : format);
//        return df.format(cal.getTime());
    }

    /**
     * 오늘일자 기준 월 계산 - 년월일
     *
     * @param month
     * @return
     */
    public static String getDateStrAddMonth(int month) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        DateFormat df = new SimpleDateFormat(FORMAT_yyyyMMdd);
        cal.add(Calendar.MONTH, month);
        return df.format(cal.getTime());
    }

    /**
     * 오늘일자 기준 월 계산
     *
     * @param month
     * @return
     */
    public static String getDateStrAddMonth(int month, String format) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        DateFormat df = new SimpleDateFormat(
                (format != null && (!FORMAT_yyyyMMdd.equals(format) || !FORMAT_yyyyMM.equals(format))) ? FORMAT_yyyyMMdd
                        : format);
        cal.add(Calendar.MONTH, month);
        return df.format(cal.getTime());
    }

    public static String invalidDateToNull(String date) {
        if (date == null)
            return null;
        date = date.replaceAll("[^0-9]", "");
        String formatter = "";
        switch (date.length()) {
            case 14:
                formatter = "ss";
                break;
            case 12:
                formatter = "HHmm" + formatter;
                break;
            case 8:
                formatter = "yyyyMMdd" + formatter;
                break;
            default:
                return null;
        }
        SimpleDateFormat sdformat = new SimpleDateFormat(formatter);
        try {
            Date res = sdformat.parse(date);
            return sdformat.format(res);
        } catch (ParseException e) {
            return null;
        }
    }

    /**
     * 현재 일시 반환 yyyyMMddhhmmss
     *
     * @return
     */
    public static String getCurrentDateTime() {
        return new SimpleDateFormat(FORMAT_yyyyMMddhhmmss).format(new Date());
    }

    /**
     * 오늘일자 - 시분
     */
    public static String getDateNowHourMin() {
        return new SimpleDateFormat(FORMAT_hhmm).format(new Date());
    }

    /**
     * 문자열 Date 객체로 변환
     *
     * @param date
     * @param format
     * @return
     */
    public static Date parseDate(String date, String format) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            return new Date(sdf.parse(date).getTime());
        } catch (ParseException e) {
            return null;
        }
    }

    public static int daysBetween(String startDate, String endDate) {
        int year = Integer.parseInt(startDate.substring(0, 4));
        int month = Integer.parseInt(startDate.substring(4, 6));
        int day = Integer.parseInt(startDate.substring(6));

        int year2 = Integer.parseInt(endDate.substring(0, 4));
        int month2 = Integer.parseInt(endDate.substring(4, 6));
        int day2 = Integer.parseInt(endDate.substring(6));

        LocalDate fromDate = LocalDate.of(year, month, day);
        LocalDate toDate = LocalDate.of(year2, month2, day2);

        return (int) ChronoUnit.DAYS.between(fromDate, toDate);
    }

    public static int monthsBetween(String startDate, String endDate) {
        int year = Integer.parseInt(startDate.substring(0, 4));
        int month = Integer.parseInt(startDate.substring(4, 6));
        int day = Integer.parseInt(startDate.substring(6));

        int year2 = Integer.parseInt(endDate.substring(0, 4));
        int month2 = Integer.parseInt(endDate.substring(4, 6));
        int day2 = Integer.parseInt(endDate.substring(6));

        LocalDate fromDate = LocalDate.of(year, month, day);
        LocalDate toDate = LocalDate.of(year2, month2, day2);

        return (int) ChronoUnit.MONTHS.between(fromDate, toDate);
    }

    /**
     * String 과 infmt, outfmt 을 받아 날짜를 출력해준다.
     * ex) getFormatDate("20080901","yyyyMMdd","yyyy-MM-dd") -> 2008-09-01
     *
     * @param date
     * @param infmt
     * @param outfmt
     * @return
     */
    public static String getFormatDate(String date, String infmt, String outfmt) {
        try {
            // date 형식이 infmt 에 맞지 않다면 date 를 infmt 에 맞추어줌.
            StringBuffer sDate = new StringBuffer(date);
            int len = date.length();

            if (infmt.equals("yyyyMMddHHmm") && len < 12) {
                for (int i = len; i < 12; i++) {
                    sDate.append("0");
                }
            } else if (infmt.equals("yyyyMMddHHmmss") && len < 14) {
                for (int i = len; i < 14; i++) {
                    sDate.append("0");
                }
            }

            SimpleDateFormat sdf = new SimpleDateFormat(infmt, Locale.US);
            Date d = sdf.parse(sDate.toString());
            sdf.applyPattern(outfmt);

            return sdf.format(d);
        } catch (ParseException e) {
            return "";
        }
    }

    public static Date date() {
        return new Date();
    }

    public static Timestamp getTimestamp() {
        return new Timestamp(date().getTime());
    }

    // Instant To timeStamp 변환
    public static Timestamp toTimestamp(Instant instant) {
        return Timestamp.from(instant);
    }

    // TImestamp To Instant 변환
    public static Instant toInstant(Timestamp timestamp) {
        return timestamp.toInstant();
    }

    // Instant To DataTime 변환
    public static Date toDate(Instant instant) {
        return Date.from(instant);
    }

    /**
     * Instant을 LocalDateTime으로 반환해준다
     *
     * @param : Instant
     * @return LocalDateTime
     */
    public static LocalDateTime toLocalDateTime(Instant instant) {
        return LocalDateTime.ofInstant(instant, ZoneOffset.UTC);
    }

    /**
     * LocalDateTime을 Instant로 반환해준다
     *
     * @param : LocalDateTime
     * @return Instant
     */
    public static Instant toInstant(LocalDateTime ldt) {
        return ldt.toInstant(ZoneOffset.UTC);
    }

    /**
     * pattern 형식 String
     *
     * @param : instant (시간)
     * @param pattern (DateTimeFormatter)
     * @return 해당하는 format이 된 String 문자열
     */
    public static String formatOfPattern(LocalDateTime ldt, String pattern) {
        return ldt.format(DateTimeFormatter.ofPattern(pattern));

    }

    /**
     * pattern 형식 DateTimeFormatter
     *
     * @param instant (시간)
     * @param pattern (DateTimeFormatter)
     * @return 해당하는 format이 된 String 문자열
     */
    public static String formatOfPattern(Instant instant, DateTimeFormatter pattern) {
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneOffset.UTC);
        return localDateTime.format(pattern);
    }

//    public static String formatOfPattern(String date, String pattern) {
//
//        LocalDate formatOfPattern = LocalDate.parse(date);
//        return formatOfPattern.format(DateTimeFormatter.ofPattern(pattern));
//    }

    /**
     * 두 일자 사이의 Date 구하기
     *
     * @param :
     * @return :
     * @name : DateUtil.getDateList
     * @author : JuHeon Kim
     **/

    public static List<String> getDateList(String startDate, String lastDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        Integer days = DateUtil.daysBetween(startDate, lastDate);
        List<String> dateList = new ArrayList<>();
        for (int i = 0; i < days + 1; i++) {
            DateTimeFormatter newformatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate date = LocalDate.parse(startDate, formatter);
            LocalDate newDate = date.plusDays(i);
            String newDateStr = newDate.format(newformatter);
            dateList.add(newDateStr);
        }
        return dateList;
    }

    /**
     * 요일 구하기(1 ~ 7 일 수 반환. 일요일이 1, 토요일이 7 임.)
     *
     * @param :
     * @return :
     * @name : DateUtil.getWeekNum
     * @author : JuHeon Kim
     **/
    public static int getWeekNum(String date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.parse(date, formatter);
        return localDate.getDayOfWeek().getValue();
    }


    /**
     * 기준일시가 원하는 시간 이후인지 확인
     *
     * @param :
     * @return :
     * @name : DateUtil.isAfterAnyHours
     * @author : JuHeon Kim
     **/
    public static boolean isAfterAnyHours(LocalDateTime currDtm, int hours) {
        LocalDateTime currentTime = currDtm;
        LocalDateTime previousTime = currentTime.minusHours(hours);
        return currentTime.isAfter(previousTime);
    }

    /**
     * 현재시간이 기준일시가 원하는 시간 이전인지 확인
     *
     * @param :
     * @return :
     * @name : DateUtil.isPrevAnyHours
     * @author : leh
     **/
    public static boolean isPrevAnyHours(LocalDateTime stdDtm, int hours) {
        LocalDateTime currentTime = LocalDateTime.now();
        LocalDateTime afterTime = stdDtm.plusHours(hours);
        return currentTime.isBefore(afterTime);
    }

    /**
     * 기준일시가 원하는 시간 이후인지 확인
     *
     * @param : 문자열('-' 제외한 8자리 날짜형태의 문자열)
     * @param : 문자열('-' 제외한 8자리 날짜형태의 문자열)
     * @return : 일자형태의 문자열
     * @name : DateUtil.procDaySubmit
     * @author : Lee SangHyup
     **/
    public static String procDaySubmit(String firstDt, String secondDt) {
        LocalDate fDate = LocalDate.parse(firstDt, DateTimeFormatter.ofPattern("yyyyMMdd"));
        LocalDate sDate = LocalDate.parse(secondDt, DateTimeFormatter.ofPattern("yyyyMMdd"));
        return String.valueOf(fDate.until(sDate).getDays());
    }


    /**
     * 날자 변수 인지 판단
     *
     * @param str     string of the date
     * @param : pattern date format
     * @return return <code>true</code>if valid date and <code>false</code> if
     * not.
     */
    public static boolean isDate(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        LocalDate dateStr = LocalDate.parse(str, DateTimeFormatter.ofPattern("yyyyMMdd"));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDate dateLocal = LocalDate.parse(str, formatter);

        if (!dateLocal.toString().equals(dateStr.toString())) {
            return false;
        }
        return true;
    }


    public static boolean isBetween(String checkDate, String startDate, String endDate) {
        if (isDate(checkDate) && isDate(startDate) && isDate(endDate)) {
            LocalDate startLocalDate = LocalDate.parse(startDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            LocalDate endLocalDate = LocalDate.parse(endDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            LocalDate checkLocalDate = LocalDate.parse(checkDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            return checkLocalDate.isAfter(startLocalDate) && checkLocalDate.isBefore(endLocalDate);
        } else {
            return !(isDate(checkDate) && isDate(startDate) && isDate(endDate));
        }
    }

    public static LocalDateTime getDateTime(String dateTime) {
        if (dateTime == null || dateTime.isEmpty()) {
            return null;
        }
        if (dateTime.length() < 14) {
            return LocalDateTime.parse(dateTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        }
        return null;
    }

    public static String formatLdt(LocalDateTime source){
        if(source == null) return null;
        return source.toString().replace("T", " ");
    }

    public static LocalDate stringToLocalDate(String date) {
        String replaceDate = date.replaceAll("[\\-|\\.|\\:|\\/]", "-");
        return LocalDate.parse(replaceDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }

    public static LocalDate stringToLocalDate2(String date) {
        String replaceDate = date.replaceAll("[\\-|\\.|\\:|\\/]", "-");
        return LocalDate.parse(replaceDate, DateTimeFormatter.ofPattern("yyyyMMdd"));
    }


    public static String LdToStringByFormat(LocalDate ld) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy년 MM월 dd일");
        return dateTimeFormatter.format(ld);
    }

    public static String TmToStringByFormat(LocalTime tm) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH시 mm분");
        return dateTimeFormatter.format(tm);
    }

    /**
     * 들어온 시간을 당일 기준으로 분단위로 반환한다.
     * Ex)
     * 1  시간  => 60
     * 2  시간  => 120
     * 24 시간  => 1440
     *
     * @param : LocalDateTime.class
     * @return Long.class
     */
    public static Long formatTimeCharge(LocalDateTime target) {
        //현재 시간을 기준으로 들어온 데이터의 기준을 나눈다.
        LocalTime targetTime = target.toLocalTime();
        LocalTime nowTime = LocalDateTime.now().toLocalTime();

        Duration diff = Duration.between(target, LocalDateTime.now());
        long diffMin = diff.toMinutes();

        // 분을 long으로 리턴
        return diffMin;
    }


    /**
     * 인입된 시간을 기준으로 아래의 포맷과 같이 반환한다.
     * Ex)
     *  1시간 이내 => mm분 전
     *   1일  이내 => hh 시간 전
     *   3일  이내 => dd 일 전
     *   그외      => MM월 dd일
     *
     * @param : LocalDateTime.class
     * @return String.class
     */
    public static String typeOfFormat(LocalDateTime time) {
        Long formatTime = formatTimeCharge(time);
        String format = "";
        if (formatTime < 60) {
            //한시간 이내일 경우
            format = formatTime + "분 전";
        } else if (formatTime < 1440) {
            Long hour = formatTime / 60;
            Double formatHour = Math.floor(hour);
            format = formatHour.longValue() + "시간 전";
        } else if (formatTime < 4320) {
            Long day = formatTime / 60 / 24;
            Double formatHour = Math.floor(day);
            format = formatHour.longValue() + "일 전";
        } else {
            LocalDate sndDt = time.toLocalDate();
            format = sndDt.format(DateTimeFormatter.ofPattern("MM월 dd일"));
        }
        return format;
    }

    public static String formatStrDt(String strDt) throws ParseException {
        SimpleDateFormat formatter1 = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd");

        Date formatDate = formatter1.parse(strDt);

        return formatter2.format(formatDate);
    }

    public static String ldtToStrDt(LocalDateTime ldt) {
        return ldt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }

    public static String ldtToStr14(LocalDateTime ldt){
        return ldt.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
    }

    public static String getDateAddDays(String startDate, int days) {
        if(startDate == null || startDate.length() != 8 ) return startDate;
        LocalDate ldt = LocalDate.parse(startDate, DateTimeFormatter.ofPattern(FORMAT_yyyyMMdd));
        return  ldt.plusDays(days).format(DateTimeFormatter.ofPattern(FORMAT_yyyyMMdd));
    }


    //LocalDateTime 을 String 형태로 반환하는 함수
    public static String dateTimeToString(LocalDateTime dateTime) {
        if (dateTime == null) {
            return "";
        }
        // 원하는 형식으로 날짜를 포맷
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return dateTime.format(formatter);
    }

}