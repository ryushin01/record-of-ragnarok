package com.bankle.common.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ImgConfig {

    // 등기자료 경로
    public static String IMG_PATH_BIZ_01;
    // 등기접수증 경로
    public static String IMG_PATH_BIZ_02;
    // 사업자등록증 경로
    public static String IMG_PATH_CUST_03;
    // 공지사항 첨부파일 경로
    public static String IMG_PATH_BOARD_04;
    // 회원등록 신청서 경로
    public static String IMG_PATH_CUST_05;
    // 프로필 이미지 경로
    public static String IMG_PATH_PROFILE_06;
    //이미지 오류 저장 경로
    public static String IMG_PATH_99;

    // tiff파일 암호화 키
    public static final String TIFF_SECRET_KEY = "jmlim12345bbbbbaaaaa123456789066"; // 32bit

    public static final String IMAGE_URL_PREFIX = "/files/images/dcyt/"; // 이미지 단건 조회 URI 접두사

    //SFTP
    public static String SFTP_IP;
    public static int SFTP_PORT;
    public static String SFTP_ID;
    public static String SFTP_PW;


    @Value("${data.files.biz}")
    public void setIMG_PATH_BIZ_01(String imgPathBiz){
        IMG_PATH_BIZ_01 = imgPathBiz + "/01";}

    @Value("${data.files.biz}")
    public void setIMG_PATH_BIZ_02(String imgPathBiz){
        IMG_PATH_BIZ_02 = imgPathBiz + "/02";}

    @Value("${data.files.cust}")
    public void setIMG_PATH_CUST_03(String imgPathCust){
        IMG_PATH_CUST_03 = imgPathCust + "/03";}

    @Value("${data.files.board}")
    public void setIMG_PATH_BOARD_04(String imgPathBoard){
        IMG_PATH_BOARD_04 = imgPathBoard + "/04";}

    @Value("${data.files.cust}")
    public void setIMG_PATH_CUST_05(String imgPathCust){
        IMG_PATH_CUST_05 = imgPathCust + "/05";}

    @Value("${data.files.profile}")
    public void setIMG_PATH_PROFILE_06(String imgPathProfile){
        IMG_PATH_PROFILE_06 = imgPathProfile + "/06";}

}
