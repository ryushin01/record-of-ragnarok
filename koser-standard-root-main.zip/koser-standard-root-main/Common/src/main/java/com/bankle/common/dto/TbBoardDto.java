package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbBoard}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TbBoardDto implements Serializable {
    LocalDateTime crtDtm;
    String crtMembNo;
    LocalDateTime chgDtm;
    String chgMembNo;
    @Size(max = 13)
    String seq;
    @Size(max = 100)
    String boardTitle;
    String boardContents;
    @Size(max = 3)
    String emcyYn;
    Integer hits;
    @Size(max = 13)
    String boardFilSeq;
    @Size(max = 1)
    String delYn;
}