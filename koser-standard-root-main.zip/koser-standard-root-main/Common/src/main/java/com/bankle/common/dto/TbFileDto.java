package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbFile}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor(force = true)
public class TbFileDto implements Serializable {
    LocalDateTime crtDtm;
    String crtMembNo;
    LocalDateTime chgDtm;
    String chgMembNo;
    TbFileIdDto id;
    @Size(max = 2)
    String attcFilCd;
    @Size(max = 100)
    String attcFilLocNm;
    @Size(max = 200)
    String attcFilNm;
    @Size(max = 100)
    String chgAttcFilNm;
    Long filSize;
    @Size(max = 1)
    String delYn;
}