package com.bankle.common.vo;


import com.bankle.common.annotation.NullToEmptyString;
import com.bankle.common.utils.httpapi.vo.BaseResponseVo;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.validator.constraints.Length;

import java.util.List;

/**
 * 공통 - 인터넷등기소 API
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.18
 */
public class IrosVo {

    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class GetUnqRgstrNoReq{

        @Schema(description = "도로명주소" , example = "서울 중구 청계천로 100 시그니쳐타워")
        @NotEmpty(message = "도로명주소를 입력해 주세요.")
        private String rdnmAddr;

        @Schema(
                description = """
        지번주소 코드:
        - 01: 동 + 호
        - 02: 동
        - 03: 호
        - 04: 없음
        """,
                example = "01"
        )
        @NotEmpty(message = "지번주소코드를 입력해 주세요.")
        private String lotnumAddrCd;

        @Schema(description = "동" , example = "102")
        private String bldg;

        @Schema(description = "호" , example = "204")
        private String unit;

    }

    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class GetUnqRgstrNoRes{
        @Schema( description = "등기고유번호" , example = "123456789011111")
        @NullToEmptyString
        private String unqRgstrNo;

        @Schema( description = "결과 코드" , example = "00")
        @NullToEmptyString
        private String resCd;

        @Schema( description = "메세지" , example = "에러 메세지")
        @NullToEmptyString
        private String msg;
    }


    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class GetAddrRes{
        @Schema( description = "도로명 주소" , example = "서울 중구 청계천로 100 시그니쳐타워")
        @NullToEmptyString
        private String rdnmAddr;

        @Schema( description = "결과 코드" , example = "00")
        @NullToEmptyString
        private String resCd;

        @Schema( description = "메세지" , example = "에러 메세지")
        @NullToEmptyString
        private String msg;
    }

    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SearchAddrInSvo {
        @JsonProperty("appCd")
        @Schema(description = "어플리케이션 코드")
        String appCd;

        @JsonProperty("orgCd")
        @Schema(description = "기관코드")
        String orgCd;

        @JsonProperty("svcCd")
        @Schema(description = "서비스 코드")
        String svcCd;

        @JsonProperty("vAddrCls")
        @Schema(description = "")
        String vAddrCls;

        @JsonProperty("kindcls")
        @Schema(description = "")
        String kindcls;

        @JsonProperty("admin_regn1")
        @Schema(description = "")
        String adminRegn1;

        @JsonProperty("admin_regn3")
        @Schema(description = "")
        String adminRegn3;

        @JsonProperty("cls_flag")
        @Schema(description = "")
        String clsFlag;

        @JsonProperty("uniqNo")
        @Schema(description = "고유번호")
        String unqRgstrNo;
    }

    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SearchUnqRgstrNoReq {
        @JsonProperty("appCd")
        @Schema(description = "어플리케이션 코드")
        String appCd;

        @JsonProperty("orgCd")
        @Schema(description = "기관코드")
        String orgCd;

        @JsonProperty("svcCd")
        @Schema(description = "서비스 코드")
        String svcCd;

        @JsonProperty("vAddrCls")
        @Schema(description = "")
        String vAddrCls;

        @JsonProperty("kindcls")
        @Schema(description = "")
        String kindcls;

        @JsonProperty("admin_regn1")
        @Schema(description = "")
        String adminRegn1;

        @JsonProperty("admin_regn3")
        @Schema(description = "")
        String adminRegn3;

        @JsonProperty("cls_flag")
        @Schema(description = "")
        String clsFlag;

        @JsonProperty("simple_address")
        @Schema(description = "주소")
        String simpleAddress;
    }


    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class IrosC0000Res extends BaseResponseVo {

        @JsonProperty("resCd")
        private String resCd;

        @JsonProperty("resMsg")
        private String resMsg;

        @JsonProperty("out")
        private OutC0000Data out;

        @JsonProperty("reqTm")
        private String reqTm;

        @JsonProperty("reqTmSs")
        private String reqTmSs;

        @JsonProperty("resTm")
        private String resTm;

        @JsonProperty("resTmSs")
        private String resTmSs;

        @JsonProperty("reqCd")
        private String reqCd;


    }

    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OutC0000Data {
        @JsonProperty("uid")
        private String uid;

        @JsonProperty("outC0000")
        private OutC0000 outC0000;

        @JsonProperty("orgCd")
        private String orgCd;

        @JsonProperty("resCd")
        private String resCd;

        @JsonProperty("errMsg")
        private String errMsg;

        @JsonProperty("appCd")
        private String appCd;

        @JsonProperty("reqCd")
        private String reqCd;

        @JsonProperty("svcCd")
        private String svcCd;

        @JsonProperty("resMsg")
        private String resMsg;

        @JsonProperty("device")
        private String device;

        @JsonProperty("errYn")
        private String errYn;

    }

    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OutC0000 {
        @JsonProperty("errYn")
        private String errYn;

        @JsonProperty("errMsg")
        private String errMsg;

        @JsonProperty("list")
        private List<C0000DataItem> list;

        @JsonProperty("totCnt")
        private String totCnt;

        // Getters and Setters
    }

    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class C0000DataItem {
        @JsonProperty("부동산고유번호")
        private String propertyUniqueId;

        @JsonProperty("구분")
        private String category;

        @JsonProperty("부동산소재지번")
        private String propertyLocation;

        @JsonProperty("소유자")
        private String owner;

        @JsonProperty("상태")
        private String status;
    }


    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SearchRgstrReqInfoReq {
        @Schema(description = "등기고유번호")
        private String unqRgstrNo;
        @Schema(description = "등기신청인/소유자")
        private String ownerName;
        @Schema(description = "1: 등기신청인 , 2:소유자", example = "1: 등기신청인 , 2:소유자")
        private String nameTape;
        @Schema(description = "등기소번호")
        private String selRegt;
        @Schema(description = "사건접수번호")
        private String inpRecevNo;
    }


    /*
    고유번호로 등기신청사건 조회 API
     */
    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SearchRgstrReq {
        @JsonProperty("appCd")
        @Schema(description = "어플리케이션 코드")
        String appCd;

        @JsonProperty("orgCd")
        @Schema(description = "기관코드")
        String orgCd;

        @JsonProperty("svcCd")
        @Schema(description = "서비스 코드")
        String svcCd;

        @JsonProperty("userId")
        @Schema(description = "")
        String userId;

        @JsonProperty("userPw")
        @Schema(description = "")
        String userPw;

        @JsonProperty("selRegt")
        @Schema(description = "")
        String selRegt;

        @JsonProperty("inpRecevNo")
        @Schema(description = "")
        String inpRecevNo;

        @JsonProperty("rstNo")
        @Schema(description = "")
        String rstNo;

        @JsonProperty("nameType")
        @Schema(description = "")
        String nameType;

        @JsonProperty("ownerName")
        @Schema(description = "")
        String ownerName;

        @JsonProperty("passYn")
        @Schema(description = "")
        String passYn;

    }


    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class IrosC0003Res extends BaseResponseVo {

        @JsonProperty("resCd")
        private String resCd;

        @JsonProperty("resMsg")
        private String resMsg;

        @JsonProperty("out")
        private OutC0003Data out;

        @JsonProperty("reqTm")
        private String reqTm;

        @JsonProperty("reqTmSs")
        private String reqTmSs;

        @JsonProperty("resTm")
        private String resTm;

        @JsonProperty("resTmSs")
        private String resTmSs;

        @JsonProperty("reqCd")
        private String reqCd;


    }

    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OutC0003Data {
        @JsonProperty("uid")
        private String uid;

        @JsonProperty("outC0003")
        private OutC0003 outC0003;

        @JsonProperty("orgCd")
        private String orgCd;

        @JsonProperty("resCd")
        private String resCd;

        @JsonProperty("errMsg")
        private String errMsg;

        @JsonProperty("appCd")
        private String appCd;

        @JsonProperty("reqCd")
        private String reqCd;

        @JsonProperty("svcCd")
        private String svcCd;

        @JsonProperty("resMsg")
        private String resMsg;

        @JsonProperty("device")
        private String device;

        @JsonProperty("errYn")
        private String errYn;

    }


    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OutC0003 {
        @JsonProperty("errYn")
        private String errYn;

        @JsonProperty("errMsg")
        private String errMsg;

        @JsonProperty("list")
        private List<C0003DataItem> list;

        @JsonProperty("변동여부")
        private String fluctuationsYn;

        @JsonProperty("outStr")
        private String outStr;

    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class C0003DataItem {
        @JsonProperty("일련번호")
        private String seq;

        @JsonProperty("접수번호")
        private String receiptNum;

        @JsonProperty("접수일자")
        private String receiptDate;

        @JsonProperty("관할등기소")
        private String cptRego;

        @JsonProperty("관할등기소번호")
        private String cptRegoNum;

        @JsonProperty("계")
        private String category;

        @JsonProperty("소재지번")
        private String seatLotn;

        @JsonProperty("소재지번목록")
        private List<SeatLotn> seatLotnList;

        @JsonProperty("등기목적")
        private String registrationPurpose;

        @JsonProperty("처리상태")
        private String processingStatus;

        @JsonProperty("국민주택채권매입환급액")
        private String natlHusBondPurchaseRefundAmt;

        @JsonProperty("국민주택채권")
        private List<NatlHousingBond> natlHousingBondList;

        @JsonProperty("신청구분")
        private String applicationType;

        @JsonProperty("등기필정보등교부상태")
        private String registrationInformationDeliveryStatus;

        @JsonProperty("소유자")
        private String owner;

        @JsonProperty("등기목적코드")
        private String registrationPurposeCode;

        @JsonProperty("상태")
        private String status;


    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SeatLotn {
        @JsonProperty("부동산고유번호")
        private String realEstateUniqueId;

        @JsonProperty("부동산소재지번")
        private String realEstateAddr;

    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class NatlHousingBond {
        @JsonProperty("순번")
        private String seq;

        @JsonProperty("채권번호")
        private String bndNum;

        @JsonProperty("은행")
        private String bank;

        @JsonProperty("매입액")
        private String purchaseAmt;

        @JsonProperty("환급액")
        private String refundAmt;
    }

    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AcptNoValidReq{
        @Schema( description = "의뢰번호" , example = "1234567890111")
        @Size(min = 13 , max = 13, message = "의뢰번호는 13자리 입니다.")
        private String rqstNo;

        @Schema(description = "등기접수번호", example = "12345")
        @Size(min = 1 , message = "등기접수번호는 필수 입력 값 입니다.")
        private String acptNo;

        @Schema(description = "등기소 코드", example = "12345")
        @Size(min = 1 , message = "등기소 코드는 필수 입력 값 입니다.")
        private String regoCd;
    }

    @Data
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AcptNoListValidReq{
        @Schema( description = "의뢰번호" , example = "1234567890111")
        @Size(min = 13 , max = 13, message = "의뢰번호는 13자리 입니다.")
        private String rqstNo;

        @Schema(description = "등기접수번호", example = "112345,131211,121211")
        @Size(min = 1 , message = "등기접수번호는 필수 입력 값 입니다.")
        private String acptNos;

        @Schema(description = "등기소 코드", example = "12345")
        @Size(min = 1 , message = "등기소 코드는 필수 입력 값 입니다.")
        private String regoCd;
    }

}
