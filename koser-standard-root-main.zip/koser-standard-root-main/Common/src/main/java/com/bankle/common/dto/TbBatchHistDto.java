package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbBatchHist}
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TbBatchHistDto implements Serializable {
    Long seq;
    @Size(max = 100)
    String batchId;
    @Size(max = 150)
    String method;
    @Size(max = 1)
    String errYn;
    String errMsg;
    LocalDateTime stDtm;
    LocalDateTime endDtm;
}