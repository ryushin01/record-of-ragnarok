package com.bankle.common.mapper;

import com.bankle.common.dto.TbSequenceDto;
import com.bankle.common.entity.TbSequence;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbSequenceMapper extends DefaultMapper<TbSequenceDto, TbSequence> {
    TbSequenceMapper INSTANCE = Mappers.getMapper(TbSequenceMapper.class);
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    TbSequence partialUpdate(TbSequenceDto tbSequenceDto, @MappingTarget TbSequence tbSequence);
}