package com.bankle.common.entity;

import com.bankle.common.entity.base.BaseTimeEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "TB_OFFICE_MASTER")
public class TbOfficeMaster extends BaseTimeEntity {
    @Id
    @Size(max = 10)
    @Column(name = "BIZ_NO", nullable = false, length = 10)
    private String bizNo;

    @Size(max = 100)
    @Column(name = "BIZ_NM", length = 100)
    private String bizNm;

    @Size(max = 50)
    @Column(name = "REPT_NM", length = 50)
    private String reptNm;

    @Size(max = 1000)
    @Column(name = "BIZ_ADDR", length = 1000)
    private String bizAddr;

    @Size(max = 13)
    @Column(name = "BIZ_FIL_SEQ", length = 13)
    private String bizFilSeq;

    @Size(max = 13)
    @Column(name = "PRO_FIL_SEQ", length = 13)
    private String proFilSeq;

    @Size(max = 2)
    @Column(name = "BIZ_GB_CD", length = 1000)
    private String bizGbCd;

    @Size(max = 2)
    @Column(name = "STAT_CD", length = 1000)
    private String statCd;

}