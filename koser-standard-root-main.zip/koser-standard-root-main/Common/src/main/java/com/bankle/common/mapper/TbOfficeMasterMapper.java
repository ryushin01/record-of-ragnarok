package com.bankle.common.mapper;

import com.bankle.common.dto.TbOfficeMasterDto;
import com.bankle.common.entity.TbOfficeMaster;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbOfficeMasterMapper extends DefaultMapper<TbOfficeMasterDto, TbOfficeMaster> {
    TbOfficeMasterMapper INSTANCE = Mappers.getMapper(   TbOfficeMasterMapper.class);
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    TbOfficeMaster partialUpdate(TbOfficeMasterDto tbOfficeMasterDto, @MappingTarget TbOfficeMaster tbOfficeMaster);
}