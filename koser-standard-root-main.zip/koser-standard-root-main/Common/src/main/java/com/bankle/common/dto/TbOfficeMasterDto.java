package com.bankle.common.dto;

import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbOfficeMaster}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TbOfficeMasterDto implements Serializable {
    LocalDateTime crtDtm;
    String crtMembNo;
    LocalDateTime chgDtm;
    String chgMembNo;
    @Size(max = 10)
    String bizNo;
    @Size(max = 100)
    String bizNm;
    @Size(max = 50)
    String reptNm;
    @Size(max = 1000)
    String bizAddr;
    @Size(max = 13)
    String bizFilSeq;
    @Size(max = 13)
    String proFilSeq;
    @Size(max = 2)
    String bizGbCd;
    @Size(max = 2)
    String statCd;

}