package com.bankle.common.repo;

import com.bankle.common.entity.TbBatchHist;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TbBatchHistRepository extends JpaRepository<TbBatchHist, Long> {
}