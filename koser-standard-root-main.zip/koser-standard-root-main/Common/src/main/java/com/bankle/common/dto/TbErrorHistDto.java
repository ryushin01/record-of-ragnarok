package com.bankle.common.dto;

import com.bankle.common.entity.TbErrorHist;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDateTime;

/**
 * DTO for {@link TbErrorHist}
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TbErrorHistDto implements Serializable {
    Long seq;
    @Size(max = 300)
    String url;
    @Size(max = 10)
    String httpMethod;
    Integer statCd;
    @Size(max = 300)
    String classNm;
    String parameter;
    String message;
    @Size(max = 300)
    String userAgent;
    @Size(max = 100)
    String ipAddr;
    @Size(max = 300)
    String referrer;
    String crtMembNo;
    LocalDateTime crtDtm;
}