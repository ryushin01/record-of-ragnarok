package com.bankle.common.mapper;

import com.bankle.common.dto.TbFileDto;
import com.bankle.common.entity.TbFile;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbFileMapper extends DefaultMapper<TbFileDto, TbFile> {

    TbFileMapper INSTANCE = Mappers.getMapper(TbFileMapper.class);
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    TbFile partialUpdate(TbFileDto tbFileDto, @MappingTarget TbFile tbFile);
}