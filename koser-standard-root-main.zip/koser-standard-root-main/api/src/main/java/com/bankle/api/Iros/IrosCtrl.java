package com.bankle.api.Iros;

import com.bankle.common.commSvc.IrosSvc;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.vo.IrosVo;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


/**
 * 인터넷등기소 API
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.18
 */
@Tag(name = "인터넷등기소 API", description = "IROS API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class IrosCtrl {

    private final IrosSvc irosSvc;

    @Operation(
            summary = "주소로 등기고유번호 검색 API",
            description = """
                    요청 데이터
                    - 도로명주소 (rdnmAddr)
                    - 지번주소 코드 (lotnumAddrCd) -> 
                      01 : 동 + 호 ,
                      02 : 동 ,
                      03 : 호 ,
                      04 : 없음 
                    - 동 (bldg)
                    - 호 (unit)
                            
                    응답 데이터
                    - 도로명 주소와 상세주소를 결합하여 인터넷 등기소의 간편검색 방식으로 등기고유번호를 조회합니다.
                    - API 호출 오류 또는 조회된 고유번호가 한 개가 아닐 경우, 조회 실패(code: 99)로 처리합니다.
                    - 조회 성공(code: 00) 시 등기고유번호를 반환합니다.
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/api/iros/unqrgstrno")
    public ResponseEntity<?> getUnqrgstrno(@Valid IrosVo.GetUnqRgstrNoReq req) throws Exception {

        var res = irosSvc.getUnqRgstrNo(req);
        if ("00".equals(res.getResCd())) {
            return ResData.SUCCESS(res.getUnqRgstrNo(), "조회 성공");
        } else {
            return ResData.FAIL("고유번호 조회에 실패하였습니다. 주소를 다시 확인해 주세요.");
        }

    }

    @Operation(
            summary = "등기고유번호로 도로명 주소 검색 API",
            description = """
                    요청 데이터
                    - 등기고유번호 (unqrgstrno)
                            
                    응답 데이터 
                    - 조회 성공(code: 00) 시 도로명 주소를 반환합니다.
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/api/iros/addr/{unqrgstrno}")
    public ResponseEntity<?> getAddr(@PathVariable(name = "unqrgstrno") String unqRgstrNo) throws Exception {

        var res = irosSvc.getAddr(unqRgstrNo);
        if ("00".equals(res.getResCd())) {
            return ResData.SUCCESS(res.getRdnmAddr(), "조회 성공");
        } else {
            return ResData.FAIL(res.getMsg());
        }

    }


    @Operation(
            summary = "접수번호 리스트 조회 API",
            description = """
                    입력된 접수번호 리스트를 IROS 사건조회 API를 통해 유효성 검사를 수행합니다.
                          
                    처리 과정:
                    1. 입력된 접수번호를 콤마(,)로 구분하여 조회합니다.
                    2. 각 접수번호를 IROS 사건조회 API를 통해 유효성 검증합니다.
                    3. 하나라도 유효하지 않은 접수번호가 있으면 조회 실패로 처리합니다.
                            
                    요청 데이터:
                    - 의뢰번호 (rqstNo)
                    - 등기접수번호 (acptNos)
                    - 등기소 코드 (regoCd)
                            
                          
                    응답 코드:
                    - 00: 모든 접수번호 조회 성공 (true 반환)
                    - 99: 하나 이상의 접수번호 조회 실패 (false 반환)
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = boolean.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class))),
            @ApiResponse(responseCode = "500", description = "서버 오류", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/api/iros/acceptno")
    public ResponseEntity<?> acptNoValid(@Valid IrosVo.AcptNoListValidReq req) throws Exception {

        if (irosSvc.acptNoListValid(req)) {
            return ResData.SUCCESS(true, "조회 성공");
        } else {
            return ResData.FAIL(false, "조회 실패");
        }

    }


}
