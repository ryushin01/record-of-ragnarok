# koser-standard 개발 참고사항

### <span style='color:#F7DDBE'> Mapping 전략</span>

```
@RequestMapping 사용 금지
@PostMapping 사용
- url 시작은 각 프로젝트단위로 작성
- 모든 url은 소문자로 작성을 진행한다.

REST API URL 명명 규칙 (예시)

1. REST API 명명 규칙 (네이밍 방식 적용)

아래와 같이 get, create, update, delete 접두어를 사용하여 API 동작을 명확하게 표현합니다.

	•	조회 (POST) → /패키지명/get+리소스명
	•	POST /client/getNameList → 이름 리스트 조회
	•	POST /client/getUserDetail/{id} → 특정 유저 상세 조회

	•	생성 (POST) → /패키지명/create+리소스명
	•	POST /client/createUser → 유저 생성
	•	POST /client/createOrder → 주문 생성

	•	수정 (POST) → /패키지명/update+리소스명
	•	POST /client/updateUser/{id} → 특정 유저 정보 수정
	•	POST /client/updateOrder/{id} → 특정 주문 일부 수정

	•	삭제 (POST) → /패키지명/delete+리소스명
	•	POST /client/deleteUser/{id} → 특정 유저 삭제
	•	POST /client/deleteOrder/{id} → 특정 주문 삭제

```

---

### <span style='color:#F7DDBE'> 패키지 및 서비스 명</span>

- [구글스프레드시트 - 서비스 분석 - 업무명] (https://docs.google.com/spreadsheets/d/16sGOkauZhg5mkaTw3hB9zBxeXDg0TIdrErNaupJCKO8/edit?gid=1493773233#gid=1493773233)

---

### <span style='color:#F7DDBE'> 형변환</span>

- String to Boolean
    - DataBase 필드 중 <span style='background-color: #ffdce0;color:red'>Y/N(여부)</span>로
      지정된 필드들은 <br> 전부 Java내에서
      <span style='background-color: #ffdce0;color:red'>boolean</span> 값으로 변경하여 Client단에 전달

---

### <span style='color:#F7DDBE'> 응답 코드</span>

- Client에게 전달하는 응답 코드는 HttpStauts 코드에 의거하여 전달 진행
    - 성공의 경우 *200* code
    - 실패의 경우 *4xx,5xx* 등의 상태에 맞게 Exception 발생
        - 4xx
            - 클라이언트 오류 - 접근 권한관련 오류들로 구성<br>
              <b>Forbidden<br>Not Found</b>

        - 5xx
            - 서버 오류 - 실제 로직이 돌아가는 서버 내에서 발생하는 오류들로 구성<br>
              <b>Internal Server Error<br>Service Unavailable<br>NullPoint</b>

---

### <span style='color:#F7DDBE'> 파라미터 명 정의</span>

- 단일객체는 각 로직단에 맞는 객체로 작성
    - Main Vo Class
        - VO<br>&nbsp;&nbsp;
          Req(Reqeust)<br>&nbsp;&nbsp;
          Res(Response)
---
### <span style='color:#F7DDBE'> Vo 작성시 유의사항</span>
- Vo 내 필드의 어노테이션은<br>@Schema()를 사용한다.
  <br>Schema의 필드는 description 과 maxLength 사용
  <br> DataBase내 필드가 <span style='color:green'>String, int, Long, Decimal</span>  등 크기가 명확한 변수에 maxLength 사용
  <br> DataBase내 필드가 <span style='color:red'>LongText, LocalDateTime</span> 등 크기가 불명확한 변수에는 maxLength 미사용
  <br> ex)<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style='color:black'>@Schema(description = "샘플링", maxLength = 15)<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;private String sampling;</span>

---

### <span style='color:#F7DDBE'>DB 접속 정보 (개발)</span>
```
Host: 106.249.246.6
Port: 4306
DB : koser
ID: koserDb
PW: koser1@@2
```
---

### <span style='color:#F7DDBE'>DB 접속 정보 (운영)</span>
```
Host: 211.251.254.64(172.16.2.35)
Port: 30001
ID: root
PW: dKsqW4RazZw9
```
---

### <span style='color:#F7DDBE'>Was 접속 정보</span>
```
Host: 211.251.254.64(172.16.1.17)
Port: 30010
ID: root
PW: CuVuePKK4qaB
```
---

### <span style='color:#F7DDBE'>WEB 접속 정보</span>
```
Host: 211.251.254.64(172.16.0.34)
Port: 30100
ID: root
PW: cSOPBsFa2Cdw
```
---



#### <span style='color:tomato'> 라이브템플릿</span> (필요하면 가져다 쓰세요)
```java
// Vo 작성시
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public static class VoAnnotation{} 
```
```java
// Comment 작성시
//변수 편집 들어갔을 경우 작성해야하는 변수들
// $class$ => className()
// $method$ => methodName()
// $date$ => date()
/**
 * @class    : $class$.java
 * @method   : $method$
 * @data     : $date$
 * @desc     : 
 * @author   : lsh
 * @version  : 1.
 **/
```
```java
// Mapper 선언
private final CustomeModelMapper customeModelMapper;
```
```java
// Controller 선언
// $package$ => currentPackage() 
// $class$ => className()
// $date$ => date()
/**
 * @package  : $package$
 * @class    : $class$.java
 * @data     : $date$
 * @author   : lsh
 * @version  : 1.
**/
@Tag(name = "", description = "")
@Slf4j
@RestController
@RequiredArgsConstructor
```
```java
// Dao 선언
@Slf4j
@Repository
@RequiredArgsConstructor
```
```java
// Method 작성
// Mapping 잘 나누어 사용 진행
// methodName에 각 작업에 맞는 메소드 작성
@Operation(summary = "", description = "")
@ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = String.class)))
})
@PostMapping(value = "")
public ResponseEntity<?> methodName() {
    try {
        return ResData.SUCCESS("");
    } catch (Exception e) {
        e.printStackTrace();
        throw new DefaultException(e.getMessage());
    }
}
```
```java
// Service 선언
@Slf4j
@Service
@RequiredArgsConstructor
```

```java
// TryCatch문 작성
try {
} catch (Exception e) {
    e.printStackTrace();
    throw new DefaultException(e.getMessage());
}
```