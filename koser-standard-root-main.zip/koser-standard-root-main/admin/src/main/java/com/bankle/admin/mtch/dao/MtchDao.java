package com.bankle.admin.mtch.dao;


import com.bankle.admin.mtch.vo.MtchVo;
import com.bankle.common.exception.BadRequestException;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.util.List;

import static com.bankle.common.entity.QTbCustMaster.tbCustMaster;
import static com.bankle.common.entity.QTbOfficeMaster.tbOfficeMaster;

@Slf4j
@Repository
@RequiredArgsConstructor
public class MtchDao {

    private final JPAQueryFactory jpaQueryFactory;

}
