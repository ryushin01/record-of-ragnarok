package com.bankle.admin.member.vo;

import com.bankle.common.annotation.LocalDateTimeToString;
import com.bankle.common.annotation.NullToEmptyString;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class MemberVo {

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class bizListRes {
        @Schema(name = "bizNo", example = "1000020000")
        @NullToEmptyString
        String bizNo;

        @Schema(name = "bizNm", example = "성북신용협동조합")
        @NullToEmptyString
        String bizNm;
    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class memberSaveReq {

        /**
         * 사업자 정보
         * */
        @NotEmpty(message = "사업자등록번호는 필수입니다.")
        @Size(min = 10 , max = 10 , message = "사업자등록번호는 10자리 입니다.")
        @Schema(name = "bizNo", example = "1140012300")
        String bizNo;

        /**
         * 회원 정보
         * */
        @NotEmpty(message = "회원 번호를 입력해 주세요")
        @Schema(name = "membNo", example = "25040100001")
        @Size(min = 11, max = 11, message = "회원번호는 11자리 입니다.")
        String membNo;

        @Schema(name = "membNm", example = "홍길동")
        String membNm;

        @Schema(name = "membHpno", example = "01012345678")
        String membHpno;

        /**
         * 계정정보
         * */
        @NotEmpty(message = "아이디를 입력해 주세요")
        @Schema(name = "membId", example = "honggildong")
        String membId;

        @NotEmpty(message = "비밀번호를 입력해 주세요")
        @Schema(name = "pwd", example = "asdf1234")
        String pwd;

    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class bizSaveReq {

        @NotEmpty(message = "사업자유형은 필수입니다.")
        @Schema(name = "bizGbCd", example = "00")
        String bizGbCd;

        @NotEmpty(message = "사업자등록번호는 필수입니다.")
        @Size(min = 10 , max = 10 , message = "사업자등록번호는 필수입니다.")
        @Schema(name = "bizNo", example = "1140412345")
        String bizNo;

        @Schema(name = "bizNm", example = "소공신용협동조합")
        String bizNm;

        @Schema(name = "reptNm", example = "남대표")
        String reptNm;

        @Schema(name = "bizAddr", example = "서울특별시 중구 세종대로 74(태평로2가) 1층 소공신협")
        String bizAddr;

    }

    @Getter
    @Setter
    public static class MemberListReq {

        @Size(min = 2 , max = 2 , message = "tap 구분 값은 필수 값 입니다.")
        @Schema(description = "tap 선택", example = "00")
        private String tabSelection;

        @Schema(description = "회원명", example = "성북신협")
        private String membNm;

        @Min(value = 1, message = "현재 페이지는 1 이상이어야 합니다.")
        @Schema( description = "현재 페이지" , example = "1")
        private int pageNum;

        @Min(value = 1, message = "페이지에 보여지는 데이터 수는 1 이상이어야 합니다.")
        @Schema( description = "페이지에 보여지는 데이터수" , example = "50")
        private int pageSize;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MemberListRes {
        @Schema(description = "전체 페이지 개수", example = "7")
        private int totalPages = 0;

        @Schema(description = "전체 데이터 개수 (검색된 모든 데이터 항목 수)", example = "100")
        private long totalElements = 0;

        @Schema(description = "회원 목록")
        private List<MemberDetail> memberList = new ArrayList<>();
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MemberDetail {
        @Schema(description = "회원번호" , example = "25031200001")
        @NullToEmptyString
        private String membNo;

        @Schema(description = """
                    회원유형코드
                    00 : 금융기관
                    10 : 법무대리인
                """
                , example = "00")
        @NullToEmptyString
        private String membGbCd;

        @Schema(description = """
                    회원유형명
                    00 : 금융기관
                    10 : 법무대리인
                """
                , example = "금융기관")
        @NullToEmptyString
        private String membGbNm;

        @Schema(description = "상호명" , example = "뱅클신용협동조합")
        @NullToEmptyString
        private String bizNm;

        @Schema(description = "회원명" , example = "홍길동")
        @NullToEmptyString
        private String membNm;

        @Schema(description = "아이디" , example = "honggildong")
        @NullToEmptyString
        private String membId;


        @Schema(description = "가입일" , example = "2025-03-20 17:21:50.000")
        @LocalDateTimeToString
        private LocalDateTime joinDtm;

    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MemberInfoRes {
        private MemberDetailRes member;
        private OfficeDetailRes office;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MemberDetailRes {

        /** 회원 정보 */
        @Schema(description = "회원명" , example = "홍길동")
        @NullToEmptyString
        private String membNm;

        @Schema(description = "회원번호" , example = "25031200001")
        @NullToEmptyString
        private String membNo;

        @Schema(description = "회원유형" , example = "금융기관")
        @NullToEmptyString
        private String membGbNm;

        @Schema(description = "가입일" , example = "2025-03-20 17:21:50.000")
        @NullToEmptyString
        private String joinDtm;

        /** 계정 정보 */
        @Schema(description = "아이디" , example = "test")
        @NullToEmptyString
        private String membId;

        @Schema(description = "비밀번호" , example = "test1234")
        @NullToEmptyString
        private String membPwd;

    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OfficeDetailRes {

        @Schema(description = "사업자등록번호" , example = "test")
        @NullToEmptyString
        private String bizNo;

        @Schema(description = "상호명" , example = "test")
        @NullToEmptyString
        private String bizNm;

        @Schema(description = "대표자명" , example = "test")
        @NullToEmptyString
        private String reptNm;

        @Schema(description = "사업장 소재지" , example = "test")
        @NullToEmptyString
        private String bizAddr;

    }

}
