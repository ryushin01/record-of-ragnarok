package com.bankle.admin.board.ctrl;


import com.bankle.admin.board.svc.BoardSvc;
import com.bankle.admin.board.vo.BoardVo;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


/**
 * 관리자 - 공지관리 컨트롤러
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.19
 */
@Tag(name = "관리자 - 공지관리", description = "관리자 - 공지관리")
@Slf4j
@RestController
@RequiredArgsConstructor
public class BoardCtrl {

    private final BoardSvc boardSvc;

    @Operation(
            summary = "공지사항 목록 조회 API",
            description = """
                    요청 데이터:
                    - 현재 페이지 (pageNum)
                    - 페이지에 보여지는 데이터수 (pageSize)  
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = BoardVo.BoardListRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/admin/board/list")
    public ResponseEntity<?> getBoardlist(@Valid BoardVo.BoardListReq req) throws Exception {
        return ResData.SUCCESS(boardSvc.boardList(req), "공지 목록 조회 성공");
    }


    @Operation(
            summary = "공지사항 수정 정보 조회 API",
            description = """
                    요청 데이터:
                    - 공지사항 일련번호 (seq)
                            
                    참고 사항:
                    - 등록자와 등록일은 로그인한 관리자의 이름과 오늘날짜를 표시하여 주시기 바랍니다.
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = boolean.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/admin/board/modify/{seq}")
    public ResponseEntity<?> getBoardModifyInfo(@PathVariable(name = "seq") String seq) throws Exception {

        return ResData.SUCCESS(boardSvc.getBoardModifyInfo(seq), "조회 성공");

    }


    @Operation(
            summary = "공지사항 리스트 삭제 API",
            description = """
                    요청 데이터:
                    - 공지사항 일련번호 리스트
                            
                    응답 결과:
                    - code 00 / data true  : 삭제 성공
                    - 이외의 응답 : 삭제 실패
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = boolean.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @DeleteMapping(value = "/admin/board/list")
    public ResponseEntity<?> deleteBoardList(@RequestBody List<String> seqs) throws Exception {

        return ResData.SUCCESS(boardSvc.deleteBoardList(seqs), "삭제 성공");

    }


    @Operation(
            summary = "공지사항 등록 API",
            description = """
                        응답 결과:
                        - code 00 / data true  : 등록 성공
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PostMapping(value = "/admin/board", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> saveMatch(
            @Valid @RequestPart() @Parameter(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE), required = true) BoardVo.BoarSaveReq req,
            @RequestPart(value = "multipartFiles", required = false) @Parameter(content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE)) List<MultipartFile> multipartFiles
    ) throws Exception {

        return ResData.SUCCESS(boardSvc.saveBoard(req, multipartFiles), "등록 성공");

    }


    @Operation(
            summary = "공지사항 수정 API",
            description = """
                        응답 결과:
                        - code 00 / data true  : 수정 성공

                        fileInfoList 예시
                        등록 : []
                        수정 : /files/images 파일 조회 응답값

                        "fileInfoList": [
                            {
                              "seq": "2025031200001",
                              "filIdx": 1,
                              "src": "/files/images/dcyt/2025031200001/1",
                              "attcFilNm": "스크린샷 2025-01-14 오후 4.05.12.png",
                              "filSize": 1000
                            },
                            {
                              "seq": "2025031200001",
                              "filIdx": 2,
                              "src": "/files/images/dcyt/2025031200001/2",
                              "attcFilNm": "스크린샷 2025-01-15 오전 10.33.56.png",
                              "filSize": 2000
                            }
                        ]
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PatchMapping(value = "/admin/board", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> modifyMatch(
            @Valid @RequestPart() @Parameter(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE), required = true) BoardVo.BoarModifyReq req,
            @RequestPart(value = "multipartFiles", required = false) @Parameter(content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE)) List<MultipartFile> multipartFiles
    ) throws Exception {

        return ResData.SUCCESS(boardSvc.modifyBoard(req, multipartFiles), "수정 성공");

    }


}
