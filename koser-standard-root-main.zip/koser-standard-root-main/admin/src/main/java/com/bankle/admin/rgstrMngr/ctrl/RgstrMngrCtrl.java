package com.bankle.admin.rgstrMngr.ctrl;


import com.bankle.admin.rgstrMngr.svc.RgstrMngrSvc;
import com.bankle.admin.rgstrMngr.vo.RgstrMngrVo;
import com.bankle.common.config.CommCont;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Tag(name = "관리자 - 등기관리", description = "등기관리")
@Slf4j
@RestController
@RequiredArgsConstructor
public class RgstrMngrCtrl {

    private final RgstrMngrSvc rgstrMngrSvc;

    @Operation(summary = "전자등기 현황 목록", description = "전자등기 현황 목록 조회")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RgstrMngrVo.RgstrMngrListRes.class)))
    })
    @GetMapping(value = "/admin/registration/list")
    public ResponseEntity<?> getList(@Valid RgstrMngrVo.RgstrMngrListReq reqVo) throws Exception {

        RgstrMngrVo.RgstrMngrListRes resVo = rgstrMngrSvc.getList(reqVo);
        return ResData.SUCCESS(resVo, "성공");

    }

    @Operation(summary = "등기자료 상세 조회", description = "등기자료 상세 조회")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RgstrMngrVo.RgstrMngrDetailRes.class)))
    })
    @GetMapping(value = "/admin/registration/detail")
    public ResponseEntity<?> getDetailInfo(@RequestParam String rqstno) throws Exception {
        RgstrMngrVo.RgstrMngrDetailRes resVo = rgstrMngrSvc.getDetailInfo(rqstno);
        return ResData.SUCCESS(resVo, "성공");
    }

    @Operation(summary = "등기자료 정보 조회", description = "등기자료 정보 조회")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RgstrMngrVo.RgstrMngrDataRes.class)))
    })
    @GetMapping(value = "/admin/registration/data")
    public ResponseEntity<?> getDataInfo(@RequestParam String rqstno) throws Exception {

        RgstrMngrVo.RgstrMngrDataRes resVo = rgstrMngrSvc.getDataInfo(rqstno);
        return ResData.SUCCESS(resVo, "성공");

    }

    @Operation(summary = "등기접수증 정보 조회", description = "등기접수증 정보 조회")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RgstrMngrVo.RgstrMngrAcceptRes.class)))
    })
    @GetMapping(value = "/admin/registration/accept")
    public ResponseEntity<?> getAcceptInfo(@RequestParam String rqstno) throws Exception {

        RgstrMngrVo.RgstrMngrAcceptRes resVo = rgstrMngrSvc.getAcceptInfo(rqstno);
        return ResData.SUCCESS(resVo, "성공");

    }

    @Operation(summary = "등기접수 정보 등록 조회", description = "등기접수 정보 등록 조회")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = RgstrMngrVo.RgstrMngrRes.class)))
    })
    @GetMapping(value = "/admin/registration/info")
    public ResponseEntity<?> getRgstrInfo(@RequestParam String rqstno) throws Exception {

        RgstrMngrVo.RgstrMngrRes resVo = rgstrMngrSvc.getRgstrInfo(rqstno);
        return ResData.SUCCESS(resVo, "성공");

    }

    @Operation(summary = "의뢰번호 검색", description = "의뢰번호 검색")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = Boolean.class)))
    })
    @GetMapping(value = "/admin/registration/search")
    public ResponseEntity<?> getSearch(@RequestParam @Size(min = 13, max=13, message = "의뢰번호 전체를 입력해주세요.") String rqstno) throws Exception {

        boolean result = rgstrMngrSvc.getSearch(rqstno);
        return ResData.SUCCESS(result, "성공");

    }

    @Operation(summary = "보완요청", description = "관리자 보완요청")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PatchMapping(value = "/admin/registration/supplementation")
    public ResponseEntity<?> supplementation(@RequestBody RgstrMngrVo.RgstrMngrStatReq reqVo) throws Exception {

        rgstrMngrSvc.updateRgstrState(reqVo, CommCont.RGSTR_STAT_SPLMT);
        return ResData.SUCCESS("00", "성공");

    }

    @Operation(summary = "진행취소", description = "관리자 진행취소")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PatchMapping(value = "/admin/registration/cancel")
    public ResponseEntity<?> cancel(@RequestBody RgstrMngrVo.RgstrMngrStatReq reqVo) throws Exception {

        rgstrMngrSvc.updateRgstrState(reqVo, CommCont.RGSTR_STAT_CNCL);
        return ResData.SUCCESS("00", "성공");

    }

    @Operation(summary = "승인하기", description = "관리자 승인처리")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PatchMapping(value = "/admin/registration/approval")
    public ResponseEntity<?> approval(@RequestBody RgstrMngrVo.RgstrMngrStatReq reqVo) throws Exception {

        rgstrMngrSvc.updateRgstrState(reqVo, CommCont.RGSTR_STAT_CMPT);
        return ResData.SUCCESS("00", "성공");

    }

    @Operation(summary = "반려하기", description = "관리자 반려처리")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PatchMapping(value = "/admin/registration/reject")
    public ResponseEntity<?> reject(@RequestBody RgstrMngrVo.RgstrMngrStatReq reqVo) throws Exception {

        rgstrMngrSvc.updateRgstrState(reqVo, CommCont.RGSTR_STAT_RTRN);
        return ResData.SUCCESS("00", "성공");

    }

    @Operation(summary = "등기접수 정보 등록",
            description = """
                등기접수 정보 등록

                imageInfo 예시
                등록 : []
                수정 : /files/images 파일 조회 응답값

                "imageInfo": [
                    {
                      "seq": "2025031200001",
                      "filIdx": 1,
                      "src": "/files/images/dcyt/2025031200001/1",
                      "attcFilNm": "스크린샷 2025-01-14 오후 4.05.12.png",
                      "filSize": 1000
                    },
                    {
                      "seq": "2025031200001",
                      "filIdx": 2,
                      "src": "/files/images/dcyt/2025031200001/2",
                      "attcFilNm": "스크린샷 2025-01-15 오전 10.33.56.png",
                      "filSize": 2000
                    }
                ]
            """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PostMapping(value = "/admin/registration/accept", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.APPLICATION_JSON_VALUE}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> updateAccept(
            @Valid @RequestPart() @Parameter(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE), required = true) RgstrMngrVo.RgstrMngrReq reqVo,
            @RequestPart(value = "multipartFiles", required = false) @Parameter(content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE)) List<MultipartFile> multipartFiles
    ) throws Exception {

        rgstrMngrSvc.updateAccept(reqVo, multipartFiles);
        return ResData.SUCCESS("00", "성공");

    }

}
