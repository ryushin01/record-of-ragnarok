package com.bankle.admin.rgstrMngr.vo;

import com.bankle.common.annotation.DateFormatString;
import com.bankle.common.annotation.LocalDateTimeToString;
import com.bankle.common.annotation.NullToEmptyString;
import com.bankle.common.commSvc.vo.ImageVo;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 관리자 - 등기관리 I/O
 *
 * @author leh
 * @version 1.0
 * @since 2025.03.18
 */
public class RgstrMngrVo {

    @Getter
    @Setter
    public static class RgstrMngrListReq {

        @Schema(description = """
                tab 선택 -
                 '' : 전체,
                20 : 배정완료,
                30 : 대출실행,
                40 : 접수검토중,
                50 : 접수반려,
                60 : 접수완료,
                70 : 진행취소,
                80 : 진행보류""", example = "20")
        private String tabSelection;

        @Min(value = 1, message = "현재 페이지는 1 이상이어야 합니다.")
        @Schema(description = "현재 페이지", example = "1")
        private int pageNum;

        @Min(value = 1, message = "페이지에 보여지는 데이터 수는 1 이상이어야 합니다.")
        @Schema(description = "페이지에 보여지는 데이터수", example = "50")
        private int pageSize;

        @Schema(description = "의뢰번호", example = "2025031200001")
        private String searchRqstNo;

        @Schema(description = "검색일 구분(대출실행일:EXEC, 의뢰일:RQST, 설정약정일:STEF )", example = "EXEC")
        @Size(min = 4, max = 4, message = "검색일 구분이 올바르지 않습니다.")
        private String searchType;

        @Schema(description = "검색 시작일", example = "20250312")
        private String fromDate;

        @Schema(description = "검색 종료일", example = "20250312")
        private String toDate;

        @Size(min = 2, max = 2, message = "정렬은 필수 값 입니다.")
        @Schema(description = "정렬(00:의뢰일순, 01:대출실행일 순)", example = "00")
        private String sortOrder;

    }

    @Getter
    @Setter
    @Builder
    public static class RgstrMngrListRes {
        @Schema(description = "전체 페이지 개수", example = "7")
        private int totalPages;

        @Schema(description = "전체 데이터 개수 (검색된 모든 데이터 항목 수)", example = "100")
        private long totalElements;

        @Schema(description = "전자등기 진행상태별 집계")
        private RgstrStatistics rgstrStatistics;

        @Schema(description = "전자등기 현황 목록")
        private List<RgstrMngrInfo> rgstrMngrList;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RgstrStatistics {
        @Schema(description = "전체", example = "400")
        private long total;

        @Schema(description = "등기의뢰", example = "50")
        private long rqst;

        @Schema(description = "배정완료", example = "50")
        private long mtchCmpt;

        @Schema(description = "대출실행", example = "50")
        private long loanExec;

        @Schema(description = "접수검토중", example = "50")
        private long rqstProg;

        @Schema(description = "접수반려", example = "50")
        private long rqstRtun;

        @Schema(description = "접수완료", example = "50")
        private long rqstCmpt;

        @Schema(description = "진행보류", example = "50")
        private long progHold;

        @Schema(description = "진행취소", example = "50")
        private long progCncl;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RgstrMngrInfo {

        @Schema(description = "진행 상태 명", example = "등기의뢰")
        @NullToEmptyString
        private String statNm;

        @Schema(description = "대출 실행일", example = "2025-03-14")
        @DateFormatString
        private String execDt;

        @Schema(description = "접수보고일시", example = "2023-12-19")
        @LocalDateTimeToString(pattern = "yyyy-MM-dd")
        private LocalDateTime acptRptDtm;

        @Schema(description = "의뢰번호", example = "1234567890")
        @NullToEmptyString
        private String rqstNo;

        @Schema(description = "채권자명", example = "홍길동")
        @NullToEmptyString
        private String bndMembNm;

        @Schema(description = "채무자명", example = "홍길동")
        @NullToEmptyString
        private String dbtrNm;

        @Schema(description = "법무대리인", example = "홍길동법무법인")
        @NullToEmptyString
        private String lgagMembNm;

        @Schema(description = """
                진행상태 코드 - 
                 00 : 등기의뢰,
                10 : 보안필요,
                20 : 배정완료,
                30 : 대출실행,
                40 : 접수검토중,
                50 : 접수반려,
                60 : 접수완료,
                70 : 진행취소,
                80 : 진행보류""", example = "00")
        @NullToEmptyString
        private String statCd;

    }

    @Getter
    @Setter
    @Schema(description = "등기관리 상세")
    public static class RgstrMngrDetailRes {

        @Schema(description = "지번", example = "서울시")
        @NullToEmptyString
        private String lotnumAddr;

        @Schema(description = "도로명", example = "서울시")
        @NullToEmptyString
        private String rdnmAddr;

        @Schema(description = "상세주소(동)", example = "101")
        @NullToEmptyString
        private String bldg;

        @Schema(description = "상세주소(호)", example = "11")
        @NullToEmptyString
        private String unit;

        @Schema(description = "고유번호", example = "1234-5678-1223123")
        @NullToEmptyString
        private String unqRgstrNo;

        @Schema(description = "금융기관(채권자명)", example = "성북신협")
        @NullToEmptyString
        private String bndMembNm;

        @Schema(description = "금융기관 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String bndMembHpno;

        @Schema(description = "법무대리인", example = "홍길동법무법인")
        @NullToEmptyString
        private String lgagMembNm;

        @Schema(description = "법무대리인 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String lgagMembHpno;

        @Schema(description = "시스템관리자", example = "김뱅클")
        @NullToEmptyString
        private String mngrMembNm;

        @Schema(description = "시스템관리자 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String mngrMembHpno;

        @Schema(description = "의뢰번호", example = "2025031200001")
        private String rqstNo = "";

        @Schema(description = "채무자명", example = "홍길동")
        @NullToEmptyString
        private String dbtrNm;

        @Schema(description = "설정약정일", example = "2025-03-12")
        @DateFormatString
        private String seDt;

        @Schema(description = "대출실행일", example = "2025-03-12")
        @DateFormatString
        private String execDt;

        @Schema(description = "채권최고액", example = "0")
        private BigDecimal bndMaxAmt = BigDecimal.valueOf(0);

        @Schema(description = "관할법원", example = "광주지방법원")
        @NullToEmptyString
        private String judtCourtNm;

        @Schema(description = "등기소", example = "무안등기소")
        @NullToEmptyString
        private String regrNm;

        @Schema(description = "접수번호", example = "45360")
        @NullToEmptyString
        private String acptNo;

        @Schema(description = "등기접수 조회결과", example = "Y")
        @NullToEmptyString
        private String rgstrAcptYn;

        @Schema(description = """
                진행상태 코드 -
                 00 : 등기의뢰,
                10 : 보안필요,
                20 : 배정완료,
                30 : 대출실행,
                40 : 접수검토중,
                50 : 접수반려,
                60 : 접수완료,
                70 : 진행취소,
                80 : 진행보류""", example = "00")
        @NullToEmptyString
        private String statCd;

        @Schema(description = "문서 리스트")
        private List<RgstrDoc> docList;

        @Schema(description = "진행이력 리스트")
        private List<RgstrStatHist> statHistList;

    }

    @Getter
    @Setter
    @Builder
    @Schema(description = "등기관리 상세 - 문서")
    public static class RgstrDoc {

        @Schema(description = "구분", example = "등기자료")
        @NullToEmptyString
        private String kind;

        @Schema(description = "처리자", example = "관리자")
        @NullToEmptyString
        private String crtMembNm;

        @Schema(description = "처리일시", example = "2025-01-01 14:01:05")
        @LocalDateTimeToString
        private LocalDateTime crtDtm;

    }

    @Getter
    @Setter
    @Schema(description = "등기관리 상세 - 진행이력")
    public static class RgstrStatHist {

        @Schema(description = "진행상태명", example = "등기의뢰")
        @NullToEmptyString
        private String statNm;

        @Schema(description = "내용", example = "문서 보완 필요합니다.")
        @NullToEmptyString
        private String procRsnCnts;

        @Schema(description = "구분(처리자)", example = "관리자")
        @NullToEmptyString
        private String crtMembNm;

        @Schema(description = "처리일시", example = "2025-01-01 14:01:05")
        @LocalDateTimeToString
        private LocalDateTime crtDtm;

    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RgstrMngrDataRes {
        @Schema(description = "지번", example = "서울시")
        @NullToEmptyString
        private String lotnumAddr;

        @Schema(description = "도로명", example = "서울시")
        @NullToEmptyString
        private String rdnmAddr;

        @Schema(description = "상세주소(동)", example = "101")
        @NullToEmptyString
        private String bldg;

        @Schema(description = "상세주소(호)", example = "11")
        @NullToEmptyString
        private String unit;

        @Schema(description = "의뢰번호", example = "2025031200001")
        private String rqstNo = "";

        @Schema(description = "채무자명", example = "홍길동")
        @NullToEmptyString
        private String dbtrNm;

        @Schema(description = "설정약정일", example = "2025-03-12")
        @DateFormatString
        private String seDt;

        @Schema(description = "대출실행일", example = "2025-03-12")
        @DateFormatString
        private String execDt;

        @Schema(description = "채권최고액", example = "0")
        private BigDecimal bndMaxAmt = BigDecimal.valueOf(0);

        @Schema(description = "금융기관", example = "성북신협")
        @NullToEmptyString
        private String bndMembNm;

        @Schema(description = "금융기관 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String bndMembHpno;

        @Schema(description = "법무대리인", example = "홍길동법무법인")
        @NullToEmptyString
        private String lgagMembNm;

        @Schema(description = "법무대리인 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String lgagMembHpno;

        @Schema(description = "시스템관리자", example = "김뱅클")
        @NullToEmptyString
        private String mngrMembNm;

        @Schema(description = "시스템관리자 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String mngrMembHpno;

        @Schema(description = "전달사항", example = "법무대리인에게 전달사항")
        @NullToEmptyString
        private String lgagDlvrCnts;
    }

    @Getter
    @Setter
    public static class RgstrMngrAcceptRes {

        @Schema(description = "지번", example = "서울시")
        @NullToEmptyString
        private String lotnumAddr;

        @Schema(description = "도로명", example = "서울시")
        @NullToEmptyString
        private String rdnmAddr;

        @Schema(description = "상세주소(동)", example = "101")
        @NullToEmptyString
        private String bldg;

        @Schema(description = "상세주소(호)", example = "11")
        @NullToEmptyString
        private String unit;

        @Schema(description = "고유번호", example = "1234-5678-1223123")
        @NullToEmptyString
        private String unqRgstrNo;

        @Schema(description = "의뢰번호", example = "2025031200001")
        private String rqstNo = "";

        @Schema(description = "채무자명", example = "홍길동")
        @NullToEmptyString
        private String dbtrNm;

        @Schema(description = "대출실행일", example = "20250312")
        @DateFormatString
        private String execDt;

        @Schema(description = "관할법원", example = "광주지방법원")
        @NullToEmptyString
        private String judtCourtNm;

        @Schema(description = "등기소", example = "무안등기소")
        @NullToEmptyString
        private String regrNm;

        @Schema(description = "접수번호", example = "45360")
        @NullToEmptyString
        private String acptNo;

        @Schema(description = "등기접수 조회결과", example = "Y")
        @NullToEmptyString
        private String rgstrAcptYn;

        @Schema(description = "금융기관", example = "성북신협")
        @NullToEmptyString
        private String bndMembNm;

        @Schema(description = "금융기관 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String bndMembHpno;

        @Schema(description = "법무대리인", example = "홍길동법무법인")
        @NullToEmptyString
        private String lgagMembNm;

        @Schema(description = "법무대리인 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String lgagMembHpno;

        @Schema(description = "시스템관리자", example = "김뱅클")
        @NullToEmptyString
        private String mngrMembNm;

        @Schema(description = "시스템관리자 연락처", example = "02-245-6785")
        @NullToEmptyString
        private String mngrMembHpno;

        @Schema(description = "전달사항", example = "관리자에게 전달사항")
        @NullToEmptyString
        private String mngrDlvrCnts;

    }

    @Getter
    @Setter
    public static class RgstrMngrReq {

        @Schema(description = "의뢰번호", example = "2025031200001")
        @Size(min = 13, max = 13, message = "의뢰번호 13자리가 일치하지 않습니다.")
        private String rqstNo;

        @Schema(description = "관할법원 코드", example = "11")
        @NotEmpty(message = "관할법원을 선택하세요.")
        private String judtCourtCd;

        @Schema(description = "등기소 코드", example = "1101")
        @NotEmpty(message = "등기소를 선택하세요.")
        private String regrCd;

        @Schema(description = "접수번호", example = "45360")
        @NotEmpty(message = "접수번호를 입력하세요.")
        private String acptNo;

//        @Schema(description = "접수번호 조회여부", example = "Y")
//        @NotEmpty(message = "접수번호 조회결과가 없습니다.")
//        private String rgstrAcptYn;

        @Schema(description = "전달사항", example = "관리자에게 전달사항")
        private String mngrDlvrCnts;

        @Schema(description = "이미지 리스트", example = "[]")
        List<ImageVo.ImageInfo> imageInfo;

    }



    @Getter
    @Setter
    public static class RgstrMngrRes {

        @Schema(description = "의뢰번호", example = "2025031200001")
        private String rqstNo;

        @Schema(description = "채무자명", example = "홍길동")
        @NullToEmptyString
        private String dbtrNm;

        List<ImageVo.ImageInfo> fileList;

        @Schema(description = "관할법원 코드", example = "11")
        @NullToEmptyString
        private String judtCourtCd;

        @Schema(description = "등기소 코드", example = "1101")
        @NullToEmptyString
        private String regrCd;

        @Schema(description = "접수번호", example = "45360")
        @NullToEmptyString
        private String acptNo;

        @Schema(description = "전달사항", example = "관리자에게 전달사항")
        @NullToEmptyString
        private String mngrDlvrCnts;

        @Schema(description = """
                진행상태 코드 -
                 00 : 등기의뢰,
                10 : 보안필요,
                20 : 배정완료,
                30 : 대출실행,
                40 : 접수검토중,
                50 : 접수반려,
                60 : 접수완료,
                70 : 진행취소,
                80 : 진행보류""", example = "00")
        @NullToEmptyString
        private String statCd;

        @Schema(description = "반려사유", example = "반려사유")
        @NullToEmptyString
        private String procRsnCnts;

    }

    @Getter
    @Setter
    public static class RgstrMngrStatReq {

        @Schema(description = "의뢰번호", example = "1234567891234")
        @Size(min = 13, max = 13, message = "의뢰번호 13자리가 일치하지 않습니다.")
        public String rqstNo;

        @Schema(description = "처리사유", example = "처리사유")
        public String procRsnCnts;

    }

}