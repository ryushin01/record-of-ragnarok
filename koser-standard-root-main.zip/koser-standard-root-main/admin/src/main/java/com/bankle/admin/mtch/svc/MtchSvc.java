package com.bankle.admin.mtch.svc;


import com.bankle.admin.mtch.dao.MtchDao;
import com.bankle.admin.mtch.vo.MtchVo;
import com.bankle.common.code.svc.CommSvc;
import com.bankle.common.commSvc.CommonSvc;
import com.bankle.common.commSvc.FileSvc;
import com.bankle.common.dto.TbCustMasterDto;
import com.bankle.common.dto.TbOfficeMasterDto;
import com.bankle.common.dto.TbRgstrMasterDto;
import com.bankle.common.dto.TbRgstrStatHistDto;
import com.bankle.common.entity.TbCustMaster;
import com.bankle.common.entity.TbOfficeMaster;
import com.bankle.common.entity.TbRgstrMaster;
import com.bankle.common.exception.BadRequestException;
import com.bankle.common.mapper.TbCustMasterMapper;
import com.bankle.common.mapper.TbOfficeMasterMapper;
import com.bankle.common.mapper.TbRgstrMasterMapper;
import com.bankle.common.mapper.TbRgstrStatHistMapper;
import com.bankle.common.repo.*;
import com.bankle.common.userAuth.UserAuthSvc;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.StringUtil;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.*;

/**
 * 관리자 - 배정관리 서비스
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.13
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class MtchSvc {

    private final TbRgstrMasterRepository tbRgstrMasterRepository;
    private final TbRgstrStatHistRepository tbRgstrStatHistRepository;
    private final CustomeModelMapper modelMapper;
    private final CommSvc commSvc;
    private final TbCustMasterRepository tbCustMasterRepository;
    private final TbOfficeMasterRepository tbOfficeMasterRepository;
    private final TbCommCodeRepository tbCommCodeRepository;
    private final CommonSvc commonSvc;
    private final FileSvc fileSvc;
    private final MtchDao mtchDao;


    /**
     * 배정 리스트 조회
     *
     * @param : MtchVo.MtchListReq
     * @return : MtchVo.MtchListRes
     */
    @Transactional
    public MtchVo.MtchListRes mtchList(MtchVo.MtchListReq req) throws Exception {

           /*
            미배정(00): 배정되기 전 (등기의뢰, 보완필요 상태)
            배정완료(01): 배정된 후 (배정완료, 대출실행, 접수검토중, 접수반려, 접수완료)
            진행보류(02): 진행보류된 후 (진행보류)
            진행취소(03): 진행취소된 후 (진행취소)
           */
            List<String> statCds = switch (req.getTabSelection()) {
                case "00" -> Arrays.asList("00", "10"); //미배정
                case "01" -> Arrays.asList("20", "30", "40", "50", "60"); //미배정, 배정완료
                case "02" -> List.of("80"); //미배정 진행보류
                case "03" -> List.of("70"); // 미배정 진행취소
                default -> throw new BadRequestException("존재하지 않는 Tap 메뉴 입니다.");
            };


            if (!Set.of("00", "01").contains(req.getSortOrder())) {
                throw new BadRequestException("존재하지 않는 정렬 방식입니다.");
            }

            //sortOrder 정렬기준 => 00:의뢰일순, 01:대출실행일 순
            Sort sort = "00".equals(req.getSortOrder()) ? Sort.by(Sort.Direction.DESC, "crtDtm") :  Sort.by(Sort.Direction.DESC, "execDt");
            Pageable pageable = PageRequest.of(req.getPageNum() -1, req.getPageSize() , sort);

            //원장 페이징 조회
            Page<TbRgstrMaster> allList;

            if (StringUtils.hasText(req.getSearchRqstNo())) {
                // rqstNo가 유효한 경우에만 LIKE 조건으로 조회
                allList = tbRgstrMasterRepository.findByStatCdInAndRqstNoContaining(statCds, req.getSearchRqstNo(), pageable);
            } else {
                // rqstNo가 공백이거나 빈 문자열이면 rqstNo 조건 없이 조회
                allList = tbRgstrMasterRepository.findByStatCdIn(statCds, pageable);
            }

            //미배정건 카운트 조회
            long unMtchCnt = tbRgstrMasterRepository.countByStatCdIn(Arrays.asList("00", "10"));

            MtchVo.MtchListRes resVo = MtchVo.MtchListRes.builder()
                    .totalPages(allList.getTotalPages())
                    .totalElements(allList.getTotalElements())
                    .unMtchCnt(unMtchCnt)
                    .build();

            if(allList.getTotalElements() == 0) {
                resVo.setMtchList(new ArrayList<>());
                return resVo;
            }

            List<TbRgstrMasterDto> mtchDtoList = TbRgstrMasterMapper.INSTANCE.toDtoList(allList.getContent());

            List<MtchVo.MtchInfo> mtchList  = new ArrayList<>();

            // 공통코드 조회
            List<String> multiGprCd = List.of("PROC_STAT_CD");
            Map<String, Map<String, String>> codeMap = commSvc.searchCommCodeMultiList(multiGprCd);

            for (TbRgstrMasterDto masterDto : mtchDtoList) {
                //의뢰자정보
                var clientInfo = getMembInfo(masterDto.getCrtMembNo());
                // 채권자 정보
                TbOfficeMasterDto bndInfo;
                try {
                    bndInfo = commonSvc.getTbOfficeDto(masterDto.getBndBizNo());
                }catch (Exception e){
                    bndInfo = new TbOfficeMasterDto();
                }
                mtchList.add(
                        MtchVo.MtchInfo.builder()
                                .statNm(StringUtil.isNullOrEmpty(codeMap.get("PROC_STAT_CD").get(masterDto.getStatCd())))
                                .statCd(masterDto.getStatCd())
                                .rqstNo(masterDto.getRqstNo())
                                .execDt(masterDto.getExecDt())
                                .clientNm(clientInfo.getMembNm())
                                .clientMembNo(masterDto.getCrtMembNo())
                                .bndNm(bndInfo.getBizNm())
                                .bndBizNo(masterDto.getBndBizNo())
                                .dbtrNm(masterDto.getDbtrNm())
                                .crtDtm(masterDto.getCrtDtm())
                                .mtchDtm(masterDto.getMtchDtm())
                                .build()
                );
            }

            resVo.setMtchList(mtchList);

            return resVo;

    }

    public TbCustMasterDto getMembInfo(String membNo) throws Exception {
        TbCustMasterDto dto = new TbCustMasterDto();
            if(StringUtils.hasText(membNo) && membNo.length() == 11) {
                dto = TbCustMasterMapper.INSTANCE.toDto(
                        tbCustMasterRepository.findByMembNo(membNo)
                                .orElseThrow(() -> new EntityNotFoundException("회원정보가 존재하지 않습니다.")));

            }
        return dto;
    }


    /**
     * 배정 등록 서비스
     *
     * @param req           MtchVo.SaveMtchReq - 배정 요청 정보
     * @param multipartFiles List<MultipartFile> - 첨부 파일 목록
     * @param isNewSave      boolean - 신규 등록 여부
     * @return String - 처리 결과 코드
     * 처리 결과:
     * - 신규 등록일 경우:
     *   - "00" : 배정 성공
     *   - "01" : 등기자료 이미지를 등록해 주세요.
     *   - "02" : 이미 등록된 의뢰 번호 입니다.
     * - 일반 배정일 경우:
     *   - "00" : 배정 성공
     *   - "01" : 의뢰 정보가 존재하지 않습니다.
     *   - "02" : 이미 배정된 의뢰입니다.
     */
    @Transactional
    public String saveMtch(MtchVo.SaveMtchReq req, List<MultipartFile> multipartFiles , boolean isNewSave) throws Exception {

        // 조회
        var rgstrMaster = tbRgstrMasterRepository.findByRqstNo(req.getRqstNo());

        TbRgstrMasterDto rgstrMasterDto;

        if (isNewSave) { //신규 등록&배정
            if(multipartFiles == null || multipartFiles.isEmpty()){
                log.error("등기자료 이미지를 등록해 주세요.");
                return "01";
            }
            if(rgstrMaster.isPresent()){
                log.error("이미 등록된 의뢰 번호 입니다.");
                return "02";
            }
            rgstrMasterDto = modelMapper.mapping(req, TbRgstrMasterDto.class);
        } else { //일반 배정
            if (rgstrMaster.isEmpty()) {
                log.error("의뢰 정보가 존재하지 않습니다.");
                return "01";
            }

            rgstrMasterDto = TbRgstrMasterMapper.INSTANCE.toDto(rgstrMaster.get());

            if(Arrays.asList("20","30","40","50","60").contains(rgstrMasterDto.getStatCd())){
                log.error("이미 배정된 의뢰건 입니다.");
                return "02";
            }

            rgstrMasterDto.setDbtrNm(req.getDbtrNm());            // 채무자 명 설정
            rgstrMasterDto.setRealeCd(req.getRealeCd());          // 부동산구분 코드 설정 (2자리)
            rgstrMasterDto.setLotnumAddr(req.getLotnumAddr());    // 지번주소 설정
            rgstrMasterDto.setRdnmAddr(req.getRdnmAddr());        // 도로명주소 설정
            rgstrMasterDto.setLotnumAddrCd(req.getLotnumAddrCd()); // 지번주소 코드 설정
            rgstrMasterDto.setBldg(req.getBldg());                // 건물 동 설정
            rgstrMasterDto.setUnit(req.getUnit());                // 건물 호 설정
            rgstrMasterDto.setUnqRgstrNo(req.getUnqRgstrNo());    // 등기고유번호 설정 (14자리)
            rgstrMasterDto.setBndMaxAmt(req.getBndMaxAmt());      // 채권최고액 설정 (0보다 큰 값)
            rgstrMasterDto.setSeDt(req.getSeDt());                // 설정약정일 설정 (8자리)
            rgstrMasterDto.setLgagMembNo(req.getLgagMembNo());    // 법무대리인 회원번호 설정 (11자리)
            rgstrMasterDto.setLgagDlvrCnts(req.getLgagDlvrCnts()); // 법무대리인에게 전달사항 설정
        }

        // 제출 담당자 회원번호 설정 (11자리)
        rgstrMasterDto.setMngrMembNo(UserAuthSvc.getMembNo());
        //배정완료 상태로코드로 업데이트
        rgstrMasterDto.setStatCd("20");
        //배정 일시
        rgstrMasterDto.setMtchDtm(LocalDateTime.now());

        // 추가 혹은 신규등록한 이미지가 있다면 저장한다.
        if (multipartFiles != null && !multipartFiles.isEmpty()) {
            String imageSeq = fileSvc.crtImages(multipartFiles, "01", rgstrMasterDto.getRgstrDataFilSeq());
            rgstrMasterDto.setRgstrDataFilSeq(imageSeq);
        }


        //원장 테이블 저장
        tbRgstrMasterRepository.save(TbRgstrMasterMapper.INSTANCE.toEntity(rgstrMasterDto));


        // 등기이력 상태 저장
        tbRgstrStatHistRepository.save(TbRgstrStatHistMapper.INSTANCE.toEntity(TbRgstrStatHistDto.builder()
                .rqstNo(rgstrMasterDto.getRqstNo())
                .statCd(rgstrMasterDto.getStatCd())
                .build()));


        // 성공 응답 반환
        return "00";
    }


    /**
     * 배정 의뢰 정보 조회 서비스
     *
     * @param : rqstno 의뢰번호
     * @return : MtchVo.MtchInfoRes
     */
    @Transactional
    public MtchVo.MtchInfoRes getMtchInfo(String rqstno) throws Exception {

        var rgstrMasterDto = commonSvc.getRgstrMastrDto(rqstno);

        var res = modelMapper.mapping(rgstrMasterDto, MtchVo.MtchInfoRes.class);

        // 채권자 정보
        var bndInfo = commonSvc.getTbOfficeDto(res.getBndBizNo());
        // 채권자 이름
        res.setBndNm(bndInfo.getBizNm());;

        return res;
    }


    /**
     * 회원구분에 따른 회원 목록 조회
     *
     * @param : 회원유형 구분코드
     * @return : List<MtchVo.MemberInfo>
     */
    @Transactional
    public List<MtchVo.MemberInfo> getMemberList(String membGb) throws Exception {

        //00 : 금융기관, 10 : 법무대리인, 20 : 관리자
        if(!tbCommCodeRepository.existsById_CodeAndId_GrpCdAndUseYn(membGb , "MEMB_GB_CD" , "Y")){
            throw new BadRequestException("존재하지 않는 회원 유형입니다.");
        }

        List<MtchVo.MemberInfo> res = new ArrayList<>();

        //금
        if ("00".equals(membGb)) {
            //승인된 금융기관 사무소정보 리스트를 가져온다.
            List<TbOfficeMaster> tbOfficeMasters = tbOfficeMasterRepository.findByBizGbCdAndStatCd("00","10");
            if (!CollectionUtils.isEmpty(tbOfficeMasters)) {
                res = TbOfficeMasterMapper.INSTANCE.toDtoList(tbOfficeMasters).stream().map(data -> MtchVo.MemberInfo.builder().bizNo(data.getBizNo()).bizNm(data.getBizNm()).build()).toList();
            }
        } else {
            List<TbCustMaster> custMasters = tbCustMasterRepository.findByMembGbCdAndStatCd(membGb, "10");
            if (!CollectionUtils.isEmpty(custMasters)) {
                res = TbCustMasterMapper.INSTANCE.toDtoList(custMasters).stream().map(data -> MtchVo.MemberInfo.builder().membNo(data.getMembNo()).membNm(data.getMembNm()).build()).toList();
            }
        }


        return res;
    }





}
