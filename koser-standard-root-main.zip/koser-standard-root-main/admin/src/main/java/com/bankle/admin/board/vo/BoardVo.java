package com.bankle.admin.board.vo;

import com.bankle.common.annotation.LocalDateTimeToString;
import com.bankle.common.annotation.NullToEmptyString;
import com.bankle.common.annotation.YNToBoolean;
import com.bankle.common.commSvc.vo.ImageVo;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 관리자 - 공지관리 서비스
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.19
 */
public class BoardVo {

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BoardListReq {
        @Min(value = 1, message = "현재 페이지는 1 이상이어야 합니다.")
        @Schema( description = "현재 페이지" , example = "1")
        private int pageNum;

        @Min(value = 1, message = "페이지에 보여지는 데이터 수는 1 이상이어야 합니다.")
        @Schema( description = "페이지에 보여지는 데이터수" , example = "50")
        private int pageSize;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BoardListRes {
        @Schema(description = "전체 페이지 개수", example = "7")
        private int totalPages = 0;

        @Schema(description = "전체 데이터 개수 (검색된 모든 데이터 항목 수)", example = "100")
        private long totalElements = 0;

        @Schema(description = "공지 리스트")
        private List<BoardInfo> boardList = new ArrayList<>();
    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BoardInfo{

        @Schema( description = "공지사항 일련번호" , example = "2025031900001")
        @NullToEmptyString
        private String seq;

//        @Schema( description = "공지사항 순번" , example = "45")
//        long num = 0;

        @Schema( description = "공지사항 제목" , example = "제목")
        @NullToEmptyString
        private String boardTitle;

        @Schema( description = "공지사항 내용" , example = "내용 입니다.")
        @NullToEmptyString
        private String boardContents;

        @Schema(description = "긴급 여부", example = "false")
        @YNToBoolean
        private String emcyYn;

        @Schema(description = "작성자 명", example = "false")
        @NullToEmptyString
        private String writerNm;

        @Schema( description = "등록일" , example = "2025.03.19")
        @LocalDateTimeToString(pattern = "yyyy.MM.dd")
        private LocalDateTime chgDtm ;

        @Schema(description = "첨부파일 정보 리스트")
        private List<fileInfo> fileInfoList = new ArrayList<>();
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class fileInfo{
        @Schema( description = "첨부파일 일련번호" , example = "2025031300002")
        @NullToEmptyString
        private String seq;

        @Schema( description = "파일 순번" , example = "1")
        private Integer filIdx = 0;

        @Schema( description = "파일 이름" , example = "파일이름.png")
        @NullToEmptyString
        private String attcFilNm;

        @Schema( description = "파일 사이즈" , example = "400")
        private Long filSize;

    }



    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BoardModifyInfoRes{

        @Schema( description = "공지사항 일련번호" , example = "2025031900001")
        @NullToEmptyString
        private String seq;

        @Schema( description = "공지사항 제목" , example = "제목")
        @NullToEmptyString
        private String boardTitle;

        @Schema(description = "공지사항 내용" , example = "내용 입니다.")
        @NullToEmptyString
        private String boardContents;

        @Schema(description = "긴급 여부", example = "false")
        @YNToBoolean
        private String emcyYn;

        @Schema(description = "첨부파일 정보 리스트")
        private List<fileInfo> fileInfoList = new ArrayList<>();
    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BoarSaveReq{

        @Schema( description = "공지사항 제목" , example = "제목")
        @Size(min = 1 , max = 100 , message = "공지사항 제목을 입력해 주세요.")
        private String boardTitle;

        @Schema(description = "공지사항 내용" , example = "내용 입니다.")
        @Size(min = 1 , message = "공지사항 내용을 입력해 주세요.")
        private String boardContents;

        @Schema(description = "긴급 여부", example = "false")
        @NotNull(message = "긴급 여부를 입력해 주세요.")
        private boolean emcyYn;

    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BoarModifyReq{

        @Schema( description = "공지사항 일련번호" , example = "2025031900001")
        @Size(min = 13 , max = 13, message = "공지사항 일련번호는 13자리 입니다.")
        private String seq;

        @Schema( description = "공지사항 제목" , example = "제목")
        @Size(min = 1 , max = 100 , message = "공지사항 제목을 입력해 주세요.")
        private String boardTitle;

        @Schema(description = "공지사항 내용" , example = "내용 입니다.")
        @Size(min = 1 , message = "공지사항 내용을 입력해 주세요.")
        private String boardContents;

        @Schema(description = "긴급 여부", example = "false")
        @NotNull(message = "긴급 여부를 입력해 주세요.")
        private boolean emcyYn;

        @Schema(description = "파일 리스트", example = "[]")
        private List<ImageVo.ImageInfo> fileInfoList;

    }





}
