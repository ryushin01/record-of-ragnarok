package com.bankle.admin.mtch.vo;

import com.bankle.common.annotation.DateFormatString;
import com.bankle.common.annotation.LocalDateTimeToString;
import com.bankle.common.annotation.NullToEmptyString;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 관리자 - 배정관리 서비스
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.13
 */
public class MtchVo {

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MtchListReq {
        @Size(max = 13)
        @Schema(description = "검색 의뢰번호", example = "2025031200001")
        private String searchRqstNo;

        @Size(min = 2 , max = 2 , message = "tap 구분 값은 필수 값 입니다.")
        @Schema(description = "tap 선택", example = "00")
        private String tabSelection;

        @Size(min = 2 , max = 2 , message = "정렬은 필수 값 입니다.")
        @Schema(description = "정렬" , example = "00")
        private String sortOrder;

        @Min(value = 1, message = "현재 페이지는 1 이상이어야 합니다.")
        @Schema( description = "현재 페이지" , example = "1")
        private int pageNum;

        @Min(value = 1, message = "페이지에 보여지는 데이터 수는 1 이상이어야 합니다.")
        @Schema( description = "페이지에 보여지는 데이터수" , example = "50")
        private int pageSize;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MtchListRes {
        @Schema(description = "전체 페이지 개수", example = "7")
        private int totalPages = 0;

        @Schema(description = "전체 데이터 개수 (검색된 모든 데이터 항목 수)", example = "100")
        private long totalElements = 0;

        @Schema(description = "미배정 건수" , example = "7")
        private long unMtchCnt = 0;

        @Schema(description = "배정 관리 리스트")
        private List<MtchInfo> mtchList = new ArrayList<>();
    }




    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MtchInfo{

        @Schema( description = "진행 상태 명" , example = "등기의뢰")
        @NullToEmptyString
        private String statNm;

        @Schema( description = "진행 상태 코드" , example = "00")
        @NullToEmptyString
        private String statCd;

        @Schema( description = "의뢰번호" , example = "1234567890111")
        @NullToEmptyString
        private String rqstNo;

        @Schema( description = "대출 실행일" , example = "2025-03-14")
        @DateFormatString
        private String execDt;

        @Schema( description = "의뢰자 명" , example = "홍의뢰")
        @NullToEmptyString
        private String clientNm;

        @Schema( description = "의뢰자 회원번호" , example = "25031200001")
        @NullToEmptyString
        private String clientMembNo;

        @Schema( description = "채권자 명" , example = "홍권자")
        @NullToEmptyString
        private String bndNm;

        @Schema( description = "채권자 사업자번호" , example = "1111111111")
        @NullToEmptyString
        private String bndBizNo;

        @Schema( description = "채무자 명" , example = "홍무자")
        @NullToEmptyString
        private String dbtrNm;

        @Schema( description = "의뢰일시" , example = "2023-12-19 16:24:04")
        @LocalDateTimeToString
        private LocalDateTime crtDtm ;

        @Schema( description = "배정일시" , example = "2023-12-19 16:24:04")
        @LocalDateTimeToString
        private LocalDateTime mtchDtm;

    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SaveMtchReq {

        @Size(min = 13, max = 13 , message = "의뢰번호는 13 자리 입니다.")
        @Schema(description = "의뢰번호", example = "2025031200001")
        private String rqstNo;

        @Schema(description = "대출 실행일" , example = "20250314")
        @Size(min = 8, max = 8 , message = "대출실행일은 8 자리 입니다.")
        private String execDt;

        @Schema(description = "채권자 사업자 번호" , example = "1111111111")
        @Size(min = 10, max = 10 , message = "사업자번호는 10 자리 입니다.")
        private String bndBizNo;

        @Schema( description = "채무자 명" , example = "채무자명")
        @NotEmpty(message = "채무자 명을 입력해 주세요.")
        private String dbtrNm;

        @Schema(
                description = """
        부동산구분 코드:
        - 00: 전체
        - 01: 집합건물 
        - 02: 토지
        - 03: 건물
        """,
                example = "00"
        )
        @Size(min = 2, max = 2 , message = "부동산구분 코드는 2 자리 입니다.")
        private String realeCd;

        @Schema(description = "지번주소" , example = "서울 중구 수표동 99")
        @NotEmpty(message = "지번주소를 입력해 주세요.")
        private String lotnumAddr;

        @Schema(description = "도로명주소" , example = "서울 중구 청계천로 100 시그니쳐타워")
        @NotEmpty(message = "도로명주소를 입력해 주세요.")
        private String rdnmAddr;

        @Schema(
                description = """
        지번주소 코드:
        - 01: 동 + 호
        - 02: 동
        - 03: 호
        - 04: 없음
        """,
                example = "01"
        )
        @NotEmpty(message = "지번주소코드를 입력해 주세요.")
        private String lotnumAddrCd;

        @Schema(description = "동" , example = "102")
        @Size( max = 10 , message = "동은 최대 10자리까지 입력 가능합니다.")
        private String bldg;

        @Schema(description = "호" , example = "204")
        @Size( max = 10 , message = "호는 최대 10자리까지 입력 가능합니다.")
        private String unit;

        @Schema(description = "등기고유번호" , example = "13451996177867")
        @Size(min = 14, max = 14 , message = "등기고유번호는 14자리 입니다.")
        private String unqRgstrNo;

        @Schema(description = "채권최고액", example = "111111")
        @DecimalMin(value = "0.0", inclusive = false, message = "채권최고액은 0보다 커야 합니다.")
        private BigDecimal bndMaxAmt;

        @Schema(description = "설정약정일" , example = "20250314")
        @Size(min = 8, max = 8 , message = "설정약정일은 8자리 입니다.")
        private String seDt;

        @Schema(description = "법무대리인 회원번호" , example = "20250314")
//        @Size(min = 11, max = 11 , message = "법무대리인 회원번호는 11자리 입니다.")
        private String lgagMembNo;

//        @Schema(description = "제출 담당자 회원번호" , example = "25031200001")
//        @Size(min = 11, max = 11 , message = "제출 담당자 회원번호 11자리 입니다.")
//        private String mngrMembNo;

        @Schema(description = "법무대리인에게 전달사항" , example = "법무대리인에게 전달사항")
        private String lgagDlvrCnts;
    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ModifyMtchReq {

        @Size(min = 13, max = 13 , message = "의뢰번호는 13 자리 입니다.")
        @Schema(description = "의뢰번호", example = "2025031200001")
        private String rqstNo;

        @Schema( description = "채무자 명" , example = "채무자명")
        @NotEmpty(message = "채무자 명을 입력해 주세요.")
        private String dbtrNm;

        @Schema(
                description = """
        부동산구분 코드:
        - 00: 전체
        - 01: 집합건물 
        - 02: 토지
        - 03: 건물
        """,
                example = "00"
        )
        @Size(min = 2, max = 2 , message = "부동산구분 코드는 2 자리 입니다.")
        private String realeCd;

        @Schema(description = "지번주소" , example = "서울 중구 수표동 99")
        @NotEmpty(message = "지번주소를 입력해 주세요.")
        private String lotnumAddr;

        @Schema(description = "도로명주소" , example = "서울 중구 청계천로 100 시그니쳐타워")
        @NotEmpty(message = "도로명주소를 입력해 주세요.")
        private String rdnmAddr;

        @Schema(
                description = """
        지번주소 코드:
        - 01: 동 + 호
        - 02: 동
        - 03: 호
        - 04: 없음
        """,
                example = "01"
        )
        @NotEmpty(message = "지번주소코드를 입력해 주세요.")
        private String lotnumAddrCd;

        @Schema(description = "동" , example = "102")
        @Size( max = 10 , message = "동은 최대 10자리까지 입력 가능합니다.")
        private String bldg;

        @Schema(description = "호" , example = "204")
        @Size( max = 10 , message = "호는 최대 10자리까지 입력 가능합니다.")
        private String unit;

        @Schema(description = "등기고유번호" , example = "13451996177867")
        @Size(min = 14, max = 14 , message = "등기고유번호는 14자리 입니다.")
        private String unqRgstrNo;

        @Schema(description = "채권최고액", example = "111111")
        @DecimalMin(value = "0.0", inclusive = false, message = "채권최고액은 0보다 커야 합니다.")
        private BigDecimal bndMaxAmt;

        @Schema(description = "설정약정일" , example = "20250314")
        @Size(min = 8, max = 8 , message = "설정약정일은 8자리 입니다.")
        private String seDt;

        @Schema(description = "법무대리인 회원번호" , example = "20250314")
//        @Size(min = 11, max = 11 , message = "법무대리인 회원번호는 11자리 입니다.")
        private String lgagMembNo;

//        @Schema(description = "제출 담당자 회원번호" , example = "25031200001")
//        @Size(min = 11, max = 11 , message = "제출 담당자 회원번호 11자리 입니다.")
//        private String mngrMembNo;

        @Schema(description = "법무대리인에게 전달사항" , example = "법무대리인에게 전달사항")
        private String lgagDlvrCnts;
    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MtchInfoRes{
        @Schema( description = "의뢰번호" , example = "1234567890111")
        @NullToEmptyString
        private String rqstNo;

        @Schema( description = "대출 실행일" , example = "2025-03-14")
        @DateFormatString
        private String execDt;

        @Schema( description = "채권자 명" , example = "홍권자")
        @NullToEmptyString
        private String bndNm;

        @Schema( description = "채권자 사업자번호" , example = "1111111111")
        @NullToEmptyString
        private String bndBizNo;

    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MemberInfo{
        @Schema( description = "회원번호" , example = "25031200002")
        @NullToEmptyString
        private String membNo;

        @Schema( description = "회원 명" , example = "나회원")
        @NullToEmptyString
        private String membNm;

        @Schema( description = "사업자 번호" , example = "5031200002")
        @NullToEmptyString
        private String bizNo;

        @Schema( description = "상호 명" , example = "성북신협")
        @NullToEmptyString
        private String bizNm;
    }




}
