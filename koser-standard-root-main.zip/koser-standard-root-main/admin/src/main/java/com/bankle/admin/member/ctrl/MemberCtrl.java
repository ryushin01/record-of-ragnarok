package com.bankle.admin.member.ctrl;

import com.bankle.admin.member.svc.MemberSvc;
import com.bankle.admin.member.vo.MemberVo;
import com.bankle.common.commSvc.vo.ImageVo;
import com.bankle.common.exception.BadRequestException;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 관리자 - 회원관리 Controller
 *
 * @author 정가은
 * @version 1.0
 * @since 2025.03.20
 */
@Tag(name = "관리자 - 회원관리", description = "회원관리")
@Slf4j
@RestController
@RequiredArgsConstructor
public class MemberCtrl {
    private final MemberSvc memberSvc;

    @Operation(summary = "회원정보 상세", description = """
            [ REQUEST ]
            - membNo(회원번호) : 20250403001
            
            [ RESPONSE ]
            
            code
            - 00
            - 99
            
            msg
            - 성공(00)
            - 실패(99)
            
            data
            - member : 회원 정보, 계정 정보
                > membNm : 회원명\n
                > membNo : 회원번호\n
                > membGbNm : 회원유형\n
                > joinDtm : 가입일\n
                > membId : 아이디\n
                > membPwd : 비밀번호\n
            - office : 사업자 정보
                > bizNo : 사업자등록번호\n
                > bizNm : 상호명\n
                > reptNm : 대표자명\n
                > bizAddr : 사업장 소재지\n
            """)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = MemberVo.MemberInfoRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping("/admin/member/{membno}")
    public ResponseEntity<?> getMemberDetail(@PathVariable String membno) throws Exception {
        return ResData.SUCCESS(memberSvc.getMemberDetail(membno), "성공");
    }

    @Operation(summary = "회원 등록 > 사업자 조회", description = """
            [ REQUEST ]
            - bizgbcd(상호명 구분코드) : 00(금융기관), 10(법무대리인)
            
            [ RESPONSE ]
            
            code
            - 00
            - 99
            
            msg
            - 성공(00), 실패(99)
            
            data
              - 사업자 리스트
            """)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = MemberVo.MemberListRes.class)))
    })
    @GetMapping(value = "/admin/member/biz-list/{bizgbcd}")
    public ResponseEntity<?> getbizList(@PathVariable String bizgbcd) throws Exception {
        return ResData.SUCCESS(memberSvc.getBizList(bizgbcd), "성공");
    }

    @Operation(summary = "회원 등록", description = """
            [ REQUEST ]
            
            - bizNo(사업자등록번호) : 1140412345
            - membNo(신규가입 회원번호 - 시퀀스 조회 API) : 25032000001
            - membNm(회원명) : 홍길동
            - membHpno(전화번호) : 01012345678
            - membId(아이디) : honggildong
            - pwd(비밀번호) : asdf1234
            
            [ RESPONSE ]
            
            code
            - 00 : 성공 (data : 00)
            - 99 : 실패 (data : 01 ~ 99)
            
            msg
            - data : 00~99까지의 '(괄호 안)' 값
            
            data
              - 00 (회원 등록 성공)\n
              - 01 (회원번호가 이미 존재합니다.)\n
              - 02 (아이디가 이미 존재합니다.)\n
              - 03 (비밀번호가 8자 이상 ~ 20자 이하, 숫자/영문자 반드시 포함해야 합니다.)\n
              - 04 (사업자번호가 존재하지 않습니다.)\n
            """)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공",
                    content = @Content(schema = @Schema(implementation = MemberVo.memberSaveReq.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청",
                    content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PostMapping(value = "/admin/member")
    public ResponseEntity<?> saveMember(@Valid @RequestBody MemberVo.memberSaveReq memberVo) throws Exception {
        String status = memberSvc.saveMember(memberVo);

        return switch (status) {
            case "00" -> ResData.SUCCESS(status, "회원 등록 성공");
            case "01" -> ResData.FAIL(status, "회원번호가 이미 존재합니다.");
            case "02" -> ResData.FAIL(status, "아이디가 이미 존재합니다.");
            case "03" -> ResData.FAIL(status, "비밀번호가 8자 이상 ~ 20자 이하, 숫자/영문자 반드시 포함해야 합니다.");
            case "04" -> ResData.FAIL(status, "사업자번호가 존재하지 않습니다.");
            default -> throw new BadRequestException("회원 등록 실패");
        };

    }

    @Operation(summary = "사업자 등록", description = """
            [ REQUEST ]
            
            - bizGbCd(상호명 구분코드) : 00(금융기관), 10(법무대리인)
            - bizNm(상호명) : 소공신용협동조합
            - bizNo(사업자등록번호) : 1140412345
            - reptNm(대표자명) : 남대표
            - bizAddr(사업장 소재지) : 서울특별시 중구 세종대로 74(태평로2가) 1층 소공신협
            
            - multipartFiles : 사업자등록증, 프로필 사진 이미지
            
            [ RESPONSE ]
            
            code
            - 00 : 성공 (data : 00)
            - 99 : 실패 (data : 01 ~ 99)
            
            msg
            - data : 00~99까지의 '(괄호 안)' 값
            
            data
              - 00 (사업자 등록 성공)\n
              - 01 (사업자 등록번호가 이미 존재합니다.)\n
            """)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공",
                    content = @Content(schema = @Schema(implementation = MemberVo.memberSaveReq.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청",
                    content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PostMapping(value = "/admin/office",
            consumes = {MediaType.MULTIPART_FORM_DATA_VALUE},
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> saveOffice(
            @Valid @RequestPart() @Parameter(description = "사업자 정보 JSON", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE), required = true)
            MemberVo.bizSaveReq bizSaveVo,

            @RequestPart(value = "bizLicenseImg", required = false)
            @Parameter(description = "사업자등록증 이미지", content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE))
            List<MultipartFile> bizLicenseImg,

            @RequestPart(value = "profileImg", required = false)
            @Parameter(description = "프로필 이미지", content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE))
            List<MultipartFile> profileImg
    ) throws Exception {
        String status = memberSvc.saveBiz(bizSaveVo, bizLicenseImg, profileImg);

        return switch (status) {
            case "00" -> ResData.SUCCESS(status, "사업자 등록 성공");
            case "01" -> ResData.FAIL(status, "상호명 구분코드가 유효하지 않습니다.");
            case "02" -> ResData.FAIL(status, "사업자 등록번호가 이미 존재합니다.");
            default -> throw new BadRequestException("사업자 등록 실패");
        };

    }

    @Operation(summary = "사업자등록증 조회 ", description = """
            [ REQUEST ]
            
            - bizNo(사업자번호) : 1000020000
            
            [ RESPONSE ]
            
            code
            - 00 : 성공
            - 99 : 실패
            
            msg
            - 00 : 사업자등록증 조회 성공
            
            data
            - imgData : 이미지 데이터
                > src : 개별 이미지 조회 uri경로\n
                > attcFilNm : 첨부파일 명\n
                > filSize : 파일사이즈\n
            - rqstNo : bizNo(사업자번호)\n
            """)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "사업자등록증 조회 성공", content = @Content(schema = @Schema(implementation = ImageVo.ImageRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/admin/member/bizdoc/{bizno}")
    public ResponseEntity<?> bizDocCtrl(@PathVariable String bizno) throws Exception {
        return ResData.SUCCESS(memberSvc.getBizDocImg(bizno), "사업자등록증 조회 성공");
    }

    @Operation(summary = "프로필 이미지 조회", description = """
            [ REQUEST ]
            
            - bizNo(사업자번호) : 1000020000
            
            [ RESPONSE ]
            
            code
            - 00 : 성공
            - 99 : 실패
            
            msg
            - (code)00 : 프로필 이미지 조회 성공
            - (code)99 : 프로필 이미지 조회 실패
            
            data
            - imgData : 이미지 데이터
                > src : 개별 이미지 조회 uri경로\n
                > attcFilNm : 첨부파일 명\n
                > filSize : 파일사이즈\n
            - rqstNo : bizNo(사업자번호)\n
            """)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "프로필 조회 성공", content = @Content(schema = @Schema(implementation = ImageVo.ImageRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/admin/member/profile/{bizno}")
    public ResponseEntity<?> profileImgCtrl(@PathVariable String bizno) throws Exception {
        return ResData.SUCCESS(memberSvc.getProfileImg(bizno), "프로필 이미지 조회 성공");
    }

    @Operation(summary = "회원관리 목록",
            description = """
                        회원관리 목록 조회 (검색)
                        - tabSelection : 00:전체, 01:금융기관, 02:법무대리인
                        - membNm : 검색 회원명(성북신협)
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = MemberVo.MemberListRes.class)))
    })
    @GetMapping(value = "/admin/members/list")
    public ResponseEntity<?> getList(@Valid MemberVo.MemberListReq memberListReq) throws Exception {
        return ResData.SUCCESS(memberSvc.getList(memberListReq), "성공");
    }

    @Operation(summary = "회원 탈퇴처리", description = """
            [ REQUEST ]
            
            - membNo(회원번호) : 20250408001
            
            [ RESPONSE ]
            
            code
            - 00 : 성공
            - 99 : 실패
            
            msg
            - code가 00 : 탈퇴 처리되었습니다.
            - code가 99 : 해당 사용자가 존재하지 않습니다. / 해당 사용자는 금융기관 또는 법무대리인이 아닙니다.
            
            data
            - 00,01
            """)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = boolean.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @DeleteMapping("/admin/member/{membno}")
    public ResponseEntity<?> deleteMember(@PathVariable String membno) throws Exception {

        String status = memberSvc.deleteMember(membno);

        return switch (status) {
            case "00" -> ResData.SUCCESS(status, "탈퇴 처리되었습니다.");
            case "01" -> ResData.FAIL(status, "해당 사용자가 존재하지 않습니다.");
            case "02" -> ResData.FAIL(status, "해당 사용자는 금융기관 또는 법무대리인이 아닙니다.");
            default -> throw new BadRequestException("탈퇴 처리 실패");
        };

    }

}
