package com.bankle.admin.admin.ctrl;

import com.bankle.admin.admin.svc.AdminSvc;
import com.bankle.admin.admin.vo.AdminVo;
import com.bankle.admin.member.vo.MemberVo;
import com.bankle.common.exception.BadRequestException;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * 관리자 - 관리자 목록 컨트롤러
 *
 * @author 정가은
 * @version 1.0
 * @since 2025.04.07
 */
@Tag(name = "관리자 - 관리자 목록", description = "관리자 목록")
@Slf4j
@RestController
@RequiredArgsConstructor
public class AdminCtrl {

    private final AdminSvc adminSvc;

    @Operation(summary = "관리자 등록", description = """
            [ REQUEST ]
            
            - membNo(신규가입 회원번호 - 시퀀스 조회 API) : 25040700001
            - membNm(회원명) : 나관리
            - membHpno(전화번호) : 01077778888
            - membId(아이디) : mng11111
            - pwd(비밀번호) : mng11111
            
            [ RESPONSE ]
            
            code
            - 00 : 성공 (data : 00)
            - 99 : 실패 (data : 01 ~ 99)
            
            msg
            - data : 00~99까지의 '(괄호 안)' 값
            
            data
              - 00 (관리자 등록 성공)\n
              - 01 (회원번호가 이미 존재합니다.)\n
              - 02 (아이디가 이미 존재합니다.)\n
              - 03 (비밀번호가 8자 이상 ~ 20자 이하, 숫자/영문자 반드시 포함해야 합니다.)\n
            """)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공",
                    content = @Content(schema = @Schema(implementation = MemberVo.memberSaveReq.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청",
                    content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PostMapping(value = "/admin/manager")
    public ResponseEntity<?> saveAdmin(@Valid @RequestBody AdminVo.adminSaveReq managerVo) throws Exception {
        String status = adminSvc.saveAdmin(managerVo);

        return switch (status) {
            case "00" -> ResData.SUCCESS(status, "관리자 등록 성공");
            case "01" -> ResData.FAIL(status, "회원번호가 이미 존재합니다.");
            case "02" -> ResData.FAIL(status, "아이디가 이미 존재합니다.");
            case "03" -> ResData.FAIL(status, "비밀번호가 8자 이상 ~ 20자 이하, 숫자/영문자 반드시 포함해야 합니다.");
            default -> throw new BadRequestException("관리자 등록 실패");
        };

    }

    @Operation(summary = "관리자 탈퇴처리", description = """
            [ REQUEST ]
            
            - membNo(회원번호) : 20250408001
            
            [ RESPONSE ]
            
            code
            - 00 : 성공
            - 99 : 실패
            
            msg
            - code가 00 : 탈퇴 처리되었습니다.
            - code가 99 : 해당 사용자가 존재하지 않습니다. / 해당 사용자는 관리자가 아닙니다.
            
            data
            - 00,01,02
            """)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = boolean.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @DeleteMapping("/admin/manager/{membno}")
    public ResponseEntity<?> deleteManager(@PathVariable String membno) throws Exception {

        String status = adminSvc.deleteAdmin(membno);

        return switch (status) {
            case "00" -> ResData.SUCCESS(status, "탈퇴 처리되었습니다.");
            case "01" -> ResData.FAIL(status, "해당 사용자가 존재하지 않습니다.");
            case "02" -> ResData.FAIL(status, "해당 사용자는 관리자가 아닙니다.");
            default -> throw new BadRequestException("탈퇴 처리 실패");
        };

    }


    @Operation(
            summary = "관리자 목록 조회 API",
            description = """
        요청 데이터:
       
        - 검색 회원명 (searchMembNm)  
          - 50자 이하 입력 가능  
          - 공백 입력 시 전체 검색  
        
        - 현재 페이지 (pageNum)  
        - 페이지에 표시할 데이터 수 (pageSize)  
    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = AdminVo.AdminListRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/admin/manager")
    public ResponseEntity<?> getAdminList(@Valid AdminVo.AdminListReq req) throws Exception {
        return ResData.SUCCESS(adminSvc.getAdminList(req), "관리자 목록 조회 성공");
    }


    @Operation(
            summary = "관리자 수정 정보 조회 API",
            description = """
        요청 데이터:
        
        - membNo (회원번호) : 회원구분코드가 관리자("20")가 아닌 회원번호는 조회되지 않습니다.
    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation =  AdminVo.ModifyAdminInfoRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/admin/manager/modify/{membNo}")
    public ResponseEntity<?> getModifyAdminInfo(@PathVariable String membNo) throws Exception {
        return ResData.SUCCESS(adminSvc.getModifyAdminInfo(membNo), "관리자 수정 정보 조회 성공");
    }


    @Operation(
            summary = "관리자 정보 수정",
            description = """
        요청 데이터
        - 회원 번호(`membNo`)는 필수입니다.
        - 수정할 항목만 전달하면 됩니다 (이름, 연락처, 아이디, 비밀번호 중 선택).

        응답 데이터
        - code: "00" → 성공
        - 그 외 코드 → 실패

        응답 메시지
        - code가 "00"인 경우: "관리자 정보가 수정되었습니다."
    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation =  boolean.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PatchMapping(value = "/admin/manager")
    public ResponseEntity<?>  modifyAdmin(@Valid @RequestBody AdminVo.ModifyAdminReq req) throws Exception {
        adminSvc.modifyAdmin(req);
        return ResData.SUCCESS(true, "관리자 정보가 수정되었습니다.");
    }


}
