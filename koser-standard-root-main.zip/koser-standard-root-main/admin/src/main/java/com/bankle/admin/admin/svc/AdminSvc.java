package com.bankle.admin.admin.svc;

import com.bankle.admin.admin.vo.AdminVo;
import com.bankle.common.code.svc.CommSvc;
import com.bankle.common.commSvc.CommonSvc;
import com.bankle.common.dto.TbCustMasterDto;
import com.bankle.common.entity.TbCustMaster;
import com.bankle.common.exception.BadRequestException;
import com.bankle.common.mapper.TbCustMasterMapper;
import com.bankle.common.repo.TbCustMasterRepository;
import com.bankle.common.userAuth.UserAuthSvc;
import com.bankle.common.utils.CustomeModelMapper;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Pattern;

/**
 * 관리자 - 관리자 목록
 *
 * @author 정가은
 * @version 1.0
 * @since 2025.03.20
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AdminSvc {

    private final TbCustMasterRepository tbCustMasterRepository;
    private final CustomeModelMapper modelMapper;
    private final CommSvc commSvc;
    private final CommonSvc commonSvc;


    /**
     * 관리자 등록
     *
     * @param adminSaveReq : 관리자 입력 정보
     * @return (String) : 상태 값
     * @throws Exception
     */
    @Transactional
    public String saveAdmin(AdminVo.adminSaveReq adminSaveReq) throws Exception {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        TbCustMasterDto custDto;
        String regMember = UserAuthSvc.getMembNo();

        var cust01 = tbCustMasterRepository.findByMembNo(adminSaveReq.getMembNo());
        if (cust01.isPresent()) {
            return "01"; // membNo 존재
        }

        var cust02 = tbCustMasterRepository.findByMembId(adminSaveReq.getMembId());
        if (cust02.isPresent()) {
            return "02"; // membId 존재
        }

        if (!isValidPassword(adminSaveReq.getPwd())) {
            return "03"; // 비밀번호 정책 위반
        }

        custDto = TbCustMasterDto.builder()
                .membNo(adminSaveReq.getMembNo())    // 회원번호
                .joinDtm(LocalDateTime.now())        // 가입일시
                .membNm(adminSaveReq.getMembNm())    // 회원명
                .membHpno(adminSaveReq.getMembHpno())// 전화번호
                .membId(adminSaveReq.getMembId())    // 아이디
                .membPwd(encoder.encode(adminSaveReq.getPwd())) // 비밀번호
                .crtMembNo(regMember)               // 생성자
                .chgMembNo(regMember)               // 수정자
                .membGbCd("20")                     // 회원유형
                .statCd("10")                       // 회원상태(승인)
                .build();

        // ====================================
        // 회원정보 저장
        // ====================================
        tbCustMasterRepository.save(TbCustMasterMapper.INSTANCE.toEntity(custDto));

        return "00";
    }

    @Transactional
    public String deleteAdmin(String membNo) throws Exception {
        var custMasterRepo = tbCustMasterRepository.findByMembNo(membNo);

        if (custMasterRepo.isEmpty()) return "01";

        TbCustMasterDto custDto = modelMapper.mapping(custMasterRepo.get(), TbCustMasterDto.class);

        if (!"20".equals(custDto.getMembGbCd())) return "02";

        custDto.setStatCd("30");                        // 회원상태(탈퇴)
        custDto.setChgMembNo(UserAuthSvc.getMembNo());  // 수정자
        // ====================================
        // 회원정보 저장
        // ====================================
        tbCustMasterRepository.save(TbCustMasterMapper.INSTANCE.toEntity(custDto));

        return "00";
    }

    /**
     * 비밀번호 정책 (비밀번호가 8자 이상 ~ 20자 이하, 숫자/영문자 반드시 포함) 확인
     *
     * @param password
     * @return 비밀번호 정책이 지켜졌을 경우 true
     */
    public static boolean isValidPassword(String password) {
        return Pattern.matches("^(?=.*[A-Za-z])(?=.*\\d)(?!.*[ㄱ-ㅎㅏ-ㅣ가-힣])[A-Za-z\\d!@#$%^&*()_+=\\-{}\\[\\]|:;\"'<>,.?/~`]{8,20}$", password);
    }


    /**
     * 관리자 리스트 조회
     *
     * @param : AdminVo.AdminListReq
     * @return : AdminVo.AdminListRes
     */
    @Transactional
    public AdminVo.AdminListRes getAdminList(AdminVo.AdminListReq req) throws Exception {

        //정렬기준 : 가입일 기준 최신순으로 정렬
        Sort sort = Sort.by(Sort.Direction.DESC, "crtDtm");
        Pageable pageable = PageRequest.of(req.getPageNum() - 1, req.getPageSize(), sort);

        //원장 페이징 조회
        Page<TbCustMaster> allList;

        if (StringUtils.hasText(req.getSearchMembNm())) {
            // 검색 회원명이 존재하는 경우에만 LIKE 조건으로 조회
            allList = tbCustMasterRepository.findByMembGbCdAndStatCdAndMembNmContaining("20", "10", req.getSearchMembNm(), pageable);
        } else {
            // 검색 회원명이 공백이거나 빈 문자열이면 조건 없이 조회
            allList = tbCustMasterRepository.findByMembGbCdAndStatCd("20", "10", pageable);
        }

        AdminVo.AdminListRes resVo = AdminVo.AdminListRes.builder()
                .totalPages(allList.getTotalPages())
                .totalElements(allList.getTotalElements())
                .build();

        //조회된 리스트가 존재하지 않는다면 빈값으면 반환한다.
        if (allList.getTotalElements() == 0) {
            resVo.setAdminList(new ArrayList<>());
            return resVo;
        }
        // 공통코드 조회
        List<String> multiGprCd = List.of("MEMB_GB_CD");

        Map<String, Map<String, String>> codeMap = commSvc.searchCommCodeMultiList(multiGprCd);

        List<AdminVo.AdminInfo> adminInfoList =
                TbCustMasterMapper.INSTANCE.toDtoList(allList.getContent()).stream()
                        .map(dto -> {
                            AdminVo.AdminInfo info = modelMapper.mapping(dto, AdminVo.AdminInfo.class);
                            info.setMembGbNm(codeMap.get("MEMB_GB_CD").get(info.getMembGbCd()));
                            return info;
                        })
                        .toList();

        resVo.setAdminList(adminInfoList);

        return resVo;
    }


    /**
     * 관리자 수정 정보 조회 서비스
     *
     * @param membNo : 회원번호
     * @return : AdminVo.AdminListRes
     */
    @Transactional
    public AdminVo.ModifyAdminInfoRes getModifyAdminInfo(String membNo) throws Exception {

        if (!StringUtils.hasText(membNo) || membNo.length() != 11) {
            throw new BadRequestException("회원번호를 다시 입력해 주세요.");
        }

        TbCustMasterDto dto = TbCustMasterMapper.INSTANCE.toDto(
                tbCustMasterRepository.findByMembNoAndMembGbCdAndStatCd(membNo , "20", "10")
                        .orElseThrow(() -> new EntityNotFoundException("회원번호 : " + membNo)));

        return modelMapper.mapping(dto , AdminVo.ModifyAdminInfoRes.class);
    }


    /**
     * 관리자 정보 수정 서비스
     *
     * @param : AdminVo.ModifyAdminReq
     */
    @Transactional
    public void modifyAdmin(AdminVo.ModifyAdminReq req) throws Exception {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        TbCustMasterDto dto = TbCustMasterMapper.INSTANCE.toDto(
                tbCustMasterRepository.findByMembNoAndMembGbCdAndStatCd(req.getMembNo(), "20", "10")
                        .orElseThrow(() -> new EntityNotFoundException("회원번호 : " + req.getMembNo())));


        dto.setMembNm(StringUtils.hasText(req.getMembNm()) ? req.getMembNm() : dto.getMembNm());
        dto.setMembHpno(StringUtils.hasText(req.getMembHpno()) ? req.getMembHpno() : dto.getMembHpno());
        dto.setMembId(StringUtils.hasText(req.getMembId()) ? req.getMembId() : dto.getMembId());
        dto.setMembPwd(StringUtils.hasText(req.getMembPwd()) ? encoder.encode(req.getMembPwd()) : dto.getMembPwd());
        tbCustMasterRepository.save(TbCustMasterMapper.INSTANCE.toEntity(dto));
    }



}