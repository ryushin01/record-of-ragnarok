package com.bankle.admin.rgstrMngr.svc;


import com.bankle.admin.rgstrMngr.vo.RgstrMngrVo;
import com.bankle.common.commSvc.CommonSvc;
import com.bankle.common.commSvc.FileSvc;
import com.bankle.common.commSvc.IrosSvc;
import com.bankle.common.commSvc.vo.ImageVo;
import com.bankle.common.config.CommCont;
import com.bankle.common.dto.TbRgstrMasterDto;
import com.bankle.common.dto.TbRgstrStatHistDto;
import com.bankle.common.entity.TbRgstrMaster;
import com.bankle.common.entity.TbRgstrStatHist;
import com.bankle.common.entity.spce.TbRgstrMasterSpec;
import com.bankle.common.exception.BadRequestException;
import com.bankle.common.mapper.TbRgstrMasterMapper;
import com.bankle.common.mapper.TbRgstrStatHistMapper;
import com.bankle.common.repo.TbRgstrMasterRepository;
import com.bankle.common.repo.TbRgstrStatHistRepository;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.utils.StringUtil;
import com.bankle.common.vo.IrosVo;
import com.bankle.common.vo.RgstrData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 관리자 - 등기관리 서비스
 *
 * @author 이은희
 * @version 1.0
 * @since 2025.03.18
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RgstrMngrSvc {

    private final CustomeModelMapper modelMapper;
    private final CommonSvc commonSvc;
    private final TbRgstrMasterRepository tbRgstrMasterRepository;
    private final TbRgstrStatHistRepository tbRgstrStatHistRepository;
    private final FileSvc fileSvc;
    private final IrosSvc irosSvc;

    /**
     * 등기자료 의뢰번호 검색
     *
     * @param rqstNo 의뢰번호
     * @return 의뢰번호 검색 유무
     */
    public Boolean getSearch(String rqstNo) throws Exception {

        var result = tbRgstrMasterRepository.findByRqstNo(rqstNo);

        return result.isPresent();
    }

    /**
     * 등기관리 목록 조회
     *
     * @param reqVo 검색조건
     * @return 등기자료 정보
     */
    public RgstrMngrVo.RgstrMngrListRes getList(RgstrMngrVo.RgstrMngrListReq reqVo) throws Exception {

        //------------------------------------------------------------------
        // 정렬기준 세팅
        //------------------------------------------------------------------
        //의뢰일 정렬 :  등기의뢰 의뢰일 기준 최신순
        //대출실행 정렬 : 등기의뢰 대출실행일 기준 최신순(대출실행일이 같으면 의리일시 기준 최신순)
        Sort sort = StringUtil.equals("00", reqVo.getSortOrder())
                ? Sort.by(Sort.Order.desc("crtDtm"))
                : Sort.by(
                    Sort.Order.desc("execDt"),
                    Sort.Order.desc("crtDtm")
                );

        Pageable pageable = PageRequest.of(reqVo.getPageNum()-1, reqVo.getPageSize() , sort);

        //------------------------------------------------------------------
        // 검색조건 세팅
        //------------------------------------------------------------------
        Specification<TbRgstrMaster> spec = (root, query, criteriaBuilder) -> null;

        //진행상태 검색
        if(StringUtils.hasText(reqVo.getTabSelection())) {
            spec = spec.and(TbRgstrMasterSpec.equalsStatCd(reqVo.getTabSelection()));
        }

        //의뢰번호 검색
        if(StringUtils.hasText(reqVo.getSearchRqstNo())) {
            spec = spec.and(TbRgstrMasterSpec.likeRqstNo(reqVo.getSearchRqstNo()));
        } else {
            //검색기간 (대출실행일:EXEC, 의뢰일:RQST, 설정약정일:STEF )
            String SearchType = StringUtil.nvl(reqVo.getSearchType(), "");
            switch (SearchType) {
                case "EXEC" -> {
                    spec = spec.and(TbRgstrMasterSpec.greaterThanOrEqualToExecDt(reqVo.getFromDate()));
                    spec = spec.and(TbRgstrMasterSpec.lessThanOrEqualToExecDt(reqVo.getToDate()));
                }
                case "RQST" -> {
                    spec = spec.and(TbRgstrMasterSpec.greaterThanOrEqualToCrtDtm(reqVo.getFromDate()));
                    spec = spec.and(TbRgstrMasterSpec.lessThanCrtDtm(reqVo.getToDate()));
                }
                case "STEF" -> {
                    spec = spec.and(TbRgstrMasterSpec.greaterThanOrEqualToSeDt(reqVo.getFromDate()));
                    spec = spec.and(TbRgstrMasterSpec.lessThanOrEqualToSeDt(reqVo.getToDate()));
                }
            }
        }

        //------------------------------------------------------------------
        // 목록 조회
        //------------------------------------------------------------------
        Page<TbRgstrMaster> list = tbRgstrMasterRepository.findAll(spec, pageable);

        RgstrMngrVo.RgstrMngrListRes result = RgstrMngrVo.RgstrMngrListRes.builder()
                .totalPages(list.getTotalPages())
                .totalElements(list.getTotalElements())
                .build();

        if(list.isEmpty()) {
            result.setRgstrMngrList(new ArrayList<>());
            result.setRgstrStatistics(new RgstrMngrVo.RgstrStatistics());
        } else {

            List<RgstrMngrVo.RgstrMngrInfo> rqstList = list.getContent().stream()
                    .map(e -> {
                        try {
                            return modelMapper.mapping(commonSvc.getRgstrMasterInfo(e.getRqstNo()), RgstrMngrVo.RgstrMngrInfo.class);
                        } catch (Exception ex) {
                            throw new RuntimeException(ex);
                        }
                    })
                    .toList();

            result.setRgstrMngrList(rqstList);
        }

        //------------------------------------------------------------------
        // 진행상태별 집계
        //------------------------------------------------------------------
        result.setRgstrStatistics(getStatistics(reqVo));

        return result;
    }

    /**
     * 등기관리 진행상태별 집계 조회
     *
     * @param reqVo 검색조건
     * @return 등기관리 진행상태별 카운트
     */
    public RgstrMngrVo.RgstrStatistics getStatistics(RgstrMngrVo.RgstrMngrListReq reqVo) throws Exception {

        RgstrMngrVo.RgstrStatistics statistics = new RgstrMngrVo.RgstrStatistics();

        //------------------------------------------------------------------
        // 검색조건 세팅
        //------------------------------------------------------------------
        Specification<TbRgstrMaster> spec = (root, query, criteriaBuilder) -> null;

        //검색기간 (대출실행일:EXEC, 의뢰일:RQST, 설정약정일:STEF )
        String SearchType = StringUtil.nvl(reqVo.getSearchType(), "");
        switch (SearchType) {
            case "EXEC" -> {
                spec = spec.and(TbRgstrMasterSpec.greaterThanOrEqualToExecDt(reqVo.getFromDate()));
                spec = spec.and(TbRgstrMasterSpec.lessThanOrEqualToExecDt(reqVo.getToDate()));
            }
            case "RQST" -> {
                spec = spec.and(TbRgstrMasterSpec.greaterThanOrEqualToCrtDtm(reqVo.getFromDate()));
                spec = spec.and(TbRgstrMasterSpec.lessThanCrtDtm(reqVo.getToDate()));
            }
            case "STEF" -> {
                spec = spec.and(TbRgstrMasterSpec.greaterThanOrEqualToSeDt(reqVo.getFromDate()));
                spec = spec.and(TbRgstrMasterSpec.lessThanOrEqualToSeDt(reqVo.getToDate()));
            }
        }

        //------------------------------------------------------------------
        // 리스트 조회 및 진행상태별 집계
        //------------------------------------------------------------------
        var allList = tbRgstrMasterRepository.findAll(spec);
        if(allList.isPresent()) {
            List<TbRgstrMasterDto> countList = TbRgstrMasterMapper.INSTANCE.toDtoList(allList.get());

            Map<String, Long> countMap =  countList.stream()
                    .parallel()
                    .filter(dto -> dto.getStatCd() != null)
                    .collect(Collectors.groupingBy(TbRgstrMasterDto::getStatCd, Collectors.counting()));

            Iterator<String> keyset = countMap.keySet().iterator();

            statistics.setTotal(countList.size());  //전체

            while (keyset.hasNext()) {
                String key = keyset.next();
                long value = countMap.get(key);
                switch(key) {
                    case "00" -> statistics.setRqst(value);     //등기의뢰
                    case "20" -> statistics.setMtchCmpt(value); //배정완료
                    case "30" -> statistics.setLoanExec(value); //대출실행
                    case "40" -> statistics.setRqstProg(value); //접수검토중
                    case "50" -> statistics.setRqstRtun(value); //접수반려
                    case "60" -> statistics.setRqstCmpt(value); //접수완료
                    case "70" -> statistics.setProgCncl(value); //진행취소
                    case "80" -> statistics.setProgHold(value); //진행보류
                }
            }
        }

        return statistics;
    }

    /**
     * 등기자료 상세 정보 조회
     *
     * @param rqstNo 등기의뢰 번호
     * @return 등기자료 상세 정보
     */
    public RgstrMngrVo.RgstrMngrDetailRes getDetailInfo(String rqstNo) throws Exception {

        RgstrData rgstrData = commonSvc.getRgstrMasterInfo(rqstNo);

        //------------------------------------------------------------------
        // 등기 원장 정보 조회
        //------------------------------------------------------------------
        RgstrMngrVo.RgstrMngrDetailRes resVo = modelMapper.mapping(rgstrData, RgstrMngrVo.RgstrMngrDetailRes.class);
        resVo.setJudtCourtNm(commonSvc.getCommCodeNm("JUDT_COURT_CD", rgstrData.getJudtCourtCd()));
        resVo.setRegrNm(commonSvc.getCommCodeNm("REGR_CD", rgstrData.getRegrCd()));

        //------------------------------------------------------------------
        // 문서 조회
        //------------------------------------------------------------------
        List<String> dataStatCds = Arrays.asList("00", "10", "20", "70", "80");
        List<String> acceptStatCds = Arrays.asList("40", "50", "60", "70");

        List<RgstrMngrVo.RgstrDoc> docList = new ArrayList<>();
        docList.add(getDocInfo("등기자료", rqstNo, dataStatCds));
        if(StringUtils.hasText(rgstrData.getAcptNo())) {
            docList.add(getDocInfo("등기접수증", rqstNo, acceptStatCds));
        }

        resVo.setDocList(docList);

        //------------------------------------------------------------------
        // 진행이력 조회
        //------------------------------------------------------------------
        List<TbRgstrStatHist> statHistList = tbRgstrStatHistRepository.findByRqstNoOrderBySeqDesc(rqstNo);
        if(statHistList.isEmpty()) {
            resVo.setStatHistList(new ArrayList<>());
        } else {
            List<RgstrMngrVo.RgstrStatHist> list = statHistList.stream()
                    .map(e -> {
                        RgstrMngrVo.RgstrStatHist dto = modelMapper.mapping(e, RgstrMngrVo.RgstrStatHist.class);
                        try {
                            dto.setStatNm(commonSvc.getCommCodeNm("PROC_STAT_CD", e.getStatCd())); // statCd → statNm
                            dto.setCrtMembNm(commonSvc.getTbCustMasterDto(e.getCrtMembNo()).getMembNm()); // crtMembNo → crtMembNm
                        } catch (Exception ex) {
                            throw new RuntimeException(ex);
                        }
                        return dto;
                    })
                    .toList();
            resVo.setStatHistList(list);
        }

        return resVo;
    }

    /**
     * 등기문서(등기자료, 등기접수증) 최종 진행 처리자 및 처리시간 조회
     * @param rqstNo 의뢰번호
     * @param statCds 검색 대상 진행상태 리스트
     * @param doc 문서명 (등기자료, 등기접수증)
     * @return 등기문서(등기자료, 등기접수증) 최종 진행 처리자 및 처리시간
     */
    public RgstrMngrVo.RgstrDoc getDocInfo(String doc, String rqstNo, List<String> statCds) throws Exception {

        TbRgstrStatHistDto dataDto =  TbRgstrStatHistMapper.INSTANCE.toDto(
                tbRgstrStatHistRepository.findTop1ByRqstNoAndStatCdInOrderBySeqDesc(rqstNo, statCds)
                        .orElseGet(TbRgstrStatHist::new)
        );

        return RgstrMngrVo.RgstrDoc.builder()
                .kind(doc)
                .crtMembNm(StringUtils.hasText(dataDto.getCrtMembNo())
                        ? commonSvc.getTbCustMasterDto(dataDto.getCrtMembNo()).getMembNm()
                        : "")
                .crtDtm(dataDto.getCrtDtm())
                .build();
    }

    /**
     * 등기자료 정보 조회
     *
     * @param rqstNo 등기의뢰 번호
     * @return 등기자료 정보
     */
    public RgstrMngrVo.RgstrMngrDataRes getDataInfo(String rqstNo) throws Exception {

        RgstrData rgstrData = commonSvc.getRgstrMasterInfo(rqstNo);

        return modelMapper.mapping(rgstrData, RgstrMngrVo.RgstrMngrDataRes.class);
    }

    /**
     * 등기접수증 정보 조회
     *
     * @param rqstNo 등기의뢰 번호
     * @return 등기접수증 정보
     */
    public RgstrMngrVo.RgstrMngrAcceptRes getAcceptInfo(String rqstNo) throws Exception {

        RgstrData rgstrData = commonSvc.getRgstrMasterInfo(rqstNo);

        RgstrMngrVo.RgstrMngrAcceptRes resVo = modelMapper.mapping(rgstrData, RgstrMngrVo.RgstrMngrAcceptRes.class);
        resVo.setJudtCourtNm(commonSvc.getCommCodeNm("JUDT_COURT_CD", rgstrData.getJudtCourtCd()));
        resVo.setRegrNm(commonSvc.getCommCodeNm("REGR_CD", rgstrData.getRegrCd()));

        return resVo;
    }

    /**
     * 등기접수 정보 등록 조회
     *
     * @param rqstNo 등기의뢰 번호
     * @return 등기접수 정보 등록 정보
     */
    public RgstrMngrVo.RgstrMngrRes getRgstrInfo(String rqstNo) throws Exception {

        //------------------------------------------------------------------
        // 등기 마스터 정보 조회
        //------------------------------------------------------------------
        TbRgstrMasterDto rgstrDto = commonSvc.getRgstrMastrDto(rqstNo);
        RgstrMngrVo.RgstrMngrRes resVo = modelMapper.mapping(rgstrDto, RgstrMngrVo.RgstrMngrRes.class);

        //------------------------------------------------------------------
        //등기접수증 이미지 조회
        //------------------------------------------------------------------
        ImageVo.ImageInfoReq imageReq = ImageVo.ImageInfoReq.builder()
                                        .seq(rqstNo)
                                        .attcFilCd("02")
                                        .build();
        ImageVo.ImageRes imageRes = fileSvc.getImages(imageReq);
        resVo.setFileList(imageRes.getImgData());

        //------------------------------------------------------------------
        //진행상태가 접수반려 일 경우 반려사유 조회
        //------------------------------------------------------------------
        if(StringUtil.equals(resVo.getStatCd(), CommCont.RGSTR_STAT_RTRN)) {
            resVo.setProcRsnCnts(commonSvc.getProcRsnCnts(resVo.getRqstNo(), resVo.getStatCd()));
        }

        return resVo;
    }

    /**
     * 1. 등기 원장 상태 변경(진행보류/보완요청/진행취소/승인/반려)
     * 2. 등기 진행상태 이력 저장
     *
     * @param reqVo {rqstNo: 등기의뢰번호, procRsnCnts: 처리사유}
     * @param statCd 상태코드
     *
     */
    @Transactional
    public void updateRgstrState(RgstrMngrVo.RgstrMngrStatReq reqVo, String statCd) throws Exception {

        String rqstNo= reqVo.getRqstNo();
        String procRsnCnts = reqVo.getProcRsnCnts();

        //------------------------------------------------------------------
        // 등기 상태 변경 시 유효성 체크
        //------------------------------------------------------------------
        //처리사유 입력 유무체크 (반려/보완요청/진행취소 일 경우 처리사유 입력 필수)
        List<String> validList = Arrays.asList(CommCont.RGSTR_STAT_RTRN, CommCont.RGSTR_STAT_SPLMT, CommCont.RGSTR_STAT_CNCL);

        if(validList.contains(statCd) && !StringUtils.hasText(procRsnCnts)) {
            throw new BadRequestException("처리사유를 입력하세요.");
        }

        // 등기 원장 정보 조회
        TbRgstrMasterDto rgstrMasterDto = commonSvc.getRgstrMastrDto(rqstNo);

        // 보완요청 처리 시 등기요청 상태인지 체크
        if(StringUtil.equals(statCd, CommCont.RGSTR_STAT_SPLMT)
                && !StringUtil.equals(rgstrMasterDto.getStatCd(), CommCont.RGSTR_STAT_RQST)) {
            throw new BadRequestException("등기의뢰 상태에서만 보완요청 가능합니다.");
        }

        //------------------------------------------------------------------
        // 등기 상태 변경
        //------------------------------------------------------------------
        rgstrMasterDto.setStatCd(statCd);
        tbRgstrMasterRepository.save(TbRgstrMasterMapper.INSTANCE.toEntity(rgstrMasterDto));

        //------------------------------------------------------------------
        // 등기 상태 이력 저장
        //------------------------------------------------------------------
        tbRgstrStatHistRepository.save(TbRgstrStatHistMapper.INSTANCE.toEntity(TbRgstrStatHistDto.builder()
                .rqstNo(rqstNo)
                .statCd(statCd)
                .procRsnCnts(procRsnCnts)
                .build()));
    }


    /**
     * 등기접수 정보 등록
     *  1. 등기접수증 파일 업로드
     *  2. 등기 원장정보 수정
     *  3. 등기 상태 이력 정보 등록
     *
     * @param reqVo 관할법원, 등기소, 접수번호, 전달사항
     * @param multipartFiles 등기접수증 파일
     */
    @Transactional(rollbackFor = Exception.class)
    public void updateAccept(RgstrMngrVo.RgstrMngrReq reqVo, List<MultipartFile> multipartFiles) throws Exception {

        // 첨부파일 코드(등기접수증)
        String attcFilCd = "02";
        String rqstNo = reqVo.getRqstNo();

        // =================================================================
        // 등기 원장 정보 조회
        // =================================================================
        TbRgstrMasterDto rgstrMasterDto = commonSvc.getRgstrMastrDto(rqstNo);
        String rgstrAcptFilSeq = rgstrMasterDto.getRgstrAcptFilSeq();

        // =================================================================
        // 파일 업로드
        // =================================================================
        String fileSeq;
        if (rgstrAcptFilSeq == null) { // 등록
            fileSeq = fileSvc.crtImages(multipartFiles, attcFilCd, null);
        } else { // 수정
            fileSeq = fileSvc.updImages(multipartFiles, attcFilCd, rgstrAcptFilSeq, reqVo.getImageInfo());
        }

        IrosVo.AcptNoListValidReq irosReq = IrosVo.AcptNoListValidReq.builder()
                                            .rqstNo(rqstNo)
                                            .acptNos(reqVo.getAcptNo())
                                            .regoCd(reqVo.getRegrCd())
                                            .build();
        // IROS 등기 접수번호 조회 여부 (Y/N)
        boolean irosResult = irosSvc.acptNoListValid(irosReq);

        // =================================================================
        // 등기 원장 정보 수정
        // =================================================================
        rgstrMasterDto.setStatCd(CommCont.RGSTR_STAT_REVW);         //진행상태 (40:접수 검토중)
        rgstrMasterDto.setJudtCourtCd(reqVo.getJudtCourtCd());      //관할법원
        rgstrMasterDto.setRegrCd(reqVo.getRegrCd());                //등기소
        rgstrMasterDto.setAcptNo(reqVo.getAcptNo());                //접수번호
        rgstrMasterDto.setRgstrAcptYn(irosResult ? "Y" : "N");      //등기접수 조회여부
        rgstrMasterDto.setMngrDlvrCnts(reqVo.getMngrDlvrCnts());    //전달사항
        rgstrMasterDto.setRgstrAcptFilSeq(fileSeq);                 //등기접수증 파일 시퀀스
        rgstrMasterDto.setAcptRptDtm(LocalDateTime.now());          //접수 보고 일시
        tbRgstrMasterRepository.save(TbRgstrMasterMapper.INSTANCE.toEntity(rgstrMasterDto));

        // =================================================================
        // 등기 상태 이력 정보 등록
        // =================================================================
        TbRgstrStatHistDto rgstrMasterHistDto = TbRgstrStatHistDto.builder()
                                                .rqstNo(rqstNo)
                                                .statCd(CommCont.RGSTR_STAT_REVW).build();

        tbRgstrStatHistRepository.save(TbRgstrStatHistMapper.INSTANCE.toEntity(rgstrMasterHistDto));
    }


}
