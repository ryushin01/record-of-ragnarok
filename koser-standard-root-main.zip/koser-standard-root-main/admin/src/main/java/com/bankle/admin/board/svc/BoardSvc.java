package com.bankle.admin.board.svc;


import com.bankle.admin.board.vo.BoardVo;
import com.bankle.common.commSvc.CommonSvc;
import com.bankle.common.commSvc.FileSvc;
import com.bankle.common.dto.TbBoardDto;
import com.bankle.common.entity.TbBoard;
import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.BadRequestException;
import com.bankle.common.mapper.TbBoardMapper;
import com.bankle.common.repo.TbBoardRepository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.CustomeModelMapper;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;


/**
 * 관리자 - 공지관리 서비스
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.19
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BoardSvc {

    private final TbBoardRepository tbBoardRepository;
    private final CustomeModelMapper modelMapper;
    private final CommonSvc commonSvc;
    private final CustomeModelMapper customeModelMapper;
    private final BizUtil bizUtil;
    private final FileSvc fileSvc;

    /**
     * 공지 리스트 조회
     *
     * @param : BoardVo.BoardListReq
     * @return : BoardVo.BoardListRes
     */
    @Transactional
    public BoardVo.BoardListRes boardList(BoardVo.BoardListReq req) throws Exception {

        Sort sort = Sort.by(
              //  Sort.Order.desc("emcyYn"),  // emcyYn이 "Y"인 데이터 우선 정렬
                Sort.Order.desc("chgDtm")   // 그 안에서 chgDtm 내림차순 정렬
        );
        Pageable pageable = PageRequest.of(req.getPageNum() - 1, req.getPageSize(), sort);

        //게시판 페이징 조회
        Page<TbBoard> allList = tbBoardRepository.findByDelYn("N", pageable);

        // 총 게시물 수
        long totalElements = allList.getTotalElements();
        //총 페이지 수
        int totalPages = allList.getTotalPages();

        BoardVo.BoardListRes resVo = BoardVo.BoardListRes.builder()
                .totalPages(totalPages)
                .totalElements(totalElements)
                .build();

        if (allList.getTotalElements() == 0) {
            return resVo;
        }

        List<BoardVo.BoardInfo> boardInfoList = new ArrayList<>();
        var boardDtoList = TbBoardMapper.INSTANCE.toDtoList(allList.getContent());

        // 현재 페이지 번호
        int currentPage = req.getPageNum() - 1;
        // 페이지 크기
        int pageSize = req.getPageSize();

        for (int i = 0; i < boardDtoList.size(); i++) {
            TbBoardDto dto = boardDtoList.get(i);
            String writerNm = "";
            if (StringUtils.hasText(dto.getChgMembNo())) {
                var membInfo = commonSvc.getTbCustMasterDto(dto.getChgMembNo());
                writerNm = membInfo.getMembNm();
            }

            var info = modelMapper.mapping(dto, BoardVo.BoardInfo.class);
            info.setWriterNm(writerNm);

            // 번호 설정: 총 개수 - (현재 페이지 * 페이지 크기) - 인덱스
            long num = totalElements - ((long) currentPage * pageSize) - i;
//            info.setNum(num);  // 번호 설정

            if (StringUtils.hasText(dto.getBoardFilSeq())) {
                var fileDtos = commonSvc.getTbFileDtoList(dto.getBoardFilSeq());
                List<BoardVo.fileInfo> imageInfos = fileDtos.stream().map(file -> customeModelMapper.mapping(file , BoardVo.fileInfo.class))
                        .toList();
                info.setFileInfoList(imageInfos);
            }

            boardInfoList.add(info);
        }

        resVo.setBoardList(boardInfoList);
        return resVo;

    }


    /**
     * 공지 리스트 삭제 서비스
     *
     * @param seqs : 공지사항 일련번호 리스트
     * @return  boolean
     */
    @Transactional
    public boolean deleteBoardList(List<String> seqs) throws Exception {

        if(CollectionUtils.isEmpty(seqs)){
            throw new BadRequestException("삭제할 공지사항 일련번호가 존재하지 않습니다.");
        }

        for(String seq : seqs){
            deleteBoard(seq);
        }
           return true;
    }


    /**
     * 공지 삭제 서비스
     *
     * @param seq : 공지사항 일련번호 리스트
     */
    @Transactional
    public void deleteBoard(String seq) throws Exception {

        var boardDto = commonSvc.getTbBoardDto(seq);

        boardDto.setDelYn("Y");

        tbBoardRepository.save(TbBoardMapper.INSTANCE.toEntity(boardDto));
    }


    /**
     *  공지 수정 정보 조회 서비스
     *
     * @param seq : 공지사항 일련번호
     * @return : 삭제 성공 여부
     */
    @Transactional
    public BoardVo.BoardModifyInfoRes getBoardModifyInfo(String seq) throws Exception {

        var boardDto = commonSvc.getTbBoardDto(seq);

        var info = modelMapper.mapping(boardDto, BoardVo.BoardModifyInfoRes.class);

        if (StringUtils.hasText(boardDto.getBoardFilSeq())) {
            var fileDtos = commonSvc.getTbFileDtoList(boardDto.getBoardFilSeq());
            List<BoardVo.fileInfo> imageInfos = fileDtos.stream().map(file -> customeModelMapper.mapping(file , BoardVo.fileInfo.class))
                    .toList();
            info.setFileInfoList(imageInfos);
        }

        return info;
    }


    /**
     *  공지 등록 서비스
     *
     * @param req : 공지사항 정보
     * @param multipartFiles : 첨부파일 정보
     * @return :  성공 여부
     */
    @Transactional
    public boolean saveBoard(BoardVo.BoarSaveReq req , List<MultipartFile> multipartFiles) throws Exception {

        var boardDto = customeModelMapper.mapping(req , TbBoardDto.class);
        boardDto.setSeq(bizUtil.getSeq(Sequence.BOARD));
        boardDto.setEmcyYn(req.isEmcyYn() ? "Y" : "N");
        boardDto.setHits(0);
        boardDto.setDelYn("N");

        // 이미지 등록
        if (CollectionUtils.isNotEmpty(multipartFiles)) {
            String imageSeq = fileSvc.crtImages(multipartFiles, "04", null);
            boardDto.setBoardFilSeq(imageSeq);
        }

        tbBoardRepository.save(TbBoardMapper.INSTANCE.toEntity(boardDto));

        return true;
    }


    /**
     *  공지 수정 서비스
     *
     * @param req : 공지사항 정보
     * @param multipartFiles : 첨부파일 정보
     * @return : 성공 여부
     */
    @Transactional
    public boolean modifyBoard(BoardVo.BoarModifyReq req , List<MultipartFile> multipartFiles) throws Exception {

        String attcFilCd = "04";

        var boardDto = commonSvc.getTbBoardDto(req.getSeq());

        if(!StringUtils.hasText(boardDto.getSeq())){
            throw new BadRequestException("일련번호에 해당하는 공지 데이터가 존재하지 않습니다.");
        }

        boardDto.setBoardTitle(req.getBoardTitle());
        boardDto.setBoardContents(req.getBoardContents());
        boardDto.setEmcyYn(req.isEmcyYn() ? "Y" : "N");

        // 이미지 등록
        String imageSeq = fileSvc.updImages(multipartFiles, attcFilCd, boardDto.getBoardFilSeq(), req.getFileInfoList());
        boardDto.setBoardFilSeq(imageSeq);

        tbBoardRepository.save(TbBoardMapper.INSTANCE.toEntity(boardDto));

        return true;
    }








}
