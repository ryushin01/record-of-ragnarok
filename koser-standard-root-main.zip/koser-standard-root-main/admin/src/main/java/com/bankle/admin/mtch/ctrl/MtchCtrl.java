package com.bankle.admin.mtch.ctrl;


import com.bankle.admin.mtch.svc.MtchSvc;
import com.bankle.admin.mtch.vo.MtchVo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 관리자 - 배정관리 컨트롤러
 *
 * @author 박원준
 * @version 1.0
 * @since 2025.03.13
 */
@Tag(name = "관리자 - 배정관리", description = "관리자 - 배정관리")
@Slf4j
@RestController
@RequiredArgsConstructor
public class MtchCtrl {

    private final MtchSvc mtchSvc;
    private final CustomeModelMapper modelMapper;

    @Operation(
            summary = "배정관리 목록 조회 API",
            description = """
        요청 데이터:
        
        - 검색 의뢰번호 (searchRqstNo)  
          - 1자 이상 13자 이하 입력 가능  
          - 공백 입력 시 전체 검색  
        
        - 탭 선택 코드 (tabSelection)  
          - 00: 미배정  
          - 01: 배정 완료  
          - 02: 진행 보류  
          - 03: 진행 취소  
        
        - 정렬 방식 (sortOrder)  
          - 00: 의뢰일 순  
          - 01: 대출 실행일 순  
        
        - 현재 페이지 (pageNum)  
        - 페이지에 표시할 데이터 수 (pageSize)  
    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = MtchVo.MtchListRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/admin/match/list")
    public ResponseEntity<?> getMtchlist(@Valid MtchVo.MtchListReq req) throws Exception {
        return ResData.SUCCESS(mtchSvc.mtchList(req), "배정관리 목록 조회 성공");
    }

    @Operation(
            summary = "등기자료 배정하기 (신규등록) API",
            description = """
                        응답 결과:
                        - code 00 / data "00" : 배정 성공
                        - code 99 / data "01" : 등기자료 이미지를 등록해 주세요.
                        - code 99 / data "02" : 이미 등록된 의뢰 번호입니다.
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PostMapping(value = "/admin/match", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> saveMatch(
            @Valid @RequestPart() @Parameter(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE), required = true) MtchVo.SaveMtchReq req,
            @RequestPart(value = "multipartFiles", required = false) @Parameter(content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE)) List<MultipartFile> multipartFiles
    ) throws Exception {

        return switch (mtchSvc.saveMtch(req, multipartFiles, true)) {
            case "00" -> ResData.SUCCESS("00", "배정 성공");
            case "01" -> ResData.FAIL("01", "등기자료 이미지를 등록해 주세요.");
            case "02" -> ResData.FAIL("02", "이미 등록된 의뢰 번호입니다.");
            default -> throw new DefaultException("배정 실패");
        };

    }


    @Operation(
            summary = "등기자료 배정하기 (수정) API",
            description = """
                        응답 결과:
                        - code 00 / data "00" : 배정 성공
                        - code 99 / data "01" : 의뢰 정보가 존재하지 않습니다.
                        - code 99 / data "02" : 이미 배정된 의뢰입니다.
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = String.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @PatchMapping(value = "/admin/match", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> modifyMatch(
            @Valid @RequestPart() @Parameter(content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE), required = true) MtchVo.ModifyMtchReq req,
            @RequestPart(value = "multipartFiles", required = false) @Parameter(content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE)) List<MultipartFile> multipartFiles
    ) throws Exception {

        return switch (mtchSvc.saveMtch(modelMapper.mapping(req , MtchVo.SaveMtchReq.class) , multipartFiles, false)) {
            case "00" -> ResData.SUCCESS("00", "배정 성공");
            case "01" -> ResData.FAIL("01", "의뢰 정보가 존재하지 않습니다.");
            case "02" -> ResData.FAIL("02", "이미 배정된 의뢰입니다.");
            default -> throw new DefaultException("배정 실패");
        };

    }


    @Operation(
            summary = "배정 등록 정보 조회 API",
            description = """
                         요청 데이터:
                         - 의뢰번호 (rqstNo)
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = MtchVo.MtchInfoRes.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/admin/match/{rqstno}")
    public ResponseEntity<?> getMtchInfo(@PathVariable(name = "rqstno") String rqstno) throws Exception {

        return ResData.SUCCESS(mtchSvc.getMtchInfo(rqstno), "조회 성공");

    }


    @Operation(
            summary = "회원 구분에 따른 회원 목록 조회 API",
            description = """
                    요청 데이터:
                    - 회원 구분 코드 (membgb)
                      · 00 : 금융기관
                      · 10 : 법무대리인
                      · 20 : 관리자

                    응답 데이터:
                    - 회원 정보(MemberInfo)는 List 형태로 반환됩니다.
                    - 금융기관 조회 시 사업자번호와 상호명이 반환됩니다.
                    - 법무대리인 관리자 조회 시 회원번호와 회원명이 반환됩니다.
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "성공", content = @Content(schema = @Schema(implementation = MtchVo.MemberInfo.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청", content = @Content(schema = @Schema(implementation = ResData.class)))
    })
    @GetMapping(value = "/admin/match/members/{membgb}")
    public ResponseEntity<?> getMemberList(@PathVariable(name = "membgb") String membGb) throws Exception {

        return ResData.SUCCESS(mtchSvc.getMemberList(membGb), "조회 성공");

    }


}
