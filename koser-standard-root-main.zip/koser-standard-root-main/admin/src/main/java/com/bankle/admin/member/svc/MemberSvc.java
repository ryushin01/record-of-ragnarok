package com.bankle.admin.member.svc;

import com.bankle.admin.member.vo.MemberVo;
import com.bankle.common.code.svc.CommSvc;
import com.bankle.common.commSvc.CommonSvc;
import com.bankle.common.commSvc.FileSvc;
import com.bankle.common.commSvc.vo.ImageVo;
import com.bankle.common.dto.TbCommCodeDto;
import com.bankle.common.dto.TbCustMasterDto;
import com.bankle.common.dto.TbOfficeMasterDto;
import com.bankle.common.entity.TbCustMaster;
import com.bankle.common.entity.TbOfficeMaster;
import com.bankle.common.exception.BadRequestException;
import com.bankle.common.mapper.TbCustMasterMapper;
import com.bankle.common.mapper.TbOfficeMasterMapper;
import com.bankle.common.repo.TbCommCodeRepository;
import com.bankle.common.repo.TbCustMasterRepository;
import com.bankle.common.repo.TbOfficeMasterRepository;
import com.bankle.common.userAuth.UserAuthSvc;
import com.bankle.common.utils.CustomeModelMapper;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 관리자 - 회원관리 > 회원등록
 *
 * @author 정가은
 * @version 1.0
 * @since 2025.03.20
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class MemberSvc {

    private final FileSvc fileSvc;
    private final CommSvc commSvc;
    private final CommonSvc commonSvc;
    private final CustomeModelMapper customeModelMapper;

    private final TbCustMasterRepository tbCustMasterRepository;
    private final TbOfficeMasterRepository tbOfficeMasterRepository;
    private final TbCommCodeRepository tbCommCodeRepository;

    /**
     * 회원 상세 조회
     *
     * @param membNo : 회원번호
     * @return MemberInfoRes : 회원, 사업자 정보
     * @throws EntityNotFoundException 일치하는 회원 정보가 없을 경우
     */
    public MemberVo.MemberInfoRes getMemberDetail(String membNo) throws Exception {
        // 회원 정보 조회
        var custRepo = tbCustMasterRepository.findByMembNo(membNo)
                .orElseThrow(() -> new EntityNotFoundException("회원 번호 : " + membNo));
        var custDto = customeModelMapper.mapping(custRepo, TbCustMasterDto.class);

        // 공통코드 회원 구분 명
        var codeRepo = tbCommCodeRepository.findById_CodeAndId_GrpCd(custDto.getMembGbCd(), "MEMB_GB_CD")
                .orElseThrow(() -> new EntityNotFoundException("회원 유형 : " + custDto.getMembGbCd()));
        var codeDto = customeModelMapper.mapping(codeRepo, TbCommCodeDto.class);

        // 회원 정보 세팅
        MemberVo.MemberDetailRes memberDetail = customeModelMapper.mapping(custDto, MemberVo.MemberDetailRes.class);
        memberDetail.setMembGbNm(codeDto.getCodeNm());
        memberDetail.setJoinDtm(custDto.getJoinDtm().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));

        // 금융기관, 법무대리인 사업자 정보
        MemberVo.OfficeDetailRes officeDetail = new MemberVo.OfficeDetailRes();
        if (List.of("00", "10").contains(custDto.getMembGbCd())) {
            var officeRepo = tbOfficeMasterRepository.findByBizNo(custDto.getBizNo())
                    .orElseThrow(() -> new EntityNotFoundException("사업자 번호 : " + custDto.getBizNo()));
            officeDetail = customeModelMapper.mapping(officeRepo, MemberVo.OfficeDetailRes.class);
        }

        return MemberVo.MemberInfoRes.builder()
                .member(memberDetail)
                .office(officeDetail)
                .build();
    }


    /**
     * 회원 등록 내 사업자 이름 조회
     *
     * @param bizGbCd : 사업자 구분 코드
     * @return (String) : 상태 값
     * @throws Exception
     */
    @Transactional
    public List<MemberVo.bizListRes> getBizList(String bizGbCd) throws Exception {

        List<TbOfficeMaster> tbOfficeMasters = tbOfficeMasterRepository.findByBizGbCdAndStatCd(bizGbCd, "10");

        List<MemberVo.bizListRes> bizNmLists = tbOfficeMasters.stream()
                .map(data -> customeModelMapper.mapping(data, MemberVo.bizListRes.class))
                .toList();

        return bizNmLists;
    }

    /**
     * 회원 등록
     *
     * @param membSaveReq : 사용자 입력 정보
     * @return (String) : 상태 값
     * @throws Exception
     */
    @Transactional
    public String saveMember(MemberVo.memberSaveReq membSaveReq) throws Exception {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        TbCustMasterDto custDto;
        String regMember = UserAuthSvc.getMembNo();

        var cust01 = tbCustMasterRepository.findByMembNo(membSaveReq.getMembNo());
        if (cust01.isPresent()) {
            return "01"; // membNo 존재
        }

        var cust02 = tbCustMasterRepository.findByMembId(membSaveReq.getMembId());
        if (cust02.isPresent()) {
            return "02"; // membId 존재
        }

        if (!isValidPassword(membSaveReq.getPwd())) {
            return "03"; // 비밀번호 정책 위반
        }

        var officeRepo = tbOfficeMasterRepository.findByBizNo(membSaveReq.getBizNo());
        if (!officeRepo.isPresent()) {
            return "04"; // 사업자번호 미존재
        }
        var officeDto = TbOfficeMasterMapper.INSTANCE.toDto(officeRepo.get());

        custDto = TbCustMasterDto.builder()
                .bizNo(membSaveReq.getBizNo())      // 사업자 번호
                .membNo(membSaveReq.getMembNo())    // 회원번호
                .joinDtm(LocalDateTime.now())       // 가입일시
                .membNm(membSaveReq.getMembNm())    // 회원명
                .membHpno(membSaveReq.getMembHpno())// 전화번호
                .membId(membSaveReq.getMembId())    // 아이디
                .membPwd(encoder.encode(membSaveReq.getPwd()))// 비밀번호
                .crtMembNo(regMember)               // 생성자
                .chgMembNo(regMember)               // 수정자
                .membGbCd(officeDto.getBizGbCd())   // 회원유형
                .statCd("10")                       // 회원상태(승인)
                .build();

        // ====================================
        // 회원정보 저장
        // ====================================
        tbCustMasterRepository.save(TbCustMasterMapper.INSTANCE.toEntity(custDto));

        return "00";
    }

    /**
     * 사업자 등록
     *
     * @param bizSaveReq : 사업자 입력 정보
     * @return (String) : 상태 값
     * @throws Exception
     */
    @Transactional
    public String saveBiz(MemberVo.bizSaveReq bizSaveReq, List<MultipartFile> bizLicenseImg, List<MultipartFile> profileImg) throws Exception {

        TbOfficeMasterDto officeDto;

        String bizLicenseSeq = "";
        String profileImgSeq = "";
        String regMember = UserAuthSvc.getMembNo();

        if (!"00".equals(bizSaveReq.getBizGbCd()) && !"10".equals(bizSaveReq.getBizGbCd())) {
            return "01"; // 상호명 구분코드 유효하지 않음
        }

        var officeRepo = tbOfficeMasterRepository.findByBizNo(bizSaveReq.getBizNo());
        if (officeRepo.isPresent()) {
            return "02"; // 사업자 등록번호 이미 존재
        }

        /* 사업자 정보 */
        if (!CollectionUtils.isEmpty(bizLicenseImg)) {  // 사업자등록증 이미지 업로드
            bizLicenseSeq = fileSvc.crtImages(bizLicenseImg, "03", null);
        }

        if (!CollectionUtils.isEmpty(profileImg)) {     // 프로필 이미지 업로드
            profileImgSeq = fileSvc.crtImages(profileImg, "06", null);
        }

        officeDto = TbOfficeMasterDto.builder()
                .bizGbCd(bizSaveReq.getBizGbCd())   // 사업자 구분 코드
                .bizNm(bizSaveReq.getBizNm())       // 상호명
                .bizNo(bizSaveReq.getBizNo())       // 사업자등록번호
                .reptNm(bizSaveReq.getReptNm())     // 대표자명
                .bizAddr(bizSaveReq.getBizAddr())   // 사업장 소재지
                .bizFilSeq(bizLicenseSeq)           // 사업장 등록증 파일일련번호
                .proFilSeq(profileImgSeq)           // 프로필 이미지 파일일련번호
                .crtMembNo(regMember)               // 생성자
                .chgMembNo(regMember)               // 수정자
                .statCd("10")                       // 사업자 상태
                .build();

        // ====================================
        // 사업자 정보 저장
        // ====================================
        tbOfficeMasterRepository.save(TbOfficeMasterMapper.INSTANCE.toEntity(officeDto));

        return "00";
    }

    /**
     * 비밀번호 정책 (비밀번호가 8자 이상 ~ 20자 이하, 숫자/영문자 반드시 포함) 확인
     *
     * @param password
     * @return 비밀번호 정책이 지켜졌을 경우 true
     */
    public static boolean isValidPassword(String password) {
        return Pattern.matches("^(?=.*[A-Za-z])(?=.*\\d)(?!.*[ㄱ-ㅎㅏ-ㅣ가-힣])[A-Za-z\\d!@#$%^&*()_+=\\-{}\\[\\]|:;\"'<>,.?/~`]{8,20}$", password);
    }

    /**
     * 관리자 회원관리 목록 조회
     *
     * @param : 진행상태 Tab, 페이지번호
     * @return : 회원 구분별 회원 목록
     */
    @Transactional
    public MemberVo.MemberListRes getList(MemberVo.MemberListReq req) throws Exception {

        /*
            00 : 전체
            01 : 금융기관
            02 : 법무대리인
            03 : 관리자
        */
        List<String> statCds = switch (req.getTabSelection()) {
            case "00" -> Arrays.asList("00", "10"); // 전체
            case "01" -> List.of("00"); // 금융기관
            case "02" -> List.of("10"); // 법무대리인
//            case "03" -> List.of("20"); // 관리자
            default -> throw new BadRequestException("존재하지 않는 Tap 메뉴 입니다.");
        };

        //가입일 기준 최신순으로 조회
        Sort sort = Sort.by(Sort.Direction.DESC, "joinDtm");
        Pageable pageable = PageRequest.of(req.getPageNum() - 1, req.getPageSize(), sort);

        //원장 페이징 조회
        Page<TbCustMaster> list;

        String membNm = req.getMembNm().trim();
        if (StringUtils.hasText(membNm)) {
            list = tbCustMasterRepository.findByMembGbCdInAndMembNm(statCds, membNm, pageable);
        } else {
            list = tbCustMasterRepository.findByMembGbCdIn(statCds, pageable);
        }

        MemberVo.MemberListRes result = MemberVo.MemberListRes.builder()
                .totalPages(list.getTotalPages())
                .totalElements(list.getTotalElements())
                .build();

        if (list.isEmpty()) {
            result.setMemberList(new ArrayList<>());
            return result;
        }

        // 공통코드 조회
        List<String> multiGprCd = List.of("MEMB_GB_CD");
        Map<String, Map<String, String>> codeMap = commSvc.searchCommCodeMultiList(multiGprCd);

        List<TbCustMasterDto> dtoList = TbCustMasterMapper.INSTANCE.toDtoList(list.getContent());

        List<MemberVo.MemberDetail> memberList = dtoList.stream()
                .map(dto -> {
                    MemberVo.MemberDetail detail = customeModelMapper.mapping(dto, MemberVo.MemberDetail.class);
                    detail.setMembGbNm(codeMap.get("MEMB_GB_CD").get(dto.getMembGbCd()));
                    try {
                        detail.setBizNm(commonSvc.getTbOfficeDto(dto.getBizNo()).getBizNm());
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                    return detail;
                })
                .toList();

        result.setMemberList(memberList);

        return result;

    }

    /**
     * 사업자 등록증 (03) 조회
     *
     * @param : 사업자번호
     * @return ImageRes : 이미지 데이터, 대출실행일
     */
    public ImageVo.ImageRes getBizDocImg(String bizNo) throws Exception {

        ImageVo.ImageInfoReq imageReq = ImageVo.ImageInfoReq.builder()
                .seq(bizNo)
                .attcFilCd("03")
                .build();

        ImageVo.ImageRes imageRes = fileSvc.getImages(imageReq);

        return imageRes;

    }

    /**
     * 프로필 이미지 (06) 조회
     *
     * @param : 사업자번호
     * @return ImageRes : 이미지 데이터
     */
    public ImageVo.ImageRes getProfileImg(String bizNo) throws Exception {
        var office = tbOfficeMasterRepository.findByBizNo(bizNo);

        if (office.isPresent()) {
            ImageVo.ImageInfoReq imageReq = ImageVo.ImageInfoReq.builder()
                    .seq(bizNo)
                    .attcFilCd("06")
                    .build();

            ImageVo.ImageRes imageRes = fileSvc.getImages(imageReq);
            return imageRes;
        }
        return null;

    }

    @Transactional
    public String deleteMember(String membNo) throws Exception {
        var custMasterRepo = tbCustMasterRepository.findByMembNo(membNo);

        if (custMasterRepo.isEmpty()) return "01";

        TbCustMasterDto custDto = customeModelMapper.mapping(custMasterRepo.get(), TbCustMasterDto.class);

        if (!List.of("00", "10").contains(custDto.getMembGbCd())) return "02";

        custDto.setStatCd("30");                        // 회원상태(탈퇴)
        custDto.setChgMembNo(UserAuthSvc.getMembNo());  // 수정자
        // ====================================
        // 회원정보 저장
        // ====================================
        tbCustMasterRepository.save(TbCustMasterMapper.INSTANCE.toEntity(custDto));

        return "00";
    }

}
