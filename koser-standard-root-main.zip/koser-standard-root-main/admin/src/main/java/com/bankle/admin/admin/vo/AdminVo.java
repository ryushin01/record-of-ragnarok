package com.bankle.admin.admin.vo;

import com.bankle.admin.mtch.vo.MtchVo;
import com.bankle.common.annotation.LocalDateTimeToString;
import com.bankle.common.annotation.NullToEmptyString;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AdminVo {
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class adminSaveReq {

        @NotEmpty(message = "회원 번호를 입력해 주세요")
        @Schema(name = "membNo", example = "25040100001")
        @Size(min = 11, max = 11, message = "회원번호는 11자리 입니다.")
        String membNo;

        @Schema(name = "membNm", example = "나관리")
        String membNm;

        @Schema(name = "membHpno", example = "01077778888")
        String membHpno;

        @NotEmpty(message = "아이디를 입력해 주세요")
        @Schema(name = "membId", example = "mng11111")
        String membId;

        @NotEmpty(message = "비밀번호를 입력해 주세요")
        @Schema(name = "pwd", example = "mng11111")
        String pwd;

    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AdminListReq {
        @Size(max = 50 , message =  "검색 회원명은 50자리까지 입력 가능합니다.")
        @Schema(description = "검색 회원명", example = "홍길동")
        private String searchMembNm;

        @Min(value = 1, message = "현재 페이지는 1 이상이어야 합니다.")
        @Schema( description = "현재 페이지" , example = "1")
        private int pageNum;

        @Min(value = 1, message = "페이지에 보여지는 데이터 수는 1 이상이어야 합니다.")
        @Schema( description = "페이지에 보여지는 데이터수" , example = "50")
        private int pageSize;
    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AdminListRes {
        @Schema(description = "전체 페이지 개수", example = "7")
        private int totalPages = 0;

        @Schema(description = "전체 데이터 개수 (검색된 모든 데이터 항목 수)", example = "100")
        private long totalElements = 0;

        @Schema(description = "관리자 정보 리스트")
        private List<AdminInfo> adminList = new ArrayList<>();
    }


    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AdminInfo {

        @Schema(description = "회원번호", example = "25040100001")
        @NullToEmptyString
        private String membNo;

        @Schema(description = "회원유형 코드", example = "25040100001")
        @NullToEmptyString
        private String membGbCd;

        @Schema(description = "회원유형 명", example = "25040100001")
        @NullToEmptyString
        private String membGbNm;

        @Schema(description = "회원명", example = "나관리")
        @NullToEmptyString
        private String membNm;

        @Schema(description = "전화번호", example = "01077778888")
        @NullToEmptyString
        private String membHpno;

        @Schema(description = "아이디", example = "bankle")
        @NullToEmptyString
        private String membId;

        @Schema(description = "가입일", example = "2025-04-09")
        @LocalDateTimeToString(pattern = "yyyy-MM-dd")
        private LocalDateTime joinDtm;

    }



    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ModifyAdminInfoRes {

        @Schema(description = "회원번호", example = "25040100001")
        @NullToEmptyString
        private String membNo;

        @Schema(description = "가입일", example = "2025-04-09")
        @LocalDateTimeToString(pattern = "yyyy-MM-dd")
        private LocalDateTime joinDtm;

        @Schema(description = "회원명", example = "나관리")
        @NullToEmptyString
        private String membNm;

        @Schema(description = "전화번호", example = "01077778888")
        @NullToEmptyString
        private String membHpno;

        @Schema(description = "아이디", example = "bankle")
        @NullToEmptyString
        private String membId;

        @Schema(description = "비밀번호", example = "bankle123")
        @NullToEmptyString
        private String membPwd;

    }



    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ModifyAdminReq {

        @NotEmpty(message = "회원 번호를 입력해 주세요")
        @Schema(description = "회원번호" , example = "20250408003")
        @Size(min = 11, max = 11, message = "회원번호는 11자리 입니다.")
        private String membNo;

        @Schema(description = "회원명", example = "나관리")
        @Size(max = 50, message = "회원명은 50자리가 까지 입력 가능 합니다.")
        private String membNm;

        @Schema(description = "전화번호", example = "01077778888")
        @Size(max = 13, message = "전화번호는 13자리가 까지 입력 가능 합니다.")
        private String membHpno;

        @Schema(description = "아이디", example = "mng11111")
        @Size(max = 20, message = "아이디는 20자리가 까지 입력 가능 합니다.")
        private String membId;

        @Schema(description = "비밀번호", example = "mng11111")
//        @Size(max = 50, message = "비밀번호는 50자리가 까지 입력 가능 합니다.")
        private String membPwd;

    }







}
