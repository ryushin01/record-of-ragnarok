

## 서버 포트 (사용 프로젝트에 따라 변경해서 사용바람)
| 서버명          | 포트   |
|--------------|------|
| * admin      | 8074 |
| * api        | 8073 |
| * app        | 8071 |
| * batch      | 8075 |

## 맥(mac)에서 포트(port) 확인후 포트 강제 종료
```shell
lsof -i :[포트번호] 
kill -9 [pid번호]
```

## 윈도우(win)에서 포트(port) 확인후 강제 종료
```shell
netstat -ano 
taskkill /f /pid [PID번호]
```

## JDK 17 정보
- https://techblog.gccompany.co.kr/%EC%9A%B0%EB%A6%AC%ED%8C%80%EC%9D%B4-jdk-17%EC%9D%84-%EB%8F%84%EC%9E%85%ED%95%9C-%EC%9D%B4%EC%9C%A0-ced2b754cd7

## DB 접속 정보 (프로젝트에 따라 설정)
```
Host: 
Port: 
ID: 
PW: 

```

## Was 접속 정보 (프로젝트에 따라 설정)
```
Host: 
Port: 
ID: 
PW: 

```

## Web 접속 정보 (프로젝트에 따라 설정)
```
Host: 
Port: 
ID: 
PW: 


```
