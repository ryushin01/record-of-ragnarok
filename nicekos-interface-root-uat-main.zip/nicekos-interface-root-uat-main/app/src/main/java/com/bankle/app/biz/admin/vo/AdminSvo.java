package com.bankle.app.biz.admin.vo;

import lombok.Getter;
import lombok.Setter;

public class AdminSvo {

    /**
     * 로그인
     */
    @Getter
    @Setter
    public static class AdminLoginInSvo {
        /**
         * 아이디
         */
        private String lognId;

        /**
         * 비밀번호
         */
        private String pwd;
    }

    @Getter
    @Setter
    public static class AdminLoginOutSvo {
        /**
         * 로그인 중 여부
         */
        private String lognYn;
        /**
         * 결과코드
         */
        private String resCd;
        /**
         * 관리자 번호
         */
        private String membNo;
        /**
         * 관리자명
         */
        private String adminNm;

        /**
         * 권한 코드
         */
        private String permCd;
        /**
         * 권한 코드명
         */
        private String permNm;
        /**
         * 아이디
         */
        private String lognId;
        /**
         * 비밀번호
         */
        private String pwd;
        /**
         * 휴대폰번호
         */
        private String cphnNum;
        /**
         * 로그인 실패 횟수
         */
        private Integer lognFailCnt;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 상태명
         */
        private String statNm;
        /**
         * accessToken
         */
        private String accessToken;
        /**
         * refreshToken
         */
        private String refreshToken;
    }
}
