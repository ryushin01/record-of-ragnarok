package com.bankle.app.biz.trn.svc;

import com.bankle.app.biz.trn.vo.TranHistSvo;
import com.bankle.app.biz.trn.vo.TransSvo;
import com.bankle.common.code.svc.CommSvc;
import com.bankle.common.entity.TbWoTrnCommMaster;
import com.bankle.common.entity.TbWoTrnStndMaster;
import com.bankle.common.mapper.TbWoTrnCommMasterMapper;
import com.bankle.common.mapper.TbWoTrnStndMasterMapper;
import com.bankle.common.repo.TbCommCodeRepository;
import com.bankle.common.repo.TbWoTrnCommMasterRepository;
import com.bankle.common.repo.TbWoTrnStndMasterRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class TranHistSvc {

    private final TbWoTrnStndMasterRepository tbWoTrnStndMasterRepository;

    private final TbWoTrnCommMasterRepository tbWoTrnCommMasterRepository;

    private final CommSvc commSvc;

    @Transactional(rollbackFor = {Exception.class})
    public List<TranHistSvo.TranHistOutSvo> getByLoanNo(String loanNo) throws Exception {

        List<String> multiGprCd = List.of("TG_DSC");
        Map<String, Map<String, String>> codeMap = commSvc.searchCommCodeMultiList(multiGprCd);

        List<TbWoTrnStndMaster> stndEntityList = tbWoTrnStndMasterRepository.findByApprovalNum(loanNo);
        List<TranHistSvo.TranHistOutSvo> tranHistSvoList = new ArrayList<>();

        if (stndEntityList.stream().count() > 0) {
            tranHistSvoList.addAll(
                    TbWoTrnStndMasterMapper.INSTANCE.toDtoList(stndEntityList).stream()
                            .map(e -> TranHistSvo.TranHistOutSvo.builder()
                                    .seq(StringUtils.hasText(e.getSeq()) ? e.getSeq() : "")
                                    .resYn(StringUtils.hasText(e.getResYn()) ? e.getResYn() : "")
                                    .resCd(StringUtils.hasText(e.getResCode()) ? e.getResCode() : "")
                                    .trnKnd(StringUtils.hasText(e.getTrnKnd()) ? e.getTrnKnd() : "")
                                    .trnName(StringUtils.hasText(e.getTrnName()) ? e.getTrnName() : "")
                                    .reqDttm(e.getReqDttm())
                                    .build())
                            .toList());
        }

        List<TbWoTrnCommMaster> commEntityList = tbWoTrnCommMasterRepository.findByLnAprvNo(loanNo);

        if (commEntityList.stream().count() > 0) {
            tranHistSvoList.addAll(
                    TbWoTrnCommMasterMapper.INSTANCE.toDtoList(commEntityList).stream()
                            .map(e -> TranHistSvo.TranHistOutSvo.builder()
                                    .seq(StringUtils.hasText(e.getTgSqn()) ? e.getTgSqn() : "")
                                    .resYn(StringUtils.hasText(e.getResTgFnYn()) ? e.getResTgFnYn() : "")
                                    .resCd(StringUtils.hasText(e.getResCd()) ? e.getResCd() : "")
                                    .trnKnd(StringUtils.hasText(e.getTgDsc()) ? e.getTgDsc() : "")
                                    .trnName(
                                            (codeMap.containsKey("TG_DSC") &&
                                                    codeMap.get("TG_DSC") != null &&
                                                    StringUtils.hasText(codeMap.get("TG_DSC").get(e.getTgDsc())))
                                                    ? codeMap.get("TG_DSC").get(e.getTgDsc())
                                                    : ""
                                    )
                                    .reqDttm(e.getReqDtm())
                                    .build())
                            .toList());
        }

        //리스트를 내림차순으로 정렬
        if (tranHistSvoList.stream().count() > 0) {
            tranHistSvoList = tranHistSvoList.stream()
                    .sorted(Comparator.comparing(TranHistSvo.TranHistOutSvo::getReqDttm, Comparator.nullsLast(Comparator.reverseOrder()))) //내림차순 : reverseOrder() , 오름차순 : naturalOrder()
                    .toList();
        }

        return tranHistSvoList;
    }
}
