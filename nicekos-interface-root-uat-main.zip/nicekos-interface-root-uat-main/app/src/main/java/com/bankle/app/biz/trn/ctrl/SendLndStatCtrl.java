package com.bankle.app.biz.trn.ctrl;

import com.bankle.app.biz.trn.svc.SendLndStatSvc;
import com.bankle.app.biz.trn.vo.SendLndStatCvo;
import com.bankle.app.biz.trn.vo.SendLndStatSvo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "1. 원장", description = "원장 관리 API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class SendLndStatCtrl {
    private final CustomeModelMapper customeModelMapper;
    private final SendLndStatSvc sendLndStatSvc;
    @Operation(summary = "청약 의뢰 전문 전송(F6300)", description = "청약 의뢰 전문 전송(F6300) 서비스")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "청약 의뢰 전문 전송(F6300) 성공", content = @Content(schema = @Schema(implementation = SendLndStatCvo.SendLndStatReqCvo.class))),
    })
    @PostMapping("/trn/sendlndstat")
    public ResponseEntity<?> save(@RequestBody SendLndStatCvo.SendLndStatReqCvo reqCvo) throws Exception {
        try {
            boolean valid = sendLndStatSvc
                    .save(customeModelMapper
                            .mapping(reqCvo, SendLndStatSvo.SendLndStatInSvo.class));
            if (valid) {
                return ResData.SUCCESS(reqCvo, "성공");
            } else {
                return ResData.FAIL(reqCvo, "실패");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }
}
