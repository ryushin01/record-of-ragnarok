package com.bankle.app.biz.trn.svc;


import com.bankle.app.biz.trn.vo.LoanExeSvo;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.DateUtil;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6100F1Svo;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import com.bankle.common.wooriApi.socket.woori.sendSvc.SendA700Svc;
import com.bankle.common.wooriApi.socket.woori.sendSvc.vo.SendA700Svo;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class LoanExeSvc {

    private final SendA700Svc sendA700Svc;

    private final BizUtil bizUtil;

    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;

    @Transactional
    public boolean save(@Valid LoanExeSvo.LoanExeInSvo inSvo) throws Exception {

        //------------------------------------------------------------------
        // 원장 조회
        //------------------------------------------------------------------
        String LoanNo = inSvo.getLoanNo();
        TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(inSvo.getLoanNo())
                .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));
        var tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);
        //------------------------------------------------------------------
        // 전문 전송
        //------------------------------------------------------------------
        String trnNm = "";
        switch (inSvo.getProcDvsn()) {
            case "1" : trnNm = "대출실행 통지"; break;
            case "2" : trnNm = "대출취소 통지"; break;
            case "3" : trnNm = "근저당 설정 보정 발생 통지"; break;
            case "4" : trnNm = "전자 설정 접수번호 통지"; break;
            default: trnNm = ""; break;
        }
        SendA700Svo.SendA700InSvo sendInSvo =  SendA700Svo.SendA700InSvo.builder()
                .loanNo(LoanNo)
                .trLn(inSvo.getTrLn())
                .trnName(trnNm)
                .trCd(inSvo.getTrCd())
                .trTpCd(inSvo.getTrTpCd())
                .loNo(inSvo.getLoNo())
                .trSq(inSvo.getTrSq())
                .approvalNum(LoanNo)
                .exeDtm(inSvo.getExeDtm())
                .procDvsn(inSvo.getProcDvsn())
                .exeAmt(inSvo.getExeAmt())
                .categoryCd(inSvo.getCategoryCd())
                .docTax(inSvo.getDocTax())
                .debtDcAmt(inSvo.getDebtDcAmt())
                .etcAmt(inSvo.getEtcAmt())
                .insGbn(tbWoCntrMasterDto.getInsDvsn())
                .build();
        CheckResponseSvo checkResponseSvo = sendA700Svc.sendAndResponse(sendInSvo);
        return "000".equals(checkResponseSvo.getRescode());
    }
}

