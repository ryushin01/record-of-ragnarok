package com.bankle.app.biz.trn.vo;

import lombok.Data;

import java.io.InputStream;

public class TrnTgSvo {

    @Data
    public static class TrnTgInVo  {
        private String tgDsc;

        private String stdYn;

        private int trnLen;

        private String lnAprvNo;

        private byte[] data;

        private InputStream inputStream;
    }

    @Data
    public static class TrnTgOutVo  {

        private String tgDsc;

        private String stdYn;

        private int trnLen;

        private String lnAprvNo;

        private int contentLength;

        private InputStream inputStream;
    }

    @Data
    public static class TrnTgTempInVo  {
        private String tgDsc;

        private String stdYn;

        private int trnLen;

        private String lnAprvNo;

        private byte[] data;

        private InputStream inputStream;

        private String payCd;

        private String bankCd;

        private String tpCd;
    }

    @Data
    public static class TrnTgTempOutVo  {
        private String tgDsc;

        private String stdYn;

        private int trnLen;

        private String lnAprvNo;

        private byte[] data;

        private int contentLength;

        private InputStream inputStream;
    }

    @Data
    public static class TrnRcvTgInVo  {
        private String tgDsc;

        private String insGbn;

        private String stdYn;

        private int trnLen;

        private String lnAprvNo;

        private byte[] data;

        private InputStream inputStream;
    }
}
