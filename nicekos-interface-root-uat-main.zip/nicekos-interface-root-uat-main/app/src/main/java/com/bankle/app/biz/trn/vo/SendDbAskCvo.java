package com.bankle.app.biz.trn.vo;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class SendDbAskCvo {

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class SendDbAskReqCvo {

        private String loanNo;
        private String newLoanNo;
        private BigDecimal tgLen;
        private String tgDsc;
        private String resCd;
        private String lndAgncCd;
        private String bnkTgTrnsDtm;
        private String dbTgTrnsDtm;
        private String bnkTgNo;
        private BigDecimal dbTgNo;
        private String rsrvItmH;
        private String bnkAskNo;
        private String dbMngNo;
        private String kosTgTrnsDtm;
        private String kosTgNo;
        private String procDvsnCd;
        private String rthIsrnEntrYn;
        private String rthIsrnEntrCmpy;
        private String rthIsrnScrtNo;
        private String pstNo;
        private String crtdnCd;
        private String trgtAddr;
        private String trgtDtlAddr;
        private String rgstrUnqNo1;
        private String rgstrUnqNo2;
        private String rgstrUnqNo3;
        private String lndKndCd;
        private String fndYn;
        private String prdtNm;
        private String prdtCd;
        private String grntAgncCd;
        private String srvTrgtYn;
        private String stndTrgtYn;
        private String rrcpChrgTrgtYn;
        private String rvsnCntrctChrgTrgtYn;
        private String sscptAskDt;
        private String lndPlnDt;
        private String rntlPrdEndDt;
        private String lndExprdDt;
        private BigDecimal lndPrd;
        private BigDecimal lndAmt;
        private BigDecimal isrnEntrAmt;
        private BigDecimal objtEbnkRgstrRnk;
        private BigDecimal objtEbnkBndMaxAmt;
        private BigDecimal mggFnlOdprtAmt;
        private BigDecimal trolFnlOdprtAmt;
        private String srvcEndDt;
        private String dbtrNm;
        private String dbtrRrno;
        private String dbtrPstNo;
        private String dbtrAddr;
        private String dbtrPhno;
        private String dbtrHpno;
        private String wdngPlnYn;
        private String wdngPlnDt;
        private String hshldrCnddtYn;
        private String unmrdHshldr25agLstnYn;
        private String acptDsc;
        private String lwfmNm;
        private String lwfmBizno;
        private String askBrnchCd;
        private String askBrnchNm;
        private String askBrnchDrctrNm;
        private String askBrnchPhno;
        private String bnkLesDsc;
        private String fndLesDsc;
        private String cndtlCnts;
        private String isrnPrmm;
        private String rsrvItmB;
        private LocalDateTime regDtm;
        private String loanAprvNo2;
        private String slmnLndProc;
        private String srMembNo;
        private BigDecimal trAmt;
        private String sellerNm1;
        private String sellerBirthDt1;
        private String sellerNm2;
        private String sellerBirthDt2;
        private BigDecimal ownLoanMaxAmt;
        private BigDecimal ownLoanPlnAmt;
        private String ownLoanBankNm1;
        private String ownLoanBankNm2;
        private String ownLoanBankNm3;
        private String ownLoanBankNm4;
        private String ownLoanBankNm5;
        private String cnsgnNm;
        private String trstNm;
        private String bnfrNm;
        private String nowLessNm;
    }
}
