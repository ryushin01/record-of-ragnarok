package com.bankle.app.biz.payment.svc;

import com.bankle.app.biz.cntr.dao.CntrDtlDao;
import com.bankle.app.biz.cntr.vo.CntrSvo;
import com.bankle.app.biz.payment.vo.PaymentCvo;
import com.bankle.app.biz.payment.vo.PaymentSvo;
import com.bankle.common.dto.TbCommCodeDto;
import com.bankle.common.dto.TbWoCntrPaymentListDto;
import com.bankle.common.entity.TbCommCode;
import com.bankle.common.entity.TbWoCntrPaymentList;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbCommCodeMapper;
import com.bankle.common.mapper.TbWoCntrPaymentListMapper;
import com.bankle.common.repo.TbCommCodeRepository;
import com.bankle.common.repo.TbWoCntrPaymentListRepository;
import com.bankle.common.utils.CustomeModelMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentSvc {


    private final TbWoCntrPaymentListRepository tbWoCntrPaymentListRepo;
    private final TbCommCodeRepository tbCommCodeRepo;
    private final CustomeModelMapper customeModelMapper;

    @Transactional(rollbackFor = {Exception.class})
    public List<PaymentCvo.PaymentInfoResCvo> findPaymentInfoList(String loanNo) throws Exception {
        try {
            log.debug("START getByLoanNo :" + loanNo);

            // 지급 정보 조회
            List<TbWoCntrPaymentList> payEntityList = tbWoCntrPaymentListRepo.findAllById_LoanNoAndDelYn(loanNo, "N");
            if (payEntityList.isEmpty()) {
                throw new DefaultException("여신번호에 해당하는 지급정보가 존재하지 않습니다.");
            }

            // 은행 코드 리스트 및 지급 구분 코드 리스트 조회
            Map<String, String> bankCodeMap = tbCommCodeRepo.findByGrpCdAndUseYn("BANK_GB", "Y").stream()
                    .collect(Collectors.toMap(TbCommCode::getCode, TbCommCode::getCodeNm));
            Map<String, String> payCodeMap = tbCommCodeRepo.findByGrpCdAndUseYn("PAY_GB", "Y").stream()
                    .collect(Collectors.toMap(TbCommCode::getCode, TbCommCode::getCodeNm));
            Map<String, String> statCodeMap = tbCommCodeRepo.findByGrpCdAndUseYn("PAY_STAT", "Y").stream()
                    .collect(Collectors.toMap(TbCommCode::getCode, TbCommCode::getCodeNm));

            // 지급 정보 매핑
            return TbWoCntrPaymentListMapper.INSTANCE.toDtoList(payEntityList).stream()
                    .map(info -> PaymentSvo.PaymentInfoOutSvo.builder()
                            .loanNo(info.getId().getLoanNo())       // 여신번호
                            .no(info.getId().getNo())               // 입력순번
                            .payCd(getPayCd(info.getPayCd(),info.getBankCd())) // 지급구분코드
                            .payNm(payCodeMap.getOrDefault(info.getPayCd(), "")) // 지급대상
                            .statCd(getValueOrEmpty(info.getStatCd())) // 지급구분코드
                            .statNm(statCodeMap.getOrDefault(info.getStatCd(), "")) // 지급상태명
                            .bankCd(getValueOrEmpty(info.getBankCd())) // 은행코드
                            .bankNm(bankCodeMap.getOrDefault(info.getBankCd(), "")) // 은행명
                            .payAmt(info.getPayAmt())               // 지급금액
                            .payReqDt(getValueOrEmpty(info.getPayReqDt())) // 지급신청일
                            .payCmplDt(getValueOrEmpty(info.getPayCmplDt())) // 지급완료일
                            .rcptRegDtm(info.getRcptRegDtm())       // 영수증등록일시
                            .rcptBnkTransDtm(info.getRcptBnkTransDtm()) // 영수증은행전송일시
                            .gpsInfo(getValueOrEmpty(info.getGpsInfo())) // GPS정보
                            .build())
                    .map(data -> customeModelMapper.mapping(data, PaymentCvo.PaymentInfoResCvo.class))
                    .toList();

        } catch (Exception e) {
            log.error("Error in findPaymentInfoList", e);
            throw new DefaultException(e.getMessage());
        }
    }

    private String getValueOrEmpty(String value) {
        return StringUtils.hasText(value) ? value : "";
    }

    private String getPayCd(String payCd, String bankCd) {
        if (!StringUtils.hasText(payCd)) return "";

        return switch (payCd) {
            case "01" -> "SEL"; // 차주
            case "02" -> "BUY"; // 매도인/임대인
            case "03", "04" -> // 당행 타행
                    StringUtils.hasText(bankCd) ? bankCd : "";
            default -> "";
        };
    }

}














