package com.bankle.app.biz.trn.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;


public class ImageSendRsltSvo {

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class ImageSendRsltInSvo {
        @Schema(description = "대출번호")
        private String loanNo;

        @Schema(description = "전문길이 (504에서 4를 뺀 500으로 고정)")
        private String trLn;

        @Schema(description = "전문종별코드")
        private String trCd;

        @Schema(description = "거래구분코드")
        private String trTpCd;

        @Schema(description = "관리번호")
        private String loNo;

//        @Schema(description = "식별번호")
//        private String trSq;
//
//        @Schema(description = "송신일자 (YYYYMMDDHHMMSS 형식)")
//        private String reqDttm;
//
//        @Schema(description = "수신일자 (YYYYMMDDHHMMSS 형식)")
//        private String resDttm;
//
//        @Schema(description = "응답코드")
//        private String resCd;
//
//        @Schema(description = "여신승인신청번호")
//        private String approvalNum;

        @Schema(description = "이미지구분 (1: 소유권이전서류, 2: 당행상환영수증, 3: 타행상환영수증, 4: 근저당설정계약서, 5: 등기부등본, 6: 잔금완납영수증, 7: 등기접수증, 8: 등기필정보)")
        private String imgTp;

        @Schema(description = "이미지확인여부 (Y/N)")
        private String imgCheckYn;

        @Schema(description = "이미지 키 (고유 식별값)")
        private String imgKey;

        @Schema(description = "이미지 페이지 수")
        private String imgPageCnt;

        @Schema(description = "시퀀스번호")
        private String seqNo;

        @Schema(description = "이미지 파일명")
        private String imgFileName;

        @Schema(description = "처리결과 (성공/실패 코드)")
        private String resultCd;

        @Schema(description = "공란 (미사용 데이터 공간)")
        private String filler;
    }
}
