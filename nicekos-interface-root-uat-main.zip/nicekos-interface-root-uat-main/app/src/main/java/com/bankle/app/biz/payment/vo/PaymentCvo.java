package com.bankle.app.biz.payment.vo;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;


public class PaymentCvo {


    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class PaymentInfoResCvo {
        @Schema(description = "여신번호")
        String loanNo;
        @Schema(description = "입력순번")
        Integer no;
        @Schema(description = "지급구분코드")
        String payCd;
        @Schema(description = "지급대상 ex) 차주")
        String payNm;
        @Schema(description = "지급상태코드")
        String statCd;
        @Schema(description = "지급상태명")
        String statNm;
        @Schema(description = "은행코드")
        String bankCd;
        @Schema(description = "은행명")
        String bankNm;
        @Schema(description = "지급금액")
        BigDecimal payAmt;
        @Schema(description = "지급신청일")
        String payReqDt;
        @Schema(description = "지급완료일")
        String payCmplDt;
        @Schema(description = "영수증등록일시")
        LocalDateTime rcptRegDtm;
        @Schema(description = "영수증은행전송일시")
        LocalDateTime rcptBnkTransDtm;
        @Schema(description = "GPS정보")
        String gpsInfo;
    }

}
