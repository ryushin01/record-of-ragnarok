package com.bankle.app.biz.cntr.vo;

import com.bankle.common.vo.PageResData;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class CntrMasterSvo {
    /*================================================================================================================*/

    /**
     * 원장 리스트 조회
     */
    @Getter
    @Setter
    public static class CntrLstInSvo {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 사업자등록번호
         */
        private String bizNo;
        /**
         * 보험구분코드
         */
        private String isrnGbCd;
        /**
         * 은행지점코드
         */
        private String bnkBrnchCd;
        /**
         * 은행구분코드
         */
        private String bnkGbCd;
        /**
         * 지점명
         */
        private String bnkBrnchNm;
        /**
         * 은행 담당자 명
         */
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        private String lndKndCd;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 대출상태코드
         */
        private String lndStatCd;
        /**
         * 등기 구분 코드
         */
        private String rgstrGbCd;
        /**
         * 대출상품명
         */
        private String lndPrdtNm;
        /**
         * 차주명
         */
        private String dbtrNm;
        /**
         * 차주생년월일
         */
        private String dbtrBirthDt;
        /**
         * 차주 주소지
         */
        private String dbtrAddr;
        /**
         * 차주 핸드폰 번호
         */
        private String dbtrHpno;
        /**
         * 담보제공자명
         */
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰 번호
         */
        private String pwpsHpno;
        /**
         * 실행예정일자
         */
        private String execPlnDt;
        /**
         * 실행금액
         */
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        private String execDt;
        /**
         * 매매가액
         */
        private BigDecimal slPrc;
        /**
         * 법무사타은행코드1
         */
        private String lwyrDiffBankCd1;
        /**
         * 법무사타은행코드2
         */
        private String lwyrDiffBankCd2;
        /**
         * 법무사타은행코드3
         */
        private String lwyrDiffBankCd3;
        /**
         * 법무사타은행코드4
         */
        private String lwyrDiffBankCd4;
        /**
         * 법무사타은행코드5
         */
        private String lwyrDiffBankCd5;
        /**
         * 법무사타은행코드6
         */
        private String lwyrDiffBankCd6;
        /**
         * 법무사타은행코드7
         */
        private String lwyrDiffBankCd7;
        /**
         * 법무사타은행코드8
         */
        private String lwyrDiffBankCd8;
        /**
         * 법무사타은행코드9
         */
        private String lwyrDiffBankCd9;
        /**
         * 법무사타은행코드10
         */
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        private String ersuClsMsg;
        /**
         * 설정법무사 사업자번호
         */
        private String ebtsLwyrBizNo;
        /**
         * 등기소명
         */
        private String regoNm;
        /**
         * 등기접수일시
         */
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지 키
         */
        private String imgKey;
        /**
         * 대출구분코드
         */
        private String kndCd;
        /**
         * 대출물건지주소(asis:address)
         */
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        private String rdnmInclAddr;
        /**
         * 그룹번호(ASIS:M_APPROVAL_NUM)
         */
        private String grpNo;
        /**
         * 비고
         */
        private String rmk;
        /**
         * INS_DVSN
         */
        private String insDvsn;
        /**
         * 전문인입횟수
         */
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록 일자
         */
        private String refndAcctRegDate;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        private String regifRegYn;
        /**
         * 지급정보 등록 여부
         */
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        private String estmCntrFnYn;
        /**
         * 매매 계약서 유무
         */
        private String slCntrctEane;
        /**
         * 매매 계약서 파일명
         */
        private String slCntrctFlnm;
        /**
         * 전입세대열람원 제출여부
         */
        private String mvhhdSbmtYn;
        /**
         * 주민등록등본 제출여부
         */
        private String rrcpSbMtYn;
        /**
         * 수정임대차 계약서 제출 여부
         */
        private String rtalSbmtYn;
        /**
         * 조건부 계약여부
         */
        private String cndtCntrYn;
        /**
         * 등기신청번호 등록여부
         */
        private String rgstrAcptSbmtYn;
        /**
         * 이전등기 가능 법무사 유무
         */
        private String cnvntLwyrYn;

        private String offRgstrYn;

        private String rdnmStndAddr;

        private String a300Send;
        private String stndAplYn;
        /**
         * 페이지 번호
         */
        private Integer page;

        /**
         * Page 번호
         */
        private Integer pageSize;
    }

    @Getter
    @Setter
    public static class CntrLst extends PageResData {
        List<CntrLstOutSvo> list;
    }

    @Getter
    @Setter
    public static class CntrLstOutSvo {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 사업자등록번호
         */
        private String bizNo;
        /**
         * 보험구분코드
         */
        private String isrnGbCd;
        /**
         * 은행지점코드
         */
        private String bnkBrnchCd;
        /**
         * 은행구분코드
         */
        private String bnkGbCd;
        /**
         * 은행구분명
         */
        private String bnkNm;
        /**
         * 지점명
         */
        private String bnkBrnchNm;
        /**
         * 은행 담당자 명
         */
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        private String lndKndCd;
        /**
         * 대출종류명
         */
        private String lndKndNm;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 상태명
         */
        private String statNm;

        /**
         * 대출상태코드
         */
        private String lndStatCd;
        /**
         * 대출상태명
         */
        private String lndStatNm;
        /**
         * 등기 구분 코드
         */
        private String rgstrGbCd;
        /**
         * 등기 구분명
         */
        private String rgstrGbNm;
        /**
         * 대출상품명
         */
        private String lndPrdtNm;
        /**
         * 차주명
         */
        private String dbtrNm;
        /**
         * 차주생년월일
         */
        private String dbtrBirthDt;
        /**
         * 차주 주소지
         */
        private String dbtrAddr;
        /**
         * 차주 핸드폰 번호
         */
        private String dbtrHpno;
        /**
         * 담보제공자명
         */
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰 번호
         */
        private String pwpsHpno;
        /**
         * 실행예정일자
         */
        private String execPlnDt;
        /**
         * 실행금액
         */
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        private String execDt;
        /**
         * 매매가액
         */
        private BigDecimal slPrc;
        /**
         * 법무사타은행코드1
         */
        private String lwyrDiffBankCd1;
        /**
         * 법무사타은행코드2
         */
        private String lwyrDiffBankCd2;
        /**
         * 법무사타은행코드3
         */
        private String lwyrDiffBankCd3;
        /**
         * 법무사타은행코드4
         */
        private String lwyrDiffBankCd4;
        /**
         * 법무사타은행코드5
         */
        private String lwyrDiffBankCd5;
        /**
         * 법무사타은행코드6
         */
        private String lwyrDiffBankCd6;
        /**
         * 법무사타은행코드7
         */
        private String lwyrDiffBankCd7;
        /**
         * 법무사타은행코드8
         */
        private String lwyrDiffBankCd8;
        /**
         * 법무사타은행코드9
         */
        private String lwyrDiffBankCd9;
        /**
         * 법무사타은행코드10
         */
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        private String ersuClsMsg;
        /**
         * 설정법무사 사업자번호
         */
        private String ebtsLwyrBizNo;
        /**
         * 등기소명
         */
        private String regoNm;
        /**
         * 등기접수일시
         */
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지 키
         */
        private String imgKey;
        /**
         * 대출구분코드
         */
        private String kndCd;
        /**
         * 대출구분명
         */
        private String kndNm;
        /**
         * 대출물건지주소(asis:address)
         */
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        private String rdnmInclAddr;
        /**
         * 그룹번호(ASIS:M_APPROVAL_NUM)
         */
        private String grpNo;
        /**
         * 비고
         */
        private String rmk;
        /**
         * INS_DVSN
         */
        private String insDvsn;
        /**
         * 전문인입횟수
         */
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록 일자
         */
        private String refndAcctRegDate;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        private String regifRegYn;
        /**
         * 지급정보 등록 여부
         */
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        private String estmCntrFnYn;
        /**
         * 매매 계약서 유무
         */
        private String slCntrctEane;
        /**
         * 매매 계약서 파일명
         */
        private String slCntrctFlnm;
        /**
         * 전입세대열람원 제출여부
         */
        private String mvhhdSbmtYn;
        /**
         * 주민등록등본 제출여부
         */
        private String rrcpSbMtYn;
        /**
         * 수정임대차 계약서 제출 여부
         */
        private String rtalSbmtYn;
        /**
         * 조건부 계약여부
         */
        private String cndtCntrYn;
        /**
         * 등기신청번호 등록여부
         */
        private String rgstrAcptSbmtYn;
        /**
         * 이전등기 가능 법무사 유무
         */
        private String cnvntLwyrYn;
    }
    /*================================================================================================================*/

    /**
     * 원장 업데이트
     */
    @Getter
    @Setter
    public static class UpdCntrMasterInSvo {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 사업자등록번호
         */
        private String bizNo;
        /**
         * 보험구분코드
         */
        private String isrnGbCd;
        /**
         * 은행지점코드
         */
        private String bnkBrnchCd;
        /**
         * 은행구분코드
         */
        private String bnkGbCd;
        /**
         * 지점명
         */
        private String bnkBrnchNm;
        /**
         * 은행 담당자 명
         */
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        private String lndKndCd;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 대출상태코드
         */
        private String lndStatCd;
        /**
         * 이전, 설정등기 구분코드
         */
        private String rgstrGbCd;
        /**
         * 대출상품명
         */
        private String lndPrdtNm;
        /**
         * 차주명
         */
        private String dbtrNm;
        /**
         * 차주 생년월일
         */
        private String dbtrBirthDt;
        /**
         * 차주 핸드폰번호
         */
        private String dbtrHpno;
        /**
         * 매도인명
         */
        private String slrNm;
        /**
         * 매도인 생년월일
         */
        private String slrBirthDtm;
        /**
         * 담보 제공자명
         */
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰번호
         */
        private String pwpsHpno;
        /**
         * 실행예정금액
         */
        private BigDecimal execPlnAmt;
        /**
         * 실행예정일자
         */
        private String execPlnDt;
        /**
         * 실행금액
         */
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        private String execDt;
        /**
         * 매매가액
         */
        private BigDecimal slPrc;
        /**
         * 법무사 타 은행코드 1
         */
        private String lwyrDiffBankCd1;
        /**
         * 법무사 타 은행코드 2
         */
        private String lwyrDiffBankCd2;
        /**
         * 법무사 타 은행코드 3
         */
        private String lwyrDiffBankCd3;
        /**
         * 법무사 타 은행코드 4
         */
        private String lwyrDiffBankCd4;
        /**
         * 법무사 타 은행코드 5
         */
        private String lwyrDiffBankCd5;
        /**
         * 법무사 타 은행코드 6
         */
        private String lwyrDiffBankCd6;
        /**
         * 법무사 타 은행코드 7
         */
        private String lwyrDiffBankCd7;
        /**
         * 법무사 타 은행코드 8
         */
        private String lwyrDiffBankCd8;
        /**
         * 법무사 타 은행코드 9
         */
        private String lwyrDiffBankCd9;
        /**
         * 법무사 타 은행코드 10
         */
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        private String ersuClsMsg;
        /**
         * 법무사 지점코드
         */
        private String lwyrBrnchCd;
        /**
         * 등기소명
         */
        private String regoNm;
        /**
         * 등기접수일시
         */
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지키
         */
        private String imgKey;
        /**
         * 대출구분코드
         */
        private String kndCd;
        /**
         * 대출물건지주소(asis : address)
         */
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        private String rdnmInclAddr;
        /**
         * 그룹번호(asis : M_APPROVAL_NUM)
         */
        private String grpNo;

        /**
         * INS_DVSN
         */
        private String insDvsn;
        /**
         * 금액수정대상여부
         */
        private String amtModTrgtYn;
        /**
         * 전문인입횟수(6100 전문에 한함)
         */
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록한 당일인지 여부
         */
        private String refndDateCheckYn;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        private String rgstrRegYn;
        /**
         * 지급정보 등록 여부
         */
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        private String estbsCntrFnYn;

    }
    /*================================================================================================================*/

    /**
     * 여신번호로 원장 조회
     */
    @Getter
    @Setter
    public static class FndByLoanNoInSvo {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 사업자등록번호
         */
        private String bizNo;
        /**
         * 보험구분코드
         */
        private String isrnGbCd;
        /**
         * 은행지점코드
         */
        private String bnkBrnchCd;
        /**
         * 은행구분코드
         */
        private String bnkGbCd;
        /**
         * 지점명
         */
        private String bnkBrnchNm;
        /**
         * 은행 담당자 명
         */
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        private String lndKndCd;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 대출상태코드
         */
        private String lndStatCd;
        /**
         * 이전, 설정등기 구분코드
         */
        private String rgstrGbCd;
        /**
         * 대출상품명
         */
        private String lndPrdtNm;
        /**
         * 차주명
         */
        private String dbtrNm;
        /**
         * 차주 생년월일
         */
        private String dbtrBirthDt;
        /**
         * 차주 주소지
         */
        private String dbtrAddr;
        /**
         * 차주 핸드폰번호
         */
        private String dbtrHpno;
        /**
         * 매도인명
         */
        private String slrNm;
        /**
         * 매도인 생년월일
         */
        private String slrBirthDtm;
        /**
         * 담보 제공자명
         */
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰번호
         */
        private String pwpsHpno;
        /**
         * 실행예정금액
         */
        private BigDecimal execPlnAmt;
        /**
         * 실행예정일자
         */
        private String execPlnDt;
        /**
         * 실행금액
         */
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        private String execDt;
        /**
         * 매매가액
         */
        private BigDecimal slPrc;
        /**
         * 법무사 타 은행코드 1
         */
        private String lwyrDiffBankCd1;
        /**
         * 법무사 타 은행코드 2
         */
        private String lwyrDiffBankCd2;
        /**
         * 법무사 타 은행코드 3
         */
        private String lwyrDiffBankCd3;
        /**
         * 법무사 타 은행코드 4
         */
        private String lwyrDiffBankCd4;
        /**
         * 법무사 타 은행코드 5
         */
        private String lwyrDiffBankCd5;
        /**
         * 법무사 타 은행코드 6
         */
        private String lwyrDiffBankCd6;
        /**
         * 법무사 타 은행코드 7
         */
        private String lwyrDiffBankCd7;
        /**
         * 법무사 타 은행코드 8
         */
        private String lwyrDiffBankCd8;
        /**
         * 법무사 타 은행코드 9
         */
        private String lwyrDiffBankCd9;
        /**
         * 법무사 타 은행코드 10
         */
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        private String ersuClsMsg;
        /**
         * 설정법무사 사업자번호
         */
        private String ebtsLwyrBizNo;
        /**
         * 등기소명
         */
        private String regoNm;
        /**
         * 등기접수일시
         */
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지키
         */
        private String imgKey;
        /**
         * 대출구분코드
         */
        private String kndCd;
        /**
         * 대출구분
         */
        private String kndNm;
        /**
         * 대출물건지주소(asis : address)
         */
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        private String rdnmInclAddr;
        /**
         * 그룹번호(asis : M_APPROVAL_NUM)
         */
        private String grpNo;
        /**
         * 비고
         */
        private String rmk;
        /**
         * INS_DVSN
         */
        private String insDvsn;
        /**
         * 금액수정대상여부
         */
        private String amtModTrgtYn;
        /**
         * 전문인입횟수(6100 전문에 한함)
         */
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록한 당일인지 여부
         */
        private String refndAcctRegDate;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        private String rgstrRegYn;
        /**
         * 지급정보 등록 여부
         */
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        private String estbsCntrFnYn;
        /**
         * 매매계약서 유무
         */
        private String slCntrctEane;
        /**
         * 매매계약서 파일명
         */
        private String slCntrctFlNm;
        /**
         * 전입세대열람원 제출여부
         */
        private String mvhhdSbmtYn;
        /**
         * 주민등록등본 제출여부
         */
        private String rrcpSbmtYn;
        /**
         * 수정임대차 계약서 제출여부
         */
        private String rtalSbmtYn;
        /**
         * 조건부 계약여부
         */
        private String cndtCntrYn;

    }

    @Getter
    @Setter
    public static class FndByLoanNoOutSvo {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 사업자등록번호
         */
        private String bizNo;
        /**
         * 보험구분코드
         */
        private String isrnGbCd;
        /**
         * 은행지점코드
         */
        private String bnkBrnchCd;
        /**
         * 은행구분코드
         */
        private String bnkGbCd;
        /**
         * 지점명
         */
        private String bnkBrnchNm;
        /**
         * 은행 담당자 명
         */
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        private String lndKndCd;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 상태명
         */
        private String statNm;
        /**
         * 대출상태코드
         */
        private String lndStatCd;
        /**
         * 이전, 설정등기 구분코드
         */
        private String rgstrGbCd;
        /**
         * 대출상품명
         */
        private String lndPrdtNm;
        /**
         * 차주명
         */
        private String dbtrNm;
        /**
         * 차주 생년월일
         */
        private String dbtrBirthDt;
        /**
         * 차주 주소지
         */
        private String dbtrAddr;
        /**
         * 차주 핸드폰번호
         */
        private String dbtrHpno;
        /**
         * 매도인명
         */
        private String slrNm;
        /**
         * 매도인 생년월일
         */
        private String slrBirthDtm;
        /**
         * 담보 제공자명
         */
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰번호
         */
        private String pwpsHpno;
        /**
         * 실행예정금액
         */
        private BigDecimal execPlnAmt;
        /**
         * 실행예정일자
         */
        private String execPlnDt;
        /**
         * 실행금액
         */
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        private String execDt;
        /**
         * 매매가액
         */
        private BigDecimal slPrc;
        /**
         * 법무사 타 은행코드 1
         */
        private String lwyrDiffBankCd1;
        /**
         * 법무사 타 은행코드 2
         */
        private String lwyrDiffBankCd2;
        /**
         * 법무사 타 은행코드 3
         */
        private String lwyrDiffBankCd3;
        /**
         * 법무사 타 은행코드 4
         */
        private String lwyrDiffBankCd4;
        /**
         * 법무사 타 은행코드 5
         */
        private String lwyrDiffBankCd5;
        /**
         * 법무사 타 은행코드 6
         */
        private String lwyrDiffBankCd6;
        /**
         * 법무사 타 은행코드 7
         */
        private String lwyrDiffBankCd7;
        /**
         * 법무사 타 은행코드 8
         */
        private String lwyrDiffBankCd8;
        /**
         * 법무사 타 은행코드 9
         */
        private String lwyrDiffBankCd9;
        /**
         * 법무사 타 은행코드 10
         */
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        private String ersuClsMsg;
        /**
         * 설정법무사 사업자번호
         */
        private String ebtsLwyrBizNo;
        /**
         * 등기소명
         */
        private String regoNm;
        /**
         * 등기접수일시
         */
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지키
         */
        private String imgKey;
        /**
         * 대출구분코드
         */
        private String kndCd;
        /**
         * 대출구분명
         */
        private String kndNm;
        /**
         * 대출물건지주소(asis : address)
         */
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        private String rdnmInclAddr;
        /**
         * 그룹번호(asis : M_APPROVAL_NUM)
         */
        private String grpNo;
        /**
         * 비고
         */
        private String rmk;
        /**
         * INS_DVSN
         */
        private String insDvsn;
        /**
         * 금액수정대상여부
         */
        private String amtModTrgtYn;
        /**
         * 전문인입횟수(6100 전문에 한함)
         */
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록한 당일인지 여부
         */
        private String refndAcctRegDate;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        private String rgstrRegYn;
        /**
         * 지급정보 등록 여부
         */
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        private String estbsCntrFnYn;
        /**
         * 매매계약서 유무
         */
        private String slCntrctEane;
        /**
         * 매매계약서 파일명
         */
        private String slCntrctFlNm;
        /**
         * 전입세대열람원 제출여부
         */
        private String mvhhdSbmtYn;
        /**
         * 주민등록등본 제출여부
         */
        private String rrcpSbmtYn;
        /**
         * 수정임대차 계약서 제출여부
         */
        private String rtalSbmtYn;
        /**
         * 조건부 계약여부
         */
        private String cndtCntrYn;
    }

    /*================================================================================================================*/
    @Getter
    @Setter
    public static class CntrComnInVo {

        /**
         * 여신번호
         */
        @Schema(description = "여신번호", example = "12345678901")
        @Size(min = 11, max = 11, message = "여신번호는 11자리여야 합니다!!")
        private String loanNo;

        /**
         * 사업자번호
         */
        @Schema(description = "사업자번호", example = "1234567890")
        @Size(min = 10, max = 10, message = "여신번호는 10자리여야 합니다!!")
        private String bizNo;

        /**
         * 회원번호
         */
        @Schema(description = "회원번호", example = "12")
        @Size(min = 10, max = 10, message = "여신번호는 10자리여야 합니다!!")
        private String membNo;

        /**
         * 실행금액
         */
        @Schema(description = "실행금액", example = "100000000")
        @PositiveOrZero(message = "실행 금액은 숫자 클래스 0이거나 양수인 값입니다.")
        private BigDecimal execAmt;

        /**
         * 실행예정금액
         */
        @Schema(description = "실행예정금액", example = "100000000")
        @PositiveOrZero(message = "실행 예정 금액은 숫자 클래스 0이거나 양수인 값입니다.")
        private BigDecimal execPlnAmt;

        /**
         * 실행금액 변경여부
         */
        @Schema(description = "실행금액 변경여부", example = "N")
        @Size(min = 1, max = 1, message = "실행금액 변경여부는 1자리여야 합니다!!")
        private String execAmtChgYn;

        /**
         * 보정여부
         */
        @Schema(description = "보정여부", example = "N")
        @Size(min = 1, max = 1, message = "보정여부는 1자리여야 합니다!!")
        private String revChkYn;

        /**
         * 지급정보 등록여부
         */
        @Schema(description = "지급정보 등록여부", example = "N")
        @Size(min = 1, max = 1, message = "지급정보 등록여부는 1자리여야 합니다!!")
        private String payRegYn;

        /**
         * 대출금 지급 or 요청 여부
         */
        @Schema(description = "대출금 지급 or 요청 여부", example = "N")
        @Size(min = 1, max = 1, message = "대출금 지급 or 요청 여부는 1자리여야 합니다!!")
        private String lndPayYn;

        /**
         * 사건진행 구분
         */
        @Schema(description = "사건진행 구분", example = "PROG")
        @Size(min = 4, max = 4, message = "사건진행 구분은 4자리여야 합니다!!")
        private String progGb;

        /**
         * 등기구분 코드
         */
        @Schema(description = "등기구분 코드", example = "01")
        @Size(max = 2, message = "등기구분 코드는 2자리여야 합니다!!")
        private String rgstrGbCd;

        /**
         * 원장상태 코드
         */
        @Schema(description = "원장상태 코드", example = "01")
        @Size(min = 2, max = 2, message = "원장상태 코드는 2자리여야 합니다!!")
        private String statCd;

        /**
         * 대출구분 코드
         */
        @Schema(description = "대출구분 코드", example = "1")
        @Size(max = 1, message = "대출구분 코드는 1자리여야 합니다!!")
        private String kndCd;

        /**
         * 전자등기 법무사 사업자번호
         */
        @Schema(description = "전자등기 법무사 사업자번호", example = "1234567890")
        @Size(max = 10, message = "전자등기 법무사 사업자번호는 10자리여야 합니다!!")
        private String elregBizNo;

        /**
         * 설정등기 법무사 사업자번호
         */
        @Schema(description = "설정등기 법무사 사업자번호", example = "1234567890")
        @Size(max = 10, message = "설정등기 법무사 사업자번호는 10자리여야 합니다!!")
        private String ebtsLwyrBizNo;
    }

    @Getter
    @Setter
    public static class ResInfo {

        private boolean resData;

        private String title;

        private String body;

    }

    @Getter
    @Setter
    public static class CntrDetail {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 사업자등록번호
         */
        private String bizNo;
        /**
         * 보험구분코드
         */
        private String isrnGbCd;
        /*
         * 은행 지점 코드
         */
        private String bnkBranchCd;

        /**
         * 은행지점명
         */
        private String bnkBranchNm;

        /**
         * 은행구분코드
         */
        private String bnkGbCd;

        /**
         * 은행구분명
         */
        private String bnkNm;


        /**
         * 은행 담당자 명
         */
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        private String lndKndCd;

        /**
         * 대출종류명
         */
        private String lndKndNm;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 상태명
         */
        private String statNm;
        /**
         * 대출상태코드
         */
        private String lndStatCd;

        /**
         * 대출상태명
         */
        private String lndStatNm;

        /**
         * 이전, 설정등기 구분코드
         */
        private String rgstrGbCd;

        /**
         * 등기구분명
         */
        private String rgstrGbNm;

        /**
         * 대출상품명
         */
        private String lndPrdtNm;
        /**
         * 차주명
         */
        private String dbtrNm;
        /**
         * 차주 생년월일
         */
        private String dbtrBirthDt;
        /**
         * 차주 주소지
         */
        private String dbtrAddr;
        /**
         * 차주 핸드폰번호
         */
        private String dbtrHpno;
        /**
         * 매도인명
         */
        private String slrNm;
        /**
         * 매도인 생년월일
         */
        private String slrBirthDtm;
        /**
         * 담보 제공자명
         */
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰번호
         */
        private String pwpsHpno;
        /**
         * 실행예정금액
         */
        private BigDecimal execPlnAmt;
        /**
         * 실행예정일자
         */
        private String execPlnDt;
        /**
         * 실행금액
         */
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        private String execDt;
        /**
         * 매매가액
         */
        private BigDecimal slPrc;
        /**
         * 법무사 타 은행코드 1
         */
        private String lwyrDiffBankCd1;
        /**
         * 법무사 타 은행코드 2
         */
        private String lwyrDiffBankCd2;
        /**
         * 법무사 타 은행코드 3
         */
        private String lwyrDiffBankCd3;
        /**
         * 법무사 타 은행코드 4
         */
        private String lwyrDiffBankCd4;
        /**
         * 법무사 타 은행코드 5
         */
        private String lwyrDiffBankCd5;
        /**
         * 법무사 타 은행코드 6
         */
        private String lwyrDiffBankCd6;
        /**
         * 법무사 타 은행코드 7
         */
        private String lwyrDiffBankCd7;
        /**
         * 법무사 타 은행코드 8
         */
        private String lwyrDiffBankCd8;
        /**
         * 법무사 타 은행코드 9
         */
        private String lwyrDiffBankCd9;
        /**
         * 법무사 타 은행코드 10
         */
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        private String ersuClsMsg;
        /**
         * 설정법무사 사업자번호
         */
        private String ebtsLwyrBizNo;
        /**
         * 등기소명
         */
        private String regoNm;
        /**
         * 등기접수일시
         */
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지키
         */
        private String imgKey;
        /**
         * 대출구분코드
         */
        private String kndCd;
        /**
         * 대출구분명
         */
        private String kndNm;
        /**
         * 대출물건지주소(asis : address)
         */
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        private String rdnmInclAddr;
        /**
         * 그룹번호(asis : M_APPROVAL_NUM)
         */
        private String grpNo;
        /**
         * 비고
         */
        private String rmk;
        /**
         * INS_DVSN
         */
        private String insDvsn;
        /**
         * 금액수정대상여부
         */
        private String amtModTrgtYn;
        /**
         * 전문인입횟수(6100 전문에 한함)
         */
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록한 당일인지 여부
         */
        private String refndAcctRegDate;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        private String rgstrRegYn;
        /**
         * 지급정보 등록 여부
         */
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        private String estbsCntrFnYn;
        /**
         * 매매계약서 유무
         */
        private String slCntrctEane;
        /**
         * 매매계약서 파일명
         */
        private String slCntrctFlNm;
        /**
         * 전입세대열람원 제출여부
         */
        private String mvhhdSbmtYn;
        /**
         * 주민등록등본 제출여부
         */
        private String rrcpSbmtYn;
        /**
         * 수정임대차 계약서 제출여부
         */
        private String rtalSbmtYn;
        /**
         * 조건부 계약여부
         */
        private String cndtCntrYn;
        /**
         * 등기신청번호 등록여부
         */
        private String rgstrAcptSbmtYn;

        private String elregReptOfficeNm;

        private ResInfo resRfdRegd;

        private ResInfo resDateRfdRegd;

        private ResInfo resEltnSecurd;

        private ResInfo resExecAmtChngd;

        private ResInfo resEstmRegd;

        private ResInfo resRgstrRegd;

        private ResInfo resPayRegd;

        private ResInfo resEstmCnfm;

        private ResInfo resLndAmtPay;

        private ResInfo resRevisionCheck;

        private ResInfo resEstbsCntrFn;

        private ResInfo resExecDateCheck;

    }
    /*================================================================================================================*/

    /**
     * 여신승인신청번호로 BK1MC0917M조회
     */
    @Getter
    @Setter
    public static class ApprNumInSvo {
        /**
         * 식별번호
         */
        private String seq;

        /**
         * 전문이름
         */
        private String trnName;
        /**
         * 전문코드업무구분
         */
        private String trnKnd;
        /**
         * 응답완료코드
         */
        private String resCode;
        /**
         * 응답완료명
         */
        private String resName;
        /**
         * 여신승인신청번호
         */
        private String approvalNum;
        /**
         * 은행코드
         */
        private String bankCode;
        /**
         * 은행명
         */
        private String bankName;
        /**
         * 구분
         */
        private String gubun;
        /**
         * 전송 구분코드
         */
        private String tgDsc;
        /**
         * 전송상태코드
         */
        private String trnsStc;
        /**
         * 전송상태명
         */
        private String trnsStcNm;
        /**
         * 요청일시
         */
        private String reqDttm;
    }

    @Getter
    @Setter
    public static class ApprNumOutSvo {
        /**
         * 식별번호
         */
        private String seq;

        /**
         * 전문이름
         */
        private String trnName;
        /**
         * 전문코드업무구분
         */
        private String trnKnd;
        /**
         * 응답완료코드
         */
        private String resCode;
        /**
         * 응답완료명
         */
        private String resName;
        /**
         * 여신승인신청번호
         */
        private String approvalNum;
        /**
         * 은행코드
         */
        private String bankCode;
        /**
         * 은행명
         */
        private String bankName;
        /**
         * 구분
         */
        private String gubun;
        /**
         * 전송 구분코드
         */
        private String tgDsc;
        /**
         * 전송상태코드
         */
        private String trnsStc;
        /**
         * 전송상태명
         */
        private String trnsStcNm;
        /**
         * 요청일시
         */
        private String reqDttm;
    }
    /*================================================================================================================*/

    /**
     * 원장 수정
     */
    @Getter
    @Setter
    public static class UpdCntrInSvo {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 사업자등록번호
         */
        private String bizNo;
        /**
         * 보험구분코드
         */
        private String isrnGbCd;
        /**
         * 은행지점코드
         */
        private String bnkBrnchCd;
        /**
         * 은행구분코드
         */
        private String bnkGbCd;
        /**
         * 지점명
         */
        private String bnkBrnchNm;
        /**
         * 은행 담당자 명
         */
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        private String lndKndCd;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 대출상태코드
         */
        private String lndStatCd;
        /**
         * 등기 구분 코드
         */
        private String rgstrGbCd;
        /**
         * 대출상품명
         */
        private String lndPrdtNm;
        /**
         * 차주명
         */
        private String dbtrNm;
        /**
         * 차주생년월일
         */
        private String dbtrBirthDt;
        /**
         * 차주 주소지
         */
        private String dbtrAddr;
        /**
         * 차주 핸드폰 번호
         */
        private String dbtrHpno;
        /**
         * 담보제공자명
         */
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰 번호
         */
        private String pwpsHpno;
        /**
         * 실행예정금액
         */
        private BigDecimal execPlnAmt;
        /**
         * 실행예정일자
         */
        private String execPlnDt;
        /**
         * 실행금액
         */
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        private String execDt;
        /**
         * 매매가액
         */
        private BigDecimal slPrc;
        /**
         * 법무사타은행코드1
         */
        private String lwyrDiffBankCd1;
        /**
         * 법무사타은행코드2
         */
        private String lwyrDiffBankCd2;
        /**
         * 법무사타은행코드3
         */
        private String lwyrDiffBankCd3;
        /**
         * 법무사타은행코드4
         */
        private String lwyrDiffBankCd4;
        /**
         * 법무사타은행코드5
         */
        private String lwyrDiffBankCd5;
        /**
         * 법무사타은행코드6
         */
        private String lwyrDiffBankCd6;
        /**
         * 법무사타은행코드7
         */
        private String lwyrDiffBankCd7;
        /**
         * 법무사타은행코드8
         */
        private String lwyrDiffBankCd8;
        /**
         * 법무사타은행코드9
         */
        private String lwyrDiffBankCd9;
        /**
         * 법무사타은행코드10
         */
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        private String ersuClsMsg;
        /**
         * 설정법무사 사업자번호
         */
        private String ebtsLwyrBizNo;
        /**
         * 등기소명
         */
        private String regoNm;
        /**
         * 등기접수일시
         */
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지 키
         */
        private String imgKey;
        /**
         * 대출구분코드
         */
        private String kndCd;
        /**
         * 대출물건지주소(asis:address)
         */
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        private String rdnmInclAddr;
        /**
         * 그룹번호(ASIS:M_APPROVAL_NUM)
         */
        private String grpNo;
        /**
         * 비고
         */
        private String rmk;
        /**
         * INS_DVSN
         */
        private String insDvsn;
        /**
         * 전문인입횟수
         */
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록 일자
         */
        private String refndAcctRegDate;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        private String rgstrRegYn;
        /**
         * 지급정보 등록 여부
         */
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        private String estbsCntrFnYn;
        /**
         * 매매 계약서 유무
         */
        private String slCntrctEane;
        /**
         * 매매 계약서 파일명
         */
        private String slCntrctFlnm;
        /**
         * 전입세대열람원 제출여부
         */
        private String mvhhdSbmtYn;
        /**
         * 주민등록등본 제출여부
         */
        private String rrcpSbMtYn;
        /**
         * 수정임대차 계약서 제출 여부
         */
        private String rtalSbmtYn;
        /**
         * 조건부 계약여부
         */
        private String cndtCntrYn;
        /**
         * 등기신청번호 등록여부
         */
        private String rgstrAcptSbmtYn;
        /**
         * 이전등기 가능 법무사 유무
         */
        private String cnvntLwyrYn;
    }
    /*================================================================================================================*/

    /**
     * 원장 여신번호로 삭제
     */
    @Getter
    @Setter
    public static class DelCntrInSvo {
        private String loanNo;
    }
    /*================================================================================================================*/
    //cntr 기본 vo
    /*================================================================================================================*/
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CntrVo {
        String loanNo;
        String bizNo;
        String isrnGbCd;
        String bnkBrnchCd;
        String bnkGbCd;
        String bnkBrnchNm;
        String bnkDrctrNm;
        String bnkBrnchPhno;
        String lndKndCd;
        String statCd;
        String lndStatCd;
        String rgstrGbCd;
        String lndPrdtNm;
        String dbtrNm;
        String dbtrBirthDt;
        String dbtrAddr;
        String dbtrHpno;
        String pwpsNm;
        String pwpsBirthDt;
        String pwpsHpno;
        BigDecimal execPlnAmt;
        String execPlnDt;
        BigDecimal execAmt;
        String execDt;
        BigDecimal slPrc;
        String lwyrDiffBankCd1;
        String lwyrDiffBankCd2;
        String lwyrDiffBankCd3;
        String lwyrDiffBankCd4;
        String lwyrDiffBankCd5;
        String lwyrDiffBankCd6;
        String lwyrDiffBankCd7;
        String lwyrDiffBankCd8;
        String lwyrDiffBankCd9;
        String lwyrDiffBankCd10;
        String ersuClsMsg;
        String ebtbsLwyrBizNo;
        String regoNm;
        LocalDateTime rgstrAcptDtm;
        String imgKey;
        String kndCd;
        String lndThngAddr;
        String ccrstAcptNum;
        String clsctSctrtBprRegYn;
        String ccrstBprRegYn;
        String blncFpymnRcpt;
        String regifBprRegYn;
        String elregBizNo;
        String rdnmInclAddr;
        String grpNo;
        String rmk;
        String insDvsn;
        Long trnInCnt;
        String refndAcctRegYn;
        String refndAcctRegDate;
        String eltnSecuredYn;
        String execAmtChangYn;
        String estmRegYn;
        String rgstrRegYn;
        String payRegYn;
        String estmCnfmYn;
        String lndAmtPayYn;
        String revisionCheckYn;
        String estbsCntrFnYn;
        String slCntrctEane;
        String slCntrctFlnm;
        String mvhhdSbmtYn;
        String rrcpSbmtYn;
        String rtalSbmtYn;
        String cndtCntrYn;
        String rgstrAcptSbmtYn;
        String cnvntLwyrYn;
    }
    /*================================================================================================================*/
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AutoCompleteInSvo {

        String searchTypeValue;

        String searchKeyWord;

    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AutoCompleteOutSvo {

        List<AutoSerchInfo> list;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AutoSerchInfo {

        private String bizNo;
        private String loanNo;
        private String dbtrNm;
        private String execDt;
        private BigDecimal execAmt;
        private String officeNm;
        private String dbtrHpno;
    }

    /*================================================================================================================*/
    @Getter
    @Setter
    public static class ModifyStatCdOutSvo {
        /**
         * 여신번호
         */
        private String loanNo;
        /**
         * 사업자등록번호
         */
        private String bizNo;
        /**
         * 보험구분코드
         */
        private String isrnGbCd;
        /**
         * 은행지점코드
         */
        private String bnkBrnchCd;
        /**
         * 은행구분코드
         */
        private String bnkGbCd;
        /**
         * 지점명
         */
        private String bnkBrnchNm;
        /**
         * 은행 담당자 명
         */
        private String bnkDrctrNm;
        /**
         * 은행 지점 전화번호
         */
        private String bnkBrnchPhno;
        /**
         * 대출종류코드
         */
        private String lndKndCd;
        /**
         * 상태코드
         */
        private String statCd;
        /**
         * 대출상태코드
         */
        private String lndStatCd;
        /**
         * 등기 구분 코드
         */
        private String rgstrGbCd;
        /**
         * 대출상품명
         */
        private String lndPrdtNm;
        /**
         * 차주명
         */
        private String dbtrNm;
        /**
         * 차주생년월일
         */
        private String dbtrBirthDt;
        /**
         * 차주 주소지
         */
        private String dbtrAddr;
        /**
         * 차주 핸드폰 번호
         */
        private String dbtrHpno;
        /**
         * 담보제공자명
         */
        private String pwpsNm;
        /**
         * 담보제공자 생년월일
         */
        private String pwpsBirthDt;
        /**
         * 담보제공자 핸드폰 번호
         */
        private String pwpsHpno;
        /**
         * 실행예정금액
         */
        private BigDecimal execPlnAmt;
        /**
         * 실행예정일자
         */
        private String execPlnDt;
        /**
         * 실행금액
         */
        private BigDecimal execAmt;
        /**
         * 대출실행일자
         */
        private String execDt;
        /**
         * 매매가액
         */
        private BigDecimal slPrc;
        /**
         * 법무사타은행코드1
         */
        private String lwyrDiffBankCd1;
        /**
         * 법무사타은행코드2
         */
        private String lwyrDiffBankCd2;
        /**
         * 법무사타은행코드3
         */
        private String lwyrDiffBankCd3;
        /**
         * 법무사타은행코드4
         */
        private String lwyrDiffBankCd4;
        /**
         * 법무사타은행코드5
         */
        private String lwyrDiffBankCd5;
        /**
         * 법무사타은행코드6
         */
        private String lwyrDiffBankCd6;
        /**
         * 법무사타은행코드7
         */
        private String lwyrDiffBankCd7;
        /**
         * 법무사타은행코드8
         */
        private String lwyrDiffBankCd8;
        /**
         * 법무사타은행코드9
         */
        private String lwyrDiffBankCd9;
        /**
         * 법무사타은행코드10
         */
        private String lwyrDiffBankCd10;
        /**
         * 말소(감액)해당없음메시지
         */
        private String ersuClsMsg;
        /**
         * 설정법무사 사업자번호
         */
        private String ebtsLwyrBizNo;
        /**
         * 등기소명
         */
        private String regoNm;
        /**
         * 등기접수일시
         */
        private LocalDateTime rgstrAcptDtm;
        /**
         * 이미지 키
         */
        private String imgKey;
        /**
         * 대출구분코드
         */
        private String kndCd;
        /**
         * 대출물건지주소(asis:address)
         */
        private String lndThngAddr;
        /**
         * 등기부등본접수번호
         */
        private String ccrstAcptNum;
        /**
         * 근저당설정계약서BPR등록여부
         */
        private String clsctSctrtBprRegYn;
        /**
         * 등기부등본BPR등록여부
         */
        private String ccrstBprRegYn;
        /**
         * 잔금완납영수증
         */
        private String blncFpymnRcpt;
        /**
         * 등기필정보BPR등록여부
         */
        private String regifBprRegYn;
        /**
         * 전자등기사업자번호
         */
        private String elregBizNo;
        /**
         * 도로명포함주소지
         */
        private String rdnmInclAddr;
        /**
         * 그룹번호(ASIS:M_APPROVAL_NUM)
         */
        private String grpNo;
        /**
         * 비고
         */
        private String rmk;
        /**
         * INS_DVSN
         */
        private String insDvsn;
        /**
         * 전문인입횟수
         */
        private Long trnInCnt;
        /**
         * 상환금 수령용 계좌 등록 여부
         */
        private String refndAcctRegYn;
        /**
         * 상환금 수령용 계좌 최초 등록 일자
         */
        private String refndAcctRegDate;
        /**
         * 전자등기 + 자담 건인지 여부
         */
        private String eltnSecuredYn;
        /**
         * 실행금액 변경 여부
         */
        private String execAmtChangYn;
        /**
         * 견적서 등록여부
         */
        private String estmRegYn;
        /**
         * 등기정보 등록 여부
         */
        private String rgstrRegYn;
        /**
         * 지급정보 등록 여부
         */
        private String payRegYn;
        /**
         * 견적서 확정 여부
         */
        private String estmCnfmYn;
        /**
         * 대출금 또는 상환금 지급 여부
         */
        private String lndAmtPayYn;
        /**
         * 보정 여부
         */
        private String revisionCheckYn;
        /**
         * 설정 - 6200 설정등기 확인결과서 발송 여부
         */
        private String estbsCntrFnYn;
        /**
         * 매매 계약서 유무
         */
        private String slCntrctEane;
        /**
         * 매매 계약서 파일명
         */
        private String slCntrctFlnm;
        /**
         * 전입세대열람원 제출여부
         */
        private String mvhhdSbmtYn;
        /**
         * 주민등록등본 제출여부
         */
        private String rrcpSbMtYn;
        /**
         * 수정임대차 계약서 제출 여부
         */
        private String rtalSbmtYn;
        /**
         * 조건부 계약여부
         */
        private String cndtCntrYn;
        /**
         * 등기신청번호 등록여부
         */
        private String rgstrAcptSbmtYn;
        /**
         * 이전등기 가능 법무사 유무
         */
        private String cnvntLwyrYn;
    }
}
