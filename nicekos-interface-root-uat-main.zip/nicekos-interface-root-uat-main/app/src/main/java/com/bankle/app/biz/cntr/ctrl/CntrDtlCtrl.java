package com.bankle.app.biz.cntr.ctrl;

import com.bankle.app.biz.cntr.svc.CntrDtlSvc;
import com.bankle.app.biz.cntr.vo.CntrCvo;
import com.bankle.app.biz.cntr.vo.CntrMasterCvo;
import com.bankle.app.biz.cntr.vo.CntrSvo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@Tag(name = "1. 원장", description = "원장 관리 API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class CntrDtlCtrl {

    private final CntrDtlSvc cntrDtlSvc;
    private final CustomeModelMapper customeModelMapper;

    @Operation(summary = "01.여신번호로 원장 조회(사건상세)", description = "input : LoanNo(여신번호) example No : '22381866498'")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "여신번호로 원장 조회 성공", content = @Content(schema = @Schema(implementation = CntrMasterCvo.FndByLoanNoResCvo.class))),
    })
    @PostMapping("/cntr/searchcntrdetail/{loanNo}")
    public ResponseEntity<?> searchCntrDetail(@Valid @PathVariable(name = "loanNo") String loanNo) throws Exception {
        try {
            List<CntrCvo.CntrDtlResCvo> resCvoList = cntrDtlSvc.getByLoanNo(loanNo)
                    .stream()
                    .map(cntrDtl -> customeModelMapper
                            .mapping(cntrDtl, CntrCvo.CntrDtlResCvo.class))
                    .toList();
            log.debug("resCvoList: " + resCvoList.toString());
            if (resCvoList.isEmpty()) {
              return ResData.FAIL("실패");
            }
            return ResData.SUCCESS(resCvoList, "성공");
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }

    @Operation(summary = "02.원장 변경", description = "원장 변경 API")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "원장 변경 성공", content = @Content(schema = @Schema(implementation = CntrMasterCvo.FndByLoanNoResCvo.class))),
    })
    @PostMapping("/cntr/modifycntrinfo")
    public ResponseEntity<?> modifyCntrInfo(@RequestBody CntrCvo.CntrInfoReqCvo reqCvo) throws Exception {
        try {
            return ResData.SUCCESS(cntrDtlSvc.updateCntrInfo(customeModelMapper.mapping(reqCvo, CntrSvo.CntrInfoInSvo.class)), "성공");
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }


}
