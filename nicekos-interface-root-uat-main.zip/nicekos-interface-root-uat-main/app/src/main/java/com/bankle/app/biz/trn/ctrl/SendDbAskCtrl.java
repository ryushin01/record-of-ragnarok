package com.bankle.app.biz.trn.ctrl;

import com.bankle.app.biz.cntr.vo.CntrMasterCvo;
import com.bankle.app.biz.trn.svc.SendDbAskSvc;
import com.bankle.app.biz.trn.svc.SendFaAskSvc;
import com.bankle.app.biz.trn.vo.SendDbAskCvo;
import com.bankle.app.biz.trn.vo.SendDbAskSvo;
import com.bankle.app.biz.trn.vo.SendFaAskCvo;
import com.bankle.app.biz.trn.vo.SendFaAskSvo;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.vo.ResData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@Tag(name = "4.DB 청약 의뢰 전문(W1000) 발송", description = "DB 청약 의뢰 전문(W1000) 발송 API")
@Slf4j
@RestController
@RequiredArgsConstructor
public class SendDbAskCtrl {

    private final CustomeModelMapper customeModelMapper;
    private final SendDbAskSvc sendDbAskSvc;

    @Operation(summary = "DB 청약 의뢰 전문(W1000) 발송", description = "DB 청약 의뢰 전문(W1000) 발송 서비스")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "DB 청약 의뢰 전문(W1000) 발송 성공", content = @Content(schema = @Schema(implementation = CntrMasterCvo.FndByLoanNoResCvo.class))),
    })
    @PostMapping("/trn/senddbask")
    public ResponseEntity<?> save(@RequestBody SendDbAskCvo.SendDbAskReqCvo reqCvo) throws Exception {
        try {
            boolean valid = sendDbAskSvc
                    .save(customeModelMapper
                            .mapping(reqCvo, SendDbAskSvo.SendDbAskInSvo.class));
            if (valid) {
                return ResData.SUCCESS(reqCvo, "성공");
            } else {
                return ResData.FAIL(reqCvo, "실패");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new DefaultException(e.getMessage());
        }
    }
}
