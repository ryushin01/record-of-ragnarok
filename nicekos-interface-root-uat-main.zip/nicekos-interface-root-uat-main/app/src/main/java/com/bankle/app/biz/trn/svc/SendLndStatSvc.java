package com.bankle.app.biz.trn.svc;

import com.bankle.app.biz.trn.vo.SendLndStatSvo;
import com.bankle.common.dto.TbWoCntrMasterDto;
import com.bankle.common.dto.TbWoTrnFa6300F3Dto;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.enums.Sequence;
import com.bankle.common.exception.DefaultException;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.mapper.TbWoTrnFa6300F3Mapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.repo.TbWoTrnFa6300F3Repository;
import com.bankle.common.utils.BizUtil;
import com.bankle.common.utils.CustomeModelMapper;
import com.bankle.common.wooriApi.socket.ins.sendSvc.Send6300F3Svc;
import com.bankle.common.wooriApi.socket.ins.sendSvc.vo.Send6300F3Svo;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import jakarta.persistence.EntityManager;
import jakarta.validation.Valid;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class SendLndStatSvc {
    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;
    private final TbWoTrnFa6300F3Repository tbWoTrnFa6300F3Repository;
    private final CustomeModelMapper customeModelMapper;
    private final EntityManager entityManager;
    private final Send6300F3Svc send6300F3Svc;
    private final BizUtil bizUtil;
    private final String TG_DSC = "F3000";

    @Transactional
    public boolean save(@Valid SendLndStatSvo.SendLndStatInSvo inSvo) throws Exception {
        //------------------------------------------------------------------
        // 원장 생성
        //------------------------------------------------------------------
        String seq = bizUtil.getSeq(Sequence.TRANS);
        String newLoanNo = inSvo.getNewLoanNo();
        TbWoCntrMaster tbWoCntrMaster = tbWoCntrMasterRepository.findByLoanNo(inSvo.getLoanNo())
                .orElseThrow(() -> new DefaultException("존재하지 않는 여신번호입니다. 다시 시도해 주세요!"));
        log.debug("tbWoCntrMaster.loanNo : {}", tbWoCntrMaster.getLoanNo());

        if (!tbWoCntrMasterRepository.existsByLoanNo(newLoanNo)) {
            TbWoCntrMasterDto tbWoCntrMasterDto = TbWoCntrMasterMapper.INSTANCE.toDto(tbWoCntrMaster);
            tbWoCntrMasterDto.setLoanNo(newLoanNo);
            tbWoCntrMasterRepository.save(TbWoCntrMasterMapper.INSTANCE.toEntity(tbWoCntrMasterDto));
            entityManager.flush();
        }

        //------------------------------------------------------------------
        // 전문 상세 생성
        //------------------------------------------------------------------
        inSvo.setLoanNo(newLoanNo);
        inSvo.setChgDtm(LocalDateTime.now());
        inSvo.setKosTgSndNo(seq);
        log.debug("inSvo.getChgDtm : {}", inSvo.getChgDtm());
        log.debug("inSvo.getRegDtm : {}", inSvo.getRegDtm());
        tbWoTrnFa6300F3Repository.save(
                TbWoTrnFa6300F3Mapper.INSTANCE
                        .toEntity(customeModelMapper
                                .mapping(inSvo, TbWoTrnFa6300F3Dto.class)));
        entityManager.flush();


        //------------------------------------------------------------------
        // 전문 전송
        //------------------------------------------------------------------
        log.debug("inSvo.regDtm : {}", inSvo.getRegDtm());
        Send6300F3Svo.sendInVo sendInVo = Send6300F3Svo.sendInVo
                .builder()
                .loanNo(newLoanNo)
                .chgDtm(LocalDateTime.now())
                .tgDsc(TG_DSC)
                .bnkTgNo(inSvo.getBnkTgNo())
                .faTgNo(inSvo.getFaTgNo())
                .kosTgSndNo(seq)
                .tgSndDtm(LocalDateTime.now())
                .tgRcvDtm(inSvo.getTgRcvDtm())
                .resCd(inSvo.getResCd())
                .rsrvItmH(inSvo.getRsrvItmH())
                .bnkTtlReqNo(inSvo.getBnkTtlReqNo())
                .lndPrgsStc(inSvo.getLndPrgsStc())
                .prgsDt(inSvo.getPrgsDt())
                .sbmtDocLst(inSvo.getSbmtDocLst())
                .mvhrHshldrRno(inSvo.getMvhrHshldrRno())
                .mvhrTrgtThngAddr(inSvo.getMvhrTrgtThngAddr())
                .mvhrHshldrNmMvinDt(inSvo.getMvhrHshldrNmMvinDt())
                .mvhrdtm(inSvo.getMvhrdtm())
                .regDtm(inSvo.getRegDtm())
                .lnAprvNo2(inSvo.getLnAprvNo2())
                .build();
        CheckResponseSvo checkResponseSvo = send6300F3Svc.sendAndResponse(sendInVo);
        return "000".equals(checkResponseSvo.getRescode());
    }
}
