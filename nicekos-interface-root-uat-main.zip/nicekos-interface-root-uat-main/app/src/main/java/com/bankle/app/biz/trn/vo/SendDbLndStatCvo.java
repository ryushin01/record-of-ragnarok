package com.bankle.app.biz.trn.vo;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class SendDbLndStatCvo {
    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class SendDbLndStatReqCvo {
        private String loanNo;
        private String newLoanNo;
        private BigDecimal tgLen;
        private String tgDsc;
        private String resCd;
        private String lndAgncCd;
        private String bnkTgTrnsDtm;
        private String dbTgTrnsDtm;
        private String bnkTgNo;
        private BigDecimal dbTgNo;
        private String rsrvItmH;
        private String bnkAskNo;
        private String dbMngNo;
        private String kosTgTrnsDtm;
        private String kosTgNo;
        private String nttnYn;
        private String endNotiDt;
        private String endnotiTm;
        private String bnkDrctrNm;
        private String bnkDrctrPhno;
        private String rsrvItmB;
        private String regDtm;
        private LocalDateTime chgDtm;
    }
}
