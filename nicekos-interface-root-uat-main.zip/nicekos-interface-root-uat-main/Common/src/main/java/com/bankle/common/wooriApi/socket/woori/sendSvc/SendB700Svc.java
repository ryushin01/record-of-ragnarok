package com.bankle.common.wooriApi.socket.woori.sendSvc;

import com.bankle.common.utils.DateUtil;
import com.bankle.common.wooriApi.socket.woori.commonSvc.WooriCmnSvc;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.WooriCmnSvo;
import com.bankle.common.wooriApi.socket.woori.sendSvc.vo.SendB700Svo;
import com.bankle.common.wooriApi.socket.woori.socketData.B7X0;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;


@Slf4j
@Service
@RequiredArgsConstructor
public class SendB700Svc {

    private final WooriCmnSvc wooriCmnSvc;

    public CheckResponseSvo sendAndResponse(@Valid SendB700Svo.SendB700InSvo invo) throws Exception{
        log.debug("SendB700Svo.SendB700InSvo : " + invo);
        String seq = this.send(invo);
        log.debug("String seq = this.send(invo) : " + seq);
        return wooriCmnSvc.checkResponse(seq);
    }
    /**
     *
     * @name     : B700Svc.sendB700
     * @author   : rojoon
     * @param    :
     * @return   :
     **/
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public String send(@Valid SendB700Svo.SendB700InSvo invo) throws Exception {
        //------------------------------------------------------------------
        // 1. B700 전문 셋업
        //------------------------------------------------------------------
        String seq = invo.getTrSq();
        B7X0 sendData = new B7X0();
        sendData.setTR_CD(invo.getTrCd()); // 전문종별코드
        sendData.setTR_TP_CD(invo.getTrTpCd()); // 거래구분코드
        sendData.setLO_NO(invo.getLoNo());  // 관리번호
        sendData.setTR_SQ(invo.getTrSq());  // 식별번호
        sendData.setREQ_DTTM(DateUtil.getCurrentDateTime());  // 송신일자
        sendData.setAPPROVAL_NUM(invo.getLoanNo()); // 여신승인신청번호
        sendData.setIMG_TP(invo.getImgTp());  // 이미지구분
        sendData.setIMG_CHECK_YN(invo.getImgCheckYn()); // 이미지확인여부
        sendData.setIMG_KEY(invo.getImgKey());  // 이미지 키
        sendData.setIMG_PAGE_CNT(invo.getImgPageCnt()); // 이미지 페이지 수
        sendData.setSEQ_NO(invo.getSeqNo()); // 시퀀스번호
        sendData.setIMG_FILE_NAME(invo.getImgFileName()); // 이미지 파일명
        if("2".equals(invo.getImgTp())){
            sendData.setRESULT_CD("020"); //처리결과
        }else{
            sendData.setRESULT_CD(invo.getResultCd()); //처리결과
        }
        sendData.setFILLER(invo.getFiller());
        log.debug(sendData.print());
        if (!StringUtils.hasText(sendData.getLO_NO().trim())) {
            sendData.setLO_NO("0000000000000");
        }
        //------------------------------------------------------------------
        // 3.전문 전송
        //------------------------------------------------------------------
        WooriCmnSvo.sendVo sendVo = new WooriCmnSvo.sendVo();
        sendVo.setTrSeq(sendData.getTR_SQ());
        sendVo.setTrnName(invo.getTrnName());
        sendVo.setTrnKnd(sendData.getTR_CD());
        sendVo.setReqData(sendData.dataToString());
        sendVo.setReqDataLog(sendData.print());
        sendVo.setApprovalNum(sendData.getAPPROVAL_NUM());
        sendVo.setMembNo(sendData.getLO_NO());
        sendVo.setLoanNo(invo.getLoanNo());
        sendVo.setReptMembNo(sendData.getLO_NO());
        sendVo.setTgDsc(invo.getInsGbn());
        sendVo.setResendCt(0);
        log.debug("SendB700Svc.send().sendData : " + sendData.dataToString());
        wooriCmnSvc.wooriSend(sendVo);
        return seq;
    }
}
