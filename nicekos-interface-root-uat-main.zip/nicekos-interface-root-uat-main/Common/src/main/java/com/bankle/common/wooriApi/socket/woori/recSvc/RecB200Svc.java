package com.bankle.common.wooriApi.socket.woori.recSvc;

import com.bankle.common.dto.TbWoTrnRsltDto;
import com.bankle.common.entity.TbWoCntrMaster;
import com.bankle.common.entity.TbWoTrnRslt;
import com.bankle.common.mapper.TbWoCntrMasterMapper;
import com.bankle.common.mapper.TbWoTrnRsltMapper;
import com.bankle.common.repo.TbWoCntrMasterRepository;
import com.bankle.common.repo.TbWoTrnRsltRepository;
import com.bankle.common.utils.DateUtil;
import com.bankle.common.wooriApi.socket.woori.commonSvc.WooriCmnSvc;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.WooriCmnSvo;
import com.bankle.common.wooriApi.socket.woori.recSvc.vo.RecB200Svo;
import com.bankle.common.wooriApi.socket.woori.socketData.B2X0;
import lombok.*;
import lombok.extern.slf4j.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class RecB200Svc {

    private final WooriCmnSvc wooriCmnSvc;

    private final TbWoCntrMasterRepository tbWoCntrMasterRepository;
    private final TbWoTrnRsltRepository tbWoTrnRsltRepository;

    private final String TR_CD = "B210";
    private final String TR_LN = "0500";

    @Transactional(rollbackFor = {Exception.class})
    public void receive(RecB200Svo.receiveVo receiveVo) throws Exception {

        wooriCmnSvc.wooriReceive(WooriCmnSvo.receiveVo.builder()
                .trSeq(receiveVo.getTrSeq())
                .trnKnd(TR_CD)
                .trnName(receiveVo.getTrnName())
                .reqData(receiveVo.getReqData())
                .reqDataLog(receiveVo.getReqDataLog())
                .approvalNum(receiveVo.getApprovalNum())
                .membNo(receiveVo.getLoNo())
                .reptMembNo(receiveVo.getLoNo())
                .loanNo(receiveVo.getLoanNo())
                .loNo(receiveVo.getLoNo())
                .tgDsc(receiveVo.getTgDsc())
                .build());

        var cntrEntity = tbWoCntrMasterRepository
                .findByLoanNo(receiveVo.getLoanNo()).orElseGet(TbWoCntrMaster::new);
        var cntrDto = TbWoCntrMasterMapper.INSTANCE.toDto(cntrEntity);
        log.debug("TbWoCntrMasterDto ->>" + cntrDto.toString());

        B2X0 sendData = new B2X0();
        sendData.setTR_LN(TR_LN);
        sendData.setTR_CD(TR_CD); // 전문종별코드
        sendData.setTR_TP_CD(receiveVo.getTpCd()); // 거래구분코드
        sendData.setLO_NO(receiveVo.getLoNo()); // 관리번호
        sendData.setTR_SQ(receiveVo.getTrSeq()); // 식별번호
        sendData.setREQ_DTTM(receiveVo.getReqDttm()); // 송신일자
        sendData.setREQ_DT(receiveVo.getReqDt()); // 요청일자
        sendData.setRES_DTTM(DateUtil.getCurrentDateTime());
        sendData.setAPPROVAL_NUM(receiveVo.getApprovalNum()); // 여신승인신청번
        sendData.setFILLER("");

        String resCd = "999";
        log.debug("===============================================================");
        log.debug("FIND RESCD !!!");
        log.debug("===============================================================");
        log.debug("receiveVo.getLoanNo() : {}", receiveVo.getLoanNo());
        log.debug("receiveVo.getTrnKnd() : {}", receiveVo.getTrnKnd());
        Optional<TbWoTrnRslt> fndResCd = tbWoTrnRsltRepository.findByIdLoanNoAndIdTgDsc(receiveVo.getLoanNo(), receiveVo.getTrnKnd());
        if (fndResCd.isPresent()) {
            TbWoTrnRsltDto rsltDto = TbWoTrnRsltMapper.INSTANCE.toDto(fndResCd.get());
            resCd = rsltDto.getResCd();
        } else {
            resCd = "000";
        }
        sendData.setBSTR_REG_NO(cntrDto.getBizNo()); // 사업자등록번호
        sendData.setPRODUCT_NAME(cntrDto.getLndPrdtNm());
        sendData.setBUYER_NAME(cntrDto.getDbtrNm());
        sendData.setSCHEDULED_AMOUNT(cntrDto.getExecPlnAmt().toString());
        sendData.setSCHEDULED_DATE(cntrDto.getExecPlnDt());
        sendData.setEXECUTION_AMOUNT(cntrDto.getExecAmt().toString());
        sendData.setEXECUTION_DATE(cntrDto.getExecDt());
        sendData.setLEG_BANK_CODE_7(cntrDto.getLwyrDiffBankCd7()); // SR대상 여부 추가
        sendData.setLEG_BANK_CODE_9(cntrDto.getLwyrDiffBankCd9());
        sendData.setKIND_CD(cntrDto.getKndCd());
        sendData.setIMG_KEY(cntrDto.getImgKey());
        sendData.setRES_CD(resCd);
        sendData.setLEG_BANK_CODE_1(cntrDto.getLwyrDiffBankCd1());
        sendData.setLEG_BANK_CODE_2(cntrDto.getLwyrDiffBankCd2());
        sendData.setLEG_BANK_CODE_3(cntrDto.getLwyrDiffBankCd3());
        sendData.setLEG_BANK_CODE_4(cntrDto.getLwyrDiffBankCd4());
        sendData.setLEG_BANK_CODE_5(cntrDto.getLwyrDiffBankCd5());
        sendData.setLEG_BANK_CODE_6(cntrDto.getLwyrDiffBankCd6());
        sendData.setLEG_BANK_CODE_7(cntrDto.getLwyrDiffBankCd7());
        sendData.setLEG_BANK_CODE_8(cntrDto.getLwyrDiffBankCd8());
        sendData.setLEG_BANK_CODE_9(cntrDto.getLwyrDiffBankCd9());
        sendData.setLEG_BANK_CODE_10(cntrDto.getLwyrDiffBankCd10());
        log.debug("resCd : {}", sendData.getRES_CD());
        log.debug("sendData ->>" + sendData.print());
        if (!StringUtils.hasText(sendData.getLO_NO().trim())) {
            sendData.setLO_NO("0000000000000");
        }
        wooriCmnSvc.wooriSendResponse(WooriCmnSvo.sendVo.builder()
                .seq(receiveVo.getTrSeq())
                .resData(sendData.dataToString())
                //.resData(sb.toString())
                .resDataLog(sendData.print())
                .resCode(sendData.getRES_CD())
                .build());
    }
}
