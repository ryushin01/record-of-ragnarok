package com.bankle.common.wooriApi.socket.woori.commonSvc.vo;


import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class CheckResponseSvo {
	
	private String seq;
	private String rescode;
	private String resdata;  // null
	private String resyn;
	private String trns_stc; // 2 : 수신완료
	
}
