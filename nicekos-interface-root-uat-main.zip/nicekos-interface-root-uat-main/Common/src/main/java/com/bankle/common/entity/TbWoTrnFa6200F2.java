package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_TRN_FA_6200_F2")
public class TbWoTrnFa6200F2 {
    @EmbeddedId
    private TbWoTrnFa6200F2Id id;

    @Column(name = "TG_LEN", precision = 4)
    private BigDecimal tgLen;

    @Size(max = 4)
    @Column(name = "TG_DSC", length = 4)
    private String tgDsc;

    @Size(max = 8)
    @Column(name = "BNK_TG_NO", length = 8)
    private String bnkTgNo;

    @Size(max = 8)
    @Column(name = "FA_TG_NO", length = 8)
    private String faTgNo;

    @Size(max = 14)
    @Column(name = "KOS_TG_SND_NO", length = 14)
    private String kosTgSndNo;

    @Size(max = 14)
    @Column(name = "TG_SND_DTM", length = 14)
    private String tgSndDtm;

    @Size(max = 14)
    @Column(name = "TG_RCV_DTM", length = 14)
    private String tgRcvDtm;

    @Size(max = 3)
    @Column(name = "RES_CD", length = 3)
    private String resCd;

    @Size(max = 35)
    @Column(name = "RSRV_ITM_H", length = 35)
    private String rsrvItmH;

    @Size(max = 20)
    @Column(name = "BNK_TTL_REQ_NO", length = 20)
    private String bnkTtlReqNo;

    @Size(max = 2)
    @Column(name = "PROC_DSC", length = 2)
    private String procDsc;

    @Size(max = 2)
    @Column(name = "LND_KND_CD", length = 2)
    private String lndKndCd;

    @Size(max = 2)
    @Column(name = "FND_USE_CD", length = 2)
    private String fndUseCd;

    @Size(max = 1)
    @Column(name = "LND_PMNT_CNFM_SLF_CD", length = 1)
    private String lndPmntCnfmSlfCd;

    @Size(max = 1)
    @Column(name = "RCPT_INFO_CNFM_SLF_CD", length = 1)
    private String rcptInfoCnfmSlfCd;

    @Size(max = 1)
    @Column(name = "THDY_RGSTR_ACPT_NO_INPT_YN", length = 1)
    private String thdyRgstrAcptNoInptYn;

    @Size(max = 9)
    @Column(name = "ESTBS_RGSTR_ACPT_NO_1", length = 9)
    private String estbsRgstrAcptNo1;

    @Size(max = 9)
    @Column(name = "ESTBS_RGSTR_ACPT_NO_2", length = 9)
    private String estbsRgstrAcptNo2;

    @Size(max = 9)
    @Column(name = "ESTBS_RGSTR_ACPT_NO_3", length = 9)
    private String estbsRgstrAcptNo3;

    @Size(max = 9)
    @Column(name = "ERSR_ACPT_NO_1", length = 9)
    private String ersrAcptNo1;

    @Size(max = 9)
    @Column(name = "ERSR_ACPT_NO_2", length = 9)
    private String ersrAcptNo2;

    @Size(max = 9)
    @Column(name = "ERSR_ACPT_NO_3", length = 9)
    private String ersrAcptNo3;

    @Size(max = 100)
    @Column(name = "RMK_B1", length = 100)
    private String rmkB1;

    @Size(max = 1)
    @Column(name = "BNK_FXCLT_ESTBS_FN_YN", length = 1)
    private String bnkFxcltEstbsFnYn;

    @Size(max = 1)
    @Column(name = "BNK_FXCLT_RNK_MTH_YN", length = 1)
    private String bnkFxcltRnkMthYn;

    @Size(max = 1)
    @Column(name = "BNK_FXCLT_ESTBS_NO_MTH_YN", length = 1)
    private String bnkFxcltEstbsNoMthYn;

    @Size(max = 300)
    @Column(name = "RGST_ATCP_THNG_ADDR", length = 300)
    private String rgstAtcpThngAddr;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_1", length = 14)
    private String rgstrUnqNo1;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_2", length = 14)
    private String rgstrUnqNo2;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_3", length = 14)
    private String rgstrUnqNo3;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_4", length = 14)
    private String rgstrUnqNo4;

    @Size(max = 14)
    @Column(name = "RGSTR_UNQ_NO_5", length = 14)
    private String rgstrUnqNo5;

    @Size(max = 8)
    @Column(name = "BNK_FXCLT_RGSTR_ACPT_DT", length = 8)
    private String bnkFxcltRgstrAcptDt;

    @Size(max = 8)
    @Column(name = "OWN_OWNSH_MV_RGSTR_ACPT_DT", length = 8)
    private String ownOwnshMvRgstrAcptDt;

    @Size(max = 50)
    @Column(name = "OWN_NM_1", length = 50)
    private String ownNm1;

    @Size(max = 50)
    @Column(name = "OWN_NM_2", length = 50)
    private String ownNm2;

    @Size(max = 50)
    @Column(name = "OWN_NM_3", length = 50)
    private String ownNm3;

    @Size(max = 13)
    @Column(name = "OWN_BIRTH_DT_1", length = 13)
    private String ownBirthDt1;

    @Size(max = 13)
    @Column(name = "OWN_BIRTH_DT_2", length = 13)
    private String ownBirthDt2;

    @Size(max = 13)
    @Column(name = "OWN_BIRTH_DT_3", length = 13)
    private String ownBirthDt3;

    @Size(max = 150)
    @Column(name = "RMK_B2", length = 150)
    private String rmkB2;

    @Size(max = 1)
    @Column(name = "DBTR_RRCP_SBMT_YN", length = 1)
    private String dbtrRrcpSbmtYn;

    @Size(max = 1)
    @Column(name = "DBTR_FRC_SBMT_YN", length = 1)
    private String dbtrFrcSbmtYn;

    @Size(max = 1)
    @Column(name = "RRCP_DBTR_SLF_RGST_YN", length = 1)
    private String rrcpDbtrSlfRgstYn;

    @Size(max = 1)
    @Column(name = "RRCP_SPUS_RGST_YN", length = 1)
    private String rrcpSpusRgstYn;

    @Size(max = 1)
    @Column(name = "FRC_SPUS_CNFM_YN", length = 1)
    private String frcSpusCnfmYn;

    @Size(max = 150)
    @Column(name = "RMK_B3", length = 150)
    private String rmkB3;

    @Size(max = 1)
    @Column(name = "DBTR_TGRC_SBMT_YN", length = 1)
    private String dbtrTgrcSbmtYn;

    @Size(max = 1)
    @Column(name = "TGRC_DBTR_SLF_MVIN_YN", length = 1)
    private String tgrcDbtrSlfMvinYn;

    @Size(max = 1)
    @Column(name = "TGRC_DBTR_OTSD_SPRT_HSHLD_EANE", length = 1)
    private String tgrcDbtrOtsdSprtHshldEane;

    @Size(max = 1)
    @Column(name = "EXEDT_MV_MVIN_EANE", length = 1)
    private String exedtMvMvinEane;

    @Size(max = 1)
    @Column(name = "BNK_DBTR_TGRC_MTH_YN", length = 1)
    private String bnkDbtrTgrcMthYn;

    @Size(max = 1)
    @Column(name = "NOW_RENTER_EVCT_YN", length = 1)
    private String nowRenterEvctYn;

    @Size(max = 14)
    @Column(name = "MVIN_HSHLD_RD_DTM", length = 14)
    private String mvinHshldRdDtm;

    @Size(max = 255)
    @Column(name = "RMK_B4")
    private String rmkB4;

    @Size(max = 30)
    @Column(name = "RSCH_AGNC_NM", length = 30)
    private String rschAgncNm;

    @Size(max = 50)
    @Column(name = "SRCHR_NM", length = 50)
    private String srchrNm;

    @Size(max = 20)
    @Column(name = "SRCHR_PHNO", length = 20)
    private String srchrPhno;

    @Size(max = 14)
    @Column(name = "RSCH_DTM", length = 14)
    private String rschDtm;

    @Size(max = 1)
    @Column(name = "SRV_RSCH_DSC", length = 1)
    private String srvRschDsc;

    @Size(max = 50)
    @Column(name = "OJT_ANS", length = 50)
    private String ojtAns;

    @Size(max = 200)
    @Column(name = "SJT_ANS_1", length = 200)
    private String sjtAns1;

    @Size(max = 200)
    @Column(name = "SJT_ANS_2", length = 200)
    private String sjtAns2;

    @Size(max = 200)
    @Column(name = "SJT_ANS_3", length = 200)
    private String sjtAns3;

    @Size(max = 200)
    @Column(name = "SJT_ANS_4", length = 200)
    private String sjtAns4;

    @Size(max = 200)
    @Column(name = "SJT_ANS_5", length = 200)
    private String sjtAns5;

    @Size(max = 50)
    @Column(name = "SLF_CTFC_AGNC", length = 50)
    private String slfCtfcAgnc;

    @Size(max = 12)
    @Column(name = "SLF_CTFC_TM", length = 12)
    private String slfCtfcTm;

    @Size(max = 1)
    @Column(name = "RESYN", length = 1)
    private String resyn;

    @Size(max = 1)
    @Column(name = "PSL_CNFM_STRD_OPTM_YN", length = 1)
    private String pslCnfmStrdOptmYn;

    @Size(max = 1)
    @Column(name = "PSL_CNFM_RSLT_BNK_TRNS_YN", length = 1)
    private String pslCnfmRsltBnkTrnsYn;

    @Size(max = 12)
    @Column(name = "PSL_CNFM_RSLT_BNK_RCV_TM", length = 12)
    private String pslCnfmRsltBnkRcvTm;

    @Size(max = 1)
    @Column(name = "FST_EXMN_RSLT", length = 1)
    private String fstExmnRslt;

    @Size(max = 1)
    @Column(name = "SCD_EXMN_RSLT", length = 1)
    private String scdExmnRslt;

    @Size(max = 353)
    @Column(name = "RSRV_ITM_B", length = 353)
    private String rsrvItmB;

    @Column(name = "REG_DTM")
    private LocalDateTime regDtm;

    @Size(max = 20)
    @Column(name = "LN_APRV_NO2", length = 20)
    private String lnAprvNo2;

}