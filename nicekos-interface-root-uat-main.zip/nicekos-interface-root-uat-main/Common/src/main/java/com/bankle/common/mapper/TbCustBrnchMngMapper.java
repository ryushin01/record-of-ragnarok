package com.bankle.common.mapper;

import com.bankle.common.dto.TbCustBrnchMngDto;
import com.bankle.common.entity.TbCustBrnchMng;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface TbCustBrnchMngMapper extends DefaultMapper<TbCustBrnchMngDto, TbCustBrnchMng> {
    TbCustBrnchMngMapper INSTANCE = Mappers.getMapper(TbCustBrnchMngMapper.class);
}