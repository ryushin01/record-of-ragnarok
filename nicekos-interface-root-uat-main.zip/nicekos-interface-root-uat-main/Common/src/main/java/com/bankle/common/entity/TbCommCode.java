package com.bankle.common.entity;


import com.bankle.common.entity.base.BaseTimeEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "TB_COMM_CODE")
@IdClass(TbCommCode.PK.class)
public class TbCommCode extends BaseTimeEntity {

    @Id
    @Column(name = "GRP_CD", nullable = false, length = 30)
    private String grpCd;

    @Id
    @Column(name = "CODE", nullable = false, length = 20)
    private String code;

    @Column(name = "CODE_NM", nullable = false, length = 100)
    private String codeNm;

    @Column(name = "GRP_NM", nullable = false, length = 100)
    private String grpNm;

    @Column(name = "GRP_DESC", nullable = true, length = 500)
    private String grpDesc;

    @Column(name = "NUM", nullable = false, precision = 11)
    private BigDecimal num;

    @Column(name = "ETC_1", nullable = true, length = 1000)
    private String etc1;

    @Column(name = "ETC_2", nullable = true, length = 1000)
    private String etc2;

    @Column(name = "ETC_3", nullable = true, length = 1000)
    private String etc3;

    @Column(name = "USE_YN", nullable = false, length = 1)
    private String useYn;

    public TbCommCode() {
    }

    @Data
    public static class PK implements Serializable {
        private String grpCd;
        private String code;
    }

}
