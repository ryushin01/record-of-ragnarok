package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "TB_SYST_HOLIDAY")
public class TbSystHoliday {
    @Id
    @Column(name = "DTM", nullable = false)
    private String dtm;

    @Size(max = 1)
    @Column(name = "HOL_YN", length = 1)
    private String holYn;

}