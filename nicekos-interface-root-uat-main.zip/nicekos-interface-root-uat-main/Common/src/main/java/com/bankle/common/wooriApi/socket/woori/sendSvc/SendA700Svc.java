package com.bankle.common.wooriApi.socket.woori.sendSvc;

import com.bankle.common.utils.DateUtil;
import com.bankle.common.wooriApi.socket.woori.commonSvc.WooriCmnSvc;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.CheckResponseSvo;
import com.bankle.common.wooriApi.socket.woori.commonSvc.vo.WooriCmnSvo;
import com.bankle.common.wooriApi.socket.woori.sendSvc.vo.SendA700Svo;
import com.bankle.common.wooriApi.socket.woori.socketData.A7X0;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;


@Slf4j
@Service
@RequiredArgsConstructor
public class SendA700Svc {

    private final WooriCmnSvc wooriCmnSvc;

    public CheckResponseSvo sendAndResponse(@Valid SendA700Svo.SendA700InSvo invo) throws Exception{
        log.debug("SendA700Svo.SendA700InSvo : " + invo);
        String seq = this.send(invo);
        log.debug("String seq = this.send(invo) : " + seq);
        return wooriCmnSvc.checkResponse(seq);
    }
    /**
     *
     * @name     : A200Svc.sendA200
     * @author   : JuHeon Kim
     * @param    :
     * @return   :
     **/
    @org.springframework.transaction.annotation.Transactional(propagation = Propagation.REQUIRES_NEW)
    public String send(@Valid SendA700Svo.SendA700InSvo invo) throws Exception {
        //------------------------------------------------------------------
        // 1. A700 전문 셋업
        //------------------------------------------------------------------
        String seq = invo.getTrSq();
        A7X0 sendData = new A7X0();
        sendData.setTR_CD(invo.getTrCd());
        sendData.setTR_TP_CD(invo.getTrTpCd());
        sendData.setLO_NO(invo.getLoNo());
        sendData.setTR_SQ(invo.getTrSq());
        sendData.setREQ_DTTM(DateUtil.getCurrentDateTime());
        sendData.setRES_DTTM(DateUtil.getCurrentDateTime());
        sendData.setRES_CD("000");
        sendData.setAPPROVAL_NUM(invo.getApprovalNum());
        sendData.setEXE_DTM(invo.getExeDtm());
        sendData.setPROC_DVSN(invo.getProcDvsn());
        sendData.setEXE_AMT(invo.getExeAmt());
        sendData.setCATEGORY_CD(invo.getCategoryCd());
        sendData.setDOC_TAX(invo.getDocTax());
        sendData.setDEBT_DC_AMT(invo.getDebtDcAmt());
        sendData.setETC_AMT(invo.getEtcAmt());
        sendData.setFILLER(invo.getFiller());
        log.debug(sendData.print());
        if (!StringUtils.hasText(sendData.getLO_NO().trim())) {
            sendData.setLO_NO("0000000000000");
        }
        //------------------------------------------------------------------
        // 3.전문 전송
        //------------------------------------------------------------------
        WooriCmnSvo.sendVo sendVo = new WooriCmnSvo.sendVo();
        sendVo.setTrSeq(sendData.getTR_SQ());
        sendVo.setTrnName(invo.getTrnName());
        sendVo.setTrnKnd(sendData.getTR_CD());
        sendVo.setReqData(sendData.dataToString());
        sendVo.setReqDataLog(sendData.print());
        sendVo.setApprovalNum(sendData.getAPPROVAL_NUM());
        sendVo.setMembNo(sendData.getLO_NO());
        sendVo.setLoanNo(invo.getLoanNo());
        sendVo.setReptMembNo(sendData.getLO_NO());
        //sendVo.setResData(sendData.dataToString());
        //sendVo.setResDataLog(sendData.print());
        sendVo.setUserAgent(invo.getUserAgent());
        sendVo.setTgDsc(invo.getInsGbn());
        sendVo.setResendCt(0);
        log.debug("SendA700Svc.send().sendData : " + sendData.dataToString());
        wooriCmnSvc.wooriSend(sendVo);
        return seq;
    }
}
