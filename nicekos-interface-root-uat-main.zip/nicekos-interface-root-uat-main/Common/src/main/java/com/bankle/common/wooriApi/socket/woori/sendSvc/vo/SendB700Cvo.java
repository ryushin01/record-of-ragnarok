package com.bankle.common.wooriApi.socket.woori.sendSvc.vo;

import lombok.*;


public class SendB700Cvo {

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class SendB700ReqCvo {
        private String loanNo;
        private String trLn;       // 전문길이:총길이(504)에서 전문길이(4)를 뺀 길이(500) 으로 고정
        private String trCd;       // 전문종별코드
        private String trTpCd;     // 거래구분코드
        private String loNo;       // 관리번호
        private String trSq;       // 식별번호
//        private String reqDttm;    // 송신일자
//        private String resDttm;    // 수신일자
//        private String resCd;      // 응답코드
//        private String approvalNum; // 여신승인신청번호
        private String imgTp;      // 이미지구분
        private String imgCheckYn; // 이미지확인여부
        private String imgKey;     // 이미지 키
        private String imgPageCnt; // 이미지 페이지 수
        private String seqNo;      // 시퀀스번호
        private String imgFileName;// 이미지 파일명
        private String resultCd;   // 처리결과
        private String filler;     // 공란
        private String jobType;         // Send : S , Response : R
        private String trnName;         //전문 명
        private String insGbn;
    }
}
