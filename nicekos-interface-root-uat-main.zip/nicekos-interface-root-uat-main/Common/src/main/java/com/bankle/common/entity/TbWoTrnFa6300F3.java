package com.bankle.common.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "TB_WO_TRN_FA_6300_F3")
public class TbWoTrnFa6300F3 {
    @EmbeddedId
    private TbWoTrnFa6300F3Id id;

    @Column(name = "TG_LEN", precision = 4)
    private BigDecimal tgLen;

    @Size(max = 4)
    @Column(name = "TG_DSC", length = 4)
    private String tgDsc;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "BNK_TG_NO", nullable = false, precision = 8)
    private BigDecimal bnkTgNo;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "FA_TG_NO", nullable = false, precision = 8)
    private BigDecimal faTgNo;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "KOS_TG_SND_NO", nullable = false, precision = 14)
    private BigDecimal kosTgSndNo;

    @Size(max = 14)
    @Column(name = "TG_SND_DTM", length = 14)
    private String tgSndDtm;

    @Size(max = 14)
    @Column(name = "TG_RCV_DTM", length = 14)
    private String tgRcvDtm;

    @Size(max = 3)
    @Column(name = "RES_CD", length = 3)
    private String resCd;

    @Size(max = 35)
    @Column(name = "RSRV_ITM_H", length = 35)
    private String rsrvItmH;

    @Size(max = 20)
    @Column(name = "BNK_TTL_REQ_NO", length = 20)
    private String bnkTtlReqNo;

    @Size(max = 2)
    @Column(name = "LND_PRGS_STC", length = 2)
    private String lndPrgsStc;

    @Size(max = 8)
    @Column(name = "PRGS_DT", length = 8)
    private String prgsDt;

    @Size(max = 20)
    @Column(name = "SBMT_DOC_LST", length = 20)
    private String sbmtDocLst;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "MVHR_HSHLDR_RNO", nullable = false, precision = 2)
    private BigDecimal mvhrHshldrRno;

    @Size(max = 300)
    @Column(name = "MVHR_TRGT_THNG_ADDR", length = 300)
    private String mvhrTrgtThngAddr;

    @Size(max = 300)
    @Column(name = "MVHR_HSHLDR_NM_MVIN_DT", length = 300)
    private String mvhrHshldrNmMvinDt;

    @Size(max = 14)
    @Column(name = "MVHRDTM")
    private String mvhrdtm;

    @Size(max = 314)
    @Column(name = "RSRV_ITM_B", length = 314)
    private String rsrvItmB;

    @NotNull
    @ColumnDefault("current_timestamp()")
    @Column(name = "REG_DTM", nullable = false)
    private LocalDateTime regDtm;

    @Size(max = 20)
    @Column(name = "LN_APRV_NO2", length = 20)
    private String lnAprvNo2;

}