package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnFa6300F3}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnFa6300F3Dto implements Serializable {
    TbWoTrnFa6300F3IdDto id;
    BigDecimal tgLen;
    @Size(max = 4)
    String tgDsc;
    @NotNull
    BigDecimal bnkTgNo;
    @NotNull
    BigDecimal faTgNo;
    @NotNull
    BigDecimal kosTgSndNo;
    @Size(max = 14)
    String tgSndDtm;
    @Size(max = 14)
    String tgRcvDtm;
    @Size(max = 3)
    String resCd;
    @Size(max = 35)
    String rsrvItmH;
    @Size(max = 20)
    String bnkTtlReqNo;
    @Size(max = 2)
    String lndPrgsStc;
    @Size(max = 8)
    String prgsDt;
    @Size(max = 20)
    String sbmtDocLst;
    @NotNull
    BigDecimal mvhrHshldrRno;
    @Size(max = 300)
    String mvhrTrgtThngAddr;
    @Size(max = 300)
    String mvhrHshldrNmMvinDt;
    @Size(max = 14)
    String mvhrdtm;
    @Size(max = 314)
    String rsrvItmB;
    @NotNull
    LocalDateTime regDtm;
    @Size(max = 20)
    String lnAprvNo2;
}