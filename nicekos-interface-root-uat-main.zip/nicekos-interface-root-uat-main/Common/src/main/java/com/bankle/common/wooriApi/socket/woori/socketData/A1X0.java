/**
 * 여신부 지급요청내역 등록/변경
 */
package com.bankle.common.wooriApi.socket.woori.socketData;

import java.io.IOException;
import java.io.InputStream;


public class A1X0 extends GetSetData {

    byte[] TR_LN = new byte[4];    //전문길이:총길이(904)에서 전문길이(4)를 뺀 길이(500) 으로 고정
    byte[] TR_CD = new byte[4];        //전문종별코드
    byte[] TR_TP_CD = new byte[3];    //거래구분코드
    byte[] LO_NO = new byte[13];    //관리번호
    byte[] TR_SQ = new byte[14];    //식별번호
    byte[] REQ_DTTM = new byte[14];        //송신일자
    byte[] RES_DTTM = new byte[14];        //수신일자
    byte[] RES_CD = new byte[3];        //응답코드
    byte[] APPROVAL_NUM = new byte[11];    //여신승인신청번호
    byte[] REQ_TP = new byte[1];        //요청구분
    byte[] RQ_EX_AMT = new byte[15];        //실행 예정 금액
    byte[] PAY_POS_AMT = new byte[15];        //지급 가능 금액
    byte[] SELL_PAY_RQ_AMT = new byte[15];        //매도인 지급 요청 금액
    byte[] BOW_PAY_RQ_AMT = new byte[15];        //차주 지급 요청 금액

    byte[] MY_BK_TOT_CNT = new byte[2];        //당행 상환 총 건수
    byte[] MY_BK_TOT_AMT = new byte[15];        //당행 상환 총 금액

    byte[] OT_BK_CNT = new byte[2];        //타행 상환 은행 수
    byte[] OT_BK_TOT_CNT = new byte[2];        //타행 상환 총 건수
    byte[] OT_BK_TOT_AMT = new byte[15];        //타행 상환 총 금액

    byte[] OT_BK_1_CD = new byte[3];        //타행은행1 은행코드
    byte[] OT_BK_1_CNT = new byte[2];        //타행은행1 상환 건수
    byte[] OT_BK_1_AMT = new byte[15];        //타행은행1 상환 합산 금액
    byte[] OT_BK_1_TP = new byte[1];        //타행은행1 입금구분

    byte[] OT_BK_2_CD = new byte[3];        //타행은행2 은행코드
    byte[] OT_BK_2_CNT = new byte[2];        //타행은행2 상환 건수
    byte[] OT_BK_2_AMT = new byte[15];        //타행은행2 상환 합산 금액
    byte[] OT_BK_2_TP = new byte[1];        //타행은행2 입금구분

    byte[] OT_BK_3_CD = new byte[3];        //타행은행3 은행코드
    byte[] OT_BK_3_CNT = new byte[2];        //타행은행3 상환 건수
    byte[] OT_BK_3_AMT = new byte[15];        //타행은행3 상환 합산 금액
    byte[] OT_BK_3_TP = new byte[1];        //타행은행3 입금구분

    byte[] OT_BK_4_CD = new byte[3];        //타행은행4 은행코드
    byte[] OT_BK_4_CNT = new byte[2];        //타행은행4 상환 건수
    byte[] OT_BK_4_AMT = new byte[15];        //타행은행4 상환 합산 금액
    byte[] OT_BK_4_TP = new byte[1];        //타행은행4 입금구분

    byte[] OT_BK_5_CD = new byte[3];        //타행은행5 은행코드
    byte[] OT_BK_5_CNT = new byte[2];        //타행은행5 상환 건수
    byte[] OT_BK_5_AMT = new byte[15];        //타행은행5 상환 합산 금액
    byte[] OT_BK_5_TP = new byte[1];        //타행은행5 입금구분

    byte[] OT_BK_6_CD = new byte[3];        //타행은행6 은행코드
    byte[] OT_BK_6_CNT = new byte[2];        //타행은행6 상환 건수
    byte[] OT_BK_6_AMT = new byte[15];        //타행은행6 상환 합산 금액
    byte[] OT_BK_6_TP = new byte[1];        //타행은행6 입금구분

    byte[] OT_BK_7_CD = new byte[3];        //타행은행7 은행코드
    byte[] OT_BK_7_CNT = new byte[2];        //타행은행7 상환 건수
    byte[] OT_BK_7_AMT = new byte[15];        //타행은행7 상환 합산 금액
    byte[] OT_BK_7_TP = new byte[1];        //타행은행7 입금구분

    byte[] OT_BK_8_CD = new byte[3];        //타행은행8 은행코드
    byte[] OT_BK_8_CNT = new byte[2];        //타행은행8 상환 건수
    byte[] OT_BK_8_AMT = new byte[15];        //타행은행8 상환 합산 금액
    byte[] OT_BK_8_TP = new byte[1];        //타행은행8 입금구분

    byte[] OT_BK_9_CD = new byte[3];        //타행은행9 은행코드
    byte[] OT_BK_9_CNT = new byte[2];        //타행은행9 상환 건수
    byte[] OT_BK_9_AMT = new byte[15];        //타행은행9 상환 합산 금액
    byte[] OT_BK_9_TP = new byte[1];        //타행은행9 입금구분

    byte[] OT_BK_10_CD = new byte[3];        //타행은행10 은행코드
    byte[] OT_BK_10_CNT = new byte[2];        //타행은행10 상환 건수
    byte[] OT_BK_10_AMT = new byte[15];        //타행은행10 상환 합산 금액
    byte[] OT_BK_10_TP = new byte[1];        //타행은행10 입금구분

    byte[] FILLER = new byte[117];    //공란

    public A1X0() {

        //default 값 셋팅
        setData(this.TR_LN, "0500");
        setData(this.TR_CD, "");
        setData(this.TR_TP_CD, "");
        setData(this.LO_NO, "");
        setData(this.TR_SQ, "");
        setData(this.REQ_DTTM, "");
        setData(this.RES_DTTM, "");
        setData(this.RES_CD, "");
        setData(this.APPROVAL_NUM, "");
        setData(this.REQ_TP, "");
        setData(this.RQ_EX_AMT, "");
        setData(this.PAY_POS_AMT, "");
        setData(this.SELL_PAY_RQ_AMT, "");
        setData(this.BOW_PAY_RQ_AMT, "");
        setData(this.MY_BK_TOT_CNT, "");
        setData(this.MY_BK_TOT_AMT, "");
        setData(this.OT_BK_CNT, "");
        setData(this.OT_BK_TOT_CNT, "");
        setData(this.OT_BK_TOT_AMT, "");

        setData(this.OT_BK_1_CD, "");
        setData(this.OT_BK_1_CNT, "");
        setData(this.OT_BK_1_AMT, "");
        setData(this.OT_BK_1_TP, "");

        setData(this.OT_BK_2_CD, "");
        setData(this.OT_BK_2_CNT, "");
        setData(this.OT_BK_2_AMT, "");
        setData(this.OT_BK_2_TP, "");

        setData(this.OT_BK_3_CD, "");
        setData(this.OT_BK_3_CNT, "");
        setData(this.OT_BK_3_AMT, "");
        setData(this.OT_BK_3_TP, "");

        setData(this.OT_BK_4_CD, "");
        setData(this.OT_BK_4_CNT, "");
        setData(this.OT_BK_4_AMT, "");
        setData(this.OT_BK_4_TP, "");

        setData(this.OT_BK_5_CD, "");
        setData(this.OT_BK_5_CNT, "");
        setData(this.OT_BK_5_AMT, "");
        setData(this.OT_BK_5_TP, "");

        setData(this.OT_BK_6_CD, "");
        setData(this.OT_BK_6_CNT, "");
        setData(this.OT_BK_6_AMT, "");
        setData(this.OT_BK_6_TP, "");

        setData(this.OT_BK_7_CD, "");
        setData(this.OT_BK_7_CNT, "");
        setData(this.OT_BK_7_AMT, "");
        setData(this.OT_BK_7_TP, "");

        setData(this.OT_BK_8_CD, "");
        setData(this.OT_BK_8_CNT, "");
        setData(this.OT_BK_8_AMT, "");
        setData(this.OT_BK_8_TP, "");

        setData(this.OT_BK_9_CD, "");
        setData(this.OT_BK_9_CNT, "");
        setData(this.OT_BK_9_AMT, "");
        setData(this.OT_BK_9_TP, "");

        setData(this.OT_BK_10_CD, "");
        setData(this.OT_BK_10_CNT, "");
        setData(this.OT_BK_10_AMT, "");
        setData(this.OT_BK_10_TP, "");

        setData(this.FILLER, "");
    }

    //	public void print() {
    public String print() {

        StringBuffer sb = new StringBuffer();

        sb.append("TR_LN : " + getData(TR_LN) + "\tSize : " + TR_LN.length + "\n");
        sb.append("TR_CD : " + getData(TR_CD) + "\tSize : " + TR_CD.length + "\n");
        sb.append("TR_TP_CD : " + getData(TR_TP_CD) + "\tSize : " + TR_TP_CD.length + "\n");
        sb.append("LO_NO : " + getData(LO_NO) + "\tSize : " + LO_NO.length + "\n");
        sb.append("TR_SQ : " + getData(TR_SQ) + "\tSize : " + TR_SQ.length + "\n");
        sb.append("REQ_DTTM : " + getData(REQ_DTTM) + "\tSize : " + REQ_DTTM.length + "\n");
        sb.append("RES_DTTM : " + getData(RES_DTTM) + "\tSize : " + RES_DTTM.length + "\n");
        sb.append("RES_CD : " + getData(RES_CD) + "\tSize : " + RES_CD.length + "\n\n");
        sb.append("APPROVAL_NUM : " + getData(APPROVAL_NUM) + "\tSize : " + APPROVAL_NUM.length + "\n");
        sb.append("REQ_TP : " + getData(REQ_TP) + "\tSize : " + REQ_TP.length + "\n");
        sb.append("RQ_EX_AMT : " + getData(RQ_EX_AMT) + "\tSize : " + RQ_EX_AMT.length + "\n");
        sb.append("PAY_POS_AMT : " + getData(PAY_POS_AMT) + "\tSize : " + PAY_POS_AMT.length + "\n");
        sb.append("SELL_PAY_RQ_AMT : " + getData(SELL_PAY_RQ_AMT) + "\tSize : " + SELL_PAY_RQ_AMT.length + "\n");
        sb.append("BOW_PAY_RQ_AMT : " + getData(BOW_PAY_RQ_AMT) + "\tSize : " + BOW_PAY_RQ_AMT.length + "\n");
        sb.append("MY_BK_TOT_CNT : " + getData(MY_BK_TOT_CNT) + "\tSize : " + MY_BK_TOT_CNT.length + "\n");
        sb.append("MY_BK_TOT_AMT : " + getData(MY_BK_TOT_AMT) + "\tSize : " + MY_BK_TOT_AMT.length + "\n");
        sb.append("OT_BK_CNT : " + getData(OT_BK_CNT) + "\tSize : " + OT_BK_CNT.length + "\n");
        sb.append("OT_BK_TOT_CNT : " + getData(OT_BK_TOT_CNT) + "\tSize : " + OT_BK_TOT_CNT.length + "\n");
        sb.append("OT_BK_TOT_AMT : " + getData(OT_BK_TOT_AMT) + "\tSize : " + OT_BK_TOT_AMT.length + "\n");
        sb.append("OT_BK_1_CD : " + getData(OT_BK_1_CD) + "\tSize : " + OT_BK_1_CD.length + "\n");
        sb.append("OT_BK_1_CNT : " + getData(OT_BK_1_CNT) + "\tSize : " + OT_BK_1_CNT.length + "\n");
        sb.append("OT_BK_1_AMT : " + getData(OT_BK_1_AMT) + "\tSize : " + OT_BK_1_AMT.length + "\n");
        sb.append("OT_BK_1_TP : " + getData(OT_BK_1_TP) + "\tSize : " + OT_BK_1_TP.length + "\n");
        sb.append("OT_BK_2_CD : " + getData(OT_BK_2_CD) + "\tSize : " + OT_BK_2_CD.length + "\n");
        sb.append("OT_BK_2_CNT : " + getData(OT_BK_2_CNT) + "\tSize : " + OT_BK_2_CNT.length + "\n");
        sb.append("OT_BK_2_AMT : " + getData(OT_BK_2_AMT) + "\tSize : " + OT_BK_2_AMT.length + "\n");
        sb.append("OT_BK_2_TP : " + getData(OT_BK_2_TP) + "\tSize : " + OT_BK_2_TP.length + "\n");
        sb.append("OT_BK_3_CD : " + getData(OT_BK_3_CD) + "\tSize : " + OT_BK_3_CD.length + "\n");
        sb.append("OT_BK_3_CNT : " + getData(OT_BK_3_CNT) + "\tSize : " + OT_BK_3_CNT.length + "\n");
        sb.append("OT_BK_3_AMT : " + getData(OT_BK_3_AMT) + "\tSize : " + OT_BK_3_AMT.length + "\n");
        sb.append("OT_BK_3_TP : " + getData(OT_BK_3_TP) + "\tSize : " + OT_BK_3_TP.length + "\n");
        sb.append("OT_BK_4_CD : " + getData(OT_BK_4_CD) + "\tSize : " + OT_BK_4_CD.length + "\n");
        sb.append("OT_BK_4_CNT : " + getData(OT_BK_4_CNT) + "\tSize : " + OT_BK_4_CNT.length + "\n");
        sb.append("OT_BK_4_AMT : " + getData(OT_BK_4_AMT) + "\tSize : " + OT_BK_4_AMT.length + "\n");
        sb.append("OT_BK_4_TP : " + getData(OT_BK_4_TP) + "\tSize : " + OT_BK_4_TP.length + "\n");
        sb.append("OT_BK_5_CD : " + getData(OT_BK_5_CD) + "\tSize : " + OT_BK_5_CD.length + "\n");
        sb.append("OT_BK_5_CNT : " + getData(OT_BK_5_CNT) + "\tSize : " + OT_BK_5_CNT.length + "\n");
        sb.append("OT_BK_5_AMT : " + getData(OT_BK_5_AMT) + "\tSize : " + OT_BK_5_AMT.length + "\n");
        sb.append("OT_BK_5_TP : " + getData(OT_BK_5_TP) + "\tSize : " + OT_BK_5_TP.length + "\n");
        sb.append("OT_BK_6_CD : " + getData(OT_BK_6_CD) + "\tSize : " + OT_BK_6_CD.length + "\n");
        sb.append("OT_BK_6_CNT : " + getData(OT_BK_6_CNT) + "\tSize : " + OT_BK_6_CNT.length + "\n");
        sb.append("OT_BK_6_AMT : " + getData(OT_BK_6_AMT) + "\tSize : " + OT_BK_6_AMT.length + "\n");
        sb.append("OT_BK_6_TP : " + getData(OT_BK_6_TP) + "\tSize : " + OT_BK_6_TP.length + "\n");
        sb.append("OT_BK_7_CD : " + getData(OT_BK_7_CD) + "\tSize : " + OT_BK_7_CD.length + "\n");
        sb.append("OT_BK_7_CNT : " + getData(OT_BK_7_CNT) + "\tSize : " + OT_BK_7_CNT.length + "\n");
        sb.append("OT_BK_7_AMT : " + getData(OT_BK_7_AMT) + "\tSize : " + OT_BK_7_AMT.length + "\n");
        sb.append("OT_BK_7_TP : " + getData(OT_BK_7_TP) + "\tSize : " + OT_BK_7_TP.length + "\n");
        sb.append("OT_BK_8_CD : " + getData(OT_BK_8_CD) + "\tSize : " + OT_BK_8_CD.length + "\n");
        sb.append("OT_BK_8_CNT : " + getData(OT_BK_8_CNT) + "\tSize : " + OT_BK_8_CNT.length + "\n");
        sb.append("OT_BK_8_AMT : " + getData(OT_BK_8_AMT) + "\tSize : " + OT_BK_8_AMT.length + "\n");
        sb.append("OT_BK_8_TP : " + getData(OT_BK_8_TP) + "\tSize : " + OT_BK_8_TP.length + "\n");
        sb.append("OT_BK_9_CD : " + getData(OT_BK_9_CD) + "\tSize : " + OT_BK_9_CD.length + "\n");
        sb.append("OT_BK_9_CNT : " + getData(OT_BK_9_CNT) + "\tSize : " + OT_BK_9_CNT.length + "\n");
        sb.append("OT_BK_9_AMT : " + getData(OT_BK_9_AMT) + "\tSize : " + OT_BK_9_AMT.length + "\n");
        sb.append("OT_BK_9_TP : " + getData(OT_BK_9_TP) + "\tSize : " + OT_BK_9_TP.length + "\n");
        sb.append("OT_BK_10_CD : " + getData(OT_BK_10_CD) + "\tSize : " + OT_BK_10_CD.length + "\n");
        sb.append("OT_BK_10_CNT : " + getData(OT_BK_10_CNT) + "\tSize : " + OT_BK_10_CNT.length + "\n");
        sb.append("OT_BK_10_AMT : " + getData(OT_BK_10_AMT) + "\tSize : " + OT_BK_10_AMT.length + "\n");
        sb.append("OT_BK_10_TP : " + getData(OT_BK_10_TP) + "\tSize : " + OT_BK_10_TP.length + "\n");
        sb.append("FILLER : " + getData(FILLER) + "\tSize : " + FILLER.length + "\n");

        // System.out.println(sb.toString());

        return sb.toString();
    }

    public String dataToString() {
        return getData(TR_LN) + getData(TR_CD) + getData(TR_TP_CD) + getData(LO_NO) + getData(TR_SQ) + getData(REQ_DTTM) + getData(RES_DTTM) + getData(RES_CD)
                + getData(APPROVAL_NUM) + getData(REQ_TP) + getData(RQ_EX_AMT) + getData(PAY_POS_AMT) + getData(SELL_PAY_RQ_AMT) + getData(BOW_PAY_RQ_AMT)
                + getData(MY_BK_TOT_CNT) + getData(MY_BK_TOT_AMT) + getData(OT_BK_CNT) + getData(OT_BK_TOT_CNT) + getData(OT_BK_TOT_AMT)
                + getData(OT_BK_1_CD) + getData(OT_BK_1_CNT) + getData(OT_BK_1_AMT) + getData(OT_BK_1_TP)
                + getData(OT_BK_2_CD) + getData(OT_BK_2_CNT) + getData(OT_BK_2_AMT) + getData(OT_BK_2_TP)
                + getData(OT_BK_3_CD) + getData(OT_BK_3_CNT) + getData(OT_BK_3_AMT) + getData(OT_BK_3_TP)
                + getData(OT_BK_4_CD) + getData(OT_BK_4_CNT) + getData(OT_BK_4_AMT) + getData(OT_BK_4_TP)
                + getData(OT_BK_5_CD) + getData(OT_BK_5_CNT) + getData(OT_BK_5_AMT) + getData(OT_BK_5_TP)
                + getData(OT_BK_6_CD) + getData(OT_BK_6_CNT) + getData(OT_BK_6_AMT) + getData(OT_BK_6_TP)
                + getData(OT_BK_7_CD) + getData(OT_BK_7_CNT) + getData(OT_BK_7_AMT) + getData(OT_BK_7_TP)
                + getData(OT_BK_8_CD) + getData(OT_BK_8_CNT) + getData(OT_BK_8_AMT) + getData(OT_BK_8_TP)
                + getData(OT_BK_9_CD) + getData(OT_BK_9_CNT) + getData(OT_BK_9_AMT) + getData(OT_BK_9_TP)
                + getData(OT_BK_10_CD) + getData(OT_BK_10_CNT) + getData(OT_BK_10_AMT) + getData(OT_BK_10_TP)
                + getData(FILLER);
    }

    public void readDataExternal(InputStream stream) {
        try {
            stream.read(TR_LN, 0, TR_LN.length);
            stream.read(TR_CD, 0, TR_CD.length);
            stream.read(TR_TP_CD, 0, TR_TP_CD.length);
            stream.read(LO_NO, 0, LO_NO.length);
            stream.read(TR_SQ, 0, TR_SQ.length);
            stream.read(REQ_DTTM, 0, REQ_DTTM.length);
            stream.read(RES_DTTM, 0, RES_DTTM.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(APPROVAL_NUM, 0, APPROVAL_NUM.length);
            stream.read(REQ_TP, 0, REQ_TP.length);
            stream.read(RQ_EX_AMT, 0, RQ_EX_AMT.length);
            stream.read(PAY_POS_AMT, 0, PAY_POS_AMT.length);
            stream.read(SELL_PAY_RQ_AMT, 0, SELL_PAY_RQ_AMT.length);
            stream.read(BOW_PAY_RQ_AMT, 0, BOW_PAY_RQ_AMT.length);

            stream.read(MY_BK_TOT_CNT, 0, MY_BK_TOT_CNT.length);
            stream.read(MY_BK_TOT_AMT, 0, MY_BK_TOT_AMT.length);
            stream.read(OT_BK_CNT, 0, OT_BK_CNT.length);
            stream.read(OT_BK_TOT_CNT, 0, OT_BK_TOT_CNT.length);
            stream.read(OT_BK_TOT_AMT, 0, OT_BK_TOT_AMT.length);

            stream.read(OT_BK_1_CD, 0, OT_BK_1_CD.length);
            stream.read(OT_BK_1_CNT, 0, OT_BK_1_CNT.length);
            stream.read(OT_BK_1_AMT, 0, OT_BK_1_AMT.length);
            stream.read(OT_BK_1_TP, 0, OT_BK_1_TP.length);

            stream.read(OT_BK_2_CD, 0, OT_BK_2_CD.length);
            stream.read(OT_BK_2_CNT, 0, OT_BK_2_CNT.length);
            stream.read(OT_BK_2_AMT, 0, OT_BK_2_AMT.length);
            stream.read(OT_BK_2_TP, 0, OT_BK_2_TP.length);

            stream.read(OT_BK_3_CD, 0, OT_BK_3_CD.length);
            stream.read(OT_BK_3_CNT, 0, OT_BK_3_CNT.length);
            stream.read(OT_BK_3_AMT, 0, OT_BK_3_AMT.length);
            stream.read(OT_BK_3_TP, 0, OT_BK_3_TP.length);

            stream.read(OT_BK_4_CD, 0, OT_BK_4_CD.length);
            stream.read(OT_BK_4_CNT, 0, OT_BK_4_CNT.length);
            stream.read(OT_BK_4_AMT, 0, OT_BK_4_AMT.length);
            stream.read(OT_BK_4_TP, 0, OT_BK_4_TP.length);

            stream.read(OT_BK_5_CD, 0, OT_BK_5_CD.length);
            stream.read(OT_BK_5_CNT, 0, OT_BK_5_CNT.length);
            stream.read(OT_BK_5_AMT, 0, OT_BK_5_AMT.length);
            stream.read(OT_BK_5_TP, 0, OT_BK_5_TP.length);

            stream.read(OT_BK_6_CD, 0, OT_BK_6_CD.length);
            stream.read(OT_BK_6_CNT, 0, OT_BK_6_CNT.length);
            stream.read(OT_BK_6_AMT, 0, OT_BK_6_AMT.length);
            stream.read(OT_BK_6_TP, 0, OT_BK_6_TP.length);

            stream.read(OT_BK_7_CD, 0, OT_BK_7_CD.length);
            stream.read(OT_BK_7_CNT, 0, OT_BK_7_CNT.length);
            stream.read(OT_BK_7_AMT, 0, OT_BK_7_AMT.length);
            stream.read(OT_BK_7_TP, 0, OT_BK_7_TP.length);

            stream.read(OT_BK_8_CD, 0, OT_BK_8_CD.length);
            stream.read(OT_BK_8_CNT, 0, OT_BK_8_CNT.length);
            stream.read(OT_BK_8_AMT, 0, OT_BK_8_AMT.length);
            stream.read(OT_BK_8_TP, 0, OT_BK_8_TP.length);

            stream.read(OT_BK_9_CD, 0, OT_BK_9_CD.length);
            stream.read(OT_BK_9_CNT, 0, OT_BK_9_CNT.length);
            stream.read(OT_BK_9_AMT, 0, OT_BK_9_AMT.length);
            stream.read(OT_BK_9_TP, 0, OT_BK_9_TP.length);

            stream.read(OT_BK_10_CD, 0, OT_BK_10_CD.length);
            stream.read(OT_BK_10_CNT, 0, OT_BK_10_CNT.length);
            stream.read(OT_BK_10_AMT, 0, OT_BK_10_AMT.length);
            stream.read(OT_BK_10_TP, 0, OT_BK_10_TP.length);

            stream.read(FILLER, 0, FILLER.length);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //------------------------------------------------------------------
    // Get Data
    //------------------------------------------------------------------

    /**
     * 전문길이
     *
     * @return
     */
    public String getTR_LN() {
        return getData(TR_LN);
    }

    /**
     * 전문종별코드
     *
     * @return
     */
    public String getTR_CD() {
        return getData(TR_CD);
    }

    /**
     * 거래구분코드
     *
     * @return
     */
    public String getTR_TP_CD() {
        return getData(TR_TP_CD);
    }

    /**
     * 관리번호
     *
     * @return
     */
    public String getLO_NO() {
        return getData(LO_NO);
    }


    /**
     * 식별번호
     *
     * @return
     */
    public String getTR_SQ() {
        return getData(TR_SQ);
    }

    /**
     * 송신일자
     *
     * @return
     */
    public String getREQ_DTTM() {
        return getData(REQ_DTTM);
    }

    /**
     * 수신일자
     *
     * @return
     */
    public String getRES_DTTM() {
        return getData(RES_DTTM);
    }

    /**
     * 응답코드
     *
     * @return
     */
    public String getRES_CD() {
        return getData(RES_CD);
    }

    /**
     * 여신승인신청번호
     *
     * @return
     */
    public String getAPPROVAL_NUM() {
        return getData(APPROVAL_NUM);
    }

    /**
     * 요청구분
     *
     * @return
     */
    public String getREQ_TP() {
        return getData(REQ_TP);
    }

    /**
     * 실행 예정 금액
     *
     * @return
     */
    public String getRQ_EX_AMT() {
        return getData(RQ_EX_AMT);
    }

    /**
     * 지급 가능 금액
     *
     * @return
     */
    public String getPAY_POS_AMT() {
        return getData(PAY_POS_AMT);
    }

    /**
     * 매도인 지급 요청 금액
     *
     * @return
     */
    public String getSELL_PAY_RQ_AMT() {
        return getData(SELL_PAY_RQ_AMT);
    }

    /**
     * 차주 지급 요청 금액
     *
     * @return
     */
    public String getBOW_PAY_RQ_AMT() {
        return getData(BOW_PAY_RQ_AMT);
    }

    /**
     * 당행 상환 총 건수
     *
     * @return
     */
    public String getMY_BK_TOT_CNT() {
        return getData(MY_BK_TOT_CNT);
    }

    /**
     * 당행 상환 총 금액
     *
     * @return
     */
    public String getMY_BK_TOT_AMT() {
        return getData(MY_BK_TOT_AMT);
    }

    /**
     * 타행 상환 은행 수
     *
     * @return
     */
    public String getOT_BK_CNT() {
        return getData(OT_BK_CNT);
    }

    /**
     * 타행 상환 총 건수
     *
     * @return
     */
    public String getOT_BK_TOT_CNT() {
        return getData(OT_BK_TOT_CNT);
    }

    /**
     * 타행 상환 총 금액
     *
     * @return
     */
    public String getOT_BK_TOT_AMT() {
        return getData(OT_BK_TOT_AMT);
    }

    /**
     * 타행은행1 은행코드
     *
     * @return
     */
    public String getOT_BK_1_CD() {
        return getData(OT_BK_1_CD);
    }

    /**
     * 타행은행1 상환 건수
     *
     * @return
     */
    public String getOT_BK_1_CNT() {
        return getData(OT_BK_1_CNT);
    }

    /**
     * 타행은행1 상환 합산 금액
     *
     * @return
     */
    public String getOT_BK_1_AMT() {
        return getData(OT_BK_1_AMT);
    }

    /**
     * 타행은행1 입금구분
     *
     * @return
     */
    public String getOT_BK_1_TP() {
        return getData(OT_BK_1_TP);
    }

    /**
     * 타행은행2 은행코드
     *
     * @return
     */
    public String getOT_BK_2_CD() {
        return getData(OT_BK_2_CD);
    }

    /**
     * 타행은행2 상환 건수
     *
     * @return
     */
    public String getOT_BK_2_CNT() {
        return getData(OT_BK_2_CNT);
    }

    /**
     * 타행은행2 상환 합산 금액
     *
     * @return
     */
    public String getOT_BK_2_AMT() {
        return getData(OT_BK_2_AMT);
    }

    /**
     * 타행은행2 입금구분
     *
     * @return
     */
    public String getOT_BK_2_TP() {
        return getData(OT_BK_2_TP);
    }

    /**
     * 타행은행3 은행코드
     *
     * @return
     */
    public String getOT_BK_3_CD() {
        return getData(OT_BK_3_CD);
    }

    /**
     * 타행은행3 상환 건수
     *
     * @return
     */
    public String getOT_BK_3_CNT() {
        return getData(OT_BK_3_CNT);
    }

    /**
     * 타행은행3 상환 합산 금액
     *
     * @return
     */
    public String getOT_BK_3_AMT() {
        return getData(OT_BK_3_AMT);
    }

    /**
     * 타행은행3 입금구분
     *
     * @return
     */
    public String getOT_BK_3_TP() {
        return getData(OT_BK_3_TP);
    }

    /**
     * 타행은행4 은행코드
     *
     * @return
     */
    public String getOT_BK_4_CD() {
        return getData(OT_BK_4_CD);
    }

    /**
     * 타행은행4 상환 건수
     *
     * @return
     */
    public String getOT_BK_4_CNT() {
        return getData(OT_BK_4_CNT);
    }

    /**
     * 타행은행4 상환 합산 금액
     *
     * @return
     */
    public String getOT_BK_4_AMT() {
        return getData(OT_BK_4_AMT);
    }

    /**
     * 타행은행4 입금구분
     *
     * @return
     */
    public String getOT_BK_4_TP() {
        return getData(OT_BK_4_TP);
    }

    /**
     * 타행은행5 은행코드
     *
     * @return
     */
    public String getOT_BK_5_CD() {
        return getData(OT_BK_5_CD);
    }

    /**
     * 타행은행5 상환 건수
     *
     * @return
     */
    public String getOT_BK_5_CNT() {
        return getData(OT_BK_5_CNT);
    }

    /**
     * 타행은행5 상환 합산 금액
     *
     * @return
     */
    public String getOT_BK_5_AMT() {
        return getData(OT_BK_5_AMT);
    }

    /**
     * 타행은행5 입금구분
     *
     * @return
     */
    public String getOT_BK_5_TP() {
        return getData(OT_BK_5_TP);
    }

    /**
     * 타행은행6 은행코드
     *
     * @return
     */
    public String getOT_BK_6_CD() {
        return getData(OT_BK_6_CD);
    }

    /**
     * 타행은행6 상환 건수
     *
     * @return
     */
    public String getOT_BK_6_CNT() {
        return getData(OT_BK_6_CNT);
    }

    /**
     * 타행은행6 상환 합산 금액
     *
     * @return
     */
    public String getOT_BK_6_AMT() {
        return getData(OT_BK_6_AMT);
    }

    /**
     * 타행은행6 입금구분
     *
     * @return
     */
    public String getOT_BK_6_TP() {
        return getData(OT_BK_6_TP);
    }


    /**
     * 타행은행7 은행코드
     *
     * @return
     */
    public String getOT_BK_7_CD() {
        return getData(OT_BK_7_CD);
    }

    /**
     * 타행은행7 상환 건수
     *
     * @return
     */
    public String getOT_BK_7_CNT() {
        return getData(OT_BK_7_CNT);
    }

    /**
     * 타행은행7 상환 합산 금액
     *
     * @return
     */
    public String getOT_BK_7_AMT() {
        return getData(OT_BK_7_AMT);
    }

    /**
     * 타행은행7 입금구분
     *
     * @return
     */
    public String getOT_BK_7_TP() {
        return getData(OT_BK_7_TP);
    }

    /**
     * 타행은행8 은행코드
     *
     * @return
     */
    public String getOT_BK_8_CD() {
        return getData(OT_BK_8_CD);
    }

    /**
     * 타행은행8 상환 건수
     *
     * @return
     */
    public String getOT_BK_8_CNT() {
        return getData(OT_BK_8_CNT);
    }

    /**
     * 타행은행8 상환 합산 금액
     *
     * @return
     */
    public String getOT_BK_8_AMT() {
        return getData(OT_BK_8_AMT);
    }

    /**
     * 타행은행8 입금구분
     *
     * @return
     */
    public String getOT_BK_8_TP() {
        return getData(OT_BK_8_TP);
    }

    /**
     * 타행은행9 은행코드
     *
     * @param OT_BK_9_CD
     */
    public void setOT_BK_9_CD(String OT_BK_9_CD) {
        setData(this.OT_BK_9_CD, OT_BK_9_CD);
    }

    /**
     * 타행은행9 은행코드
     *
     * @return
     */
    public String getOT_BK_9_CD() {
        return getData(OT_BK_9_CD);
    }

    /**
     * 타행은행9 상환 건수
     *
     * @return
     */
    public String getOT_BK_9_CNT() {
        return getData(OT_BK_9_CNT);
    }

    /**
     * 타행은행9 상환 합산 금액
     *
     * @return
     */
    public String getOT_BK_9_AMT() {
        return getData(OT_BK_9_AMT);
    }

    /**
     * 타행은행9 입금구분
     *
     * @return
     */
    public String getOT_BK_9_TP() {
        return getData(OT_BK_9_TP);
    }

    /**
     * 타행은행10 은행코드
     *
     * @return
     */
    public String getOT_BK_10_CD() {
        return getData(OT_BK_10_CD);
    }

    /**
     * 타행은행10 상환 건수
     *
     * @return
     */
    public String getOT_BK_10_CNT() {
        return getData(OT_BK_10_CNT);
    }

    /**
     * 타행은행10 상환 합산 금액
     *
     * @return
     */
    public String getOT_BK_10_AMT() {
        return getData(OT_BK_10_AMT);
    }

    /**
     * 타행은행10 입금구분
     *
     * @return
     */
    public String getOT_BK_10_TP() {
        return getData(OT_BK_10_TP);
    }

    /**
     * 예비
     *
     * @return
     */
    public String getFILLER() {
        return getData(FILLER);
    }

    //------------------------------------------------------------------
    // Set Data
    //------------------------------------------------------------------

    /**
     * 전문길이
     *
     * @param TR_LN
     */
    public void setTR_LN(String TR_LN) {
        setData(this.TR_LN, TR_LN, "S");
    }

    /**
     * 전문종별코드
     *
     * @param TR_CD
     */
    public void setTR_CD(String TR_CD) {
        setData(this.TR_CD, TR_CD, "S");
    }

    /**
     * 거래구분코드
     *
     * @param TR_TP_CD
     */
    public void setTR_TP_CD(String TR_TP_CD) {
        setData(this.TR_TP_CD, TR_TP_CD, "S");
    }

    /**
     * 관리번호
     *
     * @param LO_NO
     */
    public void setLO_NO(String LO_NO) {
        setData(this.LO_NO, LO_NO, "N");
    }

    /**
     * 식별번호
     *
     * @param TR_SQ
     */
    public void setTR_SQ(String TR_SQ) {
        setData(this.TR_SQ, TR_SQ, "S");
    }

    /**
     * 송신일자
     *
     * @param REQ_DTTM
     */
    public void setREQ_DTTM(String REQ_DTTM) {
        setData(this.REQ_DTTM, REQ_DTTM, "S");
    }

    /**
     * 수신일자
     *
     * @param RES_DTTM
     */
    public void setRES_DTTM(String RES_DTTM) {
        setData(this.RES_DTTM, RES_DTTM, "S");
    }

    /**
     * 응답코드
     *
     * @param RES_CD
     */
    public void setRES_CD(String RES_CD) {
        setData(this.RES_CD, RES_CD, "S");
    }

    /**
     * 여신승인신청번호
     *
     * @param APPROVAL_NUM
     */
    public void setAPPROVAL_NUM(String APPROVAL_NUM) {
        setData(this.APPROVAL_NUM, APPROVAL_NUM, "S");
    }

    /**
     * 요청구분
     *
     * @param
     */
    public void setREQ_TP(String REQ_TP) {
        setData(this.REQ_TP, REQ_TP, "S");
    }

    /**
     * 실행 예정 금액
     *
     * @param RQ_EX_AMT
     */
    public void setRQ_EX_AMT(String RQ_EX_AMT) {
        setData(this.RQ_EX_AMT, RQ_EX_AMT, "N");
    }

    /**
     * 지급 가능 금액
     *
     * @param PAY_POS_AMT
     */
    public void setPAY_POS_AMT(String PAY_POS_AMT) {
        setData(this.PAY_POS_AMT, PAY_POS_AMT, "N");
    }

    /**
     * 매도인 지급 요청 금액
     *
     * @param SELL_PAY_RQ_AMT
     */
    public void setSELL_PAY_RQ_AMT(String SELL_PAY_RQ_AMT) {
        setData(this.SELL_PAY_RQ_AMT, SELL_PAY_RQ_AMT, "N");
    }

    /**
     * 차주 지급 요청 금액
     *
     * @param BOW_PAY_RQ_AMT
     */
    public void setBOW_PAY_RQ_AMT(String BOW_PAY_RQ_AMT) {
        setData(this.BOW_PAY_RQ_AMT, BOW_PAY_RQ_AMT, "N");
    }

    /**
     * 당행 상환 총 건수
     *
     * @param MY_BK_TOT_CNT
     */
    public void setMY_BK_TOT_CNT(String MY_BK_TOT_CNT) {
        setData(this.MY_BK_TOT_CNT, MY_BK_TOT_CNT, "N");
    }

    /**
     * 당행 상환 총 금액
     *
     * @param MY_BK_TOT_AMT
     */
    public void setMY_BK_TOT_AMT(String MY_BK_TOT_AMT) {
        setData(this.MY_BK_TOT_AMT, MY_BK_TOT_AMT, "N");
    }

    /**
     * 타행 상환 은행 수
     *
     * @param OT_BK_CNT
     */
    public void setOT_BK_CNT(String OT_BK_CNT) {
        setData(this.OT_BK_CNT, OT_BK_CNT, "N");
    }

    /**
     * 타행 상환 총 건수
     *
     * @param OT_BK_TOT_CNT
     */
    public void setOT_BK_TOT_CNT(String OT_BK_TOT_CNT) {
        setData(this.OT_BK_TOT_CNT, OT_BK_TOT_CNT, "N");
    }

    /**
     * 타행 상환 총 금액
     *
     * @param OT_BK_TOT_AMT
     */
    public void setOT_BK_TOT_AMT(String OT_BK_TOT_AMT) {
        setData(this.OT_BK_TOT_AMT, OT_BK_TOT_AMT, "N");
    }

    /**
     * 타행은행1 은행코드
     *
     * @param OT_BK_1_CD
     */
    public void setOT_BK_1_CD(String OT_BK_1_CD) {
        setData(this.OT_BK_1_CD, OT_BK_1_CD, "S");
    }

    /**
     * 타행은행1 상환 건수
     *
     * @param OT_BK_1_CNT
     */
    public void setOT_BK_1_CNT(String OT_BK_1_CNT) {
        setData(this.OT_BK_1_CNT, OT_BK_1_CNT,"N");
    }

    /**
     * 타행은행1 상환 합산 금액
     *
     * @param OT_BK_1_AMT
     */
    public void setOT_BK_1_AMT(String OT_BK_1_AMT) {
        setData(this.OT_BK_1_AMT, OT_BK_1_AMT,"N");
    }

    /**
     * 타행은행1 입금구분
     *
     * @param OT_BK_1_TP
     */
    public void setOT_BK_1_TP(String OT_BK_1_TP) {
        setData(this.OT_BK_1_TP, OT_BK_1_TP, "S");
    }

    /**
     * 타행은행1 입금구분
     */
    public void setOT_BK_1(String OT_BK_1_CD, String OT_BK_1_CNT, String OT_BK_1_AMT, String OT_BK_1_TP) {
        setData(this.OT_BK_1_CD, OT_BK_1_CD,"S");
        setData(this.OT_BK_1_CNT, OT_BK_1_CNT,"N");
        setData(this.OT_BK_1_AMT, OT_BK_1_AMT,"N");
        setData(this.OT_BK_1_TP, OT_BK_1_TP, "S");
    }


    /**
     * 타행은행2 은행코드
     *
     * @param OT_BK_2_CD
     */
    public void setOT_BK_2_CD(String OT_BK_2_CD) {
        setData(this.OT_BK_2_CD, OT_BK_2_CD, "S");
    }


    /**
     * 타행은행2 상환 건수
     *
     * @param OT_BK_2_CNT
     */
    public void setOT_BK_2_CNT(String OT_BK_2_CNT) {
        setData(this.OT_BK_2_CNT, OT_BK_2_CNT,"N");
    }

    /**
     * 타행은행2 상환 합산 금액
     *
     * @param OT_BK_2_AMT
     */
    public void setOT_BK_2_AMT(String OT_BK_2_AMT) {
        setData(this.OT_BK_2_AMT, OT_BK_2_AMT,"N");
    }

    /**
     * 타행은행2 입금구분
     *
     * @param OT_BK_2_TP
     */
    public void setOT_BK_2_TP(String OT_BK_2_TP) {
        setData(this.OT_BK_2_TP, OT_BK_2_TP, "S");
    }

    public void setOT_BK_2(String OT_BK_2_CD, String OT_BK_2_CNT, String OT_BK_2_AMT, String OT_BK_2_TP) {
        setData(this.OT_BK_2_CD, OT_BK_2_CD,"S");
        setData(this.OT_BK_2_CNT, OT_BK_2_CNT,"N");
        setData(this.OT_BK_2_AMT, OT_BK_2_AMT,"N");
        setData(this.OT_BK_2_TP, OT_BK_2_TP, "S");
    }

    /**
     * 타행은행3 은행코드
     *
     * @param OT_BK_3_CD
     */
    public void setOT_BK_3_CD(String OT_BK_3_CD) {
        setData(this.OT_BK_3_CD, OT_BK_3_CD, "S");
    }

    /**
     * 타행은행3 상환 건수
     *
     * @param OT_BK_3_CNT
     */
    public void setOT_BK_3_CNT(String OT_BK_3_CNT) {
        setData(this.OT_BK_3_CNT, OT_BK_3_CNT,"N");
    }

    /**
     * 타행은행3 상환 합산 금액
     *
     * @param OT_BK_3_AMT
     */
    public void setOT_BK_3_AMT(String OT_BK_3_AMT) {
        setData(this.OT_BK_3_AMT, OT_BK_3_AMT,"N");
    }

    /**
     * 타행은행3 입금구분
     *
     * @param OT_BK_3_TP
     */
    public void setOT_BK_3_TP(String OT_BK_3_TP) {
        setData(this.OT_BK_3_TP, OT_BK_3_TP,"S");
    }

    public void setOT_BK_3(String OT_BK_3_CD, String OT_BK_3_CNT, String OT_BK_3_AMT, String OT_BK_3_TP) {
        setData(this.OT_BK_3_CD, OT_BK_3_CD,"S");
        setData(this.OT_BK_3_CNT, OT_BK_3_CNT,"N");
        setData(this.OT_BK_3_AMT, OT_BK_3_AMT,"N");
        setData(this.OT_BK_3_TP, OT_BK_3_TP,"S");
    }

    /**
     * 타행은행4 은행코드
     *
     * @param OT_BK_4_CD
     */
    public void setOT_BK_4_CD(String OT_BK_4_CD) {
        setData(this.OT_BK_4_CD, OT_BK_4_CD,"S");
    }

    /**
     * 타행은행4 상환 건수
     *
     * @param OT_BK_4_CNT
     */
    public void setOT_BK_4_CNT(String OT_BK_4_CNT) {
        setData(this.OT_BK_4_CNT, OT_BK_4_CNT,"N");
    }

    /**
     * 타행은행4 상환 합산 금액
     *
     * @param OT_BK_4_AMT
     */
    public void setOT_BK_4_AMT(String OT_BK_4_AMT) {
        setData(this.OT_BK_4_AMT, OT_BK_4_AMT,"N");
    }

    /**
     * 타행은행4 입금구분
     *
     * @param OT_BK_4_TP
     */
    public void setOT_BK_4_TP(String OT_BK_4_TP) {
        setData(this.OT_BK_4_TP, OT_BK_4_TP,"S");
    }

    public void setOT_BK_4(String OT_BK_4_CD, String OT_BK_4_CNT, String OT_BK_4_AMT, String OT_BK_4_TP) {
        setData(this.OT_BK_4_CD, OT_BK_4_CD,"S");
        setData(this.OT_BK_4_CNT, OT_BK_4_CNT,"N");
        setData(this.OT_BK_4_AMT, OT_BK_4_AMT,"N");
        setData(this.OT_BK_4_TP, OT_BK_4_TP,"S");
    }

    /**
     * 타행은행5 은행코드
     *
     * @param OT_BK_5_CD
     */
    public void setOT_BK_5_CD(String OT_BK_5_CD) {
        setData(this.OT_BK_5_CD, OT_BK_5_CD,"S");
    }

    /**
     * 타행은행5 상환 건수
     *
     * @param OT_BK_5_CNT
     */
    public void setOT_BK_5_CNT(String OT_BK_5_CNT) {
        setData(this.OT_BK_5_CNT, OT_BK_5_CNT,"N");
    }


    /**
     * 타행은행5 상환 합산 금액
     *
     * @param OT_BK_5_AMT
     */
    public void setOT_BK_5_AMT(String OT_BK_5_AMT) {
        setData(this.OT_BK_5_AMT, OT_BK_5_AMT,"N");
    }

    /**
     * 타행은행5 입금구분
     *
     * @param OT_BK_5_TP
     */
    public void setOT_BK_5_TP(String OT_BK_5_TP) {
        setData(this.OT_BK_5_TP, OT_BK_5_TP,"S");
    }

    public void setOT_BK_5(String OT_BK_5_CD, String OT_BK_5_CNT, String OT_BK_5_AMT, String OT_BK_5_TP) {
        setData(this.OT_BK_5_CD, OT_BK_5_CD,"S");
        setData(this.OT_BK_5_CNT, OT_BK_5_CNT,"N");
        setData(this.OT_BK_5_AMT, OT_BK_5_AMT,"N");
        setData(this.OT_BK_5_TP, OT_BK_5_TP,"S");
    }

    /**
     * 타행은행6 은행코드
     *
     * @param OT_BK_6_CD
     */
    public void setOT_BK_6_CD(String OT_BK_6_CD) {
        setData(this.OT_BK_6_CD, OT_BK_6_CD,"S");
    }

    /**
     * 타행은행6 상환 건수
     *
     * @param OT_BK_6_CNT
     */
    public void setOT_BK_6_CNT(String OT_BK_6_CNT) {
        setData(this.OT_BK_6_CNT, OT_BK_6_CNT,"N");
    }

    /**
     * 타행은행6 상환 합산 금액
     *
     * @param OT_BK_6_AMT
     */
    public void setOT_BK_6_AMT(String OT_BK_6_AMT) {
        setData(this.OT_BK_6_AMT, OT_BK_6_AMT,"N");
    }

    /**
     * 타행은행6 입금구분
     *
     * @param OT_BK_6_TP
     */
    public void setOT_BK_6_TP(String OT_BK_6_TP) {
        setData(this.OT_BK_6_TP, OT_BK_6_TP,"S");
    }

    public void setOT_BK_6(String OT_BK_6_CD, String OT_BK_6_CNT, String OT_BK_6_AMT, String OT_BK_6_TP) {
        setData(this.OT_BK_6_CD, OT_BK_6_CD,"S");
        setData(this.OT_BK_6_CNT, OT_BK_6_CNT,"N");
        setData(this.OT_BK_6_AMT, OT_BK_6_AMT,"N");
        setData(this.OT_BK_6_TP, OT_BK_6_TP,"S");
    }

    /**
     * 타행은행7 은행코드
     *
     * @param OT_BK_7_CD
     */
    public void setOT_BK_7_CD(String OT_BK_7_CD) {
        setData(this.OT_BK_7_CD, OT_BK_7_CD,"S");
    }

    /**
     * 타행은행7 상환 건수
     *
     * @param OT_BK_7_CNT
     */
    public void setOT_BK_7_CNT(String OT_BK_7_CNT) {
        setData(this.OT_BK_7_CNT, OT_BK_7_CNT,"N");
    }

    /**
     * 타행은행7 상환 합산 금액
     *
     * @param OT_BK_7_AMT
     */
    public void setOT_BK_7_AMT(String OT_BK_7_AMT) {
        setData(this.OT_BK_7_AMT, OT_BK_7_AMT,"N");
    }

    /**
     * 타행은행7 입금구분
     *
     * @param OT_BK_7_TP
     */
    public void setOT_BK_7_TP(String OT_BK_7_TP) {
        setData(this.OT_BK_7_TP, OT_BK_7_TP,"S");
    }

    public void setOT_BK_7(String OT_BK_7_CD, String OT_BK_7_CNT, String OT_BK_7_AMT, String OT_BK_7_TP) {
        setData(this.OT_BK_7_CD, OT_BK_7_CD,"S");
        setData(this.OT_BK_7_CNT, OT_BK_7_CNT,"N");
        setData(this.OT_BK_7_AMT, OT_BK_7_AMT,"N");
        setData(this.OT_BK_7_TP, OT_BK_7_TP,"S");
    }

    /**
     * 타행은행8 은행코드
     *
     * @param OT_BK_8_CD
     */
    public void setOT_BK_8_CD(String OT_BK_8_CD) {
        setData(this.OT_BK_8_CD, OT_BK_8_CD,"S");
    }

    /**
     * 타행은행8 상환 건수
     *
     * @param OT_BK_8_CNT
     */
    public void setOT_BK_8_CNT(String OT_BK_8_CNT) {
        setData(this.OT_BK_8_CNT, OT_BK_8_CNT,"N");
    }

    /**
     * 타행은행8 상환 합산 금액
     *
     * @param OT_BK_8_AMT
     */
    public void setOT_BK_8_AMT(String OT_BK_8_AMT) {
        setData(this.OT_BK_8_AMT, OT_BK_8_AMT,"N");
    }

    /**
     * 타행은행8 입금구분
     *
     * @param OT_BK_8_TP
     */
    public void setOT_BK_8_TP(String OT_BK_8_TP) {
        setData(this.OT_BK_8_TP, OT_BK_8_TP,"S");
    }

    public void setOT_BK_8(String OT_BK_8_CD, String OT_BK_8_CNT, String OT_BK_8_AMT, String OT_BK_8_TP) {
        setData(this.OT_BK_8_CD, OT_BK_8_CD,"S");
        setData(this.OT_BK_8_CNT, OT_BK_8_CNT,"N");
        setData(this.OT_BK_8_AMT, OT_BK_8_AMT,"N");
        setData(this.OT_BK_8_TP, OT_BK_8_TP,"S");
    }

    /**
     * 타행은행9 상환 건수
     *
     * @param OT_BK_9_CNT
     */
    public void setOT_BK_9_CNT(String OT_BK_9_CNT) {
        setData(this.OT_BK_9_CNT, OT_BK_9_CNT,"N");
    }


    /**
     * 타행은행9 상환 합산 금액
     *
     * @param OT_BK_9_AMT
     */
    public void setOT_BK_9_AMT(String OT_BK_9_AMT) {
        setData(this.OT_BK_9_AMT, OT_BK_9_AMT,"N");
    }

    /**
     * 타행은행9 입금구분
     *
     * @param OT_BK_9_TP
     */
    public void setOT_BK_9_TP(String OT_BK_9_TP) {
        setData(this.OT_BK_9_TP, OT_BK_9_TP,"S");
    }

    public void setOT_BK_9(String OT_BK_9_CD, String OT_BK_9_CNT, String OT_BK_9_AMT, String OT_BK_9_TP) {
        setData(this.OT_BK_9_CD, OT_BK_9_CD,"S");
        setData(this.OT_BK_9_CNT, OT_BK_9_CNT,"N");
        setData(this.OT_BK_9_AMT, OT_BK_9_AMT,"N");
        setData(this.OT_BK_9_TP, OT_BK_9_TP,"S");
    }

    /**
     * 타행은행10 은행코드
     *
     * @param OT_BK_10_CD
     */
    public void setOT_BK_10_CD(String OT_BK_10_CD) {
        setData(this.OT_BK_10_CD, OT_BK_10_CD,"S");
    }

    /**
     * 타행은행10 상환 건수
     *
     * @param OT_BK_10_CNT
     */
    public void setOT_BK_10_CNT(String OT_BK_10_CNT) {
        setData(this.OT_BK_10_CNT, OT_BK_10_CNT,"N");
    }

    /**
     * 타행은행10 상환 합산 금액
     *
     * @param OT_BK_10_AMT
     */
    public void setOT_BK_10_AMT(String OT_BK_10_AMT) {
        setData(this.OT_BK_10_AMT, OT_BK_10_AMT,"N");
    }

    /**
     * 타행은행10 입금구분
     *
     * @param OT_BK_10_TP
     */
    public void setOT_BK_10_TP(String OT_BK_10_TP) {
        setData(this.OT_BK_10_TP, OT_BK_10_TP,"S");
    }

    public void setOT_BK_10(String OT_BK_10_CD, String OT_BK_10_CNT, String OT_BK_10_AMT, String OT_BK_10_TP) {
        setData(this.OT_BK_10_CD, OT_BK_10_CD,"S");
        setData(this.OT_BK_10_CNT, OT_BK_10_CNT,"N");
        setData(this.OT_BK_10_AMT, OT_BK_10_AMT,"N");
        setData(this.OT_BK_10_TP, OT_BK_10_TP,"S");
    }

    /**
     * 예비
     *
     * @param FILLER
     */
    public void setFILLER(String FILLER) {
        setData(this.FILLER, FILLER,"S");
    }

}
