/**
 * 여신부 상환 신청 지금 결과 통지
 */
package com.bankle.common.wooriApi.socket.woori.socketData;

import java.io.IOException;
import java.io.InputStream;

public class A9X0 extends GetSetData {

	byte[] TR_LN         = new byte[4];  // 전문길이:총길이(504)에서 전문길이(4)를 뺀 길이(500) 으로 고정 
	byte[] TR_CD         = new byte[4];  // 전문종별코드 
	byte[] TR_TP_CD      = new byte[3];  // 거래구분코드 
	byte[] LO_NO         = new byte[13]; // 관리번호
	byte[] TR_SQ         = new byte[14]; // 식별번호
	byte[] REQ_DTTM      = new byte[14]; // 송신일자
	byte[] RES_DTTM      = new byte[14]; // 수신일자
	byte[] RES_CD        = new byte[3];  // 응답코드
	byte[] APPROVAL_NUM  = new byte[11]; // 여신승인신청번호
	byte[] PROC_DVSN     = new byte[1];  // 업무구분 [  1. 매수인 지분정보(S510) 2.접수정보(S700) ]
	byte[] JOINT_NAME_CD = new byte[1];  // 공동명의 여부 [  1. 단독명의 2.공동명의 ]
	byte[] BUYER_NUM     = new byte[1];  // 매수인 수
	byte[] IDENTIFIER_1  = new byte[16]; // 매수인1 - 식별자
	byte[] NAME_1        = new byte[30]; // 매수인1 - 성명
	byte[] DENOMINATOR_1 = new byte[5];  // 매수인1 - 지분율 분모
	byte[] NUMERATOR_1   = new byte[5];  // 매수인1 - 지분율 분자
	byte[] NUMBER_1      = new byte[15]; // 매수인1 - 이전 접수번호
	byte[] IDENTIFIER_2  = new byte[16]; // 매수인2 - 식별자
	byte[] NAME_2        = new byte[30]; // 매수인2 - 성명
	byte[] DENOMINATOR_2 = new byte[5];  // 매수인2 - 지분율 분모
	byte[] NUMERATOR_2   = new byte[5];  // 매수인2 - 지분율 분자
	byte[] NUMBER_2      = new byte[15]; // 매수인2 - 이전 접수번호
	byte[] IDENTIFIER_3  = new byte[16]; // 매수인3 - 식별자
	byte[] NAME_3        = new byte[30]; // 매수인3 - 성명
	byte[] DENOMINATOR_3 = new byte[5];  // 매수인3 - 지분율 분모
	byte[] NUMERATOR_3   = new byte[5];  // 매수인3 - 지분율 분자
	byte[] NUMBER_3      = new byte[15]; // 매수인3 - 이전 접수번호
	byte[] AUTHOR_ID     = new byte[20]; // 등기신청서 작성ID
	byte[] DOC_CRT_NUM   = new byte[20]; // 등기신청서 작성번호
	byte[] BUY_ADDR_CHG  = new byte[1];  // 매수인주소변경 [ 1.변동없음 2.변동발생 ]
	byte[] FILLER        = new byte[167];//공란

	public A9X0(){
		
		//default 값 셋팅
		setData(this.TR_LN, "0500");
        setData(this.TR_CD, "");
        setData(this.TR_TP_CD, "");
        setData(this.LO_NO, "");
        setData(this.TR_SQ, "");
        setData(this.REQ_DTTM, "");
        setData(this.RES_DTTM, "");
        setData(this.RES_CD, "");
        setData(this.APPROVAL_NUM, "");
        setData(this.PROC_DVSN, "");
        setData(this.JOINT_NAME_CD, "");
        setData(this.BUYER_NUM, "");
        setData(this.IDENTIFIER_1, "");
        setData(this.NAME_1, "");
        setData(this.DENOMINATOR_1, "");
        setData(this.NUMERATOR_1, "");
        setData(this.NUMBER_1, "");
        setData(this.IDENTIFIER_2, "");
        setData(this.NAME_2, "");
        setData(this.DENOMINATOR_2, "");
        setData(this.NUMERATOR_2, "");
        setData(this.NUMBER_2, "");
        setData(this.IDENTIFIER_3, "");
        setData(this.NAME_3, "");
        setData(this.DENOMINATOR_3, "");
        setData(this.NUMERATOR_3, "");
        setData(this.NUMBER_3, "");
        setData(this.AUTHOR_ID, "");
        setData(this.DOC_CRT_NUM, "");
        setData(this.BUY_ADDR_CHG, "");
        
        setData(this.FILLER, "");                                                                                                                                                   
	}                                                                                                                                                                              
                                                                                                                                                                                   
	public String print() {
	    
	    StringBuffer sb = new StringBuffer();
	    
	    String name_1 = "";
	    String name_2 = "";
	    String name_3 = "";
	    
	    try {
	    	 name_1 = new String(NAME_1, "MS949");		    
	    	 name_2 = new String(NAME_2, "MS949");
	    	 name_3 = new String(NAME_3, "MS949");

        } catch (Exception Ex) {
            Ex.printStackTrace();
        }
        	    
        sb.append("TR_CD : "           + getData(TR_CD          ) + "\tSize : " + TR_CD.length           + "\n");
        sb.append("TR_TP_CD : "        + getData(TR_TP_CD       ) + "\tSize : " + TR_TP_CD.length        + "\n");
        sb.append("LO_NO : "           + getData(LO_NO          ) + "\tSize : " + LO_NO.length           + "\n");
        sb.append("TR_SQ : "           + getData(TR_SQ          ) + "\tSize : " + TR_SQ.length           + "\n");
        sb.append("REQ_DTTM : "        + getData(REQ_DTTM       ) + "\tSize : " + REQ_DTTM.length        + "\n");
        sb.append("RES_DTTM : "        + getData(RES_DTTM       ) + "\tSize : " + RES_DTTM.length        + "\n");
        sb.append("RES_CD : "          + getData(RES_CD         ) + "\tSize : " + RES_CD.length          + "\n");
        sb.append("APPROVAL_NUM : "    + getData(APPROVAL_NUM   ) + "\tSize : " + APPROVAL_NUM.length    + "\n");
        sb.append("PROC_DVSN : "       + getData(PROC_DVSN      ) + "\tSize : " + PROC_DVSN.length       + "\n");
        sb.append("JOINT_NAME_CD : "   + getData(JOINT_NAME_CD  ) + "\tSize : " + JOINT_NAME_CD.length   + "\n");
        sb.append("BUYER_NUM : "       + getData(BUYER_NUM      ) + "\tSize : " + BUYER_NUM.length       + "\n");
        sb.append("IDENTIFIER_1 : "    + getData(IDENTIFIER_1   ) + "\tSize : " + IDENTIFIER_1.length    + "\n");
        sb.append("NAME_1 : "          + name_1                   + "\tSize : " + NAME_1.length          + "\n");
        sb.append("DENOMINATOR_1 : "   + getData(DENOMINATOR_1  ) + "\tSize : " + DENOMINATOR_1.length   + "\n");
        sb.append("NUMERATOR_1 : "     + getData(NUMERATOR_1    ) + "\tSize : " + NUMERATOR_1.length     + "\n");
       	sb.append("NUMBER_1 : "        + getData(NUMBER_1       ) + "\tSize : " + NUMBER_1.length        + "\n");
        sb.append("IDENTIFIER_2 : "    + getData(IDENTIFIER_2   ) + "\tSize : " + IDENTIFIER_2.length    + "\n");
        sb.append("NAME_2 : "          + name_2                   + "\tSize : " + NAME_2.length          + "\n");
        sb.append("DENOMINATOR_2 : "   + getData(DENOMINATOR_2  ) + "\tSize : " + DENOMINATOR_2.length   + "\n");
        sb.append("NUMERATOR_2 : "     + getData(NUMERATOR_2    ) + "\tSize : " + NUMERATOR_2.length     + "\n");
        sb.append("NUMBER_2 : "        + getData(NUMBER_2       ) + "\tSize : " + NUMBER_2.length        + "\n");
        sb.append("IDENTIFIER_3 : "    + getData(IDENTIFIER_3   ) + "\tSize : " + IDENTIFIER_3.length    + "\n");
        sb.append("NAME_3 : "          + name_3                   + "\tSize : " + NAME_3.length          + "\n");
        sb.append("DENOMINATOR_3 : "   + getData(DENOMINATOR_3  ) + "\tSize : " + DENOMINATOR_3.length   + "\n");
        sb.append("NUMERATOR_3 : "     + getData(NUMERATOR_3    ) + "\tSize : " + NUMERATOR_3.length     + "\n");
        sb.append("NUMBER_3 : "        + getData(NUMBER_3       ) + "\tSize : " + NUMBER_3.length        + "\n");
        sb.append("AUTHOR_ID : "       + getData(AUTHOR_ID      ) + "\tSize : " + AUTHOR_ID.length       + "\n");
        sb.append("DOC_CRT_NUM : "     + getData(DOC_CRT_NUM    ) + "\tSize : " + DOC_CRT_NUM.length     + "\n");
        sb.append("BUY_ADDR_CHG : "    + getData(BUY_ADDR_CHG   ) + "\tSize : " + BUY_ADDR_CHG.length    + "\n");
        sb.append("FILLER : "          + getData(FILLER         ) + "\tSize : " + FILLER.length          + "\n");                       
                
        return sb.toString();
    }                                                                                                                                                                            
                                                                                                                                                                                 
    public String dataToString() {                            
	    String name_1 = "";
	    String name_2 = "";
	    String name_3 = "";

	    try {
	    	 name_1 = new String(NAME_1, "MS949");		    
	    	 name_2 = new String(NAME_2, "MS949");
	    	 name_3 = new String(NAME_3, "MS949");

        } catch (Exception Ex) {
            Ex.printStackTrace();
        }

        String rtnValue = getData(TR_LN) + getData(TR_CD) + getData(TR_TP_CD) + getData(LO_NO) + getData(TR_SQ) + getData(REQ_DTTM) + getData(RES_DTTM) + getData(RES_CD) 
                              + getData(APPROVAL_NUM) + getData(PROC_DVSN) + getData(JOINT_NAME_CD) + getData(BUYER_NUM) 
                              + getData(IDENTIFIER_1) + name_1 + getData(DENOMINATOR_1) + getData(NUMERATOR_1) + getData(NUMBER_1)
                              + getData(IDENTIFIER_2) + name_2 + getData(DENOMINATOR_2) + getData(NUMERATOR_2) + getData(NUMBER_2)
                              + getData(IDENTIFIER_3) + name_3 + getData(DENOMINATOR_3) + getData(NUMERATOR_3) + getData(NUMBER_3)
                              + getData(AUTHOR_ID)    + getData(DOC_CRT_NUM) + getData(BUY_ADDR_CHG)
                              + getData(FILLER);
        return rtnValue;
    }                                                                                                                                                                       

    public void readDataExternal(InputStream stream) {                                                                                                                      
        try {                                                                                                                                                                    
            stream.read(TR_LN,         0, TR_LN.length);
            stream.read(TR_CD,         0, TR_CD.length);
            stream.read(TR_TP_CD,      0, TR_TP_CD.length);
            stream.read(LO_NO,         0, LO_NO.length);
            stream.read(TR_SQ,         0, TR_SQ.length);
            stream.read(REQ_DTTM,      0, REQ_DTTM.length);
            stream.read(RES_DTTM,      0, RES_DTTM.length);
            stream.read(RES_CD,        0, RES_CD.length);
            stream.read(APPROVAL_NUM,  0, APPROVAL_NUM.length);
            stream.read(PROC_DVSN,     0, PROC_DVSN.length);
            stream.read(JOINT_NAME_CD, 0, JOINT_NAME_CD.length);
            stream.read(BUYER_NUM,     0, BUYER_NUM.length);
            stream.read(IDENTIFIER_1,  0, IDENTIFIER_1.length);
            stream.read(NAME_1,        0, NAME_1.length);
            stream.read(DENOMINATOR_1, 0, DENOMINATOR_1.length);
            stream.read(NUMERATOR_1,   0, NUMERATOR_1.length);
            stream.read(NUMBER_1,      0, NUMBER_1.length);
            stream.read(IDENTIFIER_2,  0, IDENTIFIER_2.length);
            stream.read(NAME_2,        0, NAME_2.length);
            stream.read(DENOMINATOR_2, 0, DENOMINATOR_2.length);
            stream.read(NUMERATOR_2,   0, NUMERATOR_2.length);
            stream.read(NUMBER_2,      0, NUMBER_2.length);
            stream.read(IDENTIFIER_3,  0, IDENTIFIER_3.length);
            stream.read(NAME_3,        0, NAME_3.length);
            stream.read(DENOMINATOR_3, 0, DENOMINATOR_3.length);
            stream.read(NUMERATOR_3,   0, NUMERATOR_3.length);
            stream.read(NUMBER_3,      0, NUMBER_3.length);
            stream.read(AUTHOR_ID,     0, AUTHOR_ID.length);
            stream.read(DOC_CRT_NUM,   0, DOC_CRT_NUM.length);
            stream.read(BUY_ADDR_CHG,  0, BUY_ADDR_CHG.length);
            stream.read(FILLER,        0, FILLER.length);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	//------------------------------------------------------------------
	// Get Data
	//------------------------------------------------------------------

    /**
     * 전문길이
     * @return
     */
	public String getTR_LN() {
		return getData(TR_LN);
	}
	/**
	 * 전문종별코드
	 * @return
	 */
	public String getTR_CD() {
		return getData(TR_CD);
	}
	/**
	 * 거래구분코드
	 * @return
	 */
	public String getTR_TP_CD() {
		return getData(TR_TP_CD);
	}
	/**
	 * 관리번호
	 * @return
	 */
	public String getLO_NO() {
		return getData(LO_NO);
	}
	/**
	 * 식별번호
	 * @return
	 */
	public String getTR_SQ() {
		return getData(TR_SQ);
	}
	/**
	 * 송신일자
	 * @return
	 */
	public String getREQ_DTTM() {
		return getData(REQ_DTTM);
	}
	/**
	 * 수신일자
	 * @return
	 */
	public String getRES_DTTM() {
		return getData(RES_DTTM);
	}
	/**
	 * 응답코드
	 * @return
	 */
	public String getRES_CD() {
		return getData(RES_CD);
	}
	/**
	 * 여신승인신청번호
	 * @return
	 */
	public String getAPPROVAL_NUM() {
		return getData(APPROVAL_NUM);
	}
	/**
	 * 업무구분
	 * @return
	 */
	public String getPROC_DVSN() {
		return getData(PROC_DVSN);
	}
	/**
	 * 공동명의 여부
	 * @return
	 */
	public String getJOINT_NAME_CD() {
		return getData(JOINT_NAME_CD);
	}
	/**
	 * 매수인 수
	 * @return
	 */
	public String getBUYER_NUM() {
		return getData(BUYER_NUM);
	}
	/**
	 * 매수인1 - 식별자
	 * @return
	 */
	public String getIDENTIFIER_1() {
		return getData(IDENTIFIER_1);
	}
	/**
	 * 매수인1 - 성명
	 * @return
	 */
	public String getNAME_1() {
		return getData(NAME_1);
	}
	/**
	 * 매수인1 - 지분율 분모
	 * @return
	 */
	public String getDENOMINATOR_1() {
		return getData(DENOMINATOR_1);
	}
	/**
	 * 매수인1 - 지분율 분자
	 * @return
	 */
	public String getNUMERATOR_1() {
		return getData(NUMERATOR_1);
	}
	/**
	 * 매수인1 - 이전 접수번호
	 * @return
	 */
	public String getNUMBER_1() {
		return getData(NUMBER_1);
	}
	/**
	 * 매수인2 - 식별자
	 * @return
	 */
	public String getIDENTIFIER_2() {
		return getData(IDENTIFIER_2);
	}
	/**
	 * 매수인2 - 성명
	 * @return
	 */
	public String getNAME_2() {
		return getData(NAME_2);
	}
	/**
	 * 매수인2 - 지분율 분모
	 * @return
	 */
	public String getDENOMINATOR_2() {
		return getData(DENOMINATOR_2);
	}
	/**
	 * 매수인2 - 지분율 분자
	 * @return
	 */
	public String getNUMERATOR_2() {
		return getData(NUMERATOR_2);
	}
	/**
	 * 매수인2 - 이전 접수번호
	 * @return
	 */
	public String getNUMBER_2() {
		return getData(NUMBER_2);
	}
	/**
	 * 매수인3 - 식별자
	 * @return
	 */
	public String getIDENTIFIER_3() {
		return getData(IDENTIFIER_3);
	}
	/**
	 * 매수인3 - 성명
	 * @return
	 */
	public String getNAME_3() {
		return getData(NAME_3);
	}
	/**
	 * 매수인3 - 지분율 분모
	 * @return
	 */
	public String getDENOMINATOR_3() {
		return getData(DENOMINATOR_3);
	}
	/**
	 * 매수인3 - 지분율 분자
	 * @return
	 */
	public String getNUMERATOR_3() {
		return getData(NUMERATOR_3);
	}
	/**
	 * 매수인3 - 이전 접수번호
	 * @return
	 */
	public String getNUMBER_3() {
		return getData(NUMBER_3);
	}
	/**
	 * 이전등기 신청서 작성 ID
	 * @return
	 */
	public String getAUTHOR_ID() {
		return getData(AUTHOR_ID);
	}
	/**
	 * 이전등기 신청서 문서번호
	 * @return
	 */
	public String getDOC_CRT_NUM() {
		return getData(DOC_CRT_NUM);
	}
	/**
	 * 매수인 주소변경 여부
	 * @return
	 */
	public String getBUY_ADDR_CHG() {
		return getData(BUY_ADDR_CHG);
	}
	/**
	 * 예비
	 * @return
	 */
	public String getFILLER() {
		return getData(FILLER);
	}
	//------------------------------------------------------------------
	// Set Data
	//------------------------------------------------------------------

	/**
	 * 전문길이
	 * @param TR_LN
	 */
	public void setTR_LN(String TR_LN) {
		setData(this.TR_LN, TR_LN,"S");
	}



	/**
	 * 전문종별코드
	 * @param TR_CD
	 */
	public void setTR_CD(String TR_CD) {
		setData(this.TR_CD, TR_CD,"S");
	}



	/**
	 * 거래구분코드
	 * @param TR_TP_CD
	 */
	public void setTR_TP_CD(String TR_TP_CD) {
		setData(this.TR_TP_CD, TR_TP_CD,"S");
	}



	/**
	 * 관리번호
	 * @param LO_NO
	 */
	public void setLO_NO(String LO_NO) {
		setData(this.LO_NO, LO_NO,"S");
	}



	/**
	 * 식별번호
	 * @param TR_SQ
	 */
	public void setTR_SQ(String TR_SQ) {
		setData(this.TR_SQ, TR_SQ,"S");
	}
	


	/**
	 * 송신일자
	 * @param REQ_DTTM
	 */
	public void setREQ_DTTM(String REQ_DTTM) {
		setData(this.REQ_DTTM, REQ_DTTM,"S");
	}



	/**
	 * 수신일자
	 * @param RES_DTTM
	 */
	public void setRES_DTTM(String RES_DTTM) {
		setData(this.RES_DTTM, RES_DTTM,"S");
	}



	/**
	 * 응답코드
	 * @param RES_CD
	 */
	public void setRES_CD(String RES_CD) {
		setData(this.RES_CD, RES_CD,"S");
	}



	/**
	 * 여신승인신청번호
	 * @param APPROVAL_NUM
	 */
	public void setAPPROVAL_NUM(String APPROVAL_NUM) {
		setData(this.APPROVAL_NUM, APPROVAL_NUM,"S");
	}



	/**
	 * 업무구분
	 * @param PROC_DVSN
	 */
	public void setPROC_DVSN(String PROC_DVSN) {
		setData(this.PROC_DVSN, PROC_DVSN,"S");
	}



	/**
	 * 공동명의 여부
	 * @param JOINT_NAME_CD
	 */
	public void setJOINT_NAME_CD(String JOINT_NAME_CD) {
		setData(this.JOINT_NAME_CD, JOINT_NAME_CD,"S");
	}



	/**
	 * 매수인 수
	 * @param BUYER_NUM
	 */
	public void setBUYER_NUM(String BUYER_NUM) {
		setData(this.BUYER_NUM, BUYER_NUM,"N");
	}



	/**
	 * 매수인1 - 식별자
	 * @param IDENTIFIER_1
	 */
	public void setIDENTIFIER_1(String IDENTIFIER_1) {
		setData(this.IDENTIFIER_1, IDENTIFIER_1,"S");
	}



	/**
	 * 매수인1 - 성명
	 * @param NAME_1
	 */
	public void setNAME_1(String NAME_1) {
		setData(this.NAME_1, NAME_1,"K");
	}



	/**
	 * 매수인1 - 지분율 분모
	 * @param DENOMINATOR_1
	 */
	public void setDENOMINATOR_1(String DENOMINATOR_1) {
		setData(this.DENOMINATOR_1, DENOMINATOR_1,"N");
	}



	/**
	 * 매수인1 - 지분율 분자
	 * @param NUMERATOR_1
	 */
	public void setNUMERATOR_1(String NUMERATOR_1) {
		setData(this.NUMERATOR_1, NUMERATOR_1,"N");
	}



	/**
	 * 매수인1 - 이전 접수번호
	 * @param NUMBER_1
	 */
	public void setNUMBER_1(String NUMBER_1) {
		setData(this.NUMBER_1, NUMBER_1,"S");
	}



	/**
	 * 매수인2 - 식별자
	 * @param IDENTIFIER_2
	 */
	public void setIDENTIFIER_2(String IDENTIFIER_2) {
		setData(this.IDENTIFIER_2, IDENTIFIER_2,"S");
	}



	/**
	 * 매수인2 - 성명
	 * @param NAME_2
	 */
	public void setNAME_2(String NAME_2) {
		setData(this.NAME_2, NAME_2,"K");
	}



	/**
	 * 매수인2 - 지분율 분모
	 * @param DENOMINATOR_2
	 */
	public void setDENOMINATOR_2(String DENOMINATOR_2) {
		setData(this.DENOMINATOR_2, DENOMINATOR_2,"N");
	}



	/**
	 * 매수인2 - 지분율 분자
	 * @param NUMERATOR_2
	 */
	public void setNUMERATOR_2(String NUMERATOR_2) {
		setData(this.NUMERATOR_2, NUMERATOR_2,"N");
	}



	/**
	 * 매수인2 - 이전 접수번호
	 * @param NUMBER_2
	 */
	public void setNUMBER_2(String NUMBER_2) {
		setData(this.NUMBER_2, NUMBER_2,"S");
	}



	/**
	 * 매수인3 - 식별자
	 * @param IDENTIFIER_3
	 */
	public void setIDENTIFIER_3(String IDENTIFIER_3) {
		setData(this.IDENTIFIER_3, IDENTIFIER_3,"S");
	}



	/**
	 * 매수인3 - 성명
	 * @param NAME_3
	 */
	public void setNAME_3(String NAME_3) {
		setData(this.NAME_3, NAME_3,"K");
	}



	/**
	 * 매수인3 - 지분율 분모
	 * @param DENOMINATOR_3
	 */
	public void setDENOMINATOR_3(String DENOMINATOR_3) {
		setData(this.DENOMINATOR_3, DENOMINATOR_3,"N");
	}



	/**
	 * 매수인3 - 지분율 분자
	 * @param NUMERATOR_3
	 */
	public void setNUMERATOR_3(String NUMERATOR_3) {
		setData(this.NUMERATOR_3, NUMERATOR_3,"N");
	}



	/**
	 * 매수인3 - 이전 접수번호
	 * @param NUMBER_3
	 */
	public void setNUMBER_3(String NUMBER_3) {
		setData(this.NUMBER_3, NUMBER_3,"S");
	}



	/**
	 * 이전등기 신청서 작성 ID
	 * @param IDENTIFIER_4
	 */
	public void setAUTHOR_ID(String AUTHOR_ID) {
		setData(this.AUTHOR_ID, AUTHOR_ID,"S");
	}



	/**
	 * 이전등기 신청서 문서번호
	 * @param NAME_4
	 */
	public void setDOC_CRT_NUM(String DOC_CRT_NUM) {
		setData(this.DOC_CRT_NUM, DOC_CRT_NUM,"S");
	}



	/**
	 * 매수인 주소변경 여부
	 * @param BUY_ADDR_CHG
	 */
	public void setBUY_ADDR_CHG(String BUY_ADDR_CHG) {
		setData(this.BUY_ADDR_CHG, BUY_ADDR_CHG,"S");
	}



	/**
	 * 예비
	 * @param FILLER
	 */
	public void setFILLER(String FILLER) {
		setData(this.FILLER, FILLER,"S");
	}

}

