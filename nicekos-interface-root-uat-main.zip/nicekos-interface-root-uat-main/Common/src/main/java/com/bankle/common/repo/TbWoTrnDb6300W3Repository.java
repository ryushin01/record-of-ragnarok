package com.bankle.common.repo;

import com.bankle.common.entity.TbWoTrnDb6300W3;
import com.bankle.common.entity.TbWoTrnDb6300W3Id;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TbWoTrnDb6300W3Repository extends JpaRepository<TbWoTrnDb6300W3, TbWoTrnDb6300W3Id> {
    List<TbWoTrnDb6300W3> findByIdLoanNoOrderByIdChgDtm(String loanNo);
}