package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoResearchMaster}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoResearchMasterDto implements Serializable {
    @Size(max = 20)
    String loanNo;
    BigDecimal faBnkFxcltRgstrRnk;
    @Size(max = 10)
    String faDbtrWdngPlnYn;
    BigDecimal faBnkFxcltBndMaxAmt;
    @Size(max = 100)
    String faSpusNm;
    @Size(max = 100)
    String faWdngPlnDt;
    @Size(max = 10)
    String faRrcpCnfmYn;
    @Size(max = 1)
    String faBnkFxcltEstbsFnYn;
    @Size(max = 1)
    String faBnkFxcltRnkMthYn;
    @Size(max = 1)
    String faBnkFxcltEstbsNoMthYn;
    @Size(max = 8)
    String faBnkFxcltRgstrAcptDt;
    @Size(max = 8)
    String faOwnOwnshMvRgstrAcptDt;
    @Size(max = 4)
    String faIsrnGbCd;
    @Size(max = 14)
    String faRgstrUnqNo1;
    @Size(max = 14)
    String faRgstrUnqNo2;
    @Size(max = 14)
    String faRgstrUnqNo3;
    @Size(max = 14)
    String faRgstrUnqNo4;
    @Size(max = 14)
    String faRgstrUnqNo5;
    @Size(max = 50)
    String faOwnNm1;
    @Size(max = 50)
    String faOwnNm2;
    @Size(max = 50)
    String faOwnNm3;
    @Size(max = 13)
    String faOwnBirthDt1;
    @Size(max = 13)
    String faOwnBirthDt2;
    @Size(max = 13)
    String faOwnBirthDt3;
    @Size(max = 150)
    String faRmkB2;
    @Size(max = 100)
    String faSbmtDocLst;
    @Size(max = 1)
    String faDbtrRrcpSbmtYn;
    @Size(max = 1)
    String faDbtrFrcSbmtYn;
    @Size(max = 1)
    String faRrcpDbtrSlfRgstYn;
    @Size(max = 1)
    String faRrcpSpusRgstYn;
    @Size(max = 1)
    String faFrcSpusCnfmYn;
    @Size(max = 1)
    String faDbtrTgrcSbmtYn;
    @Size(max = 1)
    String faTgrcDbtrSlfMvinYn;
    @Size(max = 1)
    String faTgrcDbtrOtsdSprtHshldEane;
    @Size(max = 1)
    String faExedtMvMvinEane;
    @Size(max = 1)
    String faBnkDbtrTgrcMthYn;
    @Size(max = 14)
    String faMvinHshldRdDtm;
    @Size(max = 200)
    String faMvhrTrgtThngAddr;
    @Size(max = 100)
    String faFmMvhrdtm;
    @Size(max = 10)
    String faMvhrHshldrRno;
    @Size(max = 100)
    String faPrgsDt;
    @Size(max = 100)
    String faMvhrHshldrNmMvinDt;
    BigDecimal dbObjtEbnkRgstrRnk;
    @Size(max = 10)
    String dbWdngPlnYn;
    @Size(max = 10)
    String dbWdngPlnDt;
    BigDecimal dbObjtEbnkBndMaxAmt;
    @Size(max = 10)
    String dbRrcpChrgTrgtYn;
    @Size(max = 10)
    String dbRvsnCntrctChrgTrgtYn;
    Integer dbMggFnlOdprtAmt;
    Integer dbTrolFnlOdprtAmt;
    @Size(max = 10)
    String dbHshldrCnddtYn;
    @Size(max = 10)
    String dbUnmrdHshldr25agLstnYn;
    @Size(max = 10)
    String dbFndYn;
    @Size(max = 4)
    String dbGrntAgncCd;
    @Size(max = 10)
    String dbFndLesDsc;
    @Size(max = 10)
    String dbBnkLesDsc;
    @Size(max = 100)
    String dbCndtlCnts;
    @Size(max = 1)
    String dbLndAmtJstPmntYn;
    @Size(max = 1)
    String dbRcptJstChrgyn;
    @Size(max = 1)
    String dbRgstracptThdyYn;
    @Size(max = 50)
    String dbRgstrErsrAcptNo;
    @Size(max = 1)
    String dbOdprtJstYn;
    @Size(max = 1)
    String dbCndtlExecYn;
    @Size(max = 1)
    String dbUnuslFctExstYn1;
    @Size(max = 1)
    String dbUnuslThngYn;
    String dbStndRmk;
    @Size(max = 784)
    String dbRsrvItmB;
    @Size(max = 1)
    String dbDbtrSlfMvinYn;
    @Size(max = 1)
    String dbMvinAddrOptmYn;
    @Size(max = 1)
    String dbMvinDtOptmYn;
    @Size(max = 1)
    String dbSpusMvinyn;
    @Size(max = 1)
    String dbDbtrOtsdMvinOptmYn;
    @Size(max = 1)
    String dbUnuslFctExstYn2;
    String dbTtlRmk;
    String dbIsrnScrtNo1;
    String dbIsrnScrtNo2;
    String dbIsrnScrtNo3;
    @Size(max = 8)
    String dbLshdrMvinDt;
    @Size(max = 4)
    String dbIsrnGbCd;
    @Size(max = 14)
    String dbRgstrUnqNo1;
    @Size(max = 14)
    String dbRgstrUnqNo2;
    @Size(max = 14)
    String dbRgstrUnqNo3;
    @Size(max = 255)
    String dbRmkB4;
    @NotNull
    LocalDateTime crtDtm;
    @NotNull
    @Size(max = 12)
    String crtMembNo;
    @NotNull
    LocalDateTime chgDtm;
    @NotNull
    @Size(max = 12)
    String chgMembNo;
}