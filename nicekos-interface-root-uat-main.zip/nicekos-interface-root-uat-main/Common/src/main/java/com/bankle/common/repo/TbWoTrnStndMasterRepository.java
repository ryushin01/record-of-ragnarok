package com.bankle.common.repo;

import com.bankle.common.entity.TbWoTrnStndMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TbWoTrnStndMasterRepository extends JpaRepository<TbWoTrnStndMaster, String> {

    Optional<TbWoTrnStndMaster> findById(String id);

    List<TbWoTrnStndMaster> findByApprovalNum(String ApprovalNum);

    Optional<TbWoTrnStndMaster> findBySeq(String seq);
}