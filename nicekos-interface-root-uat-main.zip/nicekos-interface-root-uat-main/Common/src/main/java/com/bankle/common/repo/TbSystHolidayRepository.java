package com.bankle.common.repo;

import com.bankle.common.entity.TbSystHoliday;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface TbSystHolidayRepository extends JpaRepository<TbSystHoliday, String> {

    List<TbSystHoliday> findAllByDtmStartingWith(String year);

    List<TbSystHoliday> findByHolYnAndDtmGreaterThanOrderByDtmAsc(String holYn, String date);


    //영업일을 기준으로 현재일-x 일을 조회한다.
    @Query(value = " SELECT DATE_FORMAT(MIN(DTM), '%Y%m%d') \n" +
            "        FROM (SELECT DTM \n" +
            "              FROM TB_SYST_HOLIDAY \n" +
            "              WHERE DTM <= CURDATE() \n" +
            "              AND HOL_YN  = 'N' \n" +
            "              ORDER BY DTM DESC \n" +
            "        LIMIT :days ) A " , nativeQuery = true)
    String getBscDt(@Param("days") int days);

    Optional<TbSystHoliday> findByDtm(String dtm);

}