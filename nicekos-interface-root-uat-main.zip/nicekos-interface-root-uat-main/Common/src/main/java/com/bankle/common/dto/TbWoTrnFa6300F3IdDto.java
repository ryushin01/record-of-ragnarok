package com.bankle.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * DTO for {@link com.bankle.common.entity.TbWoTrnFa6300F3Id}
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TbWoTrnFa6300F3IdDto implements Serializable {
    @NotNull
    @Size(max = 20)
    String loanNo;
    @NotNull
    LocalDateTime chgDtm;
}