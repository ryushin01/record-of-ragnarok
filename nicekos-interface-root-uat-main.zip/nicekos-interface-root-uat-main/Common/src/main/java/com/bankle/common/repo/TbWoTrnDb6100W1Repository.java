package com.bankle.common.repo;

import com.bankle.common.entity.TbWoTrnDb6100W1;
import com.bankle.common.entity.TbWoTrnDb6100W1Id;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TbWoTrnDb6100W1Repository extends JpaRepository<TbWoTrnDb6100W1, TbWoTrnDb6100W1Id> {

    Optional<TbWoTrnDb6100W1> findByIdLoanNo(String loanNo);

    Optional<TbWoTrnDb6100W1> findTop1ByIdLoanNo(String loanNo);
}