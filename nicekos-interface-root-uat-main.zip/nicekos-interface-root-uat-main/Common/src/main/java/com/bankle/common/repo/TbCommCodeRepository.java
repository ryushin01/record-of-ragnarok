package com.bankle.common.repo;

import com.bankle.common.entity.TbCommCode;
import org.apache.ibatis.annotations.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface TbCommCodeRepository extends JpaRepository<TbCommCode, TbCommCode.PK> {

    // like 검색
    List<TbCommCode> findByCodeLike(String code);

    Optional<TbCommCode> findByGrpCdAndCode(String GrpCd, String code);
    List<TbCommCode> findByGrpCdAndCodeOrderByEtc2Asc(String GrpCd, String code);

    List<TbCommCode> findByGrpCdAndEtc2NotNullOrderByEtc2Asc(String GrpCd);

    List<TbCommCode> findAllByGrpCdAndCode(String GrpCd, String code);

    List<TbCommCode> findByGrpCdAndCodeIn(String GrpCd, List<String> code);

    Optional<TbCommCode> findTop1ByGrpCdAndCodeAndUseYn(String GrpCd, String code, String useYn);

    Optional<TbCommCode> findTop1ByGrpCdAndNumAndUseYn(String GrpCd, BigDecimal num, String useYn);

    List<TbCommCode> findAllByGrpCdAndUseYnOrderByNum(String GrpCd, String useYn);

    List<TbCommCode> findAllByGrpCdInAndUseYn(List<String> GrpCd, String useYn);

    Optional<TbCommCode> findByGrpCdAndNum(String GrpCd, BigDecimal num);

    Optional<TbCommCode> findByGrpCdAndCodeAndUseYn(String grpCd, String code, String useYn);

    Optional<Boolean> existsByGrpCdAndCodeAndUseYn(String grpCd, String code, String delYn);

    List<TbCommCode> findByGrpCdAndUseYn(String grpCd, String delYn);

    List<TbCommCode> findByGrpCd(String grpCd);
    List<TbCommCode> findByGrpCdAndNumNotOrderByNumAsc(String grpCd, BigDecimal num);

    List<TbCommCode> findByGrpCdIn(List<String> grpCd);

    List<TbCommCode> findByUseYnIn(List<String> useYn);

    @Query("SELECT MAX(c.num) FROM TbCommCode c WHERE c.grpCd = :grpCd")
    Long findMaxNumByGrpCd(@Param("grpCd") String grpCd);

    Optional<TbCommCode> findByCode(String code);

    List<TbCommCode> findByGrpCdAndEtc3AndEtc3IsNotNull(String imageBiz, String proc);

    Optional<TbCommCode> findTop1ByGrpCdOrderByCodeDesc(String GrpCd);
}
