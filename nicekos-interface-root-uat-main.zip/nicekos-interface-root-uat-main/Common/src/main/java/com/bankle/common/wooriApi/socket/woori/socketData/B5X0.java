/**
 * 수신부(BPR) 상환 영수증 전송
 */
package com.bankle.common.wooriApi.socket.woori.socketData;

import java.io.IOException;
import java.io.InputStream;

public class B5X0 extends GetSetData {

	byte[] TR_LN   = new byte[4];   	//전문길이:총길이(504)에서 전문길이(4)를 뺀 길이(500) 으로 고정 
	byte[] TR_CD = new byte[4];   		//전문종별코드 
	byte[] TR_TP_CD  = new byte[3];   	//거래구분코드 
	byte[] LO_NO  = new byte[13];   	//관리번호
	byte[] TR_SQ  = new byte[14];   	//식별번호
	byte[] REQ_DTTM  = new byte[14];  		//송신일자
	byte[] RES_DTTM  = new byte[14];  		//수신일자
	byte[] RES_CD  = new byte[3];  		//응답코드
	byte[] APPROVAL_NUM  = new byte[11];   	//여신승인신청번호
	byte[] REPAY_TP = new byte[1];  		//상환구분(2:당행상환영수증 3:타행상환영수증)
	byte[] REPAY_BANK_CD = new byte[3];	//상환 은행코드
	byte[] REPAY_AMOUNT  = new byte[15];  		//상환 금액
	byte[] BILL_CNT  = new byte[2];  		//영수증 갯수
	byte[] BILL_CHECK_YN  = new byte[1];  		//상환 영수증 확인 여부
	byte[] BILL_IMG_FILE_NAME  = new byte[20];  		//상환 영수증 이미지 파일명
	byte[] IMG_KEY  = new byte[1];			//이미지 키
	
	byte[] FILLER  = new byte[360]; 	//공란

	public B5X0(){
		
		//default 값 셋팅
		setData(this.TR_LN, "0500");
        setData(this.TR_CD, "");
        setData(this.TR_TP_CD, "");
        setData(this.LO_NO, "");
        setData(this.TR_SQ, "");
        setData(this.REQ_DTTM, "");
        setData(this.RES_DTTM, "");
        setData(this.RES_CD, "");
        setData(this.APPROVAL_NUM, "");
        setData(this.REPAY_TP, "");
        setData(this.REPAY_BANK_CD, "");
        setDataNum(this.REPAY_AMOUNT, "");
        setDataNum(this.BILL_CNT, "");
        setData(this.BILL_CHECK_YN, "");
        setData(this.BILL_IMG_FILE_NAME, "");
        setData(this.IMG_KEY, "");
        
        setData(this.FILLER, "");                                                                                                                                                   
	}                                                                                                                                                                              
                                                                                                                                                                                   
    public String print() {

        StringBuffer sb = new StringBuffer();
        
        sb.append("TR_LN : "              + getData(TR_LN             ) + "\tSize : " + TR_LN.length             + "\n");
        sb.append("TR_CD : "              + getData(TR_CD             ) + "\tSize : " + TR_CD.length             + "\n");
        sb.append("TR_TP_CD : "           + getData(TR_TP_CD          ) + "\tSize : " + TR_TP_CD.length          + "\n");
        sb.append("LO_NO : "              + getData(LO_NO             ) + "\tSize : " + LO_NO.length             + "\n");
        sb.append("TR_SQ : "              + getData(TR_SQ             ) + "\tSize : " + TR_SQ.length             + "\n");
        sb.append("REQ_DTTM : "           + getData(REQ_DTTM          ) + "\tSize : " + REQ_DTTM.length          + "\n");
        sb.append("RES_DTTM : "           + getData(RES_DTTM          ) + "\tSize : " + RES_DTTM.length          + "\n");
        sb.append("RES_CD : "             + getData(RES_CD            ) + "\tSize : " + RES_CD.length            + "\n");
        sb.append("APPROVAL_NUM : "       + getData(APPROVAL_NUM      ) + "\tSize : " + APPROVAL_NUM.length      + "\n");
        sb.append("REPAY_TP : "           + getData(REPAY_TP          ) + "\tSize : " + REPAY_TP.length          + "\n");
        sb.append("REPAY_BANK_CD : "      + getData(REPAY_BANK_CD     ) + "\tSize : " + REPAY_BANK_CD.length     + "\n");
        sb.append("REPAY_AMOUNT : "       + getData(REPAY_AMOUNT      ) + "\tSize : " + REPAY_AMOUNT.length      + "\n");
        sb.append("BILL_CNT : "           + getData(BILL_CNT          ) + "\tSize : " + BILL_CNT.length          + "\n");
        sb.append("BILL_CHECK_YN : "      + getData(BILL_CHECK_YN     ) + "\tSize : " + BILL_CHECK_YN.length     + "\n");
        sb.append("BILL_IMG_FILE_NAME : " + getData(BILL_IMG_FILE_NAME) + "\tSize : " + BILL_IMG_FILE_NAME.length+ "\n");
        sb.append("IMG_KEY : "            + getData(IMG_KEY           ) + "\tSize : " + IMG_KEY.length           + "\n");
        sb.append("FILLER : "             + getData(FILLER            ) + "\tSize : " + FILLER.length            + "\n");   
        
        // System.out.println(sb.toString());

        return sb.toString();                                                                                                                                                    
    }                                                                                                                                                                            
                                                                                                                                                                                 
    public String dataToString() {         
    	return getData(TR_LN) + getData(TR_CD) + getData(TR_TP_CD) + getData(LO_NO) + getData(TR_SQ) + getData(REQ_DTTM) + getData(RES_DTTM) + getData(RES_CD)
        						+ getData(APPROVAL_NUM) + getData(REPAY_TP) + getData(REPAY_BANK_CD) + getData(REPAY_AMOUNT) + getData(BILL_CNT) + getData(BILL_CHECK_YN)
        						 + getData(BILL_IMG_FILE_NAME) + getData(IMG_KEY)
        						+ getData(FILLER);                                                                                                                          
    }                                                                                                                                                                       
                                                                                                                                                                            
    public void readDataExternal(InputStream stream) {                                                                                                                      
        try {                                                                                                                                                                    
            stream.read(TR_LN, 0, TR_LN.length);
            stream.read(TR_CD, 0, TR_CD.length);
            stream.read(TR_TP_CD, 0, TR_TP_CD.length);
            stream.read(LO_NO, 0, LO_NO.length);
            stream.read(TR_SQ, 0, TR_SQ.length);
            stream.read(REQ_DTTM, 0, REQ_DTTM.length);
            stream.read(RES_DTTM, 0, RES_DTTM.length);
            stream.read(RES_CD, 0, RES_CD.length);
            stream.read(APPROVAL_NUM, 0, APPROVAL_NUM.length);
            stream.read(REPAY_TP, 0, REPAY_TP.length);
            stream.read(REPAY_BANK_CD, 0, REPAY_BANK_CD.length);
            stream.read(REPAY_AMOUNT, 0, REPAY_AMOUNT.length);
            stream.read(BILL_CNT, 0, BILL_CNT.length);
            stream.read(BILL_CHECK_YN, 0, BILL_CHECK_YN.length);
            stream.read(BILL_IMG_FILE_NAME, 0, BILL_IMG_FILE_NAME.length);
            stream.read(IMG_KEY, 0, IMG_KEY.length);
            
            stream.read(FILLER, 0, FILLER.length);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	//------------------------------------------------------------------
	// Get Data
	//------------------------------------------------------------------

    /**
     * 전문길이
     * @return
     */
	public String getTR_LN() {
		return getData(TR_LN);
	}
	/**
	 * 전문종별코드
	 * @return
	 */
	public String getTR_CD() {
		return getData(TR_CD);
	}
	/**
	 * 거래구분코드
	 * @return
	 */
	public String getTR_TP_CD() {
		return getData(TR_TP_CD);
	}
	/**
	 * 관리번호
	 * @return
	 */
	public String getLO_NO() {
		return getData(LO_NO);
	}
	/**
	 * 식별번호
	 * @return
	 */
	public String getTR_SQ() {
		return getData(TR_SQ);
	}
	/**
	 * 송신일자
	 * @return
	 */
	public String getREQ_DTTM() {
		return getData(REQ_DTTM);
	}
	/**
	 * 수신일자
	 * @return
	 */
	public String getRES_DTTM() {
		return getData(RES_DTTM);
	}
	/**
	 * 응답코드
	 * @return
	 */
	public String getRES_CD() {
		return getData(RES_CD);
	}
	/**
	 * 여신승인신청번호
	 * @return
	 */
	public String getAPPROVAL_NUM() {
		return getData(APPROVAL_NUM);
	}
	/**
	 * 상환구분
	 * @return
	 */
	public String getREPAY_TP() {
		return getData(REPAY_TP);
	}
	/**
	 * 상환 은행코드
	 * @return
	 */
	public String getREPAY_BANK_CD() {
		return getData(REPAY_BANK_CD);
	}
	/**
	 * 상환 금액
	 * @return
	 */
	public String getREPAY_AMOUNT() {
		return getData(REPAY_AMOUNT);
	}
	/**
	 * 영수증 갯수
	 * @return
	 */
	public String getBILL_CNT() {
		return getData(BILL_CNT);
	}
	/**
	 * 상환 영수증 확인 여부
	 * @return
	 */
	public String getBILL_CHECK_YN() {
		return getData(BILL_CHECK_YN);
	}
	/**
	 * 상환 영수증 이미지 파일명
	 * @return
	 */
	public String getBILL_IMG_FILE_NAME() {
		return getData(BILL_IMG_FILE_NAME);
	}
	/**
	 * 이미지 키
	 * @return
	 */
	public String getIMG_KEY() {
		return getData(IMG_KEY);
	}
	/**
	 * 예비
	 * @return
	 */
	public String getFILLER() {
		return getData(FILLER);
	}
	//------------------------------------------------------------------
	// Set Data
	//------------------------------------------------------------------

	/**
	 * 전문길이
	 * @param TR_LN
	 */
	public void setTR_LN(String TR_LN) {
		setData(this.TR_LN, TR_LN,"S");
	}



	/**
	 * 전문종별코드
	 * @param TR_CD
	 */
	public void setTR_CD(String TR_CD) {
		setData(this.TR_CD, TR_CD,"S");
	}



	/**
	 * 거래구분코드
	 * @param TR_TP_CD
	 */
	public void setTR_TP_CD(String TR_TP_CD) {
		setData(this.TR_TP_CD, TR_TP_CD,"S");
	}



	/**
	 * 관리번호
	 * @param LO_NO
	 */
	public void setLO_NO(String LO_NO) {
		setData(this.LO_NO, LO_NO,"S");
	}



	/**
	 * 식별번호
	 * @param TR_SQ
	 */
	public void setTR_SQ(String TR_SQ) {
		setData(this.TR_SQ, TR_SQ,"S");
	}



	/**
	 * 송신일자
	 * @param REQ_DTTM
	 */
	public void setREQ_DTTM(String REQ_DTTM) {
		setData(this.REQ_DTTM, REQ_DTTM,"S");
	}



	/**
	 * 수신일자
	 * @param RES_DTTM
	 */
	public void setRES_DTTM(String RES_DTTM) {
		setData(this.RES_DTTM, RES_DTTM,"S");
	}



	/**
	 * 응답코드
	 * @param RES_CD
	 */
	public void setRES_CD(String RES_CD) {
		setData(this.RES_CD, RES_CD,"S");
	}


	
	/**
	 * 여신승인신청번호
	 * @param APPROVAL_NUM
	 */
	public void setAPPROVAL_NUM(String APPROVAL_NUM) {
		setData(this.APPROVAL_NUM, APPROVAL_NUM,"S");
	}
	


	/**
	 * 상환구분
	 * @param REPAY_TP
	 */
	public void setREPAY_TP(String REPAY_TP) {
		setData(this.REPAY_TP, REPAY_TP,"S");
	}



	/**
	 * 상환 은행코드
	 * @param REPAY_BANK_CD
	 */
	public void setREPAY_BANK_CD(String REPAY_BANK_CD) {
		setData(this.REPAY_BANK_CD, REPAY_BANK_CD,"S");
	}
	


	/**
	 * 상환 금액
	 * @param REPAY_AMOUNT
	 */
	public void setREPAY_AMOUNT(String REPAY_AMOUNT) {
		setData(this.REPAY_AMOUNT, REPAY_AMOUNT,"N");
	}



	/**
	 * 영수증 갯수
	 * @param BILL_CNT
	 */
	public void setBILL_CNT(String BILL_CNT) {
		setData(this.BILL_CNT, BILL_CNT,"N");
	}
	


	/**
	 * 상환 영수증 확인 여부
	 * @param BILL_CHECK_YN
	 */
	public void setBILL_CHECK_YN(String BILL_CHECK_YN) {
		setData(this.BILL_CHECK_YN, BILL_CHECK_YN,"S");
	}
	


	/**
	 * 상환 영수증 이미지 파일명
	 * @param BILL_IMG_FILE_NAME
	 */
	public void setBILL_IMG_FILE_NAME(String BILL_IMG_FILE_NAME) {
		setData(this.BILL_IMG_FILE_NAME, BILL_IMG_FILE_NAME,"K");
	}



	/**
	 * 이미지 키
	 * @param IMG_KEY
	 */
	public void setIMG_KEY(String IMG_KEY) {
		setData(this.IMG_KEY, IMG_KEY,"S");
	}
	


	/**
	 * 예비
	 * @param FILLER
	 */
	public void setFILLER(String FILLER) {
		setData(this.FILLER, FILLER,"S");
	}
}
