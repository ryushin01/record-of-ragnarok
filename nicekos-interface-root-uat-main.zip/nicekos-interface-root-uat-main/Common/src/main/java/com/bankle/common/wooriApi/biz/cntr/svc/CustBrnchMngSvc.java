package com.bankle.common.wooriApi.biz.cntr.svc;

import com.bankle.common.dto.TbCustBrnchMngDto;
import com.bankle.common.entity.TbCustBrnchMng;
import com.bankle.common.mapper.TbCustBrnchMngMapper;
import com.bankle.common.repo.TbCustBrnchMngRepository;
import com.bankle.common.wooriApi.biz.cntr.vo.CustBrnchMngSvo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Slf4j
@Component
@Validated
@RequiredArgsConstructor
public class CustBrnchMngSvc {
    private final ModelMapper modelMapper;

    private final TbCustBrnchMngRepository tbCustBrnchMngRepository;


//    @Transactional
//    public CustBrnchMngSvo.CustBrnchMngOutVo findBrnchInfoByNm(CustBrnchMngSvo.CustBrnchMngInVo inVo) {
//        log.debug("CustBrnchMngSvo.CustBrnchInfo.getBrnchCd() > " + inVo.getBrnchCd());
//        log.debug("CustBrnchMngSvo.CustBrnchInfo.getBrnchNm() > " + inVo.getBrnchNm());
//        String brnchNm = inVo.getBrnchNm();
//        CustBrnchMngSvo.CustBrnchMngOutVo outVo = new CustBrnchMngSvo.CustBrnchMngOutVo();
//        if (StringUtils.hasText(brnchNm)) {
//            List<TbCustBrnchMng> brnchEntityList = tbCustBrnchMngRepository.findAllByBrnchNmContains(brnchNm);
//            List<TbCustBrnchMngDto> brnchDtoList = TbCustBrnchMngMapper.INSTANCE.toDtoList(brnchEntityList);
//            List<CustBrnchMngSvo.CustBrnchInfo> custBrnchInfoList = brnchDtoList.stream()
//                    .map(brnchElement -> modelMapper.map(brnchElement, CustBrnchMngSvo.CustBrnchInfo.class))
//                    .toList();
//            outVo.setCustBrnchInfoList(custBrnchInfoList);
//        }
//        return outVo;
//    }
}
