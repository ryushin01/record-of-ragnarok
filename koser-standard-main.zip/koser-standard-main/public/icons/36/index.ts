import AlertCircleIcon from "./alert-circle-icon36.svg";
import CheckCircleIcon from "./check-circle-icon36.svg";
import CancelIcon from "./cancel-icon36.svg";
import FileAttachmentIcon from "./file-attachment-icon36.svg";
import MenuLeftIcon from "./menu-left-icon36.svg";
import MenuRightIcon from "./menu-right-icon36.svg";

export {
  AlertCircleIcon,
  CheckCircleIcon,
  CancelIcon,
  FileAttachmentIcon,
  MenuLeftIcon,
  MenuRightIcon,
};
