import DefaultProfile from "./default_profile.svg";
import Spinner from "./spinner.svg";

export {
  DefaultProfile,
  Spinner,
};
