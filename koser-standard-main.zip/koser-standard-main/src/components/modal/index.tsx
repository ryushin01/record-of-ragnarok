import Modal from "@components/modal/Modal";
import ModalHeader from "@components/modal/ModalHeader";

export {
  Modal,
  ModalHeader,
};