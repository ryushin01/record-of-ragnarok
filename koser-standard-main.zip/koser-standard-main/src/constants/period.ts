export const PERIOD_LIST = [
  { id: "period-list-1", content: "오늘", days: 0, disabled: false },
  { id: "period-list-2", content: "1주일", days: 7, disabled: false },
  { id: "period-list-3", content: "1개월", days: 30, disabled: false },
];
